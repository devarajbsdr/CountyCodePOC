#pragma once

#if NET_4_0
#include "object-internals.h"

namespace il2cpp
{
namespace icalls
{
namespace System
{
namespace System
{
    class LIBIL2CPP_CODEGEN_API IOSelector
    {
    public:
        static void Add(intptr_t handle, Il2CppObject* job);
        static void Remove(intptr_t handle);
    };
} // namespace System
} // namespace System
} // namespace icalls
} // namespace il2cpp
#endif
