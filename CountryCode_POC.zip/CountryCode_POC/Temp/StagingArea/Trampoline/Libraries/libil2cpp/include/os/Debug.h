#pragma once

namespace il2cpp
{
namespace os
{
    class Debug
    {
    public:
        static bool IsDebuggerPresent();
    };
}
}
