﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// LocationManager
struct LocationManager_t1045714622;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t2760964972;
// System.Collections.IEnumerator
struct IEnumerator_t1608174681;
// UnityEngine.Coroutine
struct Coroutine_t3971565922;
// System.String
struct String_t;
// LocationManager/<GetLocation>c__Iterator0
struct U3CGetLocationU3Ec__Iterator0_t1376318408;
// LocationManager/<UpdateLocation>c__Iterator1
struct U3CUpdateLocationU3Ec__Iterator1_t452027185;
// LocationManager/<CountryFinder>c__Iterator2
struct U3CCountryFinderU3Ec__Iterator2_t1350621332;
// System.Object[]
struct ObjectU5BU5D_t44479575;
// UnityEngine.WWW
struct WWW_t3457365752;
// System.Xml.XmlDocument
struct XmlDocument_t2296465371;
// System.NotSupportedException
struct NotSupportedException_t962022136;
// UnityEngine.WaitForSeconds
struct WaitForSeconds_t3313172267;
// UnityEngine.LocationService
struct LocationService_t3005160692;
// MiniJSON.Json/Parser
struct Parser_t815916342;
// System.IO.StringReader
struct StringReader_t1790093495;
// System.IO.TextReader
struct TextReader_t1750538733;
// System.Collections.Generic.Dictionary`2<System.String,System.Object>
struct Dictionary_2_t1100919678;
// System.Collections.Generic.Dictionary`2<System.Object,System.Object>
struct Dictionary_2_t1240487894;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t2793634595;
// System.Text.StringBuilder
struct StringBuilder_t1854403953;
// System.Char[]
struct CharU5BU5D_t2772155777;
// MiniJSON.Json/Serializer
struct Serializer_t3957605795;
// System.Collections.IList
struct IList_t4241283331;
// System.Collections.IDictionary
struct IDictionary_t1045075095;
// System.Int32[]
struct Int32U5BU5D_t1835834309;
// System.Collections.Generic.Link[]
struct LinkU5BU5D_t3754607161;
// System.String[]
struct StringU5BU5D_t4199878655;
// System.Collections.Generic.IEqualityComparer`1<System.String>
struct IEqualityComparer_1_t4169176023;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t1589905082;
// System.Collections.Generic.Dictionary`2/Transform`1<System.String,System.Object,System.Collections.DictionaryEntry>
struct Transform_1_t2830700390;
// System.Xml.XmlNode/EmptyNodeList
struct EmptyNodeList_t2676474877;
// System.Xml.XmlNodeListChildren
struct XmlNodeListChildren_t3100780127;
// System.Collections.Generic.Dictionary`2<System.String,System.Int32>
struct Dictionary_2_t1245616680;
// System.IDisposable
struct IDisposable_t242102151;
// System.IntPtr[]
struct IntPtrU5BU5D_t1907402426;
// System.Void
struct Void_t289307186;
// System.Byte
struct Byte_t2596701031;
// System.Double
struct Double_t4024153389;
// System.UInt16
struct UInt16_t1912811313;
// System.Type[]
struct TypeU5BU5D_t4189288004;
// System.Xml.XmlNameTable
struct XmlNameTable_t1479426498;
// System.Xml.XmlImplementation
struct XmlImplementation_t3148428848;
// System.Xml.XmlResolver
struct XmlResolver_t1481695800;
// System.Collections.Hashtable
struct Hashtable_t3043587435;
// System.Xml.XmlNameEntryCache
struct XmlNameEntryCache_t3274904478;
// System.Xml.XmlLinkedNode
struct XmlLinkedNode_t2960487756;
// System.Xml.Schema.XmlSchemaSet
struct XmlSchemaSet_t410947004;
// System.Xml.Schema.IXmlSchemaInfo
struct IXmlSchemaInfo_t1034804556;
// System.Xml.XmlNodeChangedEventHandler
struct XmlNodeChangedEventHandler_t3620679463;
// UnityEngine.Networking.UnityWebRequest
struct UnityWebRequest_t916680322;
// UnityEngine.UI.Text
struct Text_t40276147;
// UnityEngine.Material
struct Material_t3291338668;
// UnityEngine.Texture2D
struct Texture2D_t2124686394;
// UnityEngine.RectTransform
struct RectTransform_t3170355171;
// UnityEngine.CanvasRenderer
struct CanvasRenderer_t3614328869;
// UnityEngine.Canvas
struct Canvas_t1472555277;
// UnityEngine.Events.UnityAction
struct UnityAction_t2721498936;
// UnityEngine.Mesh
struct Mesh_t4181844850;
// UnityEngine.UI.VertexHelper
struct VertexHelper_t2100700447;
// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween>
struct TweenRunner_1_t3951980788;
// UnityEngine.UI.RectMask2D
struct RectMask2D_t2940363972;
// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent
struct CullStateChangedEvent_t3112771094;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_t474529388;
// UnityEngine.UI.FontData
struct FontData_t4127961031;
// UnityEngine.TextGenerator
struct TextGenerator_t1782103222;
// UnityEngine.UIVertex[]
struct UIVertexU5BU5D_t388795096;

extern RuntimeClass* U3CGetLocationU3Ec__Iterator0_t1376318408_il2cpp_TypeInfo_var;
extern const uint32_t LocationManager_GetLocation_m2276540142_MetadataUsageId;
extern RuntimeClass* U3CUpdateLocationU3Ec__Iterator1_t452027185_il2cpp_TypeInfo_var;
extern const uint32_t LocationManager_UpdateLocation_m1247828680_MetadataUsageId;
extern RuntimeClass* U3CCountryFinderU3Ec__Iterator2_t1350621332_il2cpp_TypeInfo_var;
extern const uint32_t LocationManager_CountryFinder_m684489686_MetadataUsageId;
extern RuntimeClass* ObjectU5BU5D_t44479575_il2cpp_TypeInfo_var;
extern RuntimeClass* Single_t2594644343_il2cpp_TypeInfo_var;
extern RuntimeClass* String_t_il2cpp_TypeInfo_var;
extern RuntimeClass* WWW_t3457365752_il2cpp_TypeInfo_var;
extern RuntimeClass* XmlDocument_t2296465371_il2cpp_TypeInfo_var;
extern RuntimeClass* IEnumerator_t1608174681_il2cpp_TypeInfo_var;
extern RuntimeClass* XmlNode_t482051342_il2cpp_TypeInfo_var;
extern RuntimeClass* IDisposable_t242102151_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1369038755;
extern Il2CppCodeGenString* _stringLiteral1045399521;
extern Il2CppCodeGenString* _stringLiteral626003391;
extern Il2CppCodeGenString* _stringLiteral1627105707;
extern Il2CppCodeGenString* _stringLiteral1186754903;
extern Il2CppCodeGenString* _stringLiteral2421942445;
extern Il2CppCodeGenString* _stringLiteral2310387594;
extern Il2CppCodeGenString* _stringLiteral157952551;
extern Il2CppCodeGenString* _stringLiteral4195199491;
extern Il2CppCodeGenString* _stringLiteral70094325;
extern const uint32_t U3CCountryFinderU3Ec__Iterator2_MoveNext_m1722769358_MetadataUsageId;
extern RuntimeClass* NotSupportedException_t962022136_il2cpp_TypeInfo_var;
extern const uint32_t U3CCountryFinderU3Ec__Iterator2_Reset_m1333130095_MetadataUsageId;
extern RuntimeClass* WaitForSeconds_t3313172267_il2cpp_TypeInfo_var;
extern RuntimeClass* IDictionary_t1045075095_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral155016173;
extern Il2CppCodeGenString* _stringLiteral996512338;
extern Il2CppCodeGenString* _stringLiteral921067844;
extern Il2CppCodeGenString* _stringLiteral1676475345;
extern const uint32_t U3CGetLocationU3Ec__Iterator0_MoveNext_m1190961499_MetadataUsageId;
extern const uint32_t U3CGetLocationU3Ec__Iterator0_Reset_m1280529886_MetadataUsageId;
extern RuntimeClass* Input_t3034106849_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1338811556;
extern Il2CppCodeGenString* _stringLiteral2855806562;
extern Il2CppCodeGenString* _stringLiteral2753920706;
extern Il2CppCodeGenString* _stringLiteral2613751440;
extern const uint32_t U3CUpdateLocationU3Ec__Iterator1_MoveNext_m26832617_MetadataUsageId;
extern const uint32_t U3CUpdateLocationU3Ec__Iterator1_Reset_m3119857850_MetadataUsageId;
extern RuntimeClass* StringReader_t1790093495_il2cpp_TypeInfo_var;
extern const uint32_t Parser__ctor_m3660599834_MetadataUsageId;
extern RuntimeClass* Char_t4123521152_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral838919514;
extern const uint32_t Parser_IsWordBreak_m674601368_MetadataUsageId;
extern RuntimeClass* Parser_t815916342_il2cpp_TypeInfo_var;
extern const uint32_t Parser_Parse_m3352628348_MetadataUsageId;
extern RuntimeClass* Dictionary_2_t1100919678_il2cpp_TypeInfo_var;
extern const RuntimeMethod* Dictionary_2__ctor_m2414048597_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m831255642_RuntimeMethod_var;
extern const uint32_t Parser_ParseObject_m397767350_MetadataUsageId;
extern RuntimeClass* List_1_t2793634595_il2cpp_TypeInfo_var;
extern const RuntimeMethod* List_1__ctor_m663654418_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_m3949004397_RuntimeMethod_var;
extern const uint32_t Parser_ParseArray_m3427778883_MetadataUsageId;
extern RuntimeClass* Boolean_t2724601657_il2cpp_TypeInfo_var;
extern const uint32_t Parser_ParseByToken_m3441831680_MetadataUsageId;
extern RuntimeClass* StringBuilder_t1854403953_il2cpp_TypeInfo_var;
extern RuntimeClass* CharU5BU5D_t2772155777_il2cpp_TypeInfo_var;
extern RuntimeClass* Convert_t708193928_il2cpp_TypeInfo_var;
extern const uint32_t Parser_ParseString_m333155029_MetadataUsageId;
extern RuntimeClass* Int64_t2942533987_il2cpp_TypeInfo_var;
extern RuntimeClass* Double_t4024153389_il2cpp_TypeInfo_var;
extern const uint32_t Parser_ParseNumber_m2705113073_MetadataUsageId;
extern const uint32_t Parser_EatWhitespace_m4203669877_MetadataUsageId;
extern const uint32_t Parser_get_PeekChar_m3819133206_MetadataUsageId;
extern const uint32_t Parser_get_NextChar_m1876461300_MetadataUsageId;
extern const uint32_t Parser_get_NextWord_m2710760689_MetadataUsageId;
extern Il2CppCodeGenString* _stringLiteral391856821;
extern Il2CppCodeGenString* _stringLiteral1400893542;
extern Il2CppCodeGenString* _stringLiteral3159482552;
extern const uint32_t Parser_get_NextToken_m1111924718_MetadataUsageId;
extern const uint32_t Serializer__ctor_m1021995128_MetadataUsageId;
extern RuntimeClass* Serializer_t3957605795_il2cpp_TypeInfo_var;
extern const uint32_t Serializer_Serialize_m2381363365_MetadataUsageId;
extern RuntimeClass* IList_t4241283331_il2cpp_TypeInfo_var;
extern const uint32_t Serializer_SerializeValue_m766562738_MetadataUsageId;
extern RuntimeClass* IEnumerable_t3475459086_il2cpp_TypeInfo_var;
extern const uint32_t Serializer_SerializeObject_m4019526216_MetadataUsageId;
extern const uint32_t Serializer_SerializeArray_m3445866376_MetadataUsageId;
extern Il2CppCodeGenString* _stringLiteral2496710397;
extern Il2CppCodeGenString* _stringLiteral240939506;
extern Il2CppCodeGenString* _stringLiteral4173735437;
extern Il2CppCodeGenString* _stringLiteral1743058948;
extern Il2CppCodeGenString* _stringLiteral2178147880;
extern Il2CppCodeGenString* _stringLiteral3184689943;
extern Il2CppCodeGenString* _stringLiteral2198487847;
extern Il2CppCodeGenString* _stringLiteral54292398;
extern Il2CppCodeGenString* _stringLiteral284050032;
extern const uint32_t Serializer_SerializeString_m1354220936_MetadataUsageId;
extern RuntimeClass* Int32_t2946131084_il2cpp_TypeInfo_var;
extern RuntimeClass* UInt32_t1505113534_il2cpp_TypeInfo_var;
extern RuntimeClass* SByte_t669469354_il2cpp_TypeInfo_var;
extern RuntimeClass* Byte_t2596701031_il2cpp_TypeInfo_var;
extern RuntimeClass* Int16_t612759502_il2cpp_TypeInfo_var;
extern RuntimeClass* UInt16_t1912811313_il2cpp_TypeInfo_var;
extern RuntimeClass* UInt64_t4149917651_il2cpp_TypeInfo_var;
extern RuntimeClass* Decimal_t3889304405_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral247565077;
extern const uint32_t Serializer_SerializeOther_m1072816231_MetadataUsageId;

struct ObjectU5BU5D_t44479575;
struct CharU5BU5D_t2772155777;


#ifndef U3CMODULEU3E_T2709092496_H
#define U3CMODULEU3E_T2709092496_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t2709092496 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T2709092496_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
struct Il2CppArrayBounds;
#ifndef RUNTIMEARRAY_H
#define RUNTIMEARRAY_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Array

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEARRAY_H
#ifndef TEXTREADER_T1750538733_H
#define TEXTREADER_T1750538733_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.TextReader
struct  TextReader_t1750538733  : public RuntimeObject
{
public:

public:
};

struct TextReader_t1750538733_StaticFields
{
public:
	// System.IO.TextReader System.IO.TextReader::Null
	TextReader_t1750538733 * ___Null_0;

public:
	inline static int32_t get_offset_of_Null_0() { return static_cast<int32_t>(offsetof(TextReader_t1750538733_StaticFields, ___Null_0)); }
	inline TextReader_t1750538733 * get_Null_0() const { return ___Null_0; }
	inline TextReader_t1750538733 ** get_address_of_Null_0() { return &___Null_0; }
	inline void set_Null_0(TextReader_t1750538733 * value)
	{
		___Null_0 = value;
		Il2CppCodeGenWriteBarrier((&___Null_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTREADER_T1750538733_H
#ifndef STRINGBUILDER_T1854403953_H
#define STRINGBUILDER_T1854403953_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.StringBuilder
struct  StringBuilder_t1854403953  : public RuntimeObject
{
public:
	// System.Int32 System.Text.StringBuilder::_length
	int32_t ____length_1;
	// System.String System.Text.StringBuilder::_str
	String_t* ____str_2;
	// System.String System.Text.StringBuilder::_cached_str
	String_t* ____cached_str_3;
	// System.Int32 System.Text.StringBuilder::_maxCapacity
	int32_t ____maxCapacity_4;

public:
	inline static int32_t get_offset_of__length_1() { return static_cast<int32_t>(offsetof(StringBuilder_t1854403953, ____length_1)); }
	inline int32_t get__length_1() const { return ____length_1; }
	inline int32_t* get_address_of__length_1() { return &____length_1; }
	inline void set__length_1(int32_t value)
	{
		____length_1 = value;
	}

	inline static int32_t get_offset_of__str_2() { return static_cast<int32_t>(offsetof(StringBuilder_t1854403953, ____str_2)); }
	inline String_t* get__str_2() const { return ____str_2; }
	inline String_t** get_address_of__str_2() { return &____str_2; }
	inline void set__str_2(String_t* value)
	{
		____str_2 = value;
		Il2CppCodeGenWriteBarrier((&____str_2), value);
	}

	inline static int32_t get_offset_of__cached_str_3() { return static_cast<int32_t>(offsetof(StringBuilder_t1854403953, ____cached_str_3)); }
	inline String_t* get__cached_str_3() const { return ____cached_str_3; }
	inline String_t** get_address_of__cached_str_3() { return &____cached_str_3; }
	inline void set__cached_str_3(String_t* value)
	{
		____cached_str_3 = value;
		Il2CppCodeGenWriteBarrier((&____cached_str_3), value);
	}

	inline static int32_t get_offset_of__maxCapacity_4() { return static_cast<int32_t>(offsetof(StringBuilder_t1854403953, ____maxCapacity_4)); }
	inline int32_t get__maxCapacity_4() const { return ____maxCapacity_4; }
	inline int32_t* get_address_of__maxCapacity_4() { return &____maxCapacity_4; }
	inline void set__maxCapacity_4(int32_t value)
	{
		____maxCapacity_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGBUILDER_T1854403953_H
#ifndef PARSER_T815916342_H
#define PARSER_T815916342_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MiniJSON.Json/Parser
struct  Parser_t815916342  : public RuntimeObject
{
public:
	// System.IO.StringReader MiniJSON.Json/Parser::json
	StringReader_t1790093495 * ___json_1;

public:
	inline static int32_t get_offset_of_json_1() { return static_cast<int32_t>(offsetof(Parser_t815916342, ___json_1)); }
	inline StringReader_t1790093495 * get_json_1() const { return ___json_1; }
	inline StringReader_t1790093495 ** get_address_of_json_1() { return &___json_1; }
	inline void set_json_1(StringReader_t1790093495 * value)
	{
		___json_1 = value;
		Il2CppCodeGenWriteBarrier((&___json_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARSER_T815916342_H
#ifndef JSON_T2765388798_H
#define JSON_T2765388798_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MiniJSON.Json
struct  Json_t2765388798  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // JSON_T2765388798_H
#ifndef LOCATIONSERVICE_T3005160692_H
#define LOCATIONSERVICE_T3005160692_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LocationService
struct  LocationService_t3005160692  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCATIONSERVICE_T3005160692_H
#ifndef SERIALIZER_T3957605795_H
#define SERIALIZER_T3957605795_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MiniJSON.Json/Serializer
struct  Serializer_t3957605795  : public RuntimeObject
{
public:
	// System.Text.StringBuilder MiniJSON.Json/Serializer::builder
	StringBuilder_t1854403953 * ___builder_0;

public:
	inline static int32_t get_offset_of_builder_0() { return static_cast<int32_t>(offsetof(Serializer_t3957605795, ___builder_0)); }
	inline StringBuilder_t1854403953 * get_builder_0() const { return ___builder_0; }
	inline StringBuilder_t1854403953 ** get_address_of_builder_0() { return &___builder_0; }
	inline void set_builder_0(StringBuilder_t1854403953 * value)
	{
		___builder_0 = value;
		Il2CppCodeGenWriteBarrier((&___builder_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERIALIZER_T3957605795_H
#ifndef XMLNODELIST_T1166152358_H
#define XMLNODELIST_T1166152358_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlNodeList
struct  XmlNodeList_t1166152358  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLNODELIST_T1166152358_H
#ifndef DICTIONARY_2_T1100919678_H
#define DICTIONARY_2_T1100919678_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,System.Object>
struct  Dictionary_2_t1100919678  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::table
	Int32U5BU5D_t1835834309* ___table_4;
	// System.Collections.Generic.Link[] System.Collections.Generic.Dictionary`2::linkSlots
	LinkU5BU5D_t3754607161* ___linkSlots_5;
	// TKey[] System.Collections.Generic.Dictionary`2::keySlots
	StringU5BU5D_t4199878655* ___keySlots_6;
	// TValue[] System.Collections.Generic.Dictionary`2::valueSlots
	ObjectU5BU5D_t44479575* ___valueSlots_7;
	// System.Int32 System.Collections.Generic.Dictionary`2::touchedSlots
	int32_t ___touchedSlots_8;
	// System.Int32 System.Collections.Generic.Dictionary`2::emptySlot
	int32_t ___emptySlot_9;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_10;
	// System.Int32 System.Collections.Generic.Dictionary`2::threshold
	int32_t ___threshold_11;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::hcp
	RuntimeObject* ___hcp_12;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.Dictionary`2::serialization_info
	SerializationInfo_t1589905082 * ___serialization_info_13;
	// System.Int32 System.Collections.Generic.Dictionary`2::generation
	int32_t ___generation_14;

public:
	inline static int32_t get_offset_of_table_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___table_4)); }
	inline Int32U5BU5D_t1835834309* get_table_4() const { return ___table_4; }
	inline Int32U5BU5D_t1835834309** get_address_of_table_4() { return &___table_4; }
	inline void set_table_4(Int32U5BU5D_t1835834309* value)
	{
		___table_4 = value;
		Il2CppCodeGenWriteBarrier((&___table_4), value);
	}

	inline static int32_t get_offset_of_linkSlots_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___linkSlots_5)); }
	inline LinkU5BU5D_t3754607161* get_linkSlots_5() const { return ___linkSlots_5; }
	inline LinkU5BU5D_t3754607161** get_address_of_linkSlots_5() { return &___linkSlots_5; }
	inline void set_linkSlots_5(LinkU5BU5D_t3754607161* value)
	{
		___linkSlots_5 = value;
		Il2CppCodeGenWriteBarrier((&___linkSlots_5), value);
	}

	inline static int32_t get_offset_of_keySlots_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___keySlots_6)); }
	inline StringU5BU5D_t4199878655* get_keySlots_6() const { return ___keySlots_6; }
	inline StringU5BU5D_t4199878655** get_address_of_keySlots_6() { return &___keySlots_6; }
	inline void set_keySlots_6(StringU5BU5D_t4199878655* value)
	{
		___keySlots_6 = value;
		Il2CppCodeGenWriteBarrier((&___keySlots_6), value);
	}

	inline static int32_t get_offset_of_valueSlots_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___valueSlots_7)); }
	inline ObjectU5BU5D_t44479575* get_valueSlots_7() const { return ___valueSlots_7; }
	inline ObjectU5BU5D_t44479575** get_address_of_valueSlots_7() { return &___valueSlots_7; }
	inline void set_valueSlots_7(ObjectU5BU5D_t44479575* value)
	{
		___valueSlots_7 = value;
		Il2CppCodeGenWriteBarrier((&___valueSlots_7), value);
	}

	inline static int32_t get_offset_of_touchedSlots_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___touchedSlots_8)); }
	inline int32_t get_touchedSlots_8() const { return ___touchedSlots_8; }
	inline int32_t* get_address_of_touchedSlots_8() { return &___touchedSlots_8; }
	inline void set_touchedSlots_8(int32_t value)
	{
		___touchedSlots_8 = value;
	}

	inline static int32_t get_offset_of_emptySlot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___emptySlot_9)); }
	inline int32_t get_emptySlot_9() const { return ___emptySlot_9; }
	inline int32_t* get_address_of_emptySlot_9() { return &___emptySlot_9; }
	inline void set_emptySlot_9(int32_t value)
	{
		___emptySlot_9 = value;
	}

	inline static int32_t get_offset_of_count_10() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___count_10)); }
	inline int32_t get_count_10() const { return ___count_10; }
	inline int32_t* get_address_of_count_10() { return &___count_10; }
	inline void set_count_10(int32_t value)
	{
		___count_10 = value;
	}

	inline static int32_t get_offset_of_threshold_11() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___threshold_11)); }
	inline int32_t get_threshold_11() const { return ___threshold_11; }
	inline int32_t* get_address_of_threshold_11() { return &___threshold_11; }
	inline void set_threshold_11(int32_t value)
	{
		___threshold_11 = value;
	}

	inline static int32_t get_offset_of_hcp_12() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___hcp_12)); }
	inline RuntimeObject* get_hcp_12() const { return ___hcp_12; }
	inline RuntimeObject** get_address_of_hcp_12() { return &___hcp_12; }
	inline void set_hcp_12(RuntimeObject* value)
	{
		___hcp_12 = value;
		Il2CppCodeGenWriteBarrier((&___hcp_12), value);
	}

	inline static int32_t get_offset_of_serialization_info_13() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___serialization_info_13)); }
	inline SerializationInfo_t1589905082 * get_serialization_info_13() const { return ___serialization_info_13; }
	inline SerializationInfo_t1589905082 ** get_address_of_serialization_info_13() { return &___serialization_info_13; }
	inline void set_serialization_info_13(SerializationInfo_t1589905082 * value)
	{
		___serialization_info_13 = value;
		Il2CppCodeGenWriteBarrier((&___serialization_info_13), value);
	}

	inline static int32_t get_offset_of_generation_14() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678, ___generation_14)); }
	inline int32_t get_generation_14() const { return ___generation_14; }
	inline int32_t* get_address_of_generation_14() { return &___generation_14; }
	inline void set_generation_14(int32_t value)
	{
		___generation_14 = value;
	}
};

struct Dictionary_2_t1100919678_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2/Transform`1<TKey,TValue,System.Collections.DictionaryEntry> System.Collections.Generic.Dictionary`2::<>f__am$cacheB
	Transform_1_t2830700390 * ___U3CU3Ef__amU24cacheB_15;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cacheB_15() { return static_cast<int32_t>(offsetof(Dictionary_2_t1100919678_StaticFields, ___U3CU3Ef__amU24cacheB_15)); }
	inline Transform_1_t2830700390 * get_U3CU3Ef__amU24cacheB_15() const { return ___U3CU3Ef__amU24cacheB_15; }
	inline Transform_1_t2830700390 ** get_address_of_U3CU3Ef__amU24cacheB_15() { return &___U3CU3Ef__amU24cacheB_15; }
	inline void set_U3CU3Ef__amU24cacheB_15(Transform_1_t2830700390 * value)
	{
		___U3CU3Ef__amU24cacheB_15 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cacheB_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T1100919678_H
#ifndef VALUETYPE_T995865391_H
#define VALUETYPE_T995865391_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t995865391  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t995865391_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t995865391_marshaled_com
{
};
#endif // VALUETYPE_T995865391_H
#ifndef XMLNODE_T482051342_H
#define XMLNODE_T482051342_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlNode
struct  XmlNode_t482051342  : public RuntimeObject
{
public:
	// System.Xml.XmlDocument System.Xml.XmlNode::ownerDocument
	XmlDocument_t2296465371 * ___ownerDocument_1;
	// System.Xml.XmlNode System.Xml.XmlNode::parentNode
	XmlNode_t482051342 * ___parentNode_2;
	// System.Xml.XmlNodeListChildren System.Xml.XmlNode::childNodes
	XmlNodeListChildren_t3100780127 * ___childNodes_3;

public:
	inline static int32_t get_offset_of_ownerDocument_1() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___ownerDocument_1)); }
	inline XmlDocument_t2296465371 * get_ownerDocument_1() const { return ___ownerDocument_1; }
	inline XmlDocument_t2296465371 ** get_address_of_ownerDocument_1() { return &___ownerDocument_1; }
	inline void set_ownerDocument_1(XmlDocument_t2296465371 * value)
	{
		___ownerDocument_1 = value;
		Il2CppCodeGenWriteBarrier((&___ownerDocument_1), value);
	}

	inline static int32_t get_offset_of_parentNode_2() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___parentNode_2)); }
	inline XmlNode_t482051342 * get_parentNode_2() const { return ___parentNode_2; }
	inline XmlNode_t482051342 ** get_address_of_parentNode_2() { return &___parentNode_2; }
	inline void set_parentNode_2(XmlNode_t482051342 * value)
	{
		___parentNode_2 = value;
		Il2CppCodeGenWriteBarrier((&___parentNode_2), value);
	}

	inline static int32_t get_offset_of_childNodes_3() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___childNodes_3)); }
	inline XmlNodeListChildren_t3100780127 * get_childNodes_3() const { return ___childNodes_3; }
	inline XmlNodeListChildren_t3100780127 ** get_address_of_childNodes_3() { return &___childNodes_3; }
	inline void set_childNodes_3(XmlNodeListChildren_t3100780127 * value)
	{
		___childNodes_3 = value;
		Il2CppCodeGenWriteBarrier((&___childNodes_3), value);
	}
};

struct XmlNode_t482051342_StaticFields
{
public:
	// System.Xml.XmlNode/EmptyNodeList System.Xml.XmlNode::emptyList
	EmptyNodeList_t2676474877 * ___emptyList_0;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.XmlNode::<>f__switch$map44
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map44_4;

public:
	inline static int32_t get_offset_of_emptyList_0() { return static_cast<int32_t>(offsetof(XmlNode_t482051342_StaticFields, ___emptyList_0)); }
	inline EmptyNodeList_t2676474877 * get_emptyList_0() const { return ___emptyList_0; }
	inline EmptyNodeList_t2676474877 ** get_address_of_emptyList_0() { return &___emptyList_0; }
	inline void set_emptyList_0(EmptyNodeList_t2676474877 * value)
	{
		___emptyList_0 = value;
		Il2CppCodeGenWriteBarrier((&___emptyList_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map44_4() { return static_cast<int32_t>(offsetof(XmlNode_t482051342_StaticFields, ___U3CU3Ef__switchU24map44_4)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map44_4() const { return ___U3CU3Ef__switchU24map44_4; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map44_4() { return &___U3CU3Ef__switchU24map44_4; }
	inline void set_U3CU3Ef__switchU24map44_4(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map44_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map44_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLNODE_T482051342_H
#ifndef LIST_1_T2793634595_H
#define LIST_1_T2793634595_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<System.Object>
struct  List_1_t2793634595  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_t44479575* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t2793634595, ____items_1)); }
	inline ObjectU5BU5D_t44479575* get__items_1() const { return ____items_1; }
	inline ObjectU5BU5D_t44479575** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ObjectU5BU5D_t44479575* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t2793634595, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t2793634595, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t2793634595_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	ObjectU5BU5D_t44479575* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t2793634595_StaticFields, ___EmptyArray_4)); }
	inline ObjectU5BU5D_t44479575* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline ObjectU5BU5D_t44479575** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(ObjectU5BU5D_t44479575* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T2793634595_H
#ifndef U3CGETLOCATIONU3EC__ITERATOR0_T1376318408_H
#define U3CGETLOCATIONU3EC__ITERATOR0_T1376318408_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LocationManager/<GetLocation>c__Iterator0
struct  U3CGetLocationU3Ec__Iterator0_t1376318408  : public RuntimeObject
{
public:
	// UnityEngine.WWW LocationManager/<GetLocation>c__Iterator0::<www>__0
	WWW_t3457365752 * ___U3CwwwU3E__0_0;
	// System.Collections.IDictionary LocationManager/<GetLocation>c__Iterator0::<locInfo>__0
	RuntimeObject* ___U3ClocInfoU3E__0_1;
	// LocationManager LocationManager/<GetLocation>c__Iterator0::$this
	LocationManager_t1045714622 * ___U24this_2;
	// System.Object LocationManager/<GetLocation>c__Iterator0::$current
	RuntimeObject * ___U24current_3;
	// System.Boolean LocationManager/<GetLocation>c__Iterator0::$disposing
	bool ___U24disposing_4;
	// System.Int32 LocationManager/<GetLocation>c__Iterator0::$PC
	int32_t ___U24PC_5;

public:
	inline static int32_t get_offset_of_U3CwwwU3E__0_0() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U3CwwwU3E__0_0)); }
	inline WWW_t3457365752 * get_U3CwwwU3E__0_0() const { return ___U3CwwwU3E__0_0; }
	inline WWW_t3457365752 ** get_address_of_U3CwwwU3E__0_0() { return &___U3CwwwU3E__0_0; }
	inline void set_U3CwwwU3E__0_0(WWW_t3457365752 * value)
	{
		___U3CwwwU3E__0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CwwwU3E__0_0), value);
	}

	inline static int32_t get_offset_of_U3ClocInfoU3E__0_1() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U3ClocInfoU3E__0_1)); }
	inline RuntimeObject* get_U3ClocInfoU3E__0_1() const { return ___U3ClocInfoU3E__0_1; }
	inline RuntimeObject** get_address_of_U3ClocInfoU3E__0_1() { return &___U3ClocInfoU3E__0_1; }
	inline void set_U3ClocInfoU3E__0_1(RuntimeObject* value)
	{
		___U3ClocInfoU3E__0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3ClocInfoU3E__0_1), value);
	}

	inline static int32_t get_offset_of_U24this_2() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U24this_2)); }
	inline LocationManager_t1045714622 * get_U24this_2() const { return ___U24this_2; }
	inline LocationManager_t1045714622 ** get_address_of_U24this_2() { return &___U24this_2; }
	inline void set_U24this_2(LocationManager_t1045714622 * value)
	{
		___U24this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_2), value);
	}

	inline static int32_t get_offset_of_U24current_3() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U24current_3)); }
	inline RuntimeObject * get_U24current_3() const { return ___U24current_3; }
	inline RuntimeObject ** get_address_of_U24current_3() { return &___U24current_3; }
	inline void set_U24current_3(RuntimeObject * value)
	{
		___U24current_3 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_3), value);
	}

	inline static int32_t get_offset_of_U24disposing_4() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U24disposing_4)); }
	inline bool get_U24disposing_4() const { return ___U24disposing_4; }
	inline bool* get_address_of_U24disposing_4() { return &___U24disposing_4; }
	inline void set_U24disposing_4(bool value)
	{
		___U24disposing_4 = value;
	}

	inline static int32_t get_offset_of_U24PC_5() { return static_cast<int32_t>(offsetof(U3CGetLocationU3Ec__Iterator0_t1376318408, ___U24PC_5)); }
	inline int32_t get_U24PC_5() const { return ___U24PC_5; }
	inline int32_t* get_address_of_U24PC_5() { return &___U24PC_5; }
	inline void set_U24PC_5(int32_t value)
	{
		___U24PC_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CGETLOCATIONU3EC__ITERATOR0_T1376318408_H
#ifndef U3CCOUNTRYFINDERU3EC__ITERATOR2_T1350621332_H
#define U3CCOUNTRYFINDERU3EC__ITERATOR2_T1350621332_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LocationManager/<CountryFinder>c__Iterator2
struct  U3CCountryFinderU3Ec__Iterator2_t1350621332  : public RuntimeObject
{
public:
	// UnityEngine.WWW LocationManager/<CountryFinder>c__Iterator2::<www>__0
	WWW_t3457365752 * ___U3CwwwU3E__0_0;
	// System.Xml.XmlDocument LocationManager/<CountryFinder>c__Iterator2::<reverseGeocodeResult>__0
	XmlDocument_t2296465371 * ___U3CreverseGeocodeResultU3E__0_1;
	// System.String LocationManager/<CountryFinder>c__Iterator2::<countryCode>__0
	String_t* ___U3CcountryCodeU3E__0_2;
	// System.Boolean LocationManager/<CountryFinder>c__Iterator2::<countryFound>__0
	bool ___U3CcountryFoundU3E__0_3;
	// System.Collections.IEnumerator LocationManager/<CountryFinder>c__Iterator2::$locvar0
	RuntimeObject* ___U24locvar0_4;
	// System.IDisposable LocationManager/<CountryFinder>c__Iterator2::$locvar1
	RuntimeObject* ___U24locvar1_5;
	// LocationManager LocationManager/<CountryFinder>c__Iterator2::$this
	LocationManager_t1045714622 * ___U24this_6;
	// System.Object LocationManager/<CountryFinder>c__Iterator2::$current
	RuntimeObject * ___U24current_7;
	// System.Boolean LocationManager/<CountryFinder>c__Iterator2::$disposing
	bool ___U24disposing_8;
	// System.Int32 LocationManager/<CountryFinder>c__Iterator2::$PC
	int32_t ___U24PC_9;

public:
	inline static int32_t get_offset_of_U3CwwwU3E__0_0() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U3CwwwU3E__0_0)); }
	inline WWW_t3457365752 * get_U3CwwwU3E__0_0() const { return ___U3CwwwU3E__0_0; }
	inline WWW_t3457365752 ** get_address_of_U3CwwwU3E__0_0() { return &___U3CwwwU3E__0_0; }
	inline void set_U3CwwwU3E__0_0(WWW_t3457365752 * value)
	{
		___U3CwwwU3E__0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CwwwU3E__0_0), value);
	}

	inline static int32_t get_offset_of_U3CreverseGeocodeResultU3E__0_1() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U3CreverseGeocodeResultU3E__0_1)); }
	inline XmlDocument_t2296465371 * get_U3CreverseGeocodeResultU3E__0_1() const { return ___U3CreverseGeocodeResultU3E__0_1; }
	inline XmlDocument_t2296465371 ** get_address_of_U3CreverseGeocodeResultU3E__0_1() { return &___U3CreverseGeocodeResultU3E__0_1; }
	inline void set_U3CreverseGeocodeResultU3E__0_1(XmlDocument_t2296465371 * value)
	{
		___U3CreverseGeocodeResultU3E__0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CreverseGeocodeResultU3E__0_1), value);
	}

	inline static int32_t get_offset_of_U3CcountryCodeU3E__0_2() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U3CcountryCodeU3E__0_2)); }
	inline String_t* get_U3CcountryCodeU3E__0_2() const { return ___U3CcountryCodeU3E__0_2; }
	inline String_t** get_address_of_U3CcountryCodeU3E__0_2() { return &___U3CcountryCodeU3E__0_2; }
	inline void set_U3CcountryCodeU3E__0_2(String_t* value)
	{
		___U3CcountryCodeU3E__0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CcountryCodeU3E__0_2), value);
	}

	inline static int32_t get_offset_of_U3CcountryFoundU3E__0_3() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U3CcountryFoundU3E__0_3)); }
	inline bool get_U3CcountryFoundU3E__0_3() const { return ___U3CcountryFoundU3E__0_3; }
	inline bool* get_address_of_U3CcountryFoundU3E__0_3() { return &___U3CcountryFoundU3E__0_3; }
	inline void set_U3CcountryFoundU3E__0_3(bool value)
	{
		___U3CcountryFoundU3E__0_3 = value;
	}

	inline static int32_t get_offset_of_U24locvar0_4() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24locvar0_4)); }
	inline RuntimeObject* get_U24locvar0_4() const { return ___U24locvar0_4; }
	inline RuntimeObject** get_address_of_U24locvar0_4() { return &___U24locvar0_4; }
	inline void set_U24locvar0_4(RuntimeObject* value)
	{
		___U24locvar0_4 = value;
		Il2CppCodeGenWriteBarrier((&___U24locvar0_4), value);
	}

	inline static int32_t get_offset_of_U24locvar1_5() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24locvar1_5)); }
	inline RuntimeObject* get_U24locvar1_5() const { return ___U24locvar1_5; }
	inline RuntimeObject** get_address_of_U24locvar1_5() { return &___U24locvar1_5; }
	inline void set_U24locvar1_5(RuntimeObject* value)
	{
		___U24locvar1_5 = value;
		Il2CppCodeGenWriteBarrier((&___U24locvar1_5), value);
	}

	inline static int32_t get_offset_of_U24this_6() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24this_6)); }
	inline LocationManager_t1045714622 * get_U24this_6() const { return ___U24this_6; }
	inline LocationManager_t1045714622 ** get_address_of_U24this_6() { return &___U24this_6; }
	inline void set_U24this_6(LocationManager_t1045714622 * value)
	{
		___U24this_6 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_6), value);
	}

	inline static int32_t get_offset_of_U24current_7() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24current_7)); }
	inline RuntimeObject * get_U24current_7() const { return ___U24current_7; }
	inline RuntimeObject ** get_address_of_U24current_7() { return &___U24current_7; }
	inline void set_U24current_7(RuntimeObject * value)
	{
		___U24current_7 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_7), value);
	}

	inline static int32_t get_offset_of_U24disposing_8() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24disposing_8)); }
	inline bool get_U24disposing_8() const { return ___U24disposing_8; }
	inline bool* get_address_of_U24disposing_8() { return &___U24disposing_8; }
	inline void set_U24disposing_8(bool value)
	{
		___U24disposing_8 = value;
	}

	inline static int32_t get_offset_of_U24PC_9() { return static_cast<int32_t>(offsetof(U3CCountryFinderU3Ec__Iterator2_t1350621332, ___U24PC_9)); }
	inline int32_t get_U24PC_9() const { return ___U24PC_9; }
	inline int32_t* get_address_of_U24PC_9() { return &___U24PC_9; }
	inline void set_U24PC_9(int32_t value)
	{
		___U24PC_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOUNTRYFINDERU3EC__ITERATOR2_T1350621332_H
#ifndef EXCEPTION_T3056413322_H
#define EXCEPTION_T3056413322_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t3056413322  : public RuntimeObject
{
public:
	// System.IntPtr[] System.Exception::trace_ips
	IntPtrU5BU5D_t1907402426* ___trace_ips_0;
	// System.Exception System.Exception::inner_exception
	Exception_t3056413322 * ___inner_exception_1;
	// System.String System.Exception::message
	String_t* ___message_2;
	// System.String System.Exception::help_link
	String_t* ___help_link_3;
	// System.String System.Exception::class_name
	String_t* ___class_name_4;
	// System.String System.Exception::stack_trace
	String_t* ___stack_trace_5;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_6;
	// System.Int32 System.Exception::remote_stack_index
	int32_t ___remote_stack_index_7;
	// System.Int32 System.Exception::hresult
	int32_t ___hresult_8;
	// System.String System.Exception::source
	String_t* ___source_9;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_10;

public:
	inline static int32_t get_offset_of_trace_ips_0() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___trace_ips_0)); }
	inline IntPtrU5BU5D_t1907402426* get_trace_ips_0() const { return ___trace_ips_0; }
	inline IntPtrU5BU5D_t1907402426** get_address_of_trace_ips_0() { return &___trace_ips_0; }
	inline void set_trace_ips_0(IntPtrU5BU5D_t1907402426* value)
	{
		___trace_ips_0 = value;
		Il2CppCodeGenWriteBarrier((&___trace_ips_0), value);
	}

	inline static int32_t get_offset_of_inner_exception_1() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___inner_exception_1)); }
	inline Exception_t3056413322 * get_inner_exception_1() const { return ___inner_exception_1; }
	inline Exception_t3056413322 ** get_address_of_inner_exception_1() { return &___inner_exception_1; }
	inline void set_inner_exception_1(Exception_t3056413322 * value)
	{
		___inner_exception_1 = value;
		Il2CppCodeGenWriteBarrier((&___inner_exception_1), value);
	}

	inline static int32_t get_offset_of_message_2() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___message_2)); }
	inline String_t* get_message_2() const { return ___message_2; }
	inline String_t** get_address_of_message_2() { return &___message_2; }
	inline void set_message_2(String_t* value)
	{
		___message_2 = value;
		Il2CppCodeGenWriteBarrier((&___message_2), value);
	}

	inline static int32_t get_offset_of_help_link_3() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___help_link_3)); }
	inline String_t* get_help_link_3() const { return ___help_link_3; }
	inline String_t** get_address_of_help_link_3() { return &___help_link_3; }
	inline void set_help_link_3(String_t* value)
	{
		___help_link_3 = value;
		Il2CppCodeGenWriteBarrier((&___help_link_3), value);
	}

	inline static int32_t get_offset_of_class_name_4() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___class_name_4)); }
	inline String_t* get_class_name_4() const { return ___class_name_4; }
	inline String_t** get_address_of_class_name_4() { return &___class_name_4; }
	inline void set_class_name_4(String_t* value)
	{
		___class_name_4 = value;
		Il2CppCodeGenWriteBarrier((&___class_name_4), value);
	}

	inline static int32_t get_offset_of_stack_trace_5() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___stack_trace_5)); }
	inline String_t* get_stack_trace_5() const { return ___stack_trace_5; }
	inline String_t** get_address_of_stack_trace_5() { return &___stack_trace_5; }
	inline void set_stack_trace_5(String_t* value)
	{
		___stack_trace_5 = value;
		Il2CppCodeGenWriteBarrier((&___stack_trace_5), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_6() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ____remoteStackTraceString_6)); }
	inline String_t* get__remoteStackTraceString_6() const { return ____remoteStackTraceString_6; }
	inline String_t** get_address_of__remoteStackTraceString_6() { return &____remoteStackTraceString_6; }
	inline void set__remoteStackTraceString_6(String_t* value)
	{
		____remoteStackTraceString_6 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_6), value);
	}

	inline static int32_t get_offset_of_remote_stack_index_7() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___remote_stack_index_7)); }
	inline int32_t get_remote_stack_index_7() const { return ___remote_stack_index_7; }
	inline int32_t* get_address_of_remote_stack_index_7() { return &___remote_stack_index_7; }
	inline void set_remote_stack_index_7(int32_t value)
	{
		___remote_stack_index_7 = value;
	}

	inline static int32_t get_offset_of_hresult_8() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___hresult_8)); }
	inline int32_t get_hresult_8() const { return ___hresult_8; }
	inline int32_t* get_address_of_hresult_8() { return &___hresult_8; }
	inline void set_hresult_8(int32_t value)
	{
		___hresult_8 = value;
	}

	inline static int32_t get_offset_of_source_9() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ___source_9)); }
	inline String_t* get_source_9() const { return ___source_9; }
	inline String_t** get_address_of_source_9() { return &___source_9; }
	inline void set_source_9(String_t* value)
	{
		___source_9 = value;
		Il2CppCodeGenWriteBarrier((&___source_9), value);
	}

	inline static int32_t get_offset_of__data_10() { return static_cast<int32_t>(offsetof(Exception_t3056413322, ____data_10)); }
	inline RuntimeObject* get__data_10() const { return ____data_10; }
	inline RuntimeObject** get_address_of__data_10() { return &____data_10; }
	inline void set__data_10(RuntimeObject* value)
	{
		____data_10 = value;
		Il2CppCodeGenWriteBarrier((&____data_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTION_T3056413322_H
#ifndef U3CUPDATELOCATIONU3EC__ITERATOR1_T452027185_H
#define U3CUPDATELOCATIONU3EC__ITERATOR1_T452027185_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LocationManager/<UpdateLocation>c__Iterator1
struct  U3CUpdateLocationU3Ec__Iterator1_t452027185  : public RuntimeObject
{
public:
	// System.Int32 LocationManager/<UpdateLocation>c__Iterator1::<maxWait>__0
	int32_t ___U3CmaxWaitU3E__0_0;
	// LocationManager LocationManager/<UpdateLocation>c__Iterator1::$this
	LocationManager_t1045714622 * ___U24this_1;
	// System.Object LocationManager/<UpdateLocation>c__Iterator1::$current
	RuntimeObject * ___U24current_2;
	// System.Boolean LocationManager/<UpdateLocation>c__Iterator1::$disposing
	bool ___U24disposing_3;
	// System.Int32 LocationManager/<UpdateLocation>c__Iterator1::$PC
	int32_t ___U24PC_4;

public:
	inline static int32_t get_offset_of_U3CmaxWaitU3E__0_0() { return static_cast<int32_t>(offsetof(U3CUpdateLocationU3Ec__Iterator1_t452027185, ___U3CmaxWaitU3E__0_0)); }
	inline int32_t get_U3CmaxWaitU3E__0_0() const { return ___U3CmaxWaitU3E__0_0; }
	inline int32_t* get_address_of_U3CmaxWaitU3E__0_0() { return &___U3CmaxWaitU3E__0_0; }
	inline void set_U3CmaxWaitU3E__0_0(int32_t value)
	{
		___U3CmaxWaitU3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U24this_1() { return static_cast<int32_t>(offsetof(U3CUpdateLocationU3Ec__Iterator1_t452027185, ___U24this_1)); }
	inline LocationManager_t1045714622 * get_U24this_1() const { return ___U24this_1; }
	inline LocationManager_t1045714622 ** get_address_of_U24this_1() { return &___U24this_1; }
	inline void set_U24this_1(LocationManager_t1045714622 * value)
	{
		___U24this_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24this_1), value);
	}

	inline static int32_t get_offset_of_U24current_2() { return static_cast<int32_t>(offsetof(U3CUpdateLocationU3Ec__Iterator1_t452027185, ___U24current_2)); }
	inline RuntimeObject * get_U24current_2() const { return ___U24current_2; }
	inline RuntimeObject ** get_address_of_U24current_2() { return &___U24current_2; }
	inline void set_U24current_2(RuntimeObject * value)
	{
		___U24current_2 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_2), value);
	}

	inline static int32_t get_offset_of_U24disposing_3() { return static_cast<int32_t>(offsetof(U3CUpdateLocationU3Ec__Iterator1_t452027185, ___U24disposing_3)); }
	inline bool get_U24disposing_3() const { return ___U24disposing_3; }
	inline bool* get_address_of_U24disposing_3() { return &___U24disposing_3; }
	inline void set_U24disposing_3(bool value)
	{
		___U24disposing_3 = value;
	}

	inline static int32_t get_offset_of_U24PC_4() { return static_cast<int32_t>(offsetof(U3CUpdateLocationU3Ec__Iterator1_t452027185, ___U24PC_4)); }
	inline int32_t get_U24PC_4() const { return ___U24PC_4; }
	inline int32_t* get_address_of_U24PC_4() { return &___U24PC_4; }
	inline void set_U24PC_4(int32_t value)
	{
		___U24PC_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CUPDATELOCATIONU3EC__ITERATOR1_T452027185_H
#ifndef CUSTOMYIELDINSTRUCTION_T198568362_H
#define CUSTOMYIELDINSTRUCTION_T198568362_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CustomYieldInstruction
struct  CustomYieldInstruction_t198568362  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CUSTOMYIELDINSTRUCTION_T198568362_H
#ifndef YIELDINSTRUCTION_T4074576386_H
#define YIELDINSTRUCTION_T4074576386_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.YieldInstruction
struct  YieldInstruction_t4074576386  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_t4074576386_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_t4074576386_marshaled_com
{
};
#endif // YIELDINSTRUCTION_T4074576386_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::length
	int32_t ___length_0;
	// System.Char System.String::start_char
	Il2CppChar ___start_char_1;

public:
	inline static int32_t get_offset_of_length_0() { return static_cast<int32_t>(offsetof(String_t, ___length_0)); }
	inline int32_t get_length_0() const { return ___length_0; }
	inline int32_t* get_address_of_length_0() { return &___length_0; }
	inline void set_length_0(int32_t value)
	{
		___length_0 = value;
	}

	inline static int32_t get_offset_of_start_char_1() { return static_cast<int32_t>(offsetof(String_t, ___start_char_1)); }
	inline Il2CppChar get_start_char_1() const { return ___start_char_1; }
	inline Il2CppChar* get_address_of_start_char_1() { return &___start_char_1; }
	inline void set_start_char_1(Il2CppChar value)
	{
		___start_char_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_2;
	// System.Char[] System.String::WhiteChars
	CharU5BU5D_t2772155777* ___WhiteChars_3;

public:
	inline static int32_t get_offset_of_Empty_2() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_2)); }
	inline String_t* get_Empty_2() const { return ___Empty_2; }
	inline String_t** get_address_of_Empty_2() { return &___Empty_2; }
	inline void set_Empty_2(String_t* value)
	{
		___Empty_2 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_2), value);
	}

	inline static int32_t get_offset_of_WhiteChars_3() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___WhiteChars_3)); }
	inline CharU5BU5D_t2772155777* get_WhiteChars_3() const { return ___WhiteChars_3; }
	inline CharU5BU5D_t2772155777** get_address_of_WhiteChars_3() { return &___WhiteChars_3; }
	inline void set_WhiteChars_3(CharU5BU5D_t2772155777* value)
	{
		___WhiteChars_3 = value;
		Il2CppCodeGenWriteBarrier((&___WhiteChars_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef ENUM_T1176231329_H
#define ENUM_T1176231329_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t1176231329  : public ValueType_t995865391
{
public:

public:
};

struct Enum_t1176231329_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t2772155777* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t1176231329_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t2772155777* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t2772155777** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t2772155777* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t1176231329_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t1176231329_marshaled_com
{
};
#endif // ENUM_T1176231329_H
#ifndef INT64_T2942533987_H
#define INT64_T2942533987_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int64
struct  Int64_t2942533987 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t2942533987, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT64_T2942533987_H
#ifndef SYSTEMEXCEPTION_T892114958_H
#define SYSTEMEXCEPTION_T892114958_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t892114958  : public Exception_t3056413322
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T892114958_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef SBYTE_T669469354_H
#define SBYTE_T669469354_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SByte
struct  SByte_t669469354 
{
public:
	// System.SByte System.SByte::m_value
	int8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(SByte_t669469354, ___m_value_0)); }
	inline int8_t get_m_value_0() const { return ___m_value_0; }
	inline int8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int8_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SBYTE_T669469354_H
#ifndef BYTE_T2596701031_H
#define BYTE_T2596701031_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Byte
struct  Byte_t2596701031 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Byte_t2596701031, ___m_value_2)); }
	inline uint8_t get_m_value_2() const { return ___m_value_2; }
	inline uint8_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint8_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTE_T2596701031_H
#ifndef INT16_T612759502_H
#define INT16_T612759502_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int16
struct  Int16_t612759502 
{
public:
	// System.Int16 System.Int16::m_value
	int16_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int16_t612759502, ___m_value_0)); }
	inline int16_t get_m_value_0() const { return ___m_value_0; }
	inline int16_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int16_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT16_T612759502_H
#ifndef UINT16_T1912811313_H
#define UINT16_T1912811313_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt16
struct  UInt16_t1912811313 
{
public:
	// System.UInt16 System.UInt16::m_value
	uint16_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(UInt16_t1912811313, ___m_value_2)); }
	inline uint16_t get_m_value_2() const { return ___m_value_2; }
	inline uint16_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(uint16_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT16_T1912811313_H
#ifndef UINT64_T4149917651_H
#define UINT64_T4149917651_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt64
struct  UInt64_t4149917651 
{
public:
	// System.UInt64 System.UInt64::m_value
	uint64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt64_t4149917651, ___m_value_0)); }
	inline uint64_t get_m_value_0() const { return ___m_value_0; }
	inline uint64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT64_T4149917651_H
#ifndef DOUBLE_T4024153389_H
#define DOUBLE_T4024153389_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Double
struct  Double_t4024153389 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_13;

public:
	inline static int32_t get_offset_of_m_value_13() { return static_cast<int32_t>(offsetof(Double_t4024153389, ___m_value_13)); }
	inline double get_m_value_13() const { return ___m_value_13; }
	inline double* get_address_of_m_value_13() { return &___m_value_13; }
	inline void set_m_value_13(double value)
	{
		___m_value_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DOUBLE_T4024153389_H
#ifndef DECIMAL_T3889304405_H
#define DECIMAL_T3889304405_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Decimal
struct  Decimal_t3889304405 
{
public:
	// System.UInt32 System.Decimal::flags
	uint32_t ___flags_5;
	// System.UInt32 System.Decimal::hi
	uint32_t ___hi_6;
	// System.UInt32 System.Decimal::lo
	uint32_t ___lo_7;
	// System.UInt32 System.Decimal::mid
	uint32_t ___mid_8;

public:
	inline static int32_t get_offset_of_flags_5() { return static_cast<int32_t>(offsetof(Decimal_t3889304405, ___flags_5)); }
	inline uint32_t get_flags_5() const { return ___flags_5; }
	inline uint32_t* get_address_of_flags_5() { return &___flags_5; }
	inline void set_flags_5(uint32_t value)
	{
		___flags_5 = value;
	}

	inline static int32_t get_offset_of_hi_6() { return static_cast<int32_t>(offsetof(Decimal_t3889304405, ___hi_6)); }
	inline uint32_t get_hi_6() const { return ___hi_6; }
	inline uint32_t* get_address_of_hi_6() { return &___hi_6; }
	inline void set_hi_6(uint32_t value)
	{
		___hi_6 = value;
	}

	inline static int32_t get_offset_of_lo_7() { return static_cast<int32_t>(offsetof(Decimal_t3889304405, ___lo_7)); }
	inline uint32_t get_lo_7() const { return ___lo_7; }
	inline uint32_t* get_address_of_lo_7() { return &___lo_7; }
	inline void set_lo_7(uint32_t value)
	{
		___lo_7 = value;
	}

	inline static int32_t get_offset_of_mid_8() { return static_cast<int32_t>(offsetof(Decimal_t3889304405, ___mid_8)); }
	inline uint32_t get_mid_8() const { return ___mid_8; }
	inline uint32_t* get_address_of_mid_8() { return &___mid_8; }
	inline void set_mid_8(uint32_t value)
	{
		___mid_8 = value;
	}
};

struct Decimal_t3889304405_StaticFields
{
public:
	// System.Decimal System.Decimal::MinValue
	Decimal_t3889304405  ___MinValue_0;
	// System.Decimal System.Decimal::MaxValue
	Decimal_t3889304405  ___MaxValue_1;
	// System.Decimal System.Decimal::MinusOne
	Decimal_t3889304405  ___MinusOne_2;
	// System.Decimal System.Decimal::One
	Decimal_t3889304405  ___One_3;
	// System.Decimal System.Decimal::MaxValueDiv10
	Decimal_t3889304405  ___MaxValueDiv10_4;

public:
	inline static int32_t get_offset_of_MinValue_0() { return static_cast<int32_t>(offsetof(Decimal_t3889304405_StaticFields, ___MinValue_0)); }
	inline Decimal_t3889304405  get_MinValue_0() const { return ___MinValue_0; }
	inline Decimal_t3889304405 * get_address_of_MinValue_0() { return &___MinValue_0; }
	inline void set_MinValue_0(Decimal_t3889304405  value)
	{
		___MinValue_0 = value;
	}

	inline static int32_t get_offset_of_MaxValue_1() { return static_cast<int32_t>(offsetof(Decimal_t3889304405_StaticFields, ___MaxValue_1)); }
	inline Decimal_t3889304405  get_MaxValue_1() const { return ___MaxValue_1; }
	inline Decimal_t3889304405 * get_address_of_MaxValue_1() { return &___MaxValue_1; }
	inline void set_MaxValue_1(Decimal_t3889304405  value)
	{
		___MaxValue_1 = value;
	}

	inline static int32_t get_offset_of_MinusOne_2() { return static_cast<int32_t>(offsetof(Decimal_t3889304405_StaticFields, ___MinusOne_2)); }
	inline Decimal_t3889304405  get_MinusOne_2() const { return ___MinusOne_2; }
	inline Decimal_t3889304405 * get_address_of_MinusOne_2() { return &___MinusOne_2; }
	inline void set_MinusOne_2(Decimal_t3889304405  value)
	{
		___MinusOne_2 = value;
	}

	inline static int32_t get_offset_of_One_3() { return static_cast<int32_t>(offsetof(Decimal_t3889304405_StaticFields, ___One_3)); }
	inline Decimal_t3889304405  get_One_3() const { return ___One_3; }
	inline Decimal_t3889304405 * get_address_of_One_3() { return &___One_3; }
	inline void set_One_3(Decimal_t3889304405  value)
	{
		___One_3 = value;
	}

	inline static int32_t get_offset_of_MaxValueDiv10_4() { return static_cast<int32_t>(offsetof(Decimal_t3889304405_StaticFields, ___MaxValueDiv10_4)); }
	inline Decimal_t3889304405  get_MaxValueDiv10_4() const { return ___MaxValueDiv10_4; }
	inline Decimal_t3889304405 * get_address_of_MaxValueDiv10_4() { return &___MaxValueDiv10_4; }
	inline void set_MaxValueDiv10_4(Decimal_t3889304405  value)
	{
		___MaxValueDiv10_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DECIMAL_T3889304405_H
#ifndef CHAR_T4123521152_H
#define CHAR_T4123521152_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Char
struct  Char_t4123521152 
{
public:
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Char_t4123521152, ___m_value_2)); }
	inline Il2CppChar get_m_value_2() const { return ___m_value_2; }
	inline Il2CppChar* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(Il2CppChar value)
	{
		___m_value_2 = value;
	}
};

struct Char_t4123521152_StaticFields
{
public:
	// System.Byte* System.Char::category_data
	uint8_t* ___category_data_3;
	// System.Byte* System.Char::numeric_data
	uint8_t* ___numeric_data_4;
	// System.Double* System.Char::numeric_data_values
	double* ___numeric_data_values_5;
	// System.UInt16* System.Char::to_lower_data_low
	uint16_t* ___to_lower_data_low_6;
	// System.UInt16* System.Char::to_lower_data_high
	uint16_t* ___to_lower_data_high_7;
	// System.UInt16* System.Char::to_upper_data_low
	uint16_t* ___to_upper_data_low_8;
	// System.UInt16* System.Char::to_upper_data_high
	uint16_t* ___to_upper_data_high_9;

public:
	inline static int32_t get_offset_of_category_data_3() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___category_data_3)); }
	inline uint8_t* get_category_data_3() const { return ___category_data_3; }
	inline uint8_t** get_address_of_category_data_3() { return &___category_data_3; }
	inline void set_category_data_3(uint8_t* value)
	{
		___category_data_3 = value;
	}

	inline static int32_t get_offset_of_numeric_data_4() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___numeric_data_4)); }
	inline uint8_t* get_numeric_data_4() const { return ___numeric_data_4; }
	inline uint8_t** get_address_of_numeric_data_4() { return &___numeric_data_4; }
	inline void set_numeric_data_4(uint8_t* value)
	{
		___numeric_data_4 = value;
	}

	inline static int32_t get_offset_of_numeric_data_values_5() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___numeric_data_values_5)); }
	inline double* get_numeric_data_values_5() const { return ___numeric_data_values_5; }
	inline double** get_address_of_numeric_data_values_5() { return &___numeric_data_values_5; }
	inline void set_numeric_data_values_5(double* value)
	{
		___numeric_data_values_5 = value;
	}

	inline static int32_t get_offset_of_to_lower_data_low_6() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___to_lower_data_low_6)); }
	inline uint16_t* get_to_lower_data_low_6() const { return ___to_lower_data_low_6; }
	inline uint16_t** get_address_of_to_lower_data_low_6() { return &___to_lower_data_low_6; }
	inline void set_to_lower_data_low_6(uint16_t* value)
	{
		___to_lower_data_low_6 = value;
	}

	inline static int32_t get_offset_of_to_lower_data_high_7() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___to_lower_data_high_7)); }
	inline uint16_t* get_to_lower_data_high_7() const { return ___to_lower_data_high_7; }
	inline uint16_t** get_address_of_to_lower_data_high_7() { return &___to_lower_data_high_7; }
	inline void set_to_lower_data_high_7(uint16_t* value)
	{
		___to_lower_data_high_7 = value;
	}

	inline static int32_t get_offset_of_to_upper_data_low_8() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___to_upper_data_low_8)); }
	inline uint16_t* get_to_upper_data_low_8() const { return ___to_upper_data_low_8; }
	inline uint16_t** get_address_of_to_upper_data_low_8() { return &___to_upper_data_low_8; }
	inline void set_to_upper_data_low_8(uint16_t* value)
	{
		___to_upper_data_low_8 = value;
	}

	inline static int32_t get_offset_of_to_upper_data_high_9() { return static_cast<int32_t>(offsetof(Char_t4123521152_StaticFields, ___to_upper_data_high_9)); }
	inline uint16_t* get_to_upper_data_high_9() const { return ___to_upper_data_high_9; }
	inline uint16_t** get_address_of_to_upper_data_high_9() { return &___to_upper_data_high_9; }
	inline void set_to_upper_data_high_9(uint16_t* value)
	{
		___to_upper_data_high_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHAR_T4123521152_H
#ifndef COLOR_T2395139082_H
#define COLOR_T2395139082_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t2395139082 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t2395139082, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t2395139082, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t2395139082, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t2395139082, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T2395139082_H
#ifndef BOOLEAN_T2724601657_H
#define BOOLEAN_T2724601657_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_t2724601657 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Boolean_t2724601657, ___m_value_2)); }
	inline bool get_m_value_2() const { return ___m_value_2; }
	inline bool* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(bool value)
	{
		___m_value_2 = value;
	}
};

struct Boolean_t2724601657_StaticFields
{
public:
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_0;
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_1;

public:
	inline static int32_t get_offset_of_FalseString_0() { return static_cast<int32_t>(offsetof(Boolean_t2724601657_StaticFields, ___FalseString_0)); }
	inline String_t* get_FalseString_0() const { return ___FalseString_0; }
	inline String_t** get_address_of_FalseString_0() { return &___FalseString_0; }
	inline void set_FalseString_0(String_t* value)
	{
		___FalseString_0 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_0), value);
	}

	inline static int32_t get_offset_of_TrueString_1() { return static_cast<int32_t>(offsetof(Boolean_t2724601657_StaticFields, ___TrueString_1)); }
	inline String_t* get_TrueString_1() const { return ___TrueString_1; }
	inline String_t** get_address_of_TrueString_1() { return &___TrueString_1; }
	inline void set_TrueString_1(String_t* value)
	{
		___TrueString_1 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_T2724601657_H
#ifndef UINT32_T1505113534_H
#define UINT32_T1505113534_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt32
struct  UInt32_t1505113534 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t1505113534, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT32_T1505113534_H
#ifndef INT32_T2946131084_H
#define INT32_T2946131084_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t2946131084 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_2;

public:
	inline static int32_t get_offset_of_m_value_2() { return static_cast<int32_t>(offsetof(Int32_t2946131084, ___m_value_2)); }
	inline int32_t get_m_value_2() const { return ___m_value_2; }
	inline int32_t* get_address_of_m_value_2() { return &___m_value_2; }
	inline void set_m_value_2(int32_t value)
	{
		___m_value_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T2946131084_H
#ifndef SINGLE_T2594644343_H
#define SINGLE_T2594644343_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_t2594644343 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_7;

public:
	inline static int32_t get_offset_of_m_value_7() { return static_cast<int32_t>(offsetof(Single_t2594644343, ___m_value_7)); }
	inline float get_m_value_7() const { return ___m_value_7; }
	inline float* get_address_of_m_value_7() { return &___m_value_7; }
	inline void set_m_value_7(float value)
	{
		___m_value_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_T2594644343_H
#ifndef XMLDOCUMENT_T2296465371_H
#define XMLDOCUMENT_T2296465371_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlDocument
struct  XmlDocument_t2296465371  : public XmlNode_t482051342
{
public:
	// System.Boolean System.Xml.XmlDocument::optimal_create_element
	bool ___optimal_create_element_6;
	// System.Boolean System.Xml.XmlDocument::optimal_create_attribute
	bool ___optimal_create_attribute_7;
	// System.Xml.XmlNameTable System.Xml.XmlDocument::nameTable
	XmlNameTable_t1479426498 * ___nameTable_8;
	// System.String System.Xml.XmlDocument::baseURI
	String_t* ___baseURI_9;
	// System.Xml.XmlImplementation System.Xml.XmlDocument::implementation
	XmlImplementation_t3148428848 * ___implementation_10;
	// System.Boolean System.Xml.XmlDocument::preserveWhitespace
	bool ___preserveWhitespace_11;
	// System.Xml.XmlResolver System.Xml.XmlDocument::resolver
	XmlResolver_t1481695800 * ___resolver_12;
	// System.Collections.Hashtable System.Xml.XmlDocument::idTable
	Hashtable_t3043587435 * ___idTable_13;
	// System.Xml.XmlNameEntryCache System.Xml.XmlDocument::nameCache
	XmlNameEntryCache_t3274904478 * ___nameCache_14;
	// System.Xml.XmlLinkedNode System.Xml.XmlDocument::lastLinkedChild
	XmlLinkedNode_t2960487756 * ___lastLinkedChild_15;
	// System.Xml.Schema.XmlSchemaSet System.Xml.XmlDocument::schemas
	XmlSchemaSet_t410947004 * ___schemas_16;
	// System.Xml.Schema.IXmlSchemaInfo System.Xml.XmlDocument::schemaInfo
	RuntimeObject* ___schemaInfo_17;
	// System.Boolean System.Xml.XmlDocument::loadMode
	bool ___loadMode_18;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeChanged
	XmlNodeChangedEventHandler_t3620679463 * ___NodeChanged_19;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeChanging
	XmlNodeChangedEventHandler_t3620679463 * ___NodeChanging_20;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeInserted
	XmlNodeChangedEventHandler_t3620679463 * ___NodeInserted_21;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeInserting
	XmlNodeChangedEventHandler_t3620679463 * ___NodeInserting_22;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeRemoved
	XmlNodeChangedEventHandler_t3620679463 * ___NodeRemoved_23;
	// System.Xml.XmlNodeChangedEventHandler System.Xml.XmlDocument::NodeRemoving
	XmlNodeChangedEventHandler_t3620679463 * ___NodeRemoving_24;

public:
	inline static int32_t get_offset_of_optimal_create_element_6() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___optimal_create_element_6)); }
	inline bool get_optimal_create_element_6() const { return ___optimal_create_element_6; }
	inline bool* get_address_of_optimal_create_element_6() { return &___optimal_create_element_6; }
	inline void set_optimal_create_element_6(bool value)
	{
		___optimal_create_element_6 = value;
	}

	inline static int32_t get_offset_of_optimal_create_attribute_7() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___optimal_create_attribute_7)); }
	inline bool get_optimal_create_attribute_7() const { return ___optimal_create_attribute_7; }
	inline bool* get_address_of_optimal_create_attribute_7() { return &___optimal_create_attribute_7; }
	inline void set_optimal_create_attribute_7(bool value)
	{
		___optimal_create_attribute_7 = value;
	}

	inline static int32_t get_offset_of_nameTable_8() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___nameTable_8)); }
	inline XmlNameTable_t1479426498 * get_nameTable_8() const { return ___nameTable_8; }
	inline XmlNameTable_t1479426498 ** get_address_of_nameTable_8() { return &___nameTable_8; }
	inline void set_nameTable_8(XmlNameTable_t1479426498 * value)
	{
		___nameTable_8 = value;
		Il2CppCodeGenWriteBarrier((&___nameTable_8), value);
	}

	inline static int32_t get_offset_of_baseURI_9() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___baseURI_9)); }
	inline String_t* get_baseURI_9() const { return ___baseURI_9; }
	inline String_t** get_address_of_baseURI_9() { return &___baseURI_9; }
	inline void set_baseURI_9(String_t* value)
	{
		___baseURI_9 = value;
		Il2CppCodeGenWriteBarrier((&___baseURI_9), value);
	}

	inline static int32_t get_offset_of_implementation_10() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___implementation_10)); }
	inline XmlImplementation_t3148428848 * get_implementation_10() const { return ___implementation_10; }
	inline XmlImplementation_t3148428848 ** get_address_of_implementation_10() { return &___implementation_10; }
	inline void set_implementation_10(XmlImplementation_t3148428848 * value)
	{
		___implementation_10 = value;
		Il2CppCodeGenWriteBarrier((&___implementation_10), value);
	}

	inline static int32_t get_offset_of_preserveWhitespace_11() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___preserveWhitespace_11)); }
	inline bool get_preserveWhitespace_11() const { return ___preserveWhitespace_11; }
	inline bool* get_address_of_preserveWhitespace_11() { return &___preserveWhitespace_11; }
	inline void set_preserveWhitespace_11(bool value)
	{
		___preserveWhitespace_11 = value;
	}

	inline static int32_t get_offset_of_resolver_12() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___resolver_12)); }
	inline XmlResolver_t1481695800 * get_resolver_12() const { return ___resolver_12; }
	inline XmlResolver_t1481695800 ** get_address_of_resolver_12() { return &___resolver_12; }
	inline void set_resolver_12(XmlResolver_t1481695800 * value)
	{
		___resolver_12 = value;
		Il2CppCodeGenWriteBarrier((&___resolver_12), value);
	}

	inline static int32_t get_offset_of_idTable_13() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___idTable_13)); }
	inline Hashtable_t3043587435 * get_idTable_13() const { return ___idTable_13; }
	inline Hashtable_t3043587435 ** get_address_of_idTable_13() { return &___idTable_13; }
	inline void set_idTable_13(Hashtable_t3043587435 * value)
	{
		___idTable_13 = value;
		Il2CppCodeGenWriteBarrier((&___idTable_13), value);
	}

	inline static int32_t get_offset_of_nameCache_14() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___nameCache_14)); }
	inline XmlNameEntryCache_t3274904478 * get_nameCache_14() const { return ___nameCache_14; }
	inline XmlNameEntryCache_t3274904478 ** get_address_of_nameCache_14() { return &___nameCache_14; }
	inline void set_nameCache_14(XmlNameEntryCache_t3274904478 * value)
	{
		___nameCache_14 = value;
		Il2CppCodeGenWriteBarrier((&___nameCache_14), value);
	}

	inline static int32_t get_offset_of_lastLinkedChild_15() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___lastLinkedChild_15)); }
	inline XmlLinkedNode_t2960487756 * get_lastLinkedChild_15() const { return ___lastLinkedChild_15; }
	inline XmlLinkedNode_t2960487756 ** get_address_of_lastLinkedChild_15() { return &___lastLinkedChild_15; }
	inline void set_lastLinkedChild_15(XmlLinkedNode_t2960487756 * value)
	{
		___lastLinkedChild_15 = value;
		Il2CppCodeGenWriteBarrier((&___lastLinkedChild_15), value);
	}

	inline static int32_t get_offset_of_schemas_16() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___schemas_16)); }
	inline XmlSchemaSet_t410947004 * get_schemas_16() const { return ___schemas_16; }
	inline XmlSchemaSet_t410947004 ** get_address_of_schemas_16() { return &___schemas_16; }
	inline void set_schemas_16(XmlSchemaSet_t410947004 * value)
	{
		___schemas_16 = value;
		Il2CppCodeGenWriteBarrier((&___schemas_16), value);
	}

	inline static int32_t get_offset_of_schemaInfo_17() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___schemaInfo_17)); }
	inline RuntimeObject* get_schemaInfo_17() const { return ___schemaInfo_17; }
	inline RuntimeObject** get_address_of_schemaInfo_17() { return &___schemaInfo_17; }
	inline void set_schemaInfo_17(RuntimeObject* value)
	{
		___schemaInfo_17 = value;
		Il2CppCodeGenWriteBarrier((&___schemaInfo_17), value);
	}

	inline static int32_t get_offset_of_loadMode_18() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___loadMode_18)); }
	inline bool get_loadMode_18() const { return ___loadMode_18; }
	inline bool* get_address_of_loadMode_18() { return &___loadMode_18; }
	inline void set_loadMode_18(bool value)
	{
		___loadMode_18 = value;
	}

	inline static int32_t get_offset_of_NodeChanged_19() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeChanged_19)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeChanged_19() const { return ___NodeChanged_19; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeChanged_19() { return &___NodeChanged_19; }
	inline void set_NodeChanged_19(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeChanged_19 = value;
		Il2CppCodeGenWriteBarrier((&___NodeChanged_19), value);
	}

	inline static int32_t get_offset_of_NodeChanging_20() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeChanging_20)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeChanging_20() const { return ___NodeChanging_20; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeChanging_20() { return &___NodeChanging_20; }
	inline void set_NodeChanging_20(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeChanging_20 = value;
		Il2CppCodeGenWriteBarrier((&___NodeChanging_20), value);
	}

	inline static int32_t get_offset_of_NodeInserted_21() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeInserted_21)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeInserted_21() const { return ___NodeInserted_21; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeInserted_21() { return &___NodeInserted_21; }
	inline void set_NodeInserted_21(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeInserted_21 = value;
		Il2CppCodeGenWriteBarrier((&___NodeInserted_21), value);
	}

	inline static int32_t get_offset_of_NodeInserting_22() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeInserting_22)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeInserting_22() const { return ___NodeInserting_22; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeInserting_22() { return &___NodeInserting_22; }
	inline void set_NodeInserting_22(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeInserting_22 = value;
		Il2CppCodeGenWriteBarrier((&___NodeInserting_22), value);
	}

	inline static int32_t get_offset_of_NodeRemoved_23() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeRemoved_23)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeRemoved_23() const { return ___NodeRemoved_23; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeRemoved_23() { return &___NodeRemoved_23; }
	inline void set_NodeRemoved_23(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeRemoved_23 = value;
		Il2CppCodeGenWriteBarrier((&___NodeRemoved_23), value);
	}

	inline static int32_t get_offset_of_NodeRemoving_24() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371, ___NodeRemoving_24)); }
	inline XmlNodeChangedEventHandler_t3620679463 * get_NodeRemoving_24() const { return ___NodeRemoving_24; }
	inline XmlNodeChangedEventHandler_t3620679463 ** get_address_of_NodeRemoving_24() { return &___NodeRemoving_24; }
	inline void set_NodeRemoving_24(XmlNodeChangedEventHandler_t3620679463 * value)
	{
		___NodeRemoving_24 = value;
		Il2CppCodeGenWriteBarrier((&___NodeRemoving_24), value);
	}
};

struct XmlDocument_t2296465371_StaticFields
{
public:
	// System.Type[] System.Xml.XmlDocument::optimal_create_types
	TypeU5BU5D_t4189288004* ___optimal_create_types_5;

public:
	inline static int32_t get_offset_of_optimal_create_types_5() { return static_cast<int32_t>(offsetof(XmlDocument_t2296465371_StaticFields, ___optimal_create_types_5)); }
	inline TypeU5BU5D_t4189288004* get_optimal_create_types_5() const { return ___optimal_create_types_5; }
	inline TypeU5BU5D_t4189288004** get_address_of_optimal_create_types_5() { return &___optimal_create_types_5; }
	inline void set_optimal_create_types_5(TypeU5BU5D_t4189288004* value)
	{
		___optimal_create_types_5 = value;
		Il2CppCodeGenWriteBarrier((&___optimal_create_types_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLDOCUMENT_T2296465371_H
#ifndef WWW_T3457365752_H
#define WWW_T3457365752_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.WWW
struct  WWW_t3457365752  : public CustomYieldInstruction_t198568362
{
public:
	// UnityEngine.Networking.UnityWebRequest UnityEngine.WWW::_uwr
	UnityWebRequest_t916680322 * ____uwr_0;

public:
	inline static int32_t get_offset_of__uwr_0() { return static_cast<int32_t>(offsetof(WWW_t3457365752, ____uwr_0)); }
	inline UnityWebRequest_t916680322 * get__uwr_0() const { return ____uwr_0; }
	inline UnityWebRequest_t916680322 ** get_address_of__uwr_0() { return &____uwr_0; }
	inline void set__uwr_0(UnityWebRequest_t916680322 * value)
	{
		____uwr_0 = value;
		Il2CppCodeGenWriteBarrier((&____uwr_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WWW_T3457365752_H
#ifndef WAITFORSECONDS_T3313172267_H
#define WAITFORSECONDS_T3313172267_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.WaitForSeconds
struct  WaitForSeconds_t3313172267  : public YieldInstruction_t4074576386
{
public:
	// System.Single UnityEngine.WaitForSeconds::m_Seconds
	float ___m_Seconds_0;

public:
	inline static int32_t get_offset_of_m_Seconds_0() { return static_cast<int32_t>(offsetof(WaitForSeconds_t3313172267, ___m_Seconds_0)); }
	inline float get_m_Seconds_0() const { return ___m_Seconds_0; }
	inline float* get_address_of_m_Seconds_0() { return &___m_Seconds_0; }
	inline void set_m_Seconds_0(float value)
	{
		___m_Seconds_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.WaitForSeconds
struct WaitForSeconds_t3313172267_marshaled_pinvoke : public YieldInstruction_t4074576386_marshaled_pinvoke
{
	float ___m_Seconds_0;
};
// Native definition for COM marshalling of UnityEngine.WaitForSeconds
struct WaitForSeconds_t3313172267_marshaled_com : public YieldInstruction_t4074576386_marshaled_com
{
	float ___m_Seconds_0;
};
#endif // WAITFORSECONDS_T3313172267_H
#ifndef LOCATIONINFO_T2252625205_H
#define LOCATIONINFO_T2252625205_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LocationInfo
struct  LocationInfo_t2252625205 
{
public:
	// System.Double UnityEngine.LocationInfo::m_Timestamp
	double ___m_Timestamp_0;
	// System.Single UnityEngine.LocationInfo::m_Latitude
	float ___m_Latitude_1;
	// System.Single UnityEngine.LocationInfo::m_Longitude
	float ___m_Longitude_2;
	// System.Single UnityEngine.LocationInfo::m_Altitude
	float ___m_Altitude_3;
	// System.Single UnityEngine.LocationInfo::m_HorizontalAccuracy
	float ___m_HorizontalAccuracy_4;
	// System.Single UnityEngine.LocationInfo::m_VerticalAccuracy
	float ___m_VerticalAccuracy_5;

public:
	inline static int32_t get_offset_of_m_Timestamp_0() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_Timestamp_0)); }
	inline double get_m_Timestamp_0() const { return ___m_Timestamp_0; }
	inline double* get_address_of_m_Timestamp_0() { return &___m_Timestamp_0; }
	inline void set_m_Timestamp_0(double value)
	{
		___m_Timestamp_0 = value;
	}

	inline static int32_t get_offset_of_m_Latitude_1() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_Latitude_1)); }
	inline float get_m_Latitude_1() const { return ___m_Latitude_1; }
	inline float* get_address_of_m_Latitude_1() { return &___m_Latitude_1; }
	inline void set_m_Latitude_1(float value)
	{
		___m_Latitude_1 = value;
	}

	inline static int32_t get_offset_of_m_Longitude_2() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_Longitude_2)); }
	inline float get_m_Longitude_2() const { return ___m_Longitude_2; }
	inline float* get_address_of_m_Longitude_2() { return &___m_Longitude_2; }
	inline void set_m_Longitude_2(float value)
	{
		___m_Longitude_2 = value;
	}

	inline static int32_t get_offset_of_m_Altitude_3() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_Altitude_3)); }
	inline float get_m_Altitude_3() const { return ___m_Altitude_3; }
	inline float* get_address_of_m_Altitude_3() { return &___m_Altitude_3; }
	inline void set_m_Altitude_3(float value)
	{
		___m_Altitude_3 = value;
	}

	inline static int32_t get_offset_of_m_HorizontalAccuracy_4() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_HorizontalAccuracy_4)); }
	inline float get_m_HorizontalAccuracy_4() const { return ___m_HorizontalAccuracy_4; }
	inline float* get_address_of_m_HorizontalAccuracy_4() { return &___m_HorizontalAccuracy_4; }
	inline void set_m_HorizontalAccuracy_4(float value)
	{
		___m_HorizontalAccuracy_4 = value;
	}

	inline static int32_t get_offset_of_m_VerticalAccuracy_5() { return static_cast<int32_t>(offsetof(LocationInfo_t2252625205, ___m_VerticalAccuracy_5)); }
	inline float get_m_VerticalAccuracy_5() const { return ___m_VerticalAccuracy_5; }
	inline float* get_address_of_m_VerticalAccuracy_5() { return &___m_VerticalAccuracy_5; }
	inline void set_m_VerticalAccuracy_5(float value)
	{
		___m_VerticalAccuracy_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCATIONINFO_T2252625205_H
#ifndef STRINGREADER_T1790093495_H
#define STRINGREADER_T1790093495_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IO.StringReader
struct  StringReader_t1790093495  : public TextReader_t1750538733
{
public:
	// System.String System.IO.StringReader::source
	String_t* ___source_1;
	// System.Int32 System.IO.StringReader::nextChar
	int32_t ___nextChar_2;
	// System.Int32 System.IO.StringReader::sourceLength
	int32_t ___sourceLength_3;

public:
	inline static int32_t get_offset_of_source_1() { return static_cast<int32_t>(offsetof(StringReader_t1790093495, ___source_1)); }
	inline String_t* get_source_1() const { return ___source_1; }
	inline String_t** get_address_of_source_1() { return &___source_1; }
	inline void set_source_1(String_t* value)
	{
		___source_1 = value;
		Il2CppCodeGenWriteBarrier((&___source_1), value);
	}

	inline static int32_t get_offset_of_nextChar_2() { return static_cast<int32_t>(offsetof(StringReader_t1790093495, ___nextChar_2)); }
	inline int32_t get_nextChar_2() const { return ___nextChar_2; }
	inline int32_t* get_address_of_nextChar_2() { return &___nextChar_2; }
	inline void set_nextChar_2(int32_t value)
	{
		___nextChar_2 = value;
	}

	inline static int32_t get_offset_of_sourceLength_3() { return static_cast<int32_t>(offsetof(StringReader_t1790093495, ___sourceLength_3)); }
	inline int32_t get_sourceLength_3() const { return ___sourceLength_3; }
	inline int32_t* get_address_of_sourceLength_3() { return &___sourceLength_3; }
	inline void set_sourceLength_3(int32_t value)
	{
		___sourceLength_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGREADER_T1790093495_H
#ifndef VOID_T289307186_H
#define VOID_T289307186_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t289307186 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T289307186_H
#ifndef NOTSUPPORTEDEXCEPTION_T962022136_H
#define NOTSUPPORTEDEXCEPTION_T962022136_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.NotSupportedException
struct  NotSupportedException_t962022136  : public SystemException_t892114958
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NOTSUPPORTEDEXCEPTION_T962022136_H
#ifndef LOCATIONSERVICESTATUS_T1417812469_H
#define LOCATIONSERVICESTATUS_T1417812469_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LocationServiceStatus
struct  LocationServiceStatus_t1417812469 
{
public:
	// System.Int32 UnityEngine.LocationServiceStatus::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(LocationServiceStatus_t1417812469, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCATIONSERVICESTATUS_T1417812469_H
#ifndef TOKEN_T80177398_H
#define TOKEN_T80177398_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MiniJSON.Json/Parser/TOKEN
struct  TOKEN_t80177398 
{
public:
	// System.Int32 MiniJSON.Json/Parser/TOKEN::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(TOKEN_t80177398, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TOKEN_T80177398_H
#ifndef COROUTINE_T3971565922_H
#define COROUTINE_T3971565922_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Coroutine
struct  Coroutine_t3971565922  : public YieldInstruction_t4074576386
{
public:
	// System.IntPtr UnityEngine.Coroutine::m_Ptr
	intptr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(Coroutine_t3971565922, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Coroutine
struct Coroutine_t3971565922_marshaled_pinvoke : public YieldInstruction_t4074576386_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Coroutine
struct Coroutine_t3971565922_marshaled_com : public YieldInstruction_t4074576386_marshaled_com
{
	intptr_t ___m_Ptr_0;
};
#endif // COROUTINE_T3971565922_H
#ifndef OBJECT_T3285695601_H
#define OBJECT_T3285695601_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_t3285695601  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_t3285695601, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_t3285695601_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_t3285695601_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_t3285695601_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_t3285695601_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_T3285695601_H
#ifndef COMPONENT_T3460329512_H
#define COMPONENT_T3460329512_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t3460329512  : public Object_t3285695601
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T3460329512_H
#ifndef BEHAVIOUR_T789096462_H
#define BEHAVIOUR_T789096462_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_t789096462  : public Component_t3460329512
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_T789096462_H
#ifndef MONOBEHAVIOUR_T2760964972_H
#define MONOBEHAVIOUR_T2760964972_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t2760964972  : public Behaviour_t789096462
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T2760964972_H
#ifndef LOCATIONMANAGER_T1045714622_H
#define LOCATIONMANAGER_T1045714622_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LocationManager
struct  LocationManager_t1045714622  : public MonoBehaviour_t2760964972
{
public:
	// System.Single LocationManager::lat
	float ___lat_2;
	// System.Single LocationManager::lng
	float ___lng_3;
	// UnityEngine.UI.Text LocationManager::latutudeText
	Text_t40276147 * ___latutudeText_4;
	// UnityEngine.UI.Text LocationManager::longitudeText
	Text_t40276147 * ___longitudeText_5;
	// UnityEngine.UI.Text LocationManager::countryText
	Text_t40276147 * ___countryText_6;

public:
	inline static int32_t get_offset_of_lat_2() { return static_cast<int32_t>(offsetof(LocationManager_t1045714622, ___lat_2)); }
	inline float get_lat_2() const { return ___lat_2; }
	inline float* get_address_of_lat_2() { return &___lat_2; }
	inline void set_lat_2(float value)
	{
		___lat_2 = value;
	}

	inline static int32_t get_offset_of_lng_3() { return static_cast<int32_t>(offsetof(LocationManager_t1045714622, ___lng_3)); }
	inline float get_lng_3() const { return ___lng_3; }
	inline float* get_address_of_lng_3() { return &___lng_3; }
	inline void set_lng_3(float value)
	{
		___lng_3 = value;
	}

	inline static int32_t get_offset_of_latutudeText_4() { return static_cast<int32_t>(offsetof(LocationManager_t1045714622, ___latutudeText_4)); }
	inline Text_t40276147 * get_latutudeText_4() const { return ___latutudeText_4; }
	inline Text_t40276147 ** get_address_of_latutudeText_4() { return &___latutudeText_4; }
	inline void set_latutudeText_4(Text_t40276147 * value)
	{
		___latutudeText_4 = value;
		Il2CppCodeGenWriteBarrier((&___latutudeText_4), value);
	}

	inline static int32_t get_offset_of_longitudeText_5() { return static_cast<int32_t>(offsetof(LocationManager_t1045714622, ___longitudeText_5)); }
	inline Text_t40276147 * get_longitudeText_5() const { return ___longitudeText_5; }
	inline Text_t40276147 ** get_address_of_longitudeText_5() { return &___longitudeText_5; }
	inline void set_longitudeText_5(Text_t40276147 * value)
	{
		___longitudeText_5 = value;
		Il2CppCodeGenWriteBarrier((&___longitudeText_5), value);
	}

	inline static int32_t get_offset_of_countryText_6() { return static_cast<int32_t>(offsetof(LocationManager_t1045714622, ___countryText_6)); }
	inline Text_t40276147 * get_countryText_6() const { return ___countryText_6; }
	inline Text_t40276147 ** get_address_of_countryText_6() { return &___countryText_6; }
	inline void set_countryText_6(Text_t40276147 * value)
	{
		___countryText_6 = value;
		Il2CppCodeGenWriteBarrier((&___countryText_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCATIONMANAGER_T1045714622_H
#ifndef UIBEHAVIOUR_T2911488490_H
#define UIBEHAVIOUR_T2911488490_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.EventSystems.UIBehaviour
struct  UIBehaviour_t2911488490  : public MonoBehaviour_t2760964972
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UIBEHAVIOUR_T2911488490_H
#ifndef GRAPHIC_T3934133196_H
#define GRAPHIC_T3934133196_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Graphic
struct  Graphic_t3934133196  : public UIBehaviour_t2911488490
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::m_Material
	Material_t3291338668 * ___m_Material_4;
	// UnityEngine.Color UnityEngine.UI.Graphic::m_Color
	Color_t2395139082  ___m_Color_5;
	// System.Boolean UnityEngine.UI.Graphic::m_RaycastTarget
	bool ___m_RaycastTarget_6;
	// UnityEngine.RectTransform UnityEngine.UI.Graphic::m_RectTransform
	RectTransform_t3170355171 * ___m_RectTransform_7;
	// UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::m_CanvasRender
	CanvasRenderer_t3614328869 * ___m_CanvasRender_8;
	// UnityEngine.Canvas UnityEngine.UI.Graphic::m_Canvas
	Canvas_t1472555277 * ___m_Canvas_9;
	// System.Boolean UnityEngine.UI.Graphic::m_VertsDirty
	bool ___m_VertsDirty_10;
	// System.Boolean UnityEngine.UI.Graphic::m_MaterialDirty
	bool ___m_MaterialDirty_11;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyLayoutCallback
	UnityAction_t2721498936 * ___m_OnDirtyLayoutCallback_12;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyVertsCallback
	UnityAction_t2721498936 * ___m_OnDirtyVertsCallback_13;
	// UnityEngine.Events.UnityAction UnityEngine.UI.Graphic::m_OnDirtyMaterialCallback
	UnityAction_t2721498936 * ___m_OnDirtyMaterialCallback_14;
	// UnityEngine.UI.CoroutineTween.TweenRunner`1<UnityEngine.UI.CoroutineTween.ColorTween> UnityEngine.UI.Graphic::m_ColorTweenRunner
	TweenRunner_1_t3951980788 * ___m_ColorTweenRunner_17;
	// System.Boolean UnityEngine.UI.Graphic::<useLegacyMeshGeneration>k__BackingField
	bool ___U3CuseLegacyMeshGenerationU3Ek__BackingField_18;

public:
	inline static int32_t get_offset_of_m_Material_4() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_Material_4)); }
	inline Material_t3291338668 * get_m_Material_4() const { return ___m_Material_4; }
	inline Material_t3291338668 ** get_address_of_m_Material_4() { return &___m_Material_4; }
	inline void set_m_Material_4(Material_t3291338668 * value)
	{
		___m_Material_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Material_4), value);
	}

	inline static int32_t get_offset_of_m_Color_5() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_Color_5)); }
	inline Color_t2395139082  get_m_Color_5() const { return ___m_Color_5; }
	inline Color_t2395139082 * get_address_of_m_Color_5() { return &___m_Color_5; }
	inline void set_m_Color_5(Color_t2395139082  value)
	{
		___m_Color_5 = value;
	}

	inline static int32_t get_offset_of_m_RaycastTarget_6() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_RaycastTarget_6)); }
	inline bool get_m_RaycastTarget_6() const { return ___m_RaycastTarget_6; }
	inline bool* get_address_of_m_RaycastTarget_6() { return &___m_RaycastTarget_6; }
	inline void set_m_RaycastTarget_6(bool value)
	{
		___m_RaycastTarget_6 = value;
	}

	inline static int32_t get_offset_of_m_RectTransform_7() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_RectTransform_7)); }
	inline RectTransform_t3170355171 * get_m_RectTransform_7() const { return ___m_RectTransform_7; }
	inline RectTransform_t3170355171 ** get_address_of_m_RectTransform_7() { return &___m_RectTransform_7; }
	inline void set_m_RectTransform_7(RectTransform_t3170355171 * value)
	{
		___m_RectTransform_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_RectTransform_7), value);
	}

	inline static int32_t get_offset_of_m_CanvasRender_8() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_CanvasRender_8)); }
	inline CanvasRenderer_t3614328869 * get_m_CanvasRender_8() const { return ___m_CanvasRender_8; }
	inline CanvasRenderer_t3614328869 ** get_address_of_m_CanvasRender_8() { return &___m_CanvasRender_8; }
	inline void set_m_CanvasRender_8(CanvasRenderer_t3614328869 * value)
	{
		___m_CanvasRender_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_CanvasRender_8), value);
	}

	inline static int32_t get_offset_of_m_Canvas_9() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_Canvas_9)); }
	inline Canvas_t1472555277 * get_m_Canvas_9() const { return ___m_Canvas_9; }
	inline Canvas_t1472555277 ** get_address_of_m_Canvas_9() { return &___m_Canvas_9; }
	inline void set_m_Canvas_9(Canvas_t1472555277 * value)
	{
		___m_Canvas_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_Canvas_9), value);
	}

	inline static int32_t get_offset_of_m_VertsDirty_10() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_VertsDirty_10)); }
	inline bool get_m_VertsDirty_10() const { return ___m_VertsDirty_10; }
	inline bool* get_address_of_m_VertsDirty_10() { return &___m_VertsDirty_10; }
	inline void set_m_VertsDirty_10(bool value)
	{
		___m_VertsDirty_10 = value;
	}

	inline static int32_t get_offset_of_m_MaterialDirty_11() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_MaterialDirty_11)); }
	inline bool get_m_MaterialDirty_11() const { return ___m_MaterialDirty_11; }
	inline bool* get_address_of_m_MaterialDirty_11() { return &___m_MaterialDirty_11; }
	inline void set_m_MaterialDirty_11(bool value)
	{
		___m_MaterialDirty_11 = value;
	}

	inline static int32_t get_offset_of_m_OnDirtyLayoutCallback_12() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_OnDirtyLayoutCallback_12)); }
	inline UnityAction_t2721498936 * get_m_OnDirtyLayoutCallback_12() const { return ___m_OnDirtyLayoutCallback_12; }
	inline UnityAction_t2721498936 ** get_address_of_m_OnDirtyLayoutCallback_12() { return &___m_OnDirtyLayoutCallback_12; }
	inline void set_m_OnDirtyLayoutCallback_12(UnityAction_t2721498936 * value)
	{
		___m_OnDirtyLayoutCallback_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_OnDirtyLayoutCallback_12), value);
	}

	inline static int32_t get_offset_of_m_OnDirtyVertsCallback_13() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_OnDirtyVertsCallback_13)); }
	inline UnityAction_t2721498936 * get_m_OnDirtyVertsCallback_13() const { return ___m_OnDirtyVertsCallback_13; }
	inline UnityAction_t2721498936 ** get_address_of_m_OnDirtyVertsCallback_13() { return &___m_OnDirtyVertsCallback_13; }
	inline void set_m_OnDirtyVertsCallback_13(UnityAction_t2721498936 * value)
	{
		___m_OnDirtyVertsCallback_13 = value;
		Il2CppCodeGenWriteBarrier((&___m_OnDirtyVertsCallback_13), value);
	}

	inline static int32_t get_offset_of_m_OnDirtyMaterialCallback_14() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_OnDirtyMaterialCallback_14)); }
	inline UnityAction_t2721498936 * get_m_OnDirtyMaterialCallback_14() const { return ___m_OnDirtyMaterialCallback_14; }
	inline UnityAction_t2721498936 ** get_address_of_m_OnDirtyMaterialCallback_14() { return &___m_OnDirtyMaterialCallback_14; }
	inline void set_m_OnDirtyMaterialCallback_14(UnityAction_t2721498936 * value)
	{
		___m_OnDirtyMaterialCallback_14 = value;
		Il2CppCodeGenWriteBarrier((&___m_OnDirtyMaterialCallback_14), value);
	}

	inline static int32_t get_offset_of_m_ColorTweenRunner_17() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___m_ColorTweenRunner_17)); }
	inline TweenRunner_1_t3951980788 * get_m_ColorTweenRunner_17() const { return ___m_ColorTweenRunner_17; }
	inline TweenRunner_1_t3951980788 ** get_address_of_m_ColorTweenRunner_17() { return &___m_ColorTweenRunner_17; }
	inline void set_m_ColorTweenRunner_17(TweenRunner_1_t3951980788 * value)
	{
		___m_ColorTweenRunner_17 = value;
		Il2CppCodeGenWriteBarrier((&___m_ColorTweenRunner_17), value);
	}

	inline static int32_t get_offset_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(Graphic_t3934133196, ___U3CuseLegacyMeshGenerationU3Ek__BackingField_18)); }
	inline bool get_U3CuseLegacyMeshGenerationU3Ek__BackingField_18() const { return ___U3CuseLegacyMeshGenerationU3Ek__BackingField_18; }
	inline bool* get_address_of_U3CuseLegacyMeshGenerationU3Ek__BackingField_18() { return &___U3CuseLegacyMeshGenerationU3Ek__BackingField_18; }
	inline void set_U3CuseLegacyMeshGenerationU3Ek__BackingField_18(bool value)
	{
		___U3CuseLegacyMeshGenerationU3Ek__BackingField_18 = value;
	}
};

struct Graphic_t3934133196_StaticFields
{
public:
	// UnityEngine.Material UnityEngine.UI.Graphic::s_DefaultUI
	Material_t3291338668 * ___s_DefaultUI_2;
	// UnityEngine.Texture2D UnityEngine.UI.Graphic::s_WhiteTexture
	Texture2D_t2124686394 * ___s_WhiteTexture_3;
	// UnityEngine.Mesh UnityEngine.UI.Graphic::s_Mesh
	Mesh_t4181844850 * ___s_Mesh_15;
	// UnityEngine.UI.VertexHelper UnityEngine.UI.Graphic::s_VertexHelper
	VertexHelper_t2100700447 * ___s_VertexHelper_16;

public:
	inline static int32_t get_offset_of_s_DefaultUI_2() { return static_cast<int32_t>(offsetof(Graphic_t3934133196_StaticFields, ___s_DefaultUI_2)); }
	inline Material_t3291338668 * get_s_DefaultUI_2() const { return ___s_DefaultUI_2; }
	inline Material_t3291338668 ** get_address_of_s_DefaultUI_2() { return &___s_DefaultUI_2; }
	inline void set_s_DefaultUI_2(Material_t3291338668 * value)
	{
		___s_DefaultUI_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_DefaultUI_2), value);
	}

	inline static int32_t get_offset_of_s_WhiteTexture_3() { return static_cast<int32_t>(offsetof(Graphic_t3934133196_StaticFields, ___s_WhiteTexture_3)); }
	inline Texture2D_t2124686394 * get_s_WhiteTexture_3() const { return ___s_WhiteTexture_3; }
	inline Texture2D_t2124686394 ** get_address_of_s_WhiteTexture_3() { return &___s_WhiteTexture_3; }
	inline void set_s_WhiteTexture_3(Texture2D_t2124686394 * value)
	{
		___s_WhiteTexture_3 = value;
		Il2CppCodeGenWriteBarrier((&___s_WhiteTexture_3), value);
	}

	inline static int32_t get_offset_of_s_Mesh_15() { return static_cast<int32_t>(offsetof(Graphic_t3934133196_StaticFields, ___s_Mesh_15)); }
	inline Mesh_t4181844850 * get_s_Mesh_15() const { return ___s_Mesh_15; }
	inline Mesh_t4181844850 ** get_address_of_s_Mesh_15() { return &___s_Mesh_15; }
	inline void set_s_Mesh_15(Mesh_t4181844850 * value)
	{
		___s_Mesh_15 = value;
		Il2CppCodeGenWriteBarrier((&___s_Mesh_15), value);
	}

	inline static int32_t get_offset_of_s_VertexHelper_16() { return static_cast<int32_t>(offsetof(Graphic_t3934133196_StaticFields, ___s_VertexHelper_16)); }
	inline VertexHelper_t2100700447 * get_s_VertexHelper_16() const { return ___s_VertexHelper_16; }
	inline VertexHelper_t2100700447 ** get_address_of_s_VertexHelper_16() { return &___s_VertexHelper_16; }
	inline void set_s_VertexHelper_16(VertexHelper_t2100700447 * value)
	{
		___s_VertexHelper_16 = value;
		Il2CppCodeGenWriteBarrier((&___s_VertexHelper_16), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRAPHIC_T3934133196_H
#ifndef MASKABLEGRAPHIC_T829384950_H
#define MASKABLEGRAPHIC_T829384950_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.MaskableGraphic
struct  MaskableGraphic_t829384950  : public Graphic_t3934133196
{
public:
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculateStencil
	bool ___m_ShouldRecalculateStencil_19;
	// UnityEngine.Material UnityEngine.UI.MaskableGraphic::m_MaskMaterial
	Material_t3291338668 * ___m_MaskMaterial_20;
	// UnityEngine.UI.RectMask2D UnityEngine.UI.MaskableGraphic::m_ParentMask
	RectMask2D_t2940363972 * ___m_ParentMask_21;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_Maskable
	bool ___m_Maskable_22;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_IncludeForMasking
	bool ___m_IncludeForMasking_23;
	// UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::m_OnCullStateChanged
	CullStateChangedEvent_t3112771094 * ___m_OnCullStateChanged_24;
	// System.Boolean UnityEngine.UI.MaskableGraphic::m_ShouldRecalculate
	bool ___m_ShouldRecalculate_25;
	// System.Int32 UnityEngine.UI.MaskableGraphic::m_StencilValue
	int32_t ___m_StencilValue_26;
	// UnityEngine.Vector3[] UnityEngine.UI.MaskableGraphic::m_Corners
	Vector3U5BU5D_t474529388* ___m_Corners_27;

public:
	inline static int32_t get_offset_of_m_ShouldRecalculateStencil_19() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_ShouldRecalculateStencil_19)); }
	inline bool get_m_ShouldRecalculateStencil_19() const { return ___m_ShouldRecalculateStencil_19; }
	inline bool* get_address_of_m_ShouldRecalculateStencil_19() { return &___m_ShouldRecalculateStencil_19; }
	inline void set_m_ShouldRecalculateStencil_19(bool value)
	{
		___m_ShouldRecalculateStencil_19 = value;
	}

	inline static int32_t get_offset_of_m_MaskMaterial_20() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_MaskMaterial_20)); }
	inline Material_t3291338668 * get_m_MaskMaterial_20() const { return ___m_MaskMaterial_20; }
	inline Material_t3291338668 ** get_address_of_m_MaskMaterial_20() { return &___m_MaskMaterial_20; }
	inline void set_m_MaskMaterial_20(Material_t3291338668 * value)
	{
		___m_MaskMaterial_20 = value;
		Il2CppCodeGenWriteBarrier((&___m_MaskMaterial_20), value);
	}

	inline static int32_t get_offset_of_m_ParentMask_21() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_ParentMask_21)); }
	inline RectMask2D_t2940363972 * get_m_ParentMask_21() const { return ___m_ParentMask_21; }
	inline RectMask2D_t2940363972 ** get_address_of_m_ParentMask_21() { return &___m_ParentMask_21; }
	inline void set_m_ParentMask_21(RectMask2D_t2940363972 * value)
	{
		___m_ParentMask_21 = value;
		Il2CppCodeGenWriteBarrier((&___m_ParentMask_21), value);
	}

	inline static int32_t get_offset_of_m_Maskable_22() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_Maskable_22)); }
	inline bool get_m_Maskable_22() const { return ___m_Maskable_22; }
	inline bool* get_address_of_m_Maskable_22() { return &___m_Maskable_22; }
	inline void set_m_Maskable_22(bool value)
	{
		___m_Maskable_22 = value;
	}

	inline static int32_t get_offset_of_m_IncludeForMasking_23() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_IncludeForMasking_23)); }
	inline bool get_m_IncludeForMasking_23() const { return ___m_IncludeForMasking_23; }
	inline bool* get_address_of_m_IncludeForMasking_23() { return &___m_IncludeForMasking_23; }
	inline void set_m_IncludeForMasking_23(bool value)
	{
		___m_IncludeForMasking_23 = value;
	}

	inline static int32_t get_offset_of_m_OnCullStateChanged_24() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_OnCullStateChanged_24)); }
	inline CullStateChangedEvent_t3112771094 * get_m_OnCullStateChanged_24() const { return ___m_OnCullStateChanged_24; }
	inline CullStateChangedEvent_t3112771094 ** get_address_of_m_OnCullStateChanged_24() { return &___m_OnCullStateChanged_24; }
	inline void set_m_OnCullStateChanged_24(CullStateChangedEvent_t3112771094 * value)
	{
		___m_OnCullStateChanged_24 = value;
		Il2CppCodeGenWriteBarrier((&___m_OnCullStateChanged_24), value);
	}

	inline static int32_t get_offset_of_m_ShouldRecalculate_25() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_ShouldRecalculate_25)); }
	inline bool get_m_ShouldRecalculate_25() const { return ___m_ShouldRecalculate_25; }
	inline bool* get_address_of_m_ShouldRecalculate_25() { return &___m_ShouldRecalculate_25; }
	inline void set_m_ShouldRecalculate_25(bool value)
	{
		___m_ShouldRecalculate_25 = value;
	}

	inline static int32_t get_offset_of_m_StencilValue_26() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_StencilValue_26)); }
	inline int32_t get_m_StencilValue_26() const { return ___m_StencilValue_26; }
	inline int32_t* get_address_of_m_StencilValue_26() { return &___m_StencilValue_26; }
	inline void set_m_StencilValue_26(int32_t value)
	{
		___m_StencilValue_26 = value;
	}

	inline static int32_t get_offset_of_m_Corners_27() { return static_cast<int32_t>(offsetof(MaskableGraphic_t829384950, ___m_Corners_27)); }
	inline Vector3U5BU5D_t474529388* get_m_Corners_27() const { return ___m_Corners_27; }
	inline Vector3U5BU5D_t474529388** get_address_of_m_Corners_27() { return &___m_Corners_27; }
	inline void set_m_Corners_27(Vector3U5BU5D_t474529388* value)
	{
		___m_Corners_27 = value;
		Il2CppCodeGenWriteBarrier((&___m_Corners_27), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MASKABLEGRAPHIC_T829384950_H
#ifndef TEXT_T40276147_H
#define TEXT_T40276147_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Text
struct  Text_t40276147  : public MaskableGraphic_t829384950
{
public:
	// UnityEngine.UI.FontData UnityEngine.UI.Text::m_FontData
	FontData_t4127961031 * ___m_FontData_28;
	// System.String UnityEngine.UI.Text::m_Text
	String_t* ___m_Text_29;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCache
	TextGenerator_t1782103222 * ___m_TextCache_30;
	// UnityEngine.TextGenerator UnityEngine.UI.Text::m_TextCacheForLayout
	TextGenerator_t1782103222 * ___m_TextCacheForLayout_31;
	// System.Boolean UnityEngine.UI.Text::m_DisableFontTextureRebuiltCallback
	bool ___m_DisableFontTextureRebuiltCallback_33;
	// UnityEngine.UIVertex[] UnityEngine.UI.Text::m_TempVerts
	UIVertexU5BU5D_t388795096* ___m_TempVerts_34;

public:
	inline static int32_t get_offset_of_m_FontData_28() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_FontData_28)); }
	inline FontData_t4127961031 * get_m_FontData_28() const { return ___m_FontData_28; }
	inline FontData_t4127961031 ** get_address_of_m_FontData_28() { return &___m_FontData_28; }
	inline void set_m_FontData_28(FontData_t4127961031 * value)
	{
		___m_FontData_28 = value;
		Il2CppCodeGenWriteBarrier((&___m_FontData_28), value);
	}

	inline static int32_t get_offset_of_m_Text_29() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_Text_29)); }
	inline String_t* get_m_Text_29() const { return ___m_Text_29; }
	inline String_t** get_address_of_m_Text_29() { return &___m_Text_29; }
	inline void set_m_Text_29(String_t* value)
	{
		___m_Text_29 = value;
		Il2CppCodeGenWriteBarrier((&___m_Text_29), value);
	}

	inline static int32_t get_offset_of_m_TextCache_30() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_TextCache_30)); }
	inline TextGenerator_t1782103222 * get_m_TextCache_30() const { return ___m_TextCache_30; }
	inline TextGenerator_t1782103222 ** get_address_of_m_TextCache_30() { return &___m_TextCache_30; }
	inline void set_m_TextCache_30(TextGenerator_t1782103222 * value)
	{
		___m_TextCache_30 = value;
		Il2CppCodeGenWriteBarrier((&___m_TextCache_30), value);
	}

	inline static int32_t get_offset_of_m_TextCacheForLayout_31() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_TextCacheForLayout_31)); }
	inline TextGenerator_t1782103222 * get_m_TextCacheForLayout_31() const { return ___m_TextCacheForLayout_31; }
	inline TextGenerator_t1782103222 ** get_address_of_m_TextCacheForLayout_31() { return &___m_TextCacheForLayout_31; }
	inline void set_m_TextCacheForLayout_31(TextGenerator_t1782103222 * value)
	{
		___m_TextCacheForLayout_31 = value;
		Il2CppCodeGenWriteBarrier((&___m_TextCacheForLayout_31), value);
	}

	inline static int32_t get_offset_of_m_DisableFontTextureRebuiltCallback_33() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_DisableFontTextureRebuiltCallback_33)); }
	inline bool get_m_DisableFontTextureRebuiltCallback_33() const { return ___m_DisableFontTextureRebuiltCallback_33; }
	inline bool* get_address_of_m_DisableFontTextureRebuiltCallback_33() { return &___m_DisableFontTextureRebuiltCallback_33; }
	inline void set_m_DisableFontTextureRebuiltCallback_33(bool value)
	{
		___m_DisableFontTextureRebuiltCallback_33 = value;
	}

	inline static int32_t get_offset_of_m_TempVerts_34() { return static_cast<int32_t>(offsetof(Text_t40276147, ___m_TempVerts_34)); }
	inline UIVertexU5BU5D_t388795096* get_m_TempVerts_34() const { return ___m_TempVerts_34; }
	inline UIVertexU5BU5D_t388795096** get_address_of_m_TempVerts_34() { return &___m_TempVerts_34; }
	inline void set_m_TempVerts_34(UIVertexU5BU5D_t388795096* value)
	{
		___m_TempVerts_34 = value;
		Il2CppCodeGenWriteBarrier((&___m_TempVerts_34), value);
	}
};

struct Text_t40276147_StaticFields
{
public:
	// UnityEngine.Material UnityEngine.UI.Text::s_DefaultText
	Material_t3291338668 * ___s_DefaultText_32;

public:
	inline static int32_t get_offset_of_s_DefaultText_32() { return static_cast<int32_t>(offsetof(Text_t40276147_StaticFields, ___s_DefaultText_32)); }
	inline Material_t3291338668 * get_s_DefaultText_32() const { return ___s_DefaultText_32; }
	inline Material_t3291338668 ** get_address_of_s_DefaultText_32() { return &___s_DefaultText_32; }
	inline void set_s_DefaultText_32(Material_t3291338668 * value)
	{
		___s_DefaultText_32 = value;
		Il2CppCodeGenWriteBarrier((&___s_DefaultText_32), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXT_T40276147_H
// System.Object[]
struct ObjectU5BU5D_t44479575  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) RuntimeObject * m_Items[1];

public:
	inline RuntimeObject * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline RuntimeObject * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Char[]
struct CharU5BU5D_t2772155777  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Il2CppChar m_Items[1];

public:
	inline Il2CppChar GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Il2CppChar value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Il2CppChar GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Il2CppChar* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Il2CppChar value)
	{
		m_Items[index] = value;
	}
};


// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::.ctor()
extern "C"  void Dictionary_2__ctor_m1284123895_gshared (Dictionary_2_t1240487894 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::set_Item(!0,!1)
extern "C"  void Dictionary_2_set_Item_m3681439085_gshared (Dictionary_2_t1240487894 * __this, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
extern "C"  void List_1__ctor_m663654418_gshared (List_1_t2793634595 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
extern "C"  void List_1_Add_m3949004397_gshared (List_1_t2793634595 * __this, RuntimeObject * p0, const RuntimeMethod* method);

// System.Void UnityEngine.MonoBehaviour::.ctor()
extern "C"  void MonoBehaviour__ctor_m3327344375 (MonoBehaviour_t2760964972 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator LocationManager::UpdateLocation()
extern "C"  RuntimeObject* LocationManager_UpdateLocation_m1247828680 (LocationManager_t1045714622 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.Collections.IEnumerator)
extern "C"  Coroutine_t3971565922 * MonoBehaviour_StartCoroutine_m3859071397 (MonoBehaviour_t2760964972 * __this, RuntimeObject* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void LocationManager/<GetLocation>c__Iterator0::.ctor()
extern "C"  void U3CGetLocationU3Ec__Iterator0__ctor_m1912280627 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void LocationManager/<UpdateLocation>c__Iterator1::.ctor()
extern "C"  void U3CUpdateLocationU3Ec__Iterator1__ctor_m1848894950 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void LocationManager/<CountryFinder>c__Iterator2::.ctor()
extern "C"  void U3CCountryFinderU3Ec__Iterator2__ctor_m578644067 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Object::.ctor()
extern "C"  void Object__ctor_m1779107153 (RuntimeObject * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.String::Concat(System.Object[])
extern "C"  String_t* String_Concat_m1999039743 (RuntimeObject * __this /* static, unused */, ObjectU5BU5D_t44479575* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.WWW::.ctor(System.String)
extern "C"  void WWW__ctor_m1793313911 (WWW_t3457365752 * __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String UnityEngine.WWW::get_error()
extern "C"  String_t* WWW_get_error_m123222901 (WWW_t3457365752 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Xml.XmlDocument::.ctor()
extern "C"  void XmlDocument__ctor_m1169653672 (XmlDocument_t2296465371 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String UnityEngine.WWW::get_text()
extern "C"  String_t* WWW_get_text_m3960128873 (WWW_t3457365752 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.String::op_Inequality(System.String,System.String)
extern "C"  bool String_op_Inequality_m2292061380 (RuntimeObject * __this /* static, unused */, String_t* p0, String_t* p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.String::op_Equality(System.String,System.String)
extern "C"  bool String_op_Equality_m111603488 (RuntimeObject * __this /* static, unused */, String_t* p0, String_t* p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.NotSupportedException::.ctor()
extern "C"  void NotSupportedException__ctor_m445714413 (NotSupportedException_t962022136 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.WaitForSeconds::.ctor(System.Single)
extern "C"  void WaitForSeconds__ctor_m2270396794 (WaitForSeconds_t3313172267 * __this, float p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityEngine.WWW::get_isDone()
extern "C"  bool WWW_get_isDone_m1549697968 (WWW_t3457365752 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Object MiniJSON.Json::Deserialize(System.String)
extern "C"  RuntimeObject * Json_Deserialize_m2068364051 (RuntimeObject * __this /* static, unused */, String_t* ___json0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.LocationService UnityEngine.Input::get_location()
extern "C"  LocationService_t3005160692 * Input_get_location_m860675512 (RuntimeObject * __this /* static, unused */, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean UnityEngine.LocationService::get_isEnabledByUser()
extern "C"  bool LocationService_get_isEnabledByUser_m3183591938 (LocationService_t3005160692 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.LocationService::Start()
extern "C"  void LocationService_Start_m1958309970 (LocationService_t3005160692 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.LocationServiceStatus UnityEngine.LocationService::get_status()
extern "C"  int32_t LocationService_get_status_m3061476903 (LocationService_t3005160692 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.MonoBehaviour::print(System.Object)
extern "C"  void MonoBehaviour_print_m3614892973 (RuntimeObject * __this /* static, unused */, RuntimeObject * p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// UnityEngine.LocationInfo UnityEngine.LocationService::get_lastData()
extern "C"  LocationInfo_t2252625205  LocationService_get_lastData_m783021853 (LocationService_t3005160692 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Single UnityEngine.LocationInfo::get_latitude()
extern "C"  float LocationInfo_get_latitude_m1323945308 (LocationInfo_t2252625205 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Single UnityEngine.LocationInfo::get_longitude()
extern "C"  float LocationInfo_get_longitude_m2885248382 (LocationInfo_t2252625205 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Collections.IEnumerator LocationManager::CountryFinder()
extern "C"  RuntimeObject* LocationManager_CountryFinder_m684489686 (LocationManager_t1045714622 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.String::Concat(System.Object,System.Object)
extern "C"  String_t* String_Concat_m2643176368 (RuntimeObject * __this /* static, unused */, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void UnityEngine.LocationService::Stop()
extern "C"  void LocationService_Stop_m2541778892 (LocationService_t3005160692 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Object MiniJSON.Json/Parser::Parse(System.String)
extern "C"  RuntimeObject * Parser_Parse_m3352628348 (RuntimeObject * __this /* static, unused */, String_t* ___jsonString0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String MiniJSON.Json/Serializer::Serialize(System.Object)
extern "C"  String_t* Serializer_Serialize_m2381363365 (RuntimeObject * __this /* static, unused */, RuntimeObject * ___obj0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.IO.StringReader::.ctor(System.String)
extern "C"  void StringReader__ctor_m2445074759 (StringReader_t1790093495 * __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.Char::IsWhiteSpace(System.Char)
extern "C"  bool Char_IsWhiteSpace_m4026687856 (RuntimeObject * __this /* static, unused */, Il2CppChar p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Int32 System.String::IndexOf(System.Char)
extern "C"  int32_t String_IndexOf_m1323122632 (String_t* __this, Il2CppChar p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Parser::.ctor(System.String)
extern "C"  void Parser__ctor_m3660599834 (Parser_t815916342 * __this, String_t* ___jsonString0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Object MiniJSON.Json/Parser::ParseValue()
extern "C"  RuntimeObject * Parser_ParseValue_m2804928984 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.IO.TextReader::Dispose()
extern "C"  void TextReader_Dispose_m1191826538 (TextReader_t1750538733 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Object>::.ctor()
#define Dictionary_2__ctor_m2414048597(__this, method) ((  void (*) (Dictionary_2_t1100919678 *, const RuntimeMethod*))Dictionary_2__ctor_m1284123895_gshared)(__this, method)
// MiniJSON.Json/Parser/TOKEN MiniJSON.Json/Parser::get_NextToken()
extern "C"  int32_t Parser_get_NextToken_m1111924718 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String MiniJSON.Json/Parser::ParseString()
extern "C"  String_t* Parser_ParseString_m333155029 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Collections.Generic.Dictionary`2<System.String,System.Object>::set_Item(!0,!1)
#define Dictionary_2_set_Item_m831255642(__this, p0, p1, method) ((  void (*) (Dictionary_2_t1100919678 *, String_t*, RuntimeObject *, const RuntimeMethod*))Dictionary_2_set_Item_m3681439085_gshared)(__this, p0, p1, method)
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
#define List_1__ctor_m663654418(__this, method) ((  void (*) (List_1_t2793634595 *, const RuntimeMethod*))List_1__ctor_m663654418_gshared)(__this, method)
// System.Object MiniJSON.Json/Parser::ParseByToken(MiniJSON.Json/Parser/TOKEN)
extern "C"  RuntimeObject * Parser_ParseByToken_m3441831680 (Parser_t815916342 * __this, int32_t ___token0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
#define List_1_Add_m3949004397(__this, p0, method) ((  void (*) (List_1_t2793634595 *, RuntimeObject *, const RuntimeMethod*))List_1_Add_m3949004397_gshared)(__this, p0, method)
// System.Object MiniJSON.Json/Parser::ParseNumber()
extern "C"  RuntimeObject * Parser_ParseNumber_m2705113073 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Collections.Generic.Dictionary`2<System.String,System.Object> MiniJSON.Json/Parser::ParseObject()
extern "C"  Dictionary_2_t1100919678 * Parser_ParseObject_m397767350 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Collections.Generic.List`1<System.Object> MiniJSON.Json/Parser::ParseArray()
extern "C"  List_1_t2793634595 * Parser_ParseArray_m3427778883 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void System.Text.StringBuilder::.ctor()
extern "C"  void StringBuilder__ctor_m381491034 (StringBuilder_t1854403953 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Char MiniJSON.Json/Parser::get_NextChar()
extern "C"  Il2CppChar Parser_get_NextChar_m1876461300 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.Char)
extern "C"  StringBuilder_t1854403953 * StringBuilder_Append_m2231235818 (StringBuilder_t1854403953 * __this, Il2CppChar p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.String::CreateString(System.Char[])
extern "C"  String_t* String_CreateString_m3557769859 (String_t* __this, CharU5BU5D_t2772155777* ___val0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Int32 System.Convert::ToInt32(System.String,System.Int32)
extern "C"  int32_t Convert_ToInt32_m1168689724 (RuntimeObject * __this /* static, unused */, String_t* p0, int32_t p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String MiniJSON.Json/Parser::get_NextWord()
extern "C"  String_t* Parser_get_NextWord_m2710760689 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.Int64::TryParse(System.String,System.Int64&)
extern "C"  bool Int64_TryParse_m3337598207 (RuntimeObject * __this /* static, unused */, String_t* p0, int64_t* p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean System.Double::TryParse(System.String,System.Double&)
extern "C"  bool Double_TryParse_m297924056 (RuntimeObject * __this /* static, unused */, String_t* p0, double* p1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Char MiniJSON.Json/Parser::get_PeekChar()
extern "C"  Il2CppChar Parser_get_PeekChar_m3819133206 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Char System.Convert::ToChar(System.Int32)
extern "C"  Il2CppChar Convert_ToChar_m4166941018 (RuntimeObject * __this /* static, unused */, int32_t p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Boolean MiniJSON.Json/Parser::IsWordBreak(System.Char)
extern "C"  bool Parser_IsWordBreak_m674601368 (RuntimeObject * __this /* static, unused */, Il2CppChar ___c0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Parser::EatWhitespace()
extern "C"  void Parser_EatWhitespace_m4203669877 (Parser_t815916342 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::.ctor()
extern "C"  void Serializer__ctor_m1021995128 (Serializer_t3957605795 * __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::SerializeValue(System.Object)
extern "C"  void Serializer_SerializeValue_m766562738 (Serializer_t3957605795 * __this, RuntimeObject * ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.String)
extern "C"  StringBuilder_t1854403953 * StringBuilder_Append_m2042828374 (StringBuilder_t1854403953 * __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::SerializeString(System.String)
extern "C"  void Serializer_SerializeString_m1354220936 (Serializer_t3957605795 * __this, String_t* ___str0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::SerializeArray(System.Collections.IList)
extern "C"  void Serializer_SerializeArray_m3445866376 (Serializer_t3957605795 * __this, RuntimeObject* ___anArray0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::SerializeObject(System.Collections.IDictionary)
extern "C"  void Serializer_SerializeObject_m4019526216 (Serializer_t3957605795 * __this, RuntimeObject* ___obj0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.String::CreateString(System.Char,System.Int32)
extern "C"  String_t* String_CreateString_m52651688 (String_t* __this, Il2CppChar ___c0, int32_t ___count1, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Void MiniJSON.Json/Serializer::SerializeOther(System.Object)
extern "C"  void Serializer_SerializeOther_m1072816231 (Serializer_t3957605795 * __this, RuntimeObject * ___value0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Char[] System.String::ToCharArray()
extern "C"  CharU5BU5D_t2772155777* String_ToCharArray_m1352704103 (String_t* __this, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Int32 System.Convert::ToInt32(System.Char)
extern "C"  int32_t Convert_ToInt32_m3802300207 (RuntimeObject * __this /* static, unused */, Il2CppChar p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.Int32::ToString(System.String)
extern "C"  String_t* Int32_ToString_m1740000633 (int32_t* __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.Single::ToString(System.String)
extern "C"  String_t* Single_ToString_m1218876293 (float* __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.Object)
extern "C"  StringBuilder_t1854403953 * StringBuilder_Append_m2336619298 (StringBuilder_t1854403953 * __this, RuntimeObject * p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.Double System.Convert::ToDouble(System.Object)
extern "C"  double Convert_ToDouble_m2428222768 (RuntimeObject * __this /* static, unused */, RuntimeObject * p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
// System.String System.Double::ToString(System.String)
extern "C"  String_t* Double_ToString_m476927511 (double* __this, String_t* p0, const RuntimeMethod* method) IL2CPP_METHOD_ATTR;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void LocationManager::.ctor()
extern "C"  void LocationManager__ctor_m643169906 (LocationManager_t1045714622 * __this, const RuntimeMethod* method)
{
	{
		MonoBehaviour__ctor_m3327344375(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void LocationManager::Start()
extern "C"  void LocationManager_Start_m2386626789 (LocationManager_t1045714622 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = LocationManager_UpdateLocation_m1247828680(__this, /*hidden argument*/NULL);
		MonoBehaviour_StartCoroutine_m3859071397(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void LocationManager::Update()
extern "C"  void LocationManager_Update_m916350078 (LocationManager_t1045714622 * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Collections.IEnumerator LocationManager::GetLocation(System.String)
extern "C"  RuntimeObject* LocationManager_GetLocation_m2276540142 (LocationManager_t1045714622 * __this, String_t* ___ip0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocationManager_GetLocation_m2276540142_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CGetLocationU3Ec__Iterator0_t1376318408 * V_0 = NULL;
	{
		U3CGetLocationU3Ec__Iterator0_t1376318408 * L_0 = (U3CGetLocationU3Ec__Iterator0_t1376318408 *)il2cpp_codegen_object_new(U3CGetLocationU3Ec__Iterator0_t1376318408_il2cpp_TypeInfo_var);
		U3CGetLocationU3Ec__Iterator0__ctor_m1912280627(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		U3CGetLocationU3Ec__Iterator0_t1376318408 * L_1 = V_0;
		NullCheck(L_1);
		L_1->set_U24this_2(__this);
		U3CGetLocationU3Ec__Iterator0_t1376318408 * L_2 = V_0;
		return L_2;
	}
}
// System.Collections.IEnumerator LocationManager::UpdateLocation()
extern "C"  RuntimeObject* LocationManager_UpdateLocation_m1247828680 (LocationManager_t1045714622 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocationManager_UpdateLocation_m1247828680_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CUpdateLocationU3Ec__Iterator1_t452027185 * V_0 = NULL;
	{
		U3CUpdateLocationU3Ec__Iterator1_t452027185 * L_0 = (U3CUpdateLocationU3Ec__Iterator1_t452027185 *)il2cpp_codegen_object_new(U3CUpdateLocationU3Ec__Iterator1_t452027185_il2cpp_TypeInfo_var);
		U3CUpdateLocationU3Ec__Iterator1__ctor_m1848894950(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		U3CUpdateLocationU3Ec__Iterator1_t452027185 * L_1 = V_0;
		NullCheck(L_1);
		L_1->set_U24this_1(__this);
		U3CUpdateLocationU3Ec__Iterator1_t452027185 * L_2 = V_0;
		return L_2;
	}
}
// System.Collections.IEnumerator LocationManager::CountryFinder()
extern "C"  RuntimeObject* LocationManager_CountryFinder_m684489686 (LocationManager_t1045714622 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocationManager_CountryFinder_m684489686_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	U3CCountryFinderU3Ec__Iterator2_t1350621332 * V_0 = NULL;
	{
		U3CCountryFinderU3Ec__Iterator2_t1350621332 * L_0 = (U3CCountryFinderU3Ec__Iterator2_t1350621332 *)il2cpp_codegen_object_new(U3CCountryFinderU3Ec__Iterator2_t1350621332_il2cpp_TypeInfo_var);
		U3CCountryFinderU3Ec__Iterator2__ctor_m578644067(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		U3CCountryFinderU3Ec__Iterator2_t1350621332 * L_1 = V_0;
		NullCheck(L_1);
		L_1->set_U24this_6(__this);
		U3CCountryFinderU3Ec__Iterator2_t1350621332 * L_2 = V_0;
		return L_2;
	}
}
// System.Void LocationManager/<CountryFinder>c__Iterator2::.ctor()
extern "C"  void U3CCountryFinderU3Ec__Iterator2__ctor_m578644067 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m1779107153(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean LocationManager/<CountryFinder>c__Iterator2::MoveNext()
extern "C"  bool U3CCountryFinderU3Ec__Iterator2_MoveNext_m1722769358 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCountryFinderU3Ec__Iterator2_MoveNext_m1722769358_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	XmlNode_t482051342 * V_1 = NULL;
	XmlNode_t482051342 * V_2 = NULL;
	RuntimeObject* V_3 = NULL;
	RuntimeObject* V_4 = NULL;
	RuntimeObject* V_5 = NULL;
	Exception_t3056413322 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t3056413322 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		int32_t L_0 = __this->get_U24PC_9();
		V_0 = L_0;
		__this->set_U24PC_9((-1));
		uint32_t L_1 = V_0;
		switch (L_1)
		{
			case 0:
			{
				goto IL_0021;
			}
			case 1:
			{
				goto IL_0095;
			}
		}
	}
	{
		goto IL_026c;
	}

IL_0021:
	{
		ObjectU5BU5D_t44479575* L_2 = ((ObjectU5BU5D_t44479575*)SZArrayNew(ObjectU5BU5D_t44479575_il2cpp_TypeInfo_var, (uint32_t)5));
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, _stringLiteral1369038755);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (RuntimeObject *)_stringLiteral1369038755);
		ObjectU5BU5D_t44479575* L_3 = L_2;
		LocationManager_t1045714622 * L_4 = __this->get_U24this_6();
		NullCheck(L_4);
		float L_5 = L_4->get_lat_2();
		float L_6 = L_5;
		RuntimeObject * L_7 = Box(Single_t2594644343_il2cpp_TypeInfo_var, &L_6);
		NullCheck(L_3);
		ArrayElementTypeCheck (L_3, L_7);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(1), (RuntimeObject *)L_7);
		ObjectU5BU5D_t44479575* L_8 = L_3;
		NullCheck(L_8);
		ArrayElementTypeCheck (L_8, _stringLiteral1045399521);
		(L_8)->SetAt(static_cast<il2cpp_array_size_t>(2), (RuntimeObject *)_stringLiteral1045399521);
		ObjectU5BU5D_t44479575* L_9 = L_8;
		LocationManager_t1045714622 * L_10 = __this->get_U24this_6();
		NullCheck(L_10);
		float L_11 = L_10->get_lng_3();
		float L_12 = L_11;
		RuntimeObject * L_13 = Box(Single_t2594644343_il2cpp_TypeInfo_var, &L_12);
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_13);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(3), (RuntimeObject *)L_13);
		ObjectU5BU5D_t44479575* L_14 = L_9;
		NullCheck(L_14);
		ArrayElementTypeCheck (L_14, _stringLiteral626003391);
		(L_14)->SetAt(static_cast<il2cpp_array_size_t>(4), (RuntimeObject *)_stringLiteral626003391);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_15 = String_Concat_m1999039743(NULL /*static, unused*/, L_14, /*hidden argument*/NULL);
		WWW_t3457365752 * L_16 = (WWW_t3457365752 *)il2cpp_codegen_object_new(WWW_t3457365752_il2cpp_TypeInfo_var);
		WWW__ctor_m1793313911(L_16, L_15, /*hidden argument*/NULL);
		__this->set_U3CwwwU3E__0_0(L_16);
		WWW_t3457365752 * L_17 = __this->get_U3CwwwU3E__0_0();
		__this->set_U24current_7(L_17);
		bool L_18 = __this->get_U24disposing_8();
		if (L_18)
		{
			goto IL_0090;
		}
	}
	{
		__this->set_U24PC_9(1);
	}

IL_0090:
	{
		goto IL_026e;
	}

IL_0095:
	{
		WWW_t3457365752 * L_19 = __this->get_U3CwwwU3E__0_0();
		NullCheck(L_19);
		String_t* L_20 = WWW_get_error_m123222901(L_19, /*hidden argument*/NULL);
		if (!L_20)
		{
			goto IL_00aa;
		}
	}
	{
		goto IL_026c;
	}

IL_00aa:
	{
		XmlDocument_t2296465371 * L_21 = (XmlDocument_t2296465371 *)il2cpp_codegen_object_new(XmlDocument_t2296465371_il2cpp_TypeInfo_var);
		XmlDocument__ctor_m1169653672(L_21, /*hidden argument*/NULL);
		__this->set_U3CreverseGeocodeResultU3E__0_1(L_21);
		XmlDocument_t2296465371 * L_22 = __this->get_U3CreverseGeocodeResultU3E__0_1();
		WWW_t3457365752 * L_23 = __this->get_U3CwwwU3E__0_0();
		NullCheck(L_23);
		String_t* L_24 = WWW_get_text_m3960128873(L_23, /*hidden argument*/NULL);
		NullCheck(L_22);
		VirtActionInvoker1< String_t* >::Invoke(54 /* System.Void System.Xml.XmlDocument::LoadXml(System.String) */, L_22, L_24);
		XmlDocument_t2296465371 * L_25 = __this->get_U3CreverseGeocodeResultU3E__0_1();
		NullCheck(L_25);
		XmlNodeList_t1166152358 * L_26 = VirtFuncInvoker1< XmlNodeList_t1166152358 *, String_t* >::Invoke(51 /* System.Xml.XmlNodeList System.Xml.XmlDocument::GetElementsByTagName(System.String) */, L_25, _stringLiteral1627105707);
		NullCheck(L_26);
		XmlNode_t482051342 * L_27 = VirtFuncInvoker1< XmlNode_t482051342 *, int32_t >::Invoke(8 /* System.Xml.XmlNode System.Xml.XmlNodeList::Item(System.Int32) */, L_26, 0);
		NullCheck(L_27);
		XmlNodeList_t1166152358 * L_28 = VirtFuncInvoker0< XmlNodeList_t1166152358 * >::Invoke(9 /* System.Xml.XmlNodeList System.Xml.XmlNode::get_ChildNodes() */, L_27);
		NullCheck(L_28);
		XmlNode_t482051342 * L_29 = VirtFuncInvoker1< XmlNode_t482051342 *, int32_t >::Invoke(8 /* System.Xml.XmlNode System.Xml.XmlNodeList::Item(System.Int32) */, L_28, 0);
		NullCheck(L_29);
		String_t* L_30 = VirtFuncInvoker0< String_t* >::Invoke(24 /* System.String System.Xml.XmlNode::get_Value() */, L_29);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_31 = String_op_Inequality_m2292061380(NULL /*static, unused*/, L_30, _stringLiteral1186754903, /*hidden argument*/NULL);
		if (!L_31)
		{
			goto IL_0105;
		}
	}
	{
		goto IL_026c;
	}

IL_0105:
	{
		__this->set_U3CcountryCodeU3E__0_2((String_t*)NULL);
		__this->set_U3CcountryFoundU3E__0_3((bool)0);
		XmlDocument_t2296465371 * L_32 = __this->get_U3CreverseGeocodeResultU3E__0_1();
		NullCheck(L_32);
		XmlNodeList_t1166152358 * L_33 = VirtFuncInvoker1< XmlNodeList_t1166152358 *, String_t* >::Invoke(51 /* System.Xml.XmlNodeList System.Xml.XmlDocument::GetElementsByTagName(System.String) */, L_32, _stringLiteral2421942445);
		NullCheck(L_33);
		XmlNode_t482051342 * L_34 = VirtFuncInvoker1< XmlNode_t482051342 *, int32_t >::Invoke(8 /* System.Xml.XmlNode System.Xml.XmlNodeList::Item(System.Int32) */, L_33, 0);
		NullCheck(L_34);
		XmlNodeList_t1166152358 * L_35 = VirtFuncInvoker0< XmlNodeList_t1166152358 * >::Invoke(9 /* System.Xml.XmlNodeList System.Xml.XmlNode::get_ChildNodes() */, L_34);
		NullCheck(L_35);
		RuntimeObject* L_36 = VirtFuncInvoker0< RuntimeObject* >::Invoke(7 /* System.Collections.IEnumerator System.Xml.XmlNodeList::GetEnumerator() */, L_35);
		__this->set_U24locvar0_4(L_36);
	}

IL_0139:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0229;
		}

IL_013e:
		{
			RuntimeObject* L_37 = __this->get_U24locvar0_4();
			NullCheck(L_37);
			RuntimeObject * L_38 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_37);
			V_1 = ((XmlNode_t482051342 *)CastclassClass((RuntimeObject*)L_38, XmlNode_t482051342_il2cpp_TypeInfo_var));
			XmlNode_t482051342 * L_39 = V_1;
			NullCheck(L_39);
			String_t* L_40 = VirtFuncInvoker0< String_t* >::Invoke(16 /* System.String System.Xml.XmlNode::get_Name() */, L_39);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			bool L_41 = String_op_Equality_m111603488(NULL /*static, unused*/, L_40, _stringLiteral2310387594, /*hidden argument*/NULL);
			if (!L_41)
			{
				goto IL_0213;
			}
		}

IL_0164:
		{
			XmlNode_t482051342 * L_42 = V_1;
			NullCheck(L_42);
			XmlNodeList_t1166152358 * L_43 = VirtFuncInvoker0< XmlNodeList_t1166152358 * >::Invoke(9 /* System.Xml.XmlNodeList System.Xml.XmlNode::get_ChildNodes() */, L_42);
			NullCheck(L_43);
			RuntimeObject* L_44 = VirtFuncInvoker0< RuntimeObject* >::Invoke(7 /* System.Collections.IEnumerator System.Xml.XmlNodeList::GetEnumerator() */, L_43);
			V_3 = L_44;
		}

IL_0170:
		try
		{ // begin try (depth: 2)
			{
				goto IL_01dd;
			}

IL_0175:
			{
				RuntimeObject* L_45 = V_3;
				NullCheck(L_45);
				RuntimeObject * L_46 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_45);
				V_2 = ((XmlNode_t482051342 *)CastclassClass((RuntimeObject*)L_46, XmlNode_t482051342_il2cpp_TypeInfo_var));
				XmlNode_t482051342 * L_47 = V_2;
				NullCheck(L_47);
				String_t* L_48 = VirtFuncInvoker0< String_t* >::Invoke(16 /* System.String System.Xml.XmlNode::get_Name() */, L_47);
				IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
				bool L_49 = String_op_Equality_m111603488(NULL /*static, unused*/, L_48, _stringLiteral157952551, /*hidden argument*/NULL);
				if (!L_49)
				{
					goto IL_01a7;
				}
			}

IL_0196:
			{
				XmlNode_t482051342 * L_50 = V_2;
				NullCheck(L_50);
				XmlNode_t482051342 * L_51 = VirtFuncInvoker0< XmlNode_t482051342 * >::Invoke(10 /* System.Xml.XmlNode System.Xml.XmlNode::get_FirstChild() */, L_50);
				NullCheck(L_51);
				String_t* L_52 = VirtFuncInvoker0< String_t* >::Invoke(24 /* System.String System.Xml.XmlNode::get_Value() */, L_51);
				__this->set_U3CcountryCodeU3E__0_2(L_52);
			}

IL_01a7:
			{
				XmlNode_t482051342 * L_53 = V_2;
				NullCheck(L_53);
				String_t* L_54 = VirtFuncInvoker0< String_t* >::Invoke(16 /* System.String System.Xml.XmlNode::get_Name() */, L_53);
				IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
				bool L_55 = String_op_Equality_m111603488(NULL /*static, unused*/, L_54, _stringLiteral4195199491, /*hidden argument*/NULL);
				if (!L_55)
				{
					goto IL_01dd;
				}
			}

IL_01bc:
			{
				XmlNode_t482051342 * L_56 = V_2;
				NullCheck(L_56);
				XmlNode_t482051342 * L_57 = VirtFuncInvoker0< XmlNode_t482051342 * >::Invoke(10 /* System.Xml.XmlNode System.Xml.XmlNode::get_FirstChild() */, L_56);
				NullCheck(L_57);
				String_t* L_58 = VirtFuncInvoker0< String_t* >::Invoke(24 /* System.String System.Xml.XmlNode::get_Value() */, L_57);
				IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
				bool L_59 = String_op_Equality_m111603488(NULL /*static, unused*/, L_58, _stringLiteral70094325, /*hidden argument*/NULL);
				if (!L_59)
				{
					goto IL_01dd;
				}
			}

IL_01d6:
			{
				__this->set_U3CcountryFoundU3E__0_3((bool)1);
			}

IL_01dd:
			{
				RuntimeObject* L_60 = V_3;
				NullCheck(L_60);
				bool L_61 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_60);
				if (L_61)
				{
					goto IL_0175;
				}
			}

IL_01e8:
			{
				IL2CPP_LEAVE(0x203, FINALLY_01ed);
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__last_unhandled_exception = (Exception_t3056413322 *)e.ex;
			goto FINALLY_01ed;
		}

FINALLY_01ed:
		{ // begin finally (depth: 2)
			{
				RuntimeObject* L_62 = V_3;
				RuntimeObject* L_63 = ((RuntimeObject*)IsInst((RuntimeObject*)L_62, IDisposable_t242102151_il2cpp_TypeInfo_var));
				V_4 = L_63;
				if (!L_63)
				{
					goto IL_0202;
				}
			}

IL_01fb:
			{
				RuntimeObject* L_64 = V_4;
				NullCheck(L_64);
				InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t242102151_il2cpp_TypeInfo_var, L_64);
			}

IL_0202:
			{
				IL2CPP_END_FINALLY(493)
			}
		} // end finally (depth: 2)
		IL2CPP_CLEANUP(493)
		{
			IL2CPP_JUMP_TBL(0x203, IL_0203)
			IL2CPP_RETHROW_IF_UNHANDLED(Exception_t3056413322 *)
		}

IL_0203:
		{
			bool L_65 = __this->get_U3CcountryFoundU3E__0_3();
			if (!L_65)
			{
				goto IL_0213;
			}
		}

IL_020e:
		{
			goto IL_0239;
		}

IL_0213:
		{
			LocationManager_t1045714622 * L_66 = __this->get_U24this_6();
			NullCheck(L_66);
			Text_t40276147 * L_67 = L_66->get_countryText_6();
			String_t* L_68 = __this->get_U3CcountryCodeU3E__0_2();
			NullCheck(L_67);
			VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_67, L_68);
		}

IL_0229:
		{
			RuntimeObject* L_69 = __this->get_U24locvar0_4();
			NullCheck(L_69);
			bool L_70 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_69);
			if (L_70)
			{
				goto IL_013e;
			}
		}

IL_0239:
		{
			IL2CPP_LEAVE(0x265, FINALLY_023e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t3056413322 *)e.ex;
		goto FINALLY_023e;
	}

FINALLY_023e:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_71 = __this->get_U24locvar0_4();
			RuntimeObject* L_72 = ((RuntimeObject*)IsInst((RuntimeObject*)L_71, IDisposable_t242102151_il2cpp_TypeInfo_var));
			V_5 = L_72;
			__this->set_U24locvar1_5(L_72);
			RuntimeObject* L_73 = V_5;
			if (!L_73)
			{
				goto IL_0264;
			}
		}

IL_0259:
		{
			RuntimeObject* L_74 = __this->get_U24locvar1_5();
			NullCheck(L_74);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t242102151_il2cpp_TypeInfo_var, L_74);
		}

IL_0264:
		{
			IL2CPP_END_FINALLY(574)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(574)
	{
		IL2CPP_JUMP_TBL(0x265, IL_0265)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t3056413322 *)
	}

IL_0265:
	{
		__this->set_U24PC_9((-1));
	}

IL_026c:
	{
		return (bool)0;
	}

IL_026e:
	{
		return (bool)1;
	}
}
// System.Object LocationManager/<CountryFinder>c__Iterator2::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  RuntimeObject * U3CCountryFinderU3Ec__Iterator2_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3413674101 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_7();
		return L_0;
	}
}
// System.Object LocationManager/<CountryFinder>c__Iterator2::System.Collections.IEnumerator.get_Current()
extern "C"  RuntimeObject * U3CCountryFinderU3Ec__Iterator2_System_Collections_IEnumerator_get_Current_m897533116 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_7();
		return L_0;
	}
}
// System.Void LocationManager/<CountryFinder>c__Iterator2::Dispose()
extern "C"  void U3CCountryFinderU3Ec__Iterator2_Dispose_m2556735172 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	{
		__this->set_U24disposing_8((bool)1);
		__this->set_U24PC_9((-1));
		return;
	}
}
// System.Void LocationManager/<CountryFinder>c__Iterator2::Reset()
extern "C"  void U3CCountryFinderU3Ec__Iterator2_Reset_m1333130095 (U3CCountryFinderU3Ec__Iterator2_t1350621332 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CCountryFinderU3Ec__Iterator2_Reset_m1333130095_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t962022136 * L_0 = (NotSupportedException_t962022136 *)il2cpp_codegen_object_new(NotSupportedException_t962022136_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m445714413(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void LocationManager/<GetLocation>c__Iterator0::.ctor()
extern "C"  void U3CGetLocationU3Ec__Iterator0__ctor_m1912280627 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m1779107153(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean LocationManager/<GetLocation>c__Iterator0::MoveNext()
extern "C"  bool U3CGetLocationU3Ec__Iterator0_MoveNext_m1190961499 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CGetLocationU3Ec__Iterator0_MoveNext_m1190961499_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	{
		int32_t L_0 = __this->get_U24PC_5();
		V_0 = L_0;
		__this->set_U24PC_5((-1));
		uint32_t L_1 = V_0;
		switch (L_1)
		{
			case 0:
			{
				goto IL_0021;
			}
			case 1:
			{
				goto IL_005a;
			}
		}
	}
	{
		goto IL_00fb;
	}

IL_0021:
	{
		WWW_t3457365752 * L_2 = (WWW_t3457365752 *)il2cpp_codegen_object_new(WWW_t3457365752_il2cpp_TypeInfo_var);
		WWW__ctor_m1793313911(L_2, _stringLiteral155016173, /*hidden argument*/NULL);
		__this->set_U3CwwwU3E__0_0(L_2);
		goto IL_005a;
	}

IL_0036:
	{
		WaitForSeconds_t3313172267 * L_3 = (WaitForSeconds_t3313172267 *)il2cpp_codegen_object_new(WaitForSeconds_t3313172267_il2cpp_TypeInfo_var);
		WaitForSeconds__ctor_m2270396794(L_3, (2.0f), /*hidden argument*/NULL);
		__this->set_U24current_3(L_3);
		bool L_4 = __this->get_U24disposing_4();
		if (L_4)
		{
			goto IL_0055;
		}
	}
	{
		__this->set_U24PC_5(1);
	}

IL_0055:
	{
		goto IL_00fd;
	}

IL_005a:
	{
		WWW_t3457365752 * L_5 = __this->get_U3CwwwU3E__0_0();
		NullCheck(L_5);
		bool L_6 = WWW_get_isDone_m1549697968(L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0036;
		}
	}
	{
		WWW_t3457365752 * L_7 = __this->get_U3CwwwU3E__0_0();
		NullCheck(L_7);
		String_t* L_8 = WWW_get_text_m3960128873(L_7, /*hidden argument*/NULL);
		RuntimeObject * L_9 = Json_Deserialize_m2068364051(NULL /*static, unused*/, L_8, /*hidden argument*/NULL);
		__this->set_U3ClocInfoU3E__0_1(((RuntimeObject*)Castclass((RuntimeObject*)L_9, IDictionary_t1045075095_il2cpp_TypeInfo_var)));
		LocationManager_t1045714622 * L_10 = __this->get_U24this_2();
		NullCheck(L_10);
		Text_t40276147 * L_11 = L_10->get_latutudeText_4();
		RuntimeObject* L_12 = __this->get_U3ClocInfoU3E__0_1();
		NullCheck(L_12);
		RuntimeObject * L_13 = InterfaceFuncInvoker1< RuntimeObject *, RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IDictionary::get_Item(System.Object) */, IDictionary_t1045075095_il2cpp_TypeInfo_var, L_12, _stringLiteral996512338);
		NullCheck(L_13);
		String_t* L_14 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_13);
		NullCheck(L_11);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_11, L_14);
		LocationManager_t1045714622 * L_15 = __this->get_U24this_2();
		NullCheck(L_15);
		Text_t40276147 * L_16 = L_15->get_longitudeText_5();
		RuntimeObject* L_17 = __this->get_U3ClocInfoU3E__0_1();
		NullCheck(L_17);
		RuntimeObject * L_18 = InterfaceFuncInvoker1< RuntimeObject *, RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IDictionary::get_Item(System.Object) */, IDictionary_t1045075095_il2cpp_TypeInfo_var, L_17, _stringLiteral921067844);
		NullCheck(L_18);
		String_t* L_19 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_18);
		NullCheck(L_16);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_16, L_19);
		LocationManager_t1045714622 * L_20 = __this->get_U24this_2();
		NullCheck(L_20);
		Text_t40276147 * L_21 = L_20->get_countryText_6();
		RuntimeObject* L_22 = __this->get_U3ClocInfoU3E__0_1();
		NullCheck(L_22);
		RuntimeObject * L_23 = InterfaceFuncInvoker1< RuntimeObject *, RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IDictionary::get_Item(System.Object) */, IDictionary_t1045075095_il2cpp_TypeInfo_var, L_22, _stringLiteral1676475345);
		NullCheck(L_23);
		String_t* L_24 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_23);
		NullCheck(L_21);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_21, L_24);
		__this->set_U24PC_5((-1));
	}

IL_00fb:
	{
		return (bool)0;
	}

IL_00fd:
	{
		return (bool)1;
	}
}
// System.Object LocationManager/<GetLocation>c__Iterator0::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  RuntimeObject * U3CGetLocationU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2686495884 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_3();
		return L_0;
	}
}
// System.Object LocationManager/<GetLocation>c__Iterator0::System.Collections.IEnumerator.get_Current()
extern "C"  RuntimeObject * U3CGetLocationU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m992149979 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_3();
		return L_0;
	}
}
// System.Void LocationManager/<GetLocation>c__Iterator0::Dispose()
extern "C"  void U3CGetLocationU3Ec__Iterator0_Dispose_m2828404602 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	{
		__this->set_U24disposing_4((bool)1);
		__this->set_U24PC_5((-1));
		return;
	}
}
// System.Void LocationManager/<GetLocation>c__Iterator0::Reset()
extern "C"  void U3CGetLocationU3Ec__Iterator0_Reset_m1280529886 (U3CGetLocationU3Ec__Iterator0_t1376318408 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CGetLocationU3Ec__Iterator0_Reset_m1280529886_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t962022136 * L_0 = (NotSupportedException_t962022136 *)il2cpp_codegen_object_new(NotSupportedException_t962022136_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m445714413(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void LocationManager/<UpdateLocation>c__Iterator1::.ctor()
extern "C"  void U3CUpdateLocationU3Ec__Iterator1__ctor_m1848894950 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	{
		Object__ctor_m1779107153(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean LocationManager/<UpdateLocation>c__Iterator1::MoveNext()
extern "C"  bool U3CUpdateLocationU3Ec__Iterator1_MoveNext_m26832617 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CUpdateLocationU3Ec__Iterator1_MoveNext_m26832617_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	LocationInfo_t2252625205  V_1;
	memset(&V_1, 0, sizeof(V_1));
	LocationInfo_t2252625205  V_2;
	memset(&V_2, 0, sizeof(V_2));
	{
		int32_t L_0 = __this->get_U24PC_4();
		V_0 = L_0;
		__this->set_U24PC_4((-1));
		uint32_t L_1 = V_0;
		switch (L_1)
		{
			case 0:
			{
				goto IL_0021;
			}
			case 1:
			{
				goto IL_0070;
			}
		}
	}
	{
		goto IL_018a;
	}

IL_0021:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Input_t3034106849_il2cpp_TypeInfo_var);
		LocationService_t3005160692 * L_2 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_2);
		bool L_3 = LocationService_get_isEnabledByUser_m3183591938(L_2, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_0035;
		}
	}
	{
		goto IL_018a;
	}

IL_0035:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Input_t3034106849_il2cpp_TypeInfo_var);
		LocationService_t3005160692 * L_4 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_4);
		LocationService_Start_m1958309970(L_4, /*hidden argument*/NULL);
		__this->set_U3CmaxWaitU3E__0_0(((int32_t)20));
		goto IL_007e;
	}

IL_004c:
	{
		WaitForSeconds_t3313172267 * L_5 = (WaitForSeconds_t3313172267 *)il2cpp_codegen_object_new(WaitForSeconds_t3313172267_il2cpp_TypeInfo_var);
		WaitForSeconds__ctor_m2270396794(L_5, (1.0f), /*hidden argument*/NULL);
		__this->set_U24current_2(L_5);
		bool L_6 = __this->get_U24disposing_3();
		if (L_6)
		{
			goto IL_006b;
		}
	}
	{
		__this->set_U24PC_4(1);
	}

IL_006b:
	{
		goto IL_018c;
	}

IL_0070:
	{
		int32_t L_7 = __this->get_U3CmaxWaitU3E__0_0();
		__this->set_U3CmaxWaitU3E__0_0(((int32_t)((int32_t)L_7-(int32_t)1)));
	}

IL_007e:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Input_t3034106849_il2cpp_TypeInfo_var);
		LocationService_t3005160692 * L_8 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_8);
		int32_t L_9 = LocationService_get_status_m3061476903(L_8, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_9) == ((uint32_t)1))))
		{
			goto IL_009a;
		}
	}
	{
		int32_t L_10 = __this->get_U3CmaxWaitU3E__0_0();
		if ((((int32_t)L_10) > ((int32_t)0)))
		{
			goto IL_004c;
		}
	}

IL_009a:
	{
		int32_t L_11 = __this->get_U3CmaxWaitU3E__0_0();
		if ((((int32_t)L_11) >= ((int32_t)1)))
		{
			goto IL_00b5;
		}
	}
	{
		MonoBehaviour_print_m3614892973(NULL /*static, unused*/, _stringLiteral1338811556, /*hidden argument*/NULL);
		goto IL_018a;
	}

IL_00b5:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Input_t3034106849_il2cpp_TypeInfo_var);
		LocationService_t3005160692 * L_12 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_12);
		int32_t L_13 = LocationService_get_status_m3061476903(L_12, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_13) == ((uint32_t)3))))
		{
			goto IL_00d4;
		}
	}
	{
		MonoBehaviour_print_m3614892973(NULL /*static, unused*/, _stringLiteral2855806562, /*hidden argument*/NULL);
		goto IL_018a;
	}

IL_00d4:
	{
		LocationManager_t1045714622 * L_14 = __this->get_U24this_1();
		IL2CPP_RUNTIME_CLASS_INIT(Input_t3034106849_il2cpp_TypeInfo_var);
		LocationService_t3005160692 * L_15 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_15);
		LocationInfo_t2252625205  L_16 = LocationService_get_lastData_m783021853(L_15, /*hidden argument*/NULL);
		V_1 = L_16;
		float L_17 = LocationInfo_get_latitude_m1323945308((&V_1), /*hidden argument*/NULL);
		NullCheck(L_14);
		L_14->set_lat_2(L_17);
		LocationManager_t1045714622 * L_18 = __this->get_U24this_1();
		LocationService_t3005160692 * L_19 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_19);
		LocationInfo_t2252625205  L_20 = LocationService_get_lastData_m783021853(L_19, /*hidden argument*/NULL);
		V_2 = L_20;
		float L_21 = LocationInfo_get_longitude_m2885248382((&V_2), /*hidden argument*/NULL);
		NullCheck(L_18);
		L_18->set_lng_3(L_21);
		LocationManager_t1045714622 * L_22 = __this->get_U24this_1();
		LocationManager_t1045714622 * L_23 = __this->get_U24this_1();
		NullCheck(L_23);
		RuntimeObject* L_24 = LocationManager_CountryFinder_m684489686(L_23, /*hidden argument*/NULL);
		NullCheck(L_22);
		MonoBehaviour_StartCoroutine_m3859071397(L_22, L_24, /*hidden argument*/NULL);
		LocationManager_t1045714622 * L_25 = __this->get_U24this_1();
		NullCheck(L_25);
		Text_t40276147 * L_26 = L_25->get_latutudeText_4();
		LocationManager_t1045714622 * L_27 = __this->get_U24this_1();
		NullCheck(L_27);
		float L_28 = L_27->get_lat_2();
		float L_29 = L_28;
		RuntimeObject * L_30 = Box(Single_t2594644343_il2cpp_TypeInfo_var, &L_29);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_31 = String_Concat_m2643176368(NULL /*static, unused*/, _stringLiteral2753920706, L_30, /*hidden argument*/NULL);
		NullCheck(L_26);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_26, L_31);
		LocationManager_t1045714622 * L_32 = __this->get_U24this_1();
		NullCheck(L_32);
		Text_t40276147 * L_33 = L_32->get_longitudeText_5();
		LocationManager_t1045714622 * L_34 = __this->get_U24this_1();
		NullCheck(L_34);
		float L_35 = L_34->get_lng_3();
		float L_36 = L_35;
		RuntimeObject * L_37 = Box(Single_t2594644343_il2cpp_TypeInfo_var, &L_36);
		String_t* L_38 = String_Concat_m2643176368(NULL /*static, unused*/, _stringLiteral2613751440, L_37, /*hidden argument*/NULL);
		NullCheck(L_33);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_33, L_38);
		LocationService_t3005160692 * L_39 = Input_get_location_m860675512(NULL /*static, unused*/, /*hidden argument*/NULL);
		NullCheck(L_39);
		LocationService_Stop_m2541778892(L_39, /*hidden argument*/NULL);
		__this->set_U24PC_4((-1));
	}

IL_018a:
	{
		return (bool)0;
	}

IL_018c:
	{
		return (bool)1;
	}
}
// System.Object LocationManager/<UpdateLocation>c__Iterator1::System.Collections.Generic.IEnumerator<object>.get_Current()
extern "C"  RuntimeObject * U3CUpdateLocationU3Ec__Iterator1_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m1128389244 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_2();
		return L_0;
	}
}
// System.Object LocationManager/<UpdateLocation>c__Iterator1::System.Collections.IEnumerator.get_Current()
extern "C"  RuntimeObject * U3CUpdateLocationU3Ec__Iterator1_System_Collections_IEnumerator_get_Current_m99059253 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = __this->get_U24current_2();
		return L_0;
	}
}
// System.Void LocationManager/<UpdateLocation>c__Iterator1::Dispose()
extern "C"  void U3CUpdateLocationU3Ec__Iterator1_Dispose_m1362945086 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	{
		__this->set_U24disposing_3((bool)1);
		__this->set_U24PC_4((-1));
		return;
	}
}
// System.Void LocationManager/<UpdateLocation>c__Iterator1::Reset()
extern "C"  void U3CUpdateLocationU3Ec__Iterator1_Reset_m3119857850 (U3CUpdateLocationU3Ec__Iterator1_t452027185 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (U3CUpdateLocationU3Ec__Iterator1_Reset_m3119857850_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		NotSupportedException_t962022136 * L_0 = (NotSupportedException_t962022136 *)il2cpp_codegen_object_new(NotSupportedException_t962022136_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m445714413(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Object MiniJSON.Json::Deserialize(System.String)
extern "C"  RuntimeObject * Json_Deserialize_m2068364051 (RuntimeObject * __this /* static, unused */, String_t* ___json0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___json0;
		if (L_0)
		{
			goto IL_0008;
		}
	}
	{
		return NULL;
	}

IL_0008:
	{
		String_t* L_1 = ___json0;
		RuntimeObject * L_2 = Parser_Parse_m3352628348(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.String MiniJSON.Json::Serialize(System.Object)
extern "C"  String_t* Json_Serialize_m2864342744 (RuntimeObject * __this /* static, unused */, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	{
		RuntimeObject * L_0 = ___obj0;
		String_t* L_1 = Serializer_Serialize_m2381363365(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void MiniJSON.Json/Parser::.ctor(System.String)
extern "C"  void Parser__ctor_m3660599834 (Parser_t815916342 * __this, String_t* ___jsonString0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser__ctor_m3660599834_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Object__ctor_m1779107153(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___jsonString0;
		StringReader_t1790093495 * L_1 = (StringReader_t1790093495 *)il2cpp_codegen_object_new(StringReader_t1790093495_il2cpp_TypeInfo_var);
		StringReader__ctor_m2445074759(L_1, L_0, /*hidden argument*/NULL);
		__this->set_json_1(L_1);
		return;
	}
}
// System.Boolean MiniJSON.Json/Parser::IsWordBreak(System.Char)
extern "C"  bool Parser_IsWordBreak_m674601368 (RuntimeObject * __this /* static, unused */, Il2CppChar ___c0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_IsWordBreak_m674601368_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t G_B3_0 = 0;
	{
		Il2CppChar L_0 = ___c0;
		IL2CPP_RUNTIME_CLASS_INIT(Char_t4123521152_il2cpp_TypeInfo_var);
		bool L_1 = Char_IsWhiteSpace_m4026687856(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_001e;
		}
	}
	{
		Il2CppChar L_2 = ___c0;
		NullCheck(_stringLiteral838919514);
		int32_t L_3 = String_IndexOf_m1323122632(_stringLiteral838919514, L_2, /*hidden argument*/NULL);
		G_B3_0 = ((((int32_t)((((int32_t)L_3) == ((int32_t)(-1)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_001f;
	}

IL_001e:
	{
		G_B3_0 = 1;
	}

IL_001f:
	{
		return (bool)G_B3_0;
	}
}
// System.Object MiniJSON.Json/Parser::Parse(System.String)
extern "C"  RuntimeObject * Parser_Parse_m3352628348 (RuntimeObject * __this /* static, unused */, String_t* ___jsonString0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_Parse_m3352628348_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Parser_t815916342 * V_0 = NULL;
	RuntimeObject * V_1 = NULL;
	Exception_t3056413322 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t3056413322 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		String_t* L_0 = ___jsonString0;
		Parser_t815916342 * L_1 = (Parser_t815916342 *)il2cpp_codegen_object_new(Parser_t815916342_il2cpp_TypeInfo_var);
		Parser__ctor_m3660599834(L_1, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
	}

IL_0007:
	try
	{ // begin try (depth: 1)
		Parser_t815916342 * L_2 = V_0;
		NullCheck(L_2);
		RuntimeObject * L_3 = Parser_ParseValue_m2804928984(L_2, /*hidden argument*/NULL);
		V_1 = L_3;
		IL2CPP_LEAVE(0x20, FINALLY_0013);
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t3056413322 *)e.ex;
		goto FINALLY_0013;
	}

FINALLY_0013:
	{ // begin finally (depth: 1)
		{
			Parser_t815916342 * L_4 = V_0;
			if (!L_4)
			{
				goto IL_001f;
			}
		}

IL_0019:
		{
			Parser_t815916342 * L_5 = V_0;
			NullCheck(L_5);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t242102151_il2cpp_TypeInfo_var, L_5);
		}

IL_001f:
		{
			IL2CPP_END_FINALLY(19)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(19)
	{
		IL2CPP_JUMP_TBL(0x20, IL_0020)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t3056413322 *)
	}

IL_0020:
	{
		RuntimeObject * L_6 = V_1;
		return L_6;
	}
}
// System.Void MiniJSON.Json/Parser::Dispose()
extern "C"  void Parser_Dispose_m1212796882 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	{
		StringReader_t1790093495 * L_0 = __this->get_json_1();
		NullCheck(L_0);
		TextReader_Dispose_m1191826538(L_0, /*hidden argument*/NULL);
		__this->set_json_1((StringReader_t1790093495 *)NULL);
		return;
	}
}
// System.Collections.Generic.Dictionary`2<System.String,System.Object> MiniJSON.Json/Parser::ParseObject()
extern "C"  Dictionary_2_t1100919678 * Parser_ParseObject_m397767350 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_ParseObject_m397767350_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Dictionary_2_t1100919678 * V_0 = NULL;
	int32_t V_1 = 0;
	String_t* V_2 = NULL;
	{
		Dictionary_2_t1100919678 * L_0 = (Dictionary_2_t1100919678 *)il2cpp_codegen_object_new(Dictionary_2_t1100919678_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2414048597(L_0, /*hidden argument*/Dictionary_2__ctor_m2414048597_RuntimeMethod_var);
		V_0 = L_0;
		StringReader_t1790093495 * L_1 = __this->get_json_1();
		NullCheck(L_1);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_1);
	}

IL_0012:
	{
		int32_t L_2 = Parser_get_NextToken_m1111924718(__this, /*hidden argument*/NULL);
		V_1 = L_2;
		int32_t L_3 = V_1;
		switch (L_3)
		{
			case 0:
			{
				goto IL_0037;
			}
			case 1:
			{
				goto IL_002b;
			}
			case 2:
			{
				goto IL_003e;
			}
		}
	}

IL_002b:
	{
		int32_t L_4 = V_1;
		if ((((int32_t)L_4) == ((int32_t)6)))
		{
			goto IL_0039;
		}
	}
	{
		goto IL_0040;
	}

IL_0037:
	{
		return (Dictionary_2_t1100919678 *)NULL;
	}

IL_0039:
	{
		goto IL_0012;
	}

IL_003e:
	{
		Dictionary_2_t1100919678 * L_5 = V_0;
		return L_5;
	}

IL_0040:
	{
		String_t* L_6 = Parser_ParseString_m333155029(__this, /*hidden argument*/NULL);
		V_2 = L_6;
		String_t* L_7 = V_2;
		if (L_7)
		{
			goto IL_004f;
		}
	}
	{
		return (Dictionary_2_t1100919678 *)NULL;
	}

IL_004f:
	{
		int32_t L_8 = Parser_get_NextToken_m1111924718(__this, /*hidden argument*/NULL);
		if ((((int32_t)L_8) == ((int32_t)5)))
		{
			goto IL_005d;
		}
	}
	{
		return (Dictionary_2_t1100919678 *)NULL;
	}

IL_005d:
	{
		StringReader_t1790093495 * L_9 = __this->get_json_1();
		NullCheck(L_9);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_9);
		Dictionary_2_t1100919678 * L_10 = V_0;
		String_t* L_11 = V_2;
		RuntimeObject * L_12 = Parser_ParseValue_m2804928984(__this, /*hidden argument*/NULL);
		NullCheck(L_10);
		Dictionary_2_set_Item_m831255642(L_10, L_11, L_12, /*hidden argument*/Dictionary_2_set_Item_m831255642_RuntimeMethod_var);
		goto IL_007b;
	}

IL_007b:
	{
		goto IL_0012;
	}
}
// System.Collections.Generic.List`1<System.Object> MiniJSON.Json/Parser::ParseArray()
extern "C"  List_1_t2793634595 * Parser_ParseArray_m3427778883 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_ParseArray_m3427778883_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	List_1_t2793634595 * V_0 = NULL;
	bool V_1 = false;
	int32_t V_2 = 0;
	RuntimeObject * V_3 = NULL;
	{
		List_1_t2793634595 * L_0 = (List_1_t2793634595 *)il2cpp_codegen_object_new(List_1_t2793634595_il2cpp_TypeInfo_var);
		List_1__ctor_m663654418(L_0, /*hidden argument*/List_1__ctor_m663654418_RuntimeMethod_var);
		V_0 = L_0;
		StringReader_t1790093495 * L_1 = __this->get_json_1();
		NullCheck(L_1);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_1);
		V_1 = (bool)1;
		goto IL_0061;
	}

IL_0019:
	{
		int32_t L_2 = Parser_get_NextToken_m1111924718(__this, /*hidden argument*/NULL);
		V_2 = L_2;
		int32_t L_3 = V_2;
		switch (((int32_t)((int32_t)L_3-(int32_t)4)))
		{
			case 0:
			{
				goto IL_0046;
			}
			case 1:
			{
				goto IL_0034;
			}
			case 2:
			{
				goto IL_0041;
			}
		}
	}

IL_0034:
	{
		int32_t L_4 = V_2;
		if (!L_4)
		{
			goto IL_003f;
		}
	}
	{
		goto IL_004d;
	}

IL_003f:
	{
		return (List_1_t2793634595 *)NULL;
	}

IL_0041:
	{
		goto IL_0061;
	}

IL_0046:
	{
		V_1 = (bool)0;
		goto IL_0061;
	}

IL_004d:
	{
		int32_t L_5 = V_2;
		RuntimeObject * L_6 = Parser_ParseByToken_m3441831680(__this, L_5, /*hidden argument*/NULL);
		V_3 = L_6;
		List_1_t2793634595 * L_7 = V_0;
		RuntimeObject * L_8 = V_3;
		NullCheck(L_7);
		List_1_Add_m3949004397(L_7, L_8, /*hidden argument*/List_1_Add_m3949004397_RuntimeMethod_var);
		goto IL_0061;
	}

IL_0061:
	{
		bool L_9 = V_1;
		if (L_9)
		{
			goto IL_0019;
		}
	}
	{
		List_1_t2793634595 * L_10 = V_0;
		return L_10;
	}
}
// System.Object MiniJSON.Json/Parser::ParseValue()
extern "C"  RuntimeObject * Parser_ParseValue_m2804928984 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = Parser_get_NextToken_m1111924718(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		int32_t L_1 = V_0;
		RuntimeObject * L_2 = Parser_ParseByToken_m3441831680(__this, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Object MiniJSON.Json/Parser::ParseByToken(MiniJSON.Json/Parser/TOKEN)
extern "C"  RuntimeObject * Parser_ParseByToken_m3441831680 (Parser_t815916342 * __this, int32_t ___token0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_ParseByToken_m3441831680_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t L_0 = ___token0;
		switch (((int32_t)((int32_t)L_0-(int32_t)7)))
		{
			case 0:
			{
				goto IL_0035;
			}
			case 1:
			{
				goto IL_003c;
			}
			case 2:
			{
				goto IL_0051;
			}
			case 3:
			{
				goto IL_0058;
			}
			case 4:
			{
				goto IL_005f;
			}
		}
	}
	{
		int32_t L_1 = ___token0;
		switch (((int32_t)((int32_t)L_1-(int32_t)1)))
		{
			case 0:
			{
				goto IL_0043;
			}
			case 1:
			{
				goto IL_0061;
			}
			case 2:
			{
				goto IL_004a;
			}
		}
	}
	{
		goto IL_0061;
	}

IL_0035:
	{
		String_t* L_2 = Parser_ParseString_m333155029(__this, /*hidden argument*/NULL);
		return L_2;
	}

IL_003c:
	{
		RuntimeObject * L_3 = Parser_ParseNumber_m2705113073(__this, /*hidden argument*/NULL);
		return L_3;
	}

IL_0043:
	{
		Dictionary_2_t1100919678 * L_4 = Parser_ParseObject_m397767350(__this, /*hidden argument*/NULL);
		return L_4;
	}

IL_004a:
	{
		List_1_t2793634595 * L_5 = Parser_ParseArray_m3427778883(__this, /*hidden argument*/NULL);
		return L_5;
	}

IL_0051:
	{
		bool L_6 = ((bool)1);
		RuntimeObject * L_7 = Box(Boolean_t2724601657_il2cpp_TypeInfo_var, &L_6);
		return L_7;
	}

IL_0058:
	{
		bool L_8 = ((bool)0);
		RuntimeObject * L_9 = Box(Boolean_t2724601657_il2cpp_TypeInfo_var, &L_8);
		return L_9;
	}

IL_005f:
	{
		return NULL;
	}

IL_0061:
	{
		return NULL;
	}
}
// System.String MiniJSON.Json/Parser::ParseString()
extern "C"  String_t* Parser_ParseString_m333155029 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_ParseString_m333155029_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1854403953 * V_0 = NULL;
	Il2CppChar V_1 = 0x0;
	bool V_2 = false;
	CharU5BU5D_t2772155777* V_3 = NULL;
	int32_t V_4 = 0;
	{
		StringBuilder_t1854403953 * L_0 = (StringBuilder_t1854403953 *)il2cpp_codegen_object_new(StringBuilder_t1854403953_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m381491034(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringReader_t1790093495 * L_1 = __this->get_json_1();
		NullCheck(L_1);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_1);
		V_2 = (bool)1;
		goto IL_0166;
	}

IL_0019:
	{
		StringReader_t1790093495 * L_2 = __this->get_json_1();
		NullCheck(L_2);
		int32_t L_3 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_2);
		if ((!(((uint32_t)L_3) == ((uint32_t)(-1)))))
		{
			goto IL_0031;
		}
	}
	{
		V_2 = (bool)0;
		goto IL_016c;
	}

IL_0031:
	{
		Il2CppChar L_4 = Parser_get_NextChar_m1876461300(__this, /*hidden argument*/NULL);
		V_1 = L_4;
		Il2CppChar L_5 = V_1;
		if ((((int32_t)L_5) == ((int32_t)((int32_t)34))))
		{
			goto IL_004d;
		}
	}
	{
		Il2CppChar L_6 = V_1;
		if ((((int32_t)L_6) == ((int32_t)((int32_t)92))))
		{
			goto IL_0054;
		}
	}
	{
		goto IL_0159;
	}

IL_004d:
	{
		V_2 = (bool)0;
		goto IL_0166;
	}

IL_0054:
	{
		StringReader_t1790093495 * L_7 = __this->get_json_1();
		NullCheck(L_7);
		int32_t L_8 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_7);
		if ((!(((uint32_t)L_8) == ((uint32_t)(-1)))))
		{
			goto IL_006c;
		}
	}
	{
		V_2 = (bool)0;
		goto IL_0166;
	}

IL_006c:
	{
		Il2CppChar L_9 = Parser_get_NextChar_m1876461300(__this, /*hidden argument*/NULL);
		V_1 = L_9;
		Il2CppChar L_10 = V_1;
		switch (((int32_t)((int32_t)L_10-(int32_t)((int32_t)114))))
		{
			case 0:
			{
				goto IL_00f7;
			}
			case 1:
			{
				goto IL_008c;
			}
			case 2:
			{
				goto IL_0105;
			}
			case 3:
			{
				goto IL_0113;
			}
		}
	}

IL_008c:
	{
		Il2CppChar L_11 = V_1;
		if ((((int32_t)L_11) == ((int32_t)((int32_t)34))))
		{
			goto IL_00c1;
		}
	}
	{
		Il2CppChar L_12 = V_1;
		if ((((int32_t)L_12) == ((int32_t)((int32_t)47))))
		{
			goto IL_00c1;
		}
	}
	{
		Il2CppChar L_13 = V_1;
		if ((((int32_t)L_13) == ((int32_t)((int32_t)92))))
		{
			goto IL_00c1;
		}
	}
	{
		Il2CppChar L_14 = V_1;
		if ((((int32_t)L_14) == ((int32_t)((int32_t)98))))
		{
			goto IL_00ce;
		}
	}
	{
		Il2CppChar L_15 = V_1;
		if ((((int32_t)L_15) == ((int32_t)((int32_t)102))))
		{
			goto IL_00db;
		}
	}
	{
		Il2CppChar L_16 = V_1;
		if ((((int32_t)L_16) == ((int32_t)((int32_t)110))))
		{
			goto IL_00e9;
		}
	}
	{
		goto IL_0154;
	}

IL_00c1:
	{
		StringBuilder_t1854403953 * L_17 = V_0;
		Il2CppChar L_18 = V_1;
		NullCheck(L_17);
		StringBuilder_Append_m2231235818(L_17, L_18, /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_00ce:
	{
		StringBuilder_t1854403953 * L_19 = V_0;
		NullCheck(L_19);
		StringBuilder_Append_m2231235818(L_19, 8, /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_00db:
	{
		StringBuilder_t1854403953 * L_20 = V_0;
		NullCheck(L_20);
		StringBuilder_Append_m2231235818(L_20, ((int32_t)12), /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_00e9:
	{
		StringBuilder_t1854403953 * L_21 = V_0;
		NullCheck(L_21);
		StringBuilder_Append_m2231235818(L_21, ((int32_t)10), /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_00f7:
	{
		StringBuilder_t1854403953 * L_22 = V_0;
		NullCheck(L_22);
		StringBuilder_Append_m2231235818(L_22, ((int32_t)13), /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_0105:
	{
		StringBuilder_t1854403953 * L_23 = V_0;
		NullCheck(L_23);
		StringBuilder_Append_m2231235818(L_23, ((int32_t)9), /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_0113:
	{
		V_3 = ((CharU5BU5D_t2772155777*)SZArrayNew(CharU5BU5D_t2772155777_il2cpp_TypeInfo_var, (uint32_t)4));
		V_4 = 0;
		goto IL_0132;
	}

IL_0122:
	{
		CharU5BU5D_t2772155777* L_24 = V_3;
		int32_t L_25 = V_4;
		Il2CppChar L_26 = Parser_get_NextChar_m1876461300(__this, /*hidden argument*/NULL);
		NullCheck(L_24);
		(L_24)->SetAt(static_cast<il2cpp_array_size_t>(L_25), (Il2CppChar)L_26);
		int32_t L_27 = V_4;
		V_4 = ((int32_t)((int32_t)L_27+(int32_t)1));
	}

IL_0132:
	{
		int32_t L_28 = V_4;
		if ((((int32_t)L_28) < ((int32_t)4)))
		{
			goto IL_0122;
		}
	}
	{
		StringBuilder_t1854403953 * L_29 = V_0;
		CharU5BU5D_t2772155777* L_30 = V_3;
		String_t* L_31 = String_CreateString_m3557769859(NULL, L_30, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t708193928_il2cpp_TypeInfo_var);
		int32_t L_32 = Convert_ToInt32_m1168689724(NULL /*static, unused*/, L_31, ((int32_t)16), /*hidden argument*/NULL);
		NullCheck(L_29);
		StringBuilder_Append_m2231235818(L_29, (((int32_t)((uint16_t)L_32))), /*hidden argument*/NULL);
		goto IL_0154;
	}

IL_0154:
	{
		goto IL_0166;
	}

IL_0159:
	{
		StringBuilder_t1854403953 * L_33 = V_0;
		Il2CppChar L_34 = V_1;
		NullCheck(L_33);
		StringBuilder_Append_m2231235818(L_33, L_34, /*hidden argument*/NULL);
		goto IL_0166;
	}

IL_0166:
	{
		bool L_35 = V_2;
		if (L_35)
		{
			goto IL_0019;
		}
	}

IL_016c:
	{
		StringBuilder_t1854403953 * L_36 = V_0;
		NullCheck(L_36);
		String_t* L_37 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_36);
		return L_37;
	}
}
// System.Object MiniJSON.Json/Parser::ParseNumber()
extern "C"  RuntimeObject * Parser_ParseNumber_m2705113073 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_ParseNumber_m2705113073_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int64_t V_1 = 0;
	double V_2 = 0.0;
	{
		String_t* L_0 = Parser_get_NextWord_m2710760689(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		String_t* L_1 = V_0;
		NullCheck(L_1);
		int32_t L_2 = String_IndexOf_m1323122632(L_1, ((int32_t)46), /*hidden argument*/NULL);
		if ((!(((uint32_t)L_2) == ((uint32_t)(-1)))))
		{
			goto IL_0025;
		}
	}
	{
		String_t* L_3 = V_0;
		Int64_TryParse_m3337598207(NULL /*static, unused*/, L_3, (&V_1), /*hidden argument*/NULL);
		int64_t L_4 = V_1;
		int64_t L_5 = L_4;
		RuntimeObject * L_6 = Box(Int64_t2942533987_il2cpp_TypeInfo_var, &L_5);
		return L_6;
	}

IL_0025:
	{
		String_t* L_7 = V_0;
		Double_TryParse_m297924056(NULL /*static, unused*/, L_7, (&V_2), /*hidden argument*/NULL);
		double L_8 = V_2;
		double L_9 = L_8;
		RuntimeObject * L_10 = Box(Double_t4024153389_il2cpp_TypeInfo_var, &L_9);
		return L_10;
	}
}
// System.Void MiniJSON.Json/Parser::EatWhitespace()
extern "C"  void Parser_EatWhitespace_m4203669877 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_EatWhitespace_m4203669877_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		goto IL_0027;
	}

IL_0005:
	{
		StringReader_t1790093495 * L_0 = __this->get_json_1();
		NullCheck(L_0);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_0);
		StringReader_t1790093495 * L_1 = __this->get_json_1();
		NullCheck(L_1);
		int32_t L_2 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_1);
		if ((!(((uint32_t)L_2) == ((uint32_t)(-1)))))
		{
			goto IL_0027;
		}
	}
	{
		goto IL_0037;
	}

IL_0027:
	{
		Il2CppChar L_3 = Parser_get_PeekChar_m3819133206(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Char_t4123521152_il2cpp_TypeInfo_var);
		bool L_4 = Char_IsWhiteSpace_m4026687856(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0005;
		}
	}

IL_0037:
	{
		return;
	}
}
// System.Char MiniJSON.Json/Parser::get_PeekChar()
extern "C"  Il2CppChar Parser_get_PeekChar_m3819133206 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_get_PeekChar_m3819133206_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		StringReader_t1790093495 * L_0 = __this->get_json_1();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_0);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t708193928_il2cpp_TypeInfo_var);
		Il2CppChar L_2 = Convert_ToChar_m4166941018(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Char MiniJSON.Json/Parser::get_NextChar()
extern "C"  Il2CppChar Parser_get_NextChar_m1876461300 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_get_NextChar_m1876461300_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		StringReader_t1790093495 * L_0 = __this->get_json_1();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_0);
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t708193928_il2cpp_TypeInfo_var);
		Il2CppChar L_2 = Convert_ToChar_m4166941018(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.String MiniJSON.Json/Parser::get_NextWord()
extern "C"  String_t* Parser_get_NextWord_m2710760689 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_get_NextWord_m2710760689_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t1854403953 * V_0 = NULL;
	{
		StringBuilder_t1854403953 * L_0 = (StringBuilder_t1854403953 *)il2cpp_codegen_object_new(StringBuilder_t1854403953_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m381491034(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		goto IL_002e;
	}

IL_000b:
	{
		StringBuilder_t1854403953 * L_1 = V_0;
		Il2CppChar L_2 = Parser_get_NextChar_m1876461300(__this, /*hidden argument*/NULL);
		NullCheck(L_1);
		StringBuilder_Append_m2231235818(L_1, L_2, /*hidden argument*/NULL);
		StringReader_t1790093495 * L_3 = __this->get_json_1();
		NullCheck(L_3);
		int32_t L_4 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_3);
		if ((!(((uint32_t)L_4) == ((uint32_t)(-1)))))
		{
			goto IL_002e;
		}
	}
	{
		goto IL_003e;
	}

IL_002e:
	{
		Il2CppChar L_5 = Parser_get_PeekChar_m3819133206(__this, /*hidden argument*/NULL);
		bool L_6 = Parser_IsWordBreak_m674601368(NULL /*static, unused*/, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_000b;
		}
	}

IL_003e:
	{
		StringBuilder_t1854403953 * L_7 = V_0;
		NullCheck(L_7);
		String_t* L_8 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_7);
		return L_8;
	}
}
// MiniJSON.Json/Parser/TOKEN MiniJSON.Json/Parser::get_NextToken()
extern "C"  int32_t Parser_get_NextToken_m1111924718 (Parser_t815916342 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Parser_get_NextToken_m1111924718_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Il2CppChar V_0 = 0x0;
	String_t* V_1 = NULL;
	{
		Parser_EatWhitespace_m4203669877(__this, /*hidden argument*/NULL);
		StringReader_t1790093495 * L_0 = __this->get_json_1();
		NullCheck(L_0);
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(7 /* System.Int32 System.IO.TextReader::Peek() */, L_0);
		if ((!(((uint32_t)L_1) == ((uint32_t)(-1)))))
		{
			goto IL_0019;
		}
	}
	{
		return (int32_t)(0);
	}

IL_0019:
	{
		Il2CppChar L_2 = Parser_get_PeekChar_m3819133206(__this, /*hidden argument*/NULL);
		V_0 = L_2;
		Il2CppChar L_3 = V_0;
		switch (((int32_t)((int32_t)L_3-(int32_t)((int32_t)44))))
		{
			case 0:
			{
				goto IL_00bc;
			}
			case 1:
			{
				goto IL_00ce;
			}
			case 2:
			{
				goto IL_0065;
			}
			case 3:
			{
				goto IL_0065;
			}
			case 4:
			{
				goto IL_00ce;
			}
			case 5:
			{
				goto IL_00ce;
			}
			case 6:
			{
				goto IL_00ce;
			}
			case 7:
			{
				goto IL_00ce;
			}
			case 8:
			{
				goto IL_00ce;
			}
			case 9:
			{
				goto IL_00ce;
			}
			case 10:
			{
				goto IL_00ce;
			}
			case 11:
			{
				goto IL_00ce;
			}
			case 12:
			{
				goto IL_00ce;
			}
			case 13:
			{
				goto IL_00ce;
			}
			case 14:
			{
				goto IL_00cc;
			}
		}
	}

IL_0065:
	{
		Il2CppChar L_4 = V_0;
		switch (((int32_t)((int32_t)L_4-(int32_t)((int32_t)91))))
		{
			case 0:
			{
				goto IL_00ac;
			}
			case 1:
			{
				goto IL_007a;
			}
			case 2:
			{
				goto IL_00ae;
			}
		}
	}

IL_007a:
	{
		Il2CppChar L_5 = V_0;
		switch (((int32_t)((int32_t)L_5-(int32_t)((int32_t)123))))
		{
			case 0:
			{
				goto IL_009c;
			}
			case 1:
			{
				goto IL_008f;
			}
			case 2:
			{
				goto IL_009e;
			}
		}
	}

IL_008f:
	{
		Il2CppChar L_6 = V_0;
		if ((((int32_t)L_6) == ((int32_t)((int32_t)34))))
		{
			goto IL_00ca;
		}
	}
	{
		goto IL_00d0;
	}

IL_009c:
	{
		return (int32_t)(1);
	}

IL_009e:
	{
		StringReader_t1790093495 * L_7 = __this->get_json_1();
		NullCheck(L_7);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_7);
		return (int32_t)(2);
	}

IL_00ac:
	{
		return (int32_t)(3);
	}

IL_00ae:
	{
		StringReader_t1790093495 * L_8 = __this->get_json_1();
		NullCheck(L_8);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_8);
		return (int32_t)(4);
	}

IL_00bc:
	{
		StringReader_t1790093495 * L_9 = __this->get_json_1();
		NullCheck(L_9);
		VirtFuncInvoker0< int32_t >::Invoke(8 /* System.Int32 System.IO.TextReader::Read() */, L_9);
		return (int32_t)(6);
	}

IL_00ca:
	{
		return (int32_t)(7);
	}

IL_00cc:
	{
		return (int32_t)(5);
	}

IL_00ce:
	{
		return (int32_t)(8);
	}

IL_00d0:
	{
		String_t* L_10 = Parser_get_NextWord_m2710760689(__this, /*hidden argument*/NULL);
		V_1 = L_10;
		String_t* L_11 = V_1;
		if (!L_11)
		{
			goto IL_011b;
		}
	}
	{
		String_t* L_12 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_13 = String_op_Equality_m111603488(NULL /*static, unused*/, L_12, _stringLiteral391856821, /*hidden argument*/NULL);
		if (L_13)
		{
			goto IL_0112;
		}
	}
	{
		String_t* L_14 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_15 = String_op_Equality_m111603488(NULL /*static, unused*/, L_14, _stringLiteral1400893542, /*hidden argument*/NULL);
		if (L_15)
		{
			goto IL_0115;
		}
	}
	{
		String_t* L_16 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_17 = String_op_Equality_m111603488(NULL /*static, unused*/, L_16, _stringLiteral3159482552, /*hidden argument*/NULL);
		if (L_17)
		{
			goto IL_0118;
		}
	}
	{
		goto IL_011b;
	}

IL_0112:
	{
		return (int32_t)(((int32_t)10));
	}

IL_0115:
	{
		return (int32_t)(((int32_t)9));
	}

IL_0118:
	{
		return (int32_t)(((int32_t)11));
	}

IL_011b:
	{
		return (int32_t)(0);
	}
}
// System.Void MiniJSON.Json/Serializer::.ctor()
extern "C"  void Serializer__ctor_m1021995128 (Serializer_t3957605795 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer__ctor_m1021995128_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Object__ctor_m1779107153(__this, /*hidden argument*/NULL);
		StringBuilder_t1854403953 * L_0 = (StringBuilder_t1854403953 *)il2cpp_codegen_object_new(StringBuilder_t1854403953_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m381491034(L_0, /*hidden argument*/NULL);
		__this->set_builder_0(L_0);
		return;
	}
}
// System.String MiniJSON.Json/Serializer::Serialize(System.Object)
extern "C"  String_t* Serializer_Serialize_m2381363365 (RuntimeObject * __this /* static, unused */, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_Serialize_m2381363365_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Serializer_t3957605795 * V_0 = NULL;
	{
		Serializer_t3957605795 * L_0 = (Serializer_t3957605795 *)il2cpp_codegen_object_new(Serializer_t3957605795_il2cpp_TypeInfo_var);
		Serializer__ctor_m1021995128(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		Serializer_t3957605795 * L_1 = V_0;
		RuntimeObject * L_2 = ___obj0;
		NullCheck(L_1);
		Serializer_SerializeValue_m766562738(L_1, L_2, /*hidden argument*/NULL);
		Serializer_t3957605795 * L_3 = V_0;
		NullCheck(L_3);
		StringBuilder_t1854403953 * L_4 = L_3->get_builder_0();
		NullCheck(L_4);
		String_t* L_5 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_4);
		return L_5;
	}
}
// System.Void MiniJSON.Json/Serializer::SerializeValue(System.Object)
extern "C"  void Serializer_SerializeValue_m766562738 (Serializer_t3957605795 * __this, RuntimeObject * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_SerializeValue_m766562738_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	RuntimeObject* V_1 = NULL;
	String_t* V_2 = NULL;
	StringBuilder_t1854403953 * G_B7_0 = NULL;
	StringBuilder_t1854403953 * G_B6_0 = NULL;
	String_t* G_B8_0 = NULL;
	StringBuilder_t1854403953 * G_B8_1 = NULL;
	{
		RuntimeObject * L_0 = ___value0;
		if (L_0)
		{
			goto IL_001c;
		}
	}
	{
		StringBuilder_t1854403953 * L_1 = __this->get_builder_0();
		NullCheck(L_1);
		StringBuilder_Append_m2042828374(L_1, _stringLiteral3159482552, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_001c:
	{
		RuntimeObject * L_2 = ___value0;
		String_t* L_3 = ((String_t*)IsInstSealed((RuntimeObject*)L_2, String_t_il2cpp_TypeInfo_var));
		V_2 = L_3;
		if (!L_3)
		{
			goto IL_0035;
		}
	}
	{
		String_t* L_4 = V_2;
		Serializer_SerializeString_m1354220936(__this, L_4, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_0035:
	{
		RuntimeObject * L_5 = ___value0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_5, Boolean_t2724601657_il2cpp_TypeInfo_var)))
		{
			goto IL_006b;
		}
	}
	{
		StringBuilder_t1854403953 * L_6 = __this->get_builder_0();
		RuntimeObject * L_7 = ___value0;
		G_B6_0 = L_6;
		if (!((*(bool*)((bool*)UnBox(L_7, Boolean_t2724601657_il2cpp_TypeInfo_var)))))
		{
			G_B7_0 = L_6;
			goto IL_005b;
		}
	}
	{
		G_B8_0 = _stringLiteral1400893542;
		G_B8_1 = G_B6_0;
		goto IL_0060;
	}

IL_005b:
	{
		G_B8_0 = _stringLiteral391856821;
		G_B8_1 = G_B7_0;
	}

IL_0060:
	{
		NullCheck(G_B8_1);
		StringBuilder_Append_m2042828374(G_B8_1, G_B8_0, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_006b:
	{
		RuntimeObject * L_8 = ___value0;
		RuntimeObject* L_9 = ((RuntimeObject*)IsInst((RuntimeObject*)L_8, IList_t4241283331_il2cpp_TypeInfo_var));
		V_0 = L_9;
		if (!L_9)
		{
			goto IL_0084;
		}
	}
	{
		RuntimeObject* L_10 = V_0;
		Serializer_SerializeArray_m3445866376(__this, L_10, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_0084:
	{
		RuntimeObject * L_11 = ___value0;
		RuntimeObject* L_12 = ((RuntimeObject*)IsInst((RuntimeObject*)L_11, IDictionary_t1045075095_il2cpp_TypeInfo_var));
		V_1 = L_12;
		if (!L_12)
		{
			goto IL_009d;
		}
	}
	{
		RuntimeObject* L_13 = V_1;
		Serializer_SerializeObject_m4019526216(__this, L_13, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_009d:
	{
		RuntimeObject * L_14 = ___value0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_14, Char_t4123521152_il2cpp_TypeInfo_var)))
		{
			goto IL_00bf;
		}
	}
	{
		RuntimeObject * L_15 = ___value0;
		String_t* L_16 = String_CreateString_m52651688(NULL, ((*(Il2CppChar*)((Il2CppChar*)UnBox(L_15, Char_t4123521152_il2cpp_TypeInfo_var)))), 1, /*hidden argument*/NULL);
		Serializer_SerializeString_m1354220936(__this, L_16, /*hidden argument*/NULL);
		goto IL_00c6;
	}

IL_00bf:
	{
		RuntimeObject * L_17 = ___value0;
		Serializer_SerializeOther_m1072816231(__this, L_17, /*hidden argument*/NULL);
	}

IL_00c6:
	{
		return;
	}
}
// System.Void MiniJSON.Json/Serializer::SerializeObject(System.Collections.IDictionary)
extern "C"  void Serializer_SerializeObject_m4019526216 (Serializer_t3957605795 * __this, RuntimeObject* ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_SerializeObject_m4019526216_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	RuntimeObject * V_1 = NULL;
	RuntimeObject* V_2 = NULL;
	RuntimeObject* V_3 = NULL;
	Exception_t3056413322 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t3056413322 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = (bool)1;
		StringBuilder_t1854403953 * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		StringBuilder_Append_m2231235818(L_0, ((int32_t)123), /*hidden argument*/NULL);
		RuntimeObject* L_1 = ___obj0;
		NullCheck(L_1);
		RuntimeObject* L_2 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(2 /* System.Collections.ICollection System.Collections.IDictionary::get_Keys() */, IDictionary_t1045075095_il2cpp_TypeInfo_var, L_1);
		NullCheck(L_2);
		RuntimeObject* L_3 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.IEnumerator System.Collections.IEnumerable::GetEnumerator() */, IEnumerable_t3475459086_il2cpp_TypeInfo_var, L_2);
		V_2 = L_3;
	}

IL_001c:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0065;
		}

IL_0021:
		{
			RuntimeObject* L_4 = V_2;
			NullCheck(L_4);
			RuntimeObject * L_5 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_4);
			V_1 = L_5;
			bool L_6 = V_0;
			if (L_6)
			{
				goto IL_003c;
			}
		}

IL_002e:
		{
			StringBuilder_t1854403953 * L_7 = __this->get_builder_0();
			NullCheck(L_7);
			StringBuilder_Append_m2231235818(L_7, ((int32_t)44), /*hidden argument*/NULL);
		}

IL_003c:
		{
			RuntimeObject * L_8 = V_1;
			NullCheck(L_8);
			String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_8);
			Serializer_SerializeString_m1354220936(__this, L_9, /*hidden argument*/NULL);
			StringBuilder_t1854403953 * L_10 = __this->get_builder_0();
			NullCheck(L_10);
			StringBuilder_Append_m2231235818(L_10, ((int32_t)58), /*hidden argument*/NULL);
			RuntimeObject* L_11 = ___obj0;
			RuntimeObject * L_12 = V_1;
			NullCheck(L_11);
			RuntimeObject * L_13 = InterfaceFuncInvoker1< RuntimeObject *, RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IDictionary::get_Item(System.Object) */, IDictionary_t1045075095_il2cpp_TypeInfo_var, L_11, L_12);
			Serializer_SerializeValue_m766562738(__this, L_13, /*hidden argument*/NULL);
			V_0 = (bool)0;
		}

IL_0065:
		{
			RuntimeObject* L_14 = V_2;
			NullCheck(L_14);
			bool L_15 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_14);
			if (L_15)
			{
				goto IL_0021;
			}
		}

IL_0070:
		{
			IL2CPP_LEAVE(0x89, FINALLY_0075);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t3056413322 *)e.ex;
		goto FINALLY_0075;
	}

FINALLY_0075:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_16 = V_2;
			RuntimeObject* L_17 = ((RuntimeObject*)IsInst((RuntimeObject*)L_16, IDisposable_t242102151_il2cpp_TypeInfo_var));
			V_3 = L_17;
			if (!L_17)
			{
				goto IL_0088;
			}
		}

IL_0082:
		{
			RuntimeObject* L_18 = V_3;
			NullCheck(L_18);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t242102151_il2cpp_TypeInfo_var, L_18);
		}

IL_0088:
		{
			IL2CPP_END_FINALLY(117)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(117)
	{
		IL2CPP_JUMP_TBL(0x89, IL_0089)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t3056413322 *)
	}

IL_0089:
	{
		StringBuilder_t1854403953 * L_19 = __this->get_builder_0();
		NullCheck(L_19);
		StringBuilder_Append_m2231235818(L_19, ((int32_t)125), /*hidden argument*/NULL);
		return;
	}
}
// System.Void MiniJSON.Json/Serializer::SerializeArray(System.Collections.IList)
extern "C"  void Serializer_SerializeArray_m3445866376 (Serializer_t3957605795 * __this, RuntimeObject* ___anArray0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_SerializeArray_m3445866376_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	RuntimeObject * V_1 = NULL;
	RuntimeObject* V_2 = NULL;
	RuntimeObject* V_3 = NULL;
	Exception_t3056413322 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t3056413322 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		StringBuilder_t1854403953 * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		StringBuilder_Append_m2231235818(L_0, ((int32_t)91), /*hidden argument*/NULL);
		V_0 = (bool)1;
		RuntimeObject* L_1 = ___anArray0;
		NullCheck(L_1);
		RuntimeObject* L_2 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(0 /* System.Collections.IEnumerator System.Collections.IEnumerable::GetEnumerator() */, IEnumerable_t3475459086_il2cpp_TypeInfo_var, L_1);
		V_2 = L_2;
	}

IL_0017:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0040;
		}

IL_001c:
		{
			RuntimeObject* L_3 = V_2;
			NullCheck(L_3);
			RuntimeObject * L_4 = InterfaceFuncInvoker0< RuntimeObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_3);
			V_1 = L_4;
			bool L_5 = V_0;
			if (L_5)
			{
				goto IL_0037;
			}
		}

IL_0029:
		{
			StringBuilder_t1854403953 * L_6 = __this->get_builder_0();
			NullCheck(L_6);
			StringBuilder_Append_m2231235818(L_6, ((int32_t)44), /*hidden argument*/NULL);
		}

IL_0037:
		{
			RuntimeObject * L_7 = V_1;
			Serializer_SerializeValue_m766562738(__this, L_7, /*hidden argument*/NULL);
			V_0 = (bool)0;
		}

IL_0040:
		{
			RuntimeObject* L_8 = V_2;
			NullCheck(L_8);
			bool L_9 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1608174681_il2cpp_TypeInfo_var, L_8);
			if (L_9)
			{
				goto IL_001c;
			}
		}

IL_004b:
		{
			IL2CPP_LEAVE(0x64, FINALLY_0050);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t3056413322 *)e.ex;
		goto FINALLY_0050;
	}

FINALLY_0050:
	{ // begin finally (depth: 1)
		{
			RuntimeObject* L_10 = V_2;
			RuntimeObject* L_11 = ((RuntimeObject*)IsInst((RuntimeObject*)L_10, IDisposable_t242102151_il2cpp_TypeInfo_var));
			V_3 = L_11;
			if (!L_11)
			{
				goto IL_0063;
			}
		}

IL_005d:
		{
			RuntimeObject* L_12 = V_3;
			NullCheck(L_12);
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t242102151_il2cpp_TypeInfo_var, L_12);
		}

IL_0063:
		{
			IL2CPP_END_FINALLY(80)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(80)
	{
		IL2CPP_JUMP_TBL(0x64, IL_0064)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t3056413322 *)
	}

IL_0064:
	{
		StringBuilder_t1854403953 * L_13 = __this->get_builder_0();
		NullCheck(L_13);
		StringBuilder_Append_m2231235818(L_13, ((int32_t)93), /*hidden argument*/NULL);
		return;
	}
}
// System.Void MiniJSON.Json/Serializer::SerializeString(System.String)
extern "C"  void Serializer_SerializeString_m1354220936 (Serializer_t3957605795 * __this, String_t* ___str0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_SerializeString_m1354220936_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CharU5BU5D_t2772155777* V_0 = NULL;
	Il2CppChar V_1 = 0x0;
	CharU5BU5D_t2772155777* V_2 = NULL;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	{
		StringBuilder_t1854403953 * L_0 = __this->get_builder_0();
		NullCheck(L_0);
		StringBuilder_Append_m2231235818(L_0, ((int32_t)34), /*hidden argument*/NULL);
		String_t* L_1 = ___str0;
		NullCheck(L_1);
		CharU5BU5D_t2772155777* L_2 = String_ToCharArray_m1352704103(L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		CharU5BU5D_t2772155777* L_3 = V_0;
		V_2 = L_3;
		V_3 = 0;
		goto IL_014f;
	}

IL_001e:
	{
		CharU5BU5D_t2772155777* L_4 = V_2;
		int32_t L_5 = V_3;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		uint16_t L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		V_1 = L_7;
		Il2CppChar L_8 = V_1;
		switch (((int32_t)((int32_t)L_8-(int32_t)8)))
		{
			case 0:
			{
				goto IL_0083;
			}
			case 1:
			{
				goto IL_00db;
			}
			case 2:
			{
				goto IL_00af;
			}
			case 3:
			{
				goto IL_0042;
			}
			case 4:
			{
				goto IL_0099;
			}
			case 5:
			{
				goto IL_00c5;
			}
		}
	}

IL_0042:
	{
		Il2CppChar L_9 = V_1;
		if ((((int32_t)L_9) == ((int32_t)((int32_t)34))))
		{
			goto IL_0057;
		}
	}
	{
		Il2CppChar L_10 = V_1;
		if ((((int32_t)L_10) == ((int32_t)((int32_t)92))))
		{
			goto IL_006d;
		}
	}
	{
		goto IL_00f1;
	}

IL_0057:
	{
		StringBuilder_t1854403953 * L_11 = __this->get_builder_0();
		NullCheck(L_11);
		StringBuilder_Append_m2042828374(L_11, _stringLiteral2496710397, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_006d:
	{
		StringBuilder_t1854403953 * L_12 = __this->get_builder_0();
		NullCheck(L_12);
		StringBuilder_Append_m2042828374(L_12, _stringLiteral240939506, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_0083:
	{
		StringBuilder_t1854403953 * L_13 = __this->get_builder_0();
		NullCheck(L_13);
		StringBuilder_Append_m2042828374(L_13, _stringLiteral4173735437, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_0099:
	{
		StringBuilder_t1854403953 * L_14 = __this->get_builder_0();
		NullCheck(L_14);
		StringBuilder_Append_m2042828374(L_14, _stringLiteral1743058948, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_00af:
	{
		StringBuilder_t1854403953 * L_15 = __this->get_builder_0();
		NullCheck(L_15);
		StringBuilder_Append_m2042828374(L_15, _stringLiteral2178147880, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_00c5:
	{
		StringBuilder_t1854403953 * L_16 = __this->get_builder_0();
		NullCheck(L_16);
		StringBuilder_Append_m2042828374(L_16, _stringLiteral3184689943, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_00db:
	{
		StringBuilder_t1854403953 * L_17 = __this->get_builder_0();
		NullCheck(L_17);
		StringBuilder_Append_m2042828374(L_17, _stringLiteral2198487847, /*hidden argument*/NULL);
		goto IL_014b;
	}

IL_00f1:
	{
		Il2CppChar L_18 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t708193928_il2cpp_TypeInfo_var);
		int32_t L_19 = Convert_ToInt32_m3802300207(NULL /*static, unused*/, L_18, /*hidden argument*/NULL);
		V_4 = L_19;
		int32_t L_20 = V_4;
		if ((((int32_t)L_20) < ((int32_t)((int32_t)32))))
		{
			goto IL_011d;
		}
	}
	{
		int32_t L_21 = V_4;
		if ((((int32_t)L_21) > ((int32_t)((int32_t)126))))
		{
			goto IL_011d;
		}
	}
	{
		StringBuilder_t1854403953 * L_22 = __this->get_builder_0();
		Il2CppChar L_23 = V_1;
		NullCheck(L_22);
		StringBuilder_Append_m2231235818(L_22, L_23, /*hidden argument*/NULL);
		goto IL_0146;
	}

IL_011d:
	{
		StringBuilder_t1854403953 * L_24 = __this->get_builder_0();
		NullCheck(L_24);
		StringBuilder_Append_m2042828374(L_24, _stringLiteral54292398, /*hidden argument*/NULL);
		StringBuilder_t1854403953 * L_25 = __this->get_builder_0();
		String_t* L_26 = Int32_ToString_m1740000633((&V_4), _stringLiteral284050032, /*hidden argument*/NULL);
		NullCheck(L_25);
		StringBuilder_Append_m2042828374(L_25, L_26, /*hidden argument*/NULL);
	}

IL_0146:
	{
		goto IL_014b;
	}

IL_014b:
	{
		int32_t L_27 = V_3;
		V_3 = ((int32_t)((int32_t)L_27+(int32_t)1));
	}

IL_014f:
	{
		int32_t L_28 = V_3;
		CharU5BU5D_t2772155777* L_29 = V_2;
		NullCheck(L_29);
		if ((((int32_t)L_28) < ((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_29)->max_length)))))))
		{
			goto IL_001e;
		}
	}
	{
		StringBuilder_t1854403953 * L_30 = __this->get_builder_0();
		NullCheck(L_30);
		StringBuilder_Append_m2231235818(L_30, ((int32_t)34), /*hidden argument*/NULL);
		return;
	}
}
// System.Void MiniJSON.Json/Serializer::SerializeOther(System.Object)
extern "C"  void Serializer_SerializeOther_m1072816231 (Serializer_t3957605795 * __this, RuntimeObject * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Serializer_SerializeOther_m1072816231_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	double V_1 = 0.0;
	{
		RuntimeObject * L_0 = ___value0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_0, Single_t2594644343_il2cpp_TypeInfo_var)))
		{
			goto IL_002f;
		}
	}
	{
		StringBuilder_t1854403953 * L_1 = __this->get_builder_0();
		RuntimeObject * L_2 = ___value0;
		V_0 = ((*(float*)((float*)UnBox(L_2, Single_t2594644343_il2cpp_TypeInfo_var))));
		String_t* L_3 = Single_ToString_m1218876293((&V_0), _stringLiteral247565077, /*hidden argument*/NULL);
		NullCheck(L_1);
		StringBuilder_Append_m2042828374(L_1, L_3, /*hidden argument*/NULL);
		goto IL_00df;
	}

IL_002f:
	{
		RuntimeObject * L_4 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_4, Int32_t2946131084_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_5 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_5, UInt32_t1505113534_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_6 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_6, Int64_t2942533987_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_7 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_7, SByte_t669469354_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_8 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_8, Byte_t2596701031_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_9 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_9, Int16_t612759502_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_10 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_10, UInt16_t1912811313_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_11 = ___value0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_11, UInt64_t4149917651_il2cpp_TypeInfo_var)))
		{
			goto IL_0099;
		}
	}

IL_0087:
	{
		StringBuilder_t1854403953 * L_12 = __this->get_builder_0();
		RuntimeObject * L_13 = ___value0;
		NullCheck(L_12);
		StringBuilder_Append_m2336619298(L_12, L_13, /*hidden argument*/NULL);
		goto IL_00df;
	}

IL_0099:
	{
		RuntimeObject * L_14 = ___value0;
		if (((RuntimeObject *)IsInstSealed((RuntimeObject*)L_14, Double_t4024153389_il2cpp_TypeInfo_var)))
		{
			goto IL_00af;
		}
	}
	{
		RuntimeObject * L_15 = ___value0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_15, Decimal_t3889304405_il2cpp_TypeInfo_var)))
		{
			goto IL_00d3;
		}
	}

IL_00af:
	{
		StringBuilder_t1854403953 * L_16 = __this->get_builder_0();
		RuntimeObject * L_17 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t708193928_il2cpp_TypeInfo_var);
		double L_18 = Convert_ToDouble_m2428222768(NULL /*static, unused*/, L_17, /*hidden argument*/NULL);
		V_1 = L_18;
		String_t* L_19 = Double_ToString_m476927511((&V_1), _stringLiteral247565077, /*hidden argument*/NULL);
		NullCheck(L_16);
		StringBuilder_Append_m2042828374(L_16, L_19, /*hidden argument*/NULL);
		goto IL_00df;
	}

IL_00d3:
	{
		RuntimeObject * L_20 = ___value0;
		NullCheck(L_20);
		String_t* L_21 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_20);
		Serializer_SerializeString_m1354220936(__this, L_21, /*hidden argument*/NULL);
	}

IL_00df:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
