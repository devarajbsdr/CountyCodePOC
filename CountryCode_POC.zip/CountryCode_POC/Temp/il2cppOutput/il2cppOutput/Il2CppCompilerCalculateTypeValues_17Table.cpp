﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "object-internals.h"

// System.String
struct String_t;
// System.Collections.Hashtable
struct Hashtable_t3043587435;
// Mono.Xml.DTDObjectModel
struct DTDObjectModel_t739056388;
// System.Char[]
struct CharU5BU5D_t2772155777;
// System.Byte[]
struct ByteU5BU5D_t2643433246;
// System.UInt32[]
struct UInt32U5BU5D_t1349399947;
// System.Collections.Generic.Dictionary`2<System.String,System.Int32>
struct Dictionary_2_t1245616680;
// System.Xml.XmlParserInput
struct XmlParserInput_t1933096837;
// System.Collections.Stack
struct Stack_t1028188311;
// System.Text.StringBuilder
struct StringBuilder_t1854403953;
// System.Collections.Specialized.ListDictionary
struct ListDictionary_t2358247778;
// System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>[]
struct KeyValuePair_2U5BU5D_t1497786643;
// Mono.Xml.DTDAutomataFactory
struct DTDAutomataFactory_t2345474638;
// Mono.Xml.DTDElementDeclarationCollection
struct DTDElementDeclarationCollection_t3839880060;
// Mono.Xml.DTDAttListDeclarationCollection
struct DTDAttListDeclarationCollection_t4224010798;
// Mono.Xml.DTDParameterEntityDeclarationCollection
struct DTDParameterEntityDeclarationCollection_t430810332;
// Mono.Xml.DTDEntityDeclarationCollection
struct DTDEntityDeclarationCollection_t1347165388;
// Mono.Xml.DTDNotationDeclarationCollection
struct DTDNotationDeclarationCollection_t1273717105;
// System.Collections.ArrayList
struct ArrayList_t815286905;
// System.Xml.XmlResolver
struct XmlResolver_t1481695800;
// System.Xml.XmlNameTable
struct XmlNameTable_t1479426498;
// System.Xml.XmlNode/EmptyNodeList
struct EmptyNodeList_t2676474877;
// System.Xml.XmlDocument
struct XmlDocument_t2296465371;
// System.Xml.XmlNodeListChildren
struct XmlNodeListChildren_t3100780127;
// System.Collections.IEnumerator
struct IEnumerator_t1608174681;
// System.Xml.XmlNode
struct XmlNode_t482051342;
// Mono.Xml.DTDContentModel
struct DTDContentModel_t2007242871;
// System.Type
struct Type_t;
// System.Xml.NameTable/Entry[]
struct EntryU5BU5D_t3333416064;
// System.Uri
struct Uri_t1142918117;
// System.Xml.Schema.XmlSchemaDatatype
struct XmlSchemaDatatype_t2974024598;
// System.Xml.XmlNameEntry
struct XmlNameEntry_t358655993;
// System.Xml.XmlLinkedNode
struct XmlLinkedNode_t2960487756;
// System.Xml.Schema.IXmlSchemaInfo
struct IXmlSchemaInfo_t1034804556;
// Mono.Xml.DTDNode
struct DTDNode_t2342132918;
// System.Xml.XmlElement
struct XmlElement_t62277471;
// System.Security.Cryptography.RandomNumberGenerator
struct RandomNumberGenerator_t1199705397;
// System.Collections.Generic.List`1<System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>>
struct List_1_t2398859287;
// System.Xml.Schema.XmlSchemaCompilationSettings
struct XmlSchemaCompilationSettings_t2801413820;
// System.Xml.Serialization.XmlSerializerNamespaces
struct XmlSerializerNamespaces_t3956590116;
// System.String[]
struct StringU5BU5D_t4199878655;
// Mono.Xml.DTDContentModelCollection
struct DTDContentModelCollection_t2794654295;
// Mono.Xml.DictionaryBase
struct DictionaryBase_t377618675;
// Mono.Xml.Schema.XsdAnySimpleType
struct XsdAnySimpleType_t1645894131;
// Mono.Xml.Schema.XsdString
struct XsdString_t3808583524;
// Mono.Xml.Schema.XsdNormalizedString
struct XsdNormalizedString_t1600426378;
// Mono.Xml.Schema.XsdToken
struct XsdToken_t508248724;
// Mono.Xml.Schema.XsdLanguage
struct XsdLanguage_t3150055479;
// Mono.Xml.Schema.XsdNMToken
struct XsdNMToken_t2787524133;
// Mono.Xml.Schema.XsdNMTokens
struct XsdNMTokens_t3644935921;
// Mono.Xml.Schema.XsdName
struct XsdName_t2809458942;
// Mono.Xml.Schema.XsdNCName
struct XsdNCName_t2448558528;
// Mono.Xml.Schema.XsdID
struct XsdID_t3641052050;
// Mono.Xml.Schema.XsdIDRef
struct XsdIDRef_t3533441891;
// Mono.Xml.Schema.XsdIDRefs
struct XsdIDRefs_t4196912482;
// Mono.Xml.Schema.XsdEntity
struct XsdEntity_t2294332234;
// Mono.Xml.Schema.XsdEntities
struct XsdEntities_t1133855613;
// Mono.Xml.Schema.XsdNotation
struct XsdNotation_t2721234078;
// Mono.Xml.Schema.XsdDecimal
struct XsdDecimal_t3796307291;
// Mono.Xml.Schema.XsdInteger
struct XsdInteger_t1726820563;
// Mono.Xml.Schema.XsdLong
struct XsdLong_t1719775717;
// Mono.Xml.Schema.XsdInt
struct XsdInt_t4031406130;
// Mono.Xml.Schema.XsdShort
struct XsdShort_t1466004108;
// Mono.Xml.Schema.XsdByte
struct XsdByte_t2834617523;
// Mono.Xml.Schema.XsdNonNegativeInteger
struct XsdNonNegativeInteger_t2518569928;
// Mono.Xml.Schema.XsdPositiveInteger
struct XsdPositiveInteger_t858890625;
// Mono.Xml.Schema.XsdUnsignedLong
struct XsdUnsignedLong_t3088213186;
// Mono.Xml.Schema.XsdUnsignedInt
struct XsdUnsignedInt_t1345788448;
// Mono.Xml.Schema.XsdUnsignedShort
struct XsdUnsignedShort_t3040059537;
// Mono.Xml.Schema.XsdUnsignedByte
struct XsdUnsignedByte_t1503500326;
// Mono.Xml.Schema.XsdNonPositiveInteger
struct XsdNonPositiveInteger_t654673514;
// Mono.Xml.Schema.XsdNegativeInteger
struct XsdNegativeInteger_t145731310;
// Mono.Xml.Schema.XsdFloat
struct XsdFloat_t2432376376;
// Mono.Xml.Schema.XsdDouble
struct XsdDouble_t2405104440;
// Mono.Xml.Schema.XsdBase64Binary
struct XsdBase64Binary_t1793769650;
// Mono.Xml.Schema.XsdBoolean
struct XsdBoolean_t747919005;
// Mono.Xml.Schema.XsdAnyURI
struct XsdAnyURI_t1696333635;
// Mono.Xml.Schema.XsdDuration
struct XsdDuration_t4216890283;
// Mono.Xml.Schema.XsdDateTime
struct XsdDateTime_t2878826493;
// Mono.Xml.Schema.XsdDate
struct XsdDate_t84799097;
// Mono.Xml.Schema.XsdTime
struct XsdTime_t194014253;
// Mono.Xml.Schema.XsdHexBinary
struct XsdHexBinary_t309962759;
// Mono.Xml.Schema.XsdQName
struct XsdQName_t2375427330;
// Mono.Xml.Schema.XsdGYearMonth
struct XsdGYearMonth_t4060942859;
// Mono.Xml.Schema.XsdGMonthDay
struct XsdGMonthDay_t1849750074;
// Mono.Xml.Schema.XsdGYear
struct XsdGYear_t1626334498;
// Mono.Xml.Schema.XsdGMonth
struct XsdGMonth_t1559631661;
// Mono.Xml.Schema.XsdGDay
struct XsdGDay_t1637325925;
// Mono.Xml.Schema.XdtAnyAtomicType
struct XdtAnyAtomicType_t2627475155;
// Mono.Xml.Schema.XdtUntypedAtomic
struct XdtUntypedAtomic_t2359648093;
// Mono.Xml.Schema.XdtDayTimeDuration
struct XdtDayTimeDuration_t597694552;
// Mono.Xml.Schema.XdtYearMonthDuration
struct XdtYearMonthDuration_t673549898;
// System.Xml.Schema.XmlSchemaSimpleType
struct XmlSchemaSimpleType_t1597467585;
// System.Xml.Schema.XmlSchemaAttribute
struct XmlSchemaAttribute_t569796853;
// System.Xml.Schema.XmlSchemaElement
struct XmlSchemaElement_t2407988793;
// System.Xml.Schema.XmlSchemaType
struct XmlSchemaType_t524866458;
// System.Xml.XmlQualifiedName
struct XmlQualifiedName_t2861843702;
// System.Xml.Schema.XmlSchemaSimpleTypeContent
struct XmlSchemaSimpleTypeContent_t554989856;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef ENTRY_T4088204333_H
#define ENTRY_T4088204333_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.NameTable/Entry
struct  Entry_t4088204333  : public RuntimeObject
{
public:
	// System.String System.Xml.NameTable/Entry::str
	String_t* ___str_0;
	// System.Int32 System.Xml.NameTable/Entry::hash
	int32_t ___hash_1;
	// System.Int32 System.Xml.NameTable/Entry::len
	int32_t ___len_2;
	// System.Xml.NameTable/Entry System.Xml.NameTable/Entry::next
	Entry_t4088204333 * ___next_3;

public:
	inline static int32_t get_offset_of_str_0() { return static_cast<int32_t>(offsetof(Entry_t4088204333, ___str_0)); }
	inline String_t* get_str_0() const { return ___str_0; }
	inline String_t** get_address_of_str_0() { return &___str_0; }
	inline void set_str_0(String_t* value)
	{
		___str_0 = value;
		Il2CppCodeGenWriteBarrier((&___str_0), value);
	}

	inline static int32_t get_offset_of_hash_1() { return static_cast<int32_t>(offsetof(Entry_t4088204333, ___hash_1)); }
	inline int32_t get_hash_1() const { return ___hash_1; }
	inline int32_t* get_address_of_hash_1() { return &___hash_1; }
	inline void set_hash_1(int32_t value)
	{
		___hash_1 = value;
	}

	inline static int32_t get_offset_of_len_2() { return static_cast<int32_t>(offsetof(Entry_t4088204333, ___len_2)); }
	inline int32_t get_len_2() const { return ___len_2; }
	inline int32_t* get_address_of_len_2() { return &___len_2; }
	inline void set_len_2(int32_t value)
	{
		___len_2 = value;
	}

	inline static int32_t get_offset_of_next_3() { return static_cast<int32_t>(offsetof(Entry_t4088204333, ___next_3)); }
	inline Entry_t4088204333 * get_next_3() const { return ___next_3; }
	inline Entry_t4088204333 ** get_address_of_next_3() { return &___next_3; }
	inline void set_next_3(Entry_t4088204333 * value)
	{
		___next_3 = value;
		Il2CppCodeGenWriteBarrier((&___next_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENTRY_T4088204333_H
#ifndef DTDPARAMETERENTITYDECLARATIONCOLLECTION_T430810332_H
#define DTDPARAMETERENTITYDECLARATIONCOLLECTION_T430810332_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDParameterEntityDeclarationCollection
struct  DTDParameterEntityDeclarationCollection_t430810332  : public RuntimeObject
{
public:
	// System.Collections.Hashtable Mono.Xml.DTDParameterEntityDeclarationCollection::peDecls
	Hashtable_t3043587435 * ___peDecls_0;
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDParameterEntityDeclarationCollection::root
	DTDObjectModel_t739056388 * ___root_1;

public:
	inline static int32_t get_offset_of_peDecls_0() { return static_cast<int32_t>(offsetof(DTDParameterEntityDeclarationCollection_t430810332, ___peDecls_0)); }
	inline Hashtable_t3043587435 * get_peDecls_0() const { return ___peDecls_0; }
	inline Hashtable_t3043587435 ** get_address_of_peDecls_0() { return &___peDecls_0; }
	inline void set_peDecls_0(Hashtable_t3043587435 * value)
	{
		___peDecls_0 = value;
		Il2CppCodeGenWriteBarrier((&___peDecls_0), value);
	}

	inline static int32_t get_offset_of_root_1() { return static_cast<int32_t>(offsetof(DTDParameterEntityDeclarationCollection_t430810332, ___root_1)); }
	inline DTDObjectModel_t739056388 * get_root_1() const { return ___root_1; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_1() { return &___root_1; }
	inline void set_root_1(DTDObjectModel_t739056388 * value)
	{
		___root_1 = value;
		Il2CppCodeGenWriteBarrier((&___root_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDPARAMETERENTITYDECLARATIONCOLLECTION_T430810332_H
#ifndef XMLCHAR_T1412824432_H
#define XMLCHAR_T1412824432_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlChar
struct  XmlChar_t1412824432  : public RuntimeObject
{
public:

public:
};

struct XmlChar_t1412824432_StaticFields
{
public:
	// System.Char[] System.Xml.XmlChar::WhitespaceChars
	CharU5BU5D_t2772155777* ___WhitespaceChars_0;
	// System.Byte[] System.Xml.XmlChar::firstNamePages
	ByteU5BU5D_t2643433246* ___firstNamePages_1;
	// System.Byte[] System.Xml.XmlChar::namePages
	ByteU5BU5D_t2643433246* ___namePages_2;
	// System.UInt32[] System.Xml.XmlChar::nameBitmap
	UInt32U5BU5D_t1349399947* ___nameBitmap_3;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.XmlChar::<>f__switch$map47
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map47_4;

public:
	inline static int32_t get_offset_of_WhitespaceChars_0() { return static_cast<int32_t>(offsetof(XmlChar_t1412824432_StaticFields, ___WhitespaceChars_0)); }
	inline CharU5BU5D_t2772155777* get_WhitespaceChars_0() const { return ___WhitespaceChars_0; }
	inline CharU5BU5D_t2772155777** get_address_of_WhitespaceChars_0() { return &___WhitespaceChars_0; }
	inline void set_WhitespaceChars_0(CharU5BU5D_t2772155777* value)
	{
		___WhitespaceChars_0 = value;
		Il2CppCodeGenWriteBarrier((&___WhitespaceChars_0), value);
	}

	inline static int32_t get_offset_of_firstNamePages_1() { return static_cast<int32_t>(offsetof(XmlChar_t1412824432_StaticFields, ___firstNamePages_1)); }
	inline ByteU5BU5D_t2643433246* get_firstNamePages_1() const { return ___firstNamePages_1; }
	inline ByteU5BU5D_t2643433246** get_address_of_firstNamePages_1() { return &___firstNamePages_1; }
	inline void set_firstNamePages_1(ByteU5BU5D_t2643433246* value)
	{
		___firstNamePages_1 = value;
		Il2CppCodeGenWriteBarrier((&___firstNamePages_1), value);
	}

	inline static int32_t get_offset_of_namePages_2() { return static_cast<int32_t>(offsetof(XmlChar_t1412824432_StaticFields, ___namePages_2)); }
	inline ByteU5BU5D_t2643433246* get_namePages_2() const { return ___namePages_2; }
	inline ByteU5BU5D_t2643433246** get_address_of_namePages_2() { return &___namePages_2; }
	inline void set_namePages_2(ByteU5BU5D_t2643433246* value)
	{
		___namePages_2 = value;
		Il2CppCodeGenWriteBarrier((&___namePages_2), value);
	}

	inline static int32_t get_offset_of_nameBitmap_3() { return static_cast<int32_t>(offsetof(XmlChar_t1412824432_StaticFields, ___nameBitmap_3)); }
	inline UInt32U5BU5D_t1349399947* get_nameBitmap_3() const { return ___nameBitmap_3; }
	inline UInt32U5BU5D_t1349399947** get_address_of_nameBitmap_3() { return &___nameBitmap_3; }
	inline void set_nameBitmap_3(UInt32U5BU5D_t1349399947* value)
	{
		___nameBitmap_3 = value;
		Il2CppCodeGenWriteBarrier((&___nameBitmap_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map47_4() { return static_cast<int32_t>(offsetof(XmlChar_t1412824432_StaticFields, ___U3CU3Ef__switchU24map47_4)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map47_4() const { return ___U3CU3Ef__switchU24map47_4; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map47_4() { return &___U3CU3Ef__switchU24map47_4; }
	inline void set_U3CU3Ef__switchU24map47_4(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map47_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map47_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLCHAR_T1412824432_H
#ifndef XMLSCHEMACOMPILATIONSETTINGS_T2801413820_H
#define XMLSCHEMACOMPILATIONSETTINGS_T2801413820_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaCompilationSettings
struct  XmlSchemaCompilationSettings_t2801413820  : public RuntimeObject
{
public:
	// System.Boolean System.Xml.Schema.XmlSchemaCompilationSettings::enable_upa_check
	bool ___enable_upa_check_0;

public:
	inline static int32_t get_offset_of_enable_upa_check_0() { return static_cast<int32_t>(offsetof(XmlSchemaCompilationSettings_t2801413820, ___enable_upa_check_0)); }
	inline bool get_enable_upa_check_0() const { return ___enable_upa_check_0; }
	inline bool* get_address_of_enable_upa_check_0() { return &___enable_upa_check_0; }
	inline void set_enable_upa_check_0(bool value)
	{
		___enable_upa_check_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMACOMPILATIONSETTINGS_T2801413820_H
#ifndef DTDREADER_T2281877084_H
#define DTDREADER_T2281877084_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.DTDReader
struct  DTDReader_t2281877084  : public RuntimeObject
{
public:
	// System.Xml.XmlParserInput System.Xml.DTDReader::currentInput
	XmlParserInput_t1933096837 * ___currentInput_0;
	// System.Collections.Stack System.Xml.DTDReader::parserInputStack
	Stack_t1028188311 * ___parserInputStack_1;
	// System.Char[] System.Xml.DTDReader::nameBuffer
	CharU5BU5D_t2772155777* ___nameBuffer_2;
	// System.Int32 System.Xml.DTDReader::nameLength
	int32_t ___nameLength_3;
	// System.Int32 System.Xml.DTDReader::nameCapacity
	int32_t ___nameCapacity_4;
	// System.Text.StringBuilder System.Xml.DTDReader::valueBuffer
	StringBuilder_t1854403953 * ___valueBuffer_5;
	// System.Int32 System.Xml.DTDReader::currentLinkedNodeLineNumber
	int32_t ___currentLinkedNodeLineNumber_6;
	// System.Int32 System.Xml.DTDReader::currentLinkedNodeLinePosition
	int32_t ___currentLinkedNodeLinePosition_7;
	// System.Int32 System.Xml.DTDReader::dtdIncludeSect
	int32_t ___dtdIncludeSect_8;
	// System.Boolean System.Xml.DTDReader::normalization
	bool ___normalization_9;
	// System.Boolean System.Xml.DTDReader::processingInternalSubset
	bool ___processingInternalSubset_10;
	// System.String System.Xml.DTDReader::cachedPublicId
	String_t* ___cachedPublicId_11;
	// System.String System.Xml.DTDReader::cachedSystemId
	String_t* ___cachedSystemId_12;
	// Mono.Xml.DTDObjectModel System.Xml.DTDReader::DTD
	DTDObjectModel_t739056388 * ___DTD_13;

public:
	inline static int32_t get_offset_of_currentInput_0() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___currentInput_0)); }
	inline XmlParserInput_t1933096837 * get_currentInput_0() const { return ___currentInput_0; }
	inline XmlParserInput_t1933096837 ** get_address_of_currentInput_0() { return &___currentInput_0; }
	inline void set_currentInput_0(XmlParserInput_t1933096837 * value)
	{
		___currentInput_0 = value;
		Il2CppCodeGenWriteBarrier((&___currentInput_0), value);
	}

	inline static int32_t get_offset_of_parserInputStack_1() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___parserInputStack_1)); }
	inline Stack_t1028188311 * get_parserInputStack_1() const { return ___parserInputStack_1; }
	inline Stack_t1028188311 ** get_address_of_parserInputStack_1() { return &___parserInputStack_1; }
	inline void set_parserInputStack_1(Stack_t1028188311 * value)
	{
		___parserInputStack_1 = value;
		Il2CppCodeGenWriteBarrier((&___parserInputStack_1), value);
	}

	inline static int32_t get_offset_of_nameBuffer_2() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___nameBuffer_2)); }
	inline CharU5BU5D_t2772155777* get_nameBuffer_2() const { return ___nameBuffer_2; }
	inline CharU5BU5D_t2772155777** get_address_of_nameBuffer_2() { return &___nameBuffer_2; }
	inline void set_nameBuffer_2(CharU5BU5D_t2772155777* value)
	{
		___nameBuffer_2 = value;
		Il2CppCodeGenWriteBarrier((&___nameBuffer_2), value);
	}

	inline static int32_t get_offset_of_nameLength_3() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___nameLength_3)); }
	inline int32_t get_nameLength_3() const { return ___nameLength_3; }
	inline int32_t* get_address_of_nameLength_3() { return &___nameLength_3; }
	inline void set_nameLength_3(int32_t value)
	{
		___nameLength_3 = value;
	}

	inline static int32_t get_offset_of_nameCapacity_4() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___nameCapacity_4)); }
	inline int32_t get_nameCapacity_4() const { return ___nameCapacity_4; }
	inline int32_t* get_address_of_nameCapacity_4() { return &___nameCapacity_4; }
	inline void set_nameCapacity_4(int32_t value)
	{
		___nameCapacity_4 = value;
	}

	inline static int32_t get_offset_of_valueBuffer_5() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___valueBuffer_5)); }
	inline StringBuilder_t1854403953 * get_valueBuffer_5() const { return ___valueBuffer_5; }
	inline StringBuilder_t1854403953 ** get_address_of_valueBuffer_5() { return &___valueBuffer_5; }
	inline void set_valueBuffer_5(StringBuilder_t1854403953 * value)
	{
		___valueBuffer_5 = value;
		Il2CppCodeGenWriteBarrier((&___valueBuffer_5), value);
	}

	inline static int32_t get_offset_of_currentLinkedNodeLineNumber_6() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___currentLinkedNodeLineNumber_6)); }
	inline int32_t get_currentLinkedNodeLineNumber_6() const { return ___currentLinkedNodeLineNumber_6; }
	inline int32_t* get_address_of_currentLinkedNodeLineNumber_6() { return &___currentLinkedNodeLineNumber_6; }
	inline void set_currentLinkedNodeLineNumber_6(int32_t value)
	{
		___currentLinkedNodeLineNumber_6 = value;
	}

	inline static int32_t get_offset_of_currentLinkedNodeLinePosition_7() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___currentLinkedNodeLinePosition_7)); }
	inline int32_t get_currentLinkedNodeLinePosition_7() const { return ___currentLinkedNodeLinePosition_7; }
	inline int32_t* get_address_of_currentLinkedNodeLinePosition_7() { return &___currentLinkedNodeLinePosition_7; }
	inline void set_currentLinkedNodeLinePosition_7(int32_t value)
	{
		___currentLinkedNodeLinePosition_7 = value;
	}

	inline static int32_t get_offset_of_dtdIncludeSect_8() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___dtdIncludeSect_8)); }
	inline int32_t get_dtdIncludeSect_8() const { return ___dtdIncludeSect_8; }
	inline int32_t* get_address_of_dtdIncludeSect_8() { return &___dtdIncludeSect_8; }
	inline void set_dtdIncludeSect_8(int32_t value)
	{
		___dtdIncludeSect_8 = value;
	}

	inline static int32_t get_offset_of_normalization_9() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___normalization_9)); }
	inline bool get_normalization_9() const { return ___normalization_9; }
	inline bool* get_address_of_normalization_9() { return &___normalization_9; }
	inline void set_normalization_9(bool value)
	{
		___normalization_9 = value;
	}

	inline static int32_t get_offset_of_processingInternalSubset_10() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___processingInternalSubset_10)); }
	inline bool get_processingInternalSubset_10() const { return ___processingInternalSubset_10; }
	inline bool* get_address_of_processingInternalSubset_10() { return &___processingInternalSubset_10; }
	inline void set_processingInternalSubset_10(bool value)
	{
		___processingInternalSubset_10 = value;
	}

	inline static int32_t get_offset_of_cachedPublicId_11() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___cachedPublicId_11)); }
	inline String_t* get_cachedPublicId_11() const { return ___cachedPublicId_11; }
	inline String_t** get_address_of_cachedPublicId_11() { return &___cachedPublicId_11; }
	inline void set_cachedPublicId_11(String_t* value)
	{
		___cachedPublicId_11 = value;
		Il2CppCodeGenWriteBarrier((&___cachedPublicId_11), value);
	}

	inline static int32_t get_offset_of_cachedSystemId_12() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___cachedSystemId_12)); }
	inline String_t* get_cachedSystemId_12() const { return ___cachedSystemId_12; }
	inline String_t** get_address_of_cachedSystemId_12() { return &___cachedSystemId_12; }
	inline void set_cachedSystemId_12(String_t* value)
	{
		___cachedSystemId_12 = value;
		Il2CppCodeGenWriteBarrier((&___cachedSystemId_12), value);
	}

	inline static int32_t get_offset_of_DTD_13() { return static_cast<int32_t>(offsetof(DTDReader_t2281877084, ___DTD_13)); }
	inline DTDObjectModel_t739056388 * get_DTD_13() const { return ___DTD_13; }
	inline DTDObjectModel_t739056388 ** get_address_of_DTD_13() { return &___DTD_13; }
	inline void set_DTD_13(DTDObjectModel_t739056388 * value)
	{
		___DTD_13 = value;
		Il2CppCodeGenWriteBarrier((&___DTD_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDREADER_T2281877084_H
#ifndef XMLSERIALIZERNAMESPACES_T3956590116_H
#define XMLSERIALIZERNAMESPACES_T3956590116_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Serialization.XmlSerializerNamespaces
struct  XmlSerializerNamespaces_t3956590116  : public RuntimeObject
{
public:
	// System.Collections.Specialized.ListDictionary System.Xml.Serialization.XmlSerializerNamespaces::namespaces
	ListDictionary_t2358247778 * ___namespaces_0;

public:
	inline static int32_t get_offset_of_namespaces_0() { return static_cast<int32_t>(offsetof(XmlSerializerNamespaces_t3956590116, ___namespaces_0)); }
	inline ListDictionary_t2358247778 * get_namespaces_0() const { return ___namespaces_0; }
	inline ListDictionary_t2358247778 ** get_address_of_namespaces_0() { return &___namespaces_0; }
	inline void set_namespaces_0(ListDictionary_t2358247778 * value)
	{
		___namespaces_0 = value;
		Il2CppCodeGenWriteBarrier((&___namespaces_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSERIALIZERNAMESPACES_T3956590116_H
#ifndef ATTRIBUTE_T2363954793_H
#define ATTRIBUTE_T2363954793_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_t2363954793  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_T2363954793_H
#ifndef LIST_1_T2398859287_H
#define LIST_1_T2398859287_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>>
struct  List_1_t2398859287  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	KeyValuePair_2U5BU5D_t1497786643* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t2398859287, ____items_1)); }
	inline KeyValuePair_2U5BU5D_t1497786643* get__items_1() const { return ____items_1; }
	inline KeyValuePair_2U5BU5D_t1497786643** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(KeyValuePair_2U5BU5D_t1497786643* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t2398859287, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t2398859287, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}
};

struct List_1_t2398859287_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::EmptyArray
	KeyValuePair_2U5BU5D_t1497786643* ___EmptyArray_4;

public:
	inline static int32_t get_offset_of_EmptyArray_4() { return static_cast<int32_t>(offsetof(List_1_t2398859287_StaticFields, ___EmptyArray_4)); }
	inline KeyValuePair_2U5BU5D_t1497786643* get_EmptyArray_4() const { return ___EmptyArray_4; }
	inline KeyValuePair_2U5BU5D_t1497786643** get_address_of_EmptyArray_4() { return &___EmptyArray_4; }
	inline void set_EmptyArray_4(KeyValuePair_2U5BU5D_t1497786643* value)
	{
		___EmptyArray_4 = value;
		Il2CppCodeGenWriteBarrier((&___EmptyArray_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T2398859287_H
#ifndef DTDOBJECTMODEL_T739056388_H
#define DTDOBJECTMODEL_T739056388_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDObjectModel
struct  DTDObjectModel_t739056388  : public RuntimeObject
{
public:
	// Mono.Xml.DTDAutomataFactory Mono.Xml.DTDObjectModel::factory
	DTDAutomataFactory_t2345474638 * ___factory_0;
	// Mono.Xml.DTDElementDeclarationCollection Mono.Xml.DTDObjectModel::elementDecls
	DTDElementDeclarationCollection_t3839880060 * ___elementDecls_1;
	// Mono.Xml.DTDAttListDeclarationCollection Mono.Xml.DTDObjectModel::attListDecls
	DTDAttListDeclarationCollection_t4224010798 * ___attListDecls_2;
	// Mono.Xml.DTDParameterEntityDeclarationCollection Mono.Xml.DTDObjectModel::peDecls
	DTDParameterEntityDeclarationCollection_t430810332 * ___peDecls_3;
	// Mono.Xml.DTDEntityDeclarationCollection Mono.Xml.DTDObjectModel::entityDecls
	DTDEntityDeclarationCollection_t1347165388 * ___entityDecls_4;
	// Mono.Xml.DTDNotationDeclarationCollection Mono.Xml.DTDObjectModel::notationDecls
	DTDNotationDeclarationCollection_t1273717105 * ___notationDecls_5;
	// System.Collections.ArrayList Mono.Xml.DTDObjectModel::validationErrors
	ArrayList_t815286905 * ___validationErrors_6;
	// System.Xml.XmlResolver Mono.Xml.DTDObjectModel::resolver
	XmlResolver_t1481695800 * ___resolver_7;
	// System.Xml.XmlNameTable Mono.Xml.DTDObjectModel::nameTable
	XmlNameTable_t1479426498 * ___nameTable_8;
	// System.Collections.Hashtable Mono.Xml.DTDObjectModel::externalResources
	Hashtable_t3043587435 * ___externalResources_9;
	// System.String Mono.Xml.DTDObjectModel::baseURI
	String_t* ___baseURI_10;
	// System.String Mono.Xml.DTDObjectModel::name
	String_t* ___name_11;
	// System.String Mono.Xml.DTDObjectModel::publicId
	String_t* ___publicId_12;
	// System.String Mono.Xml.DTDObjectModel::systemId
	String_t* ___systemId_13;
	// System.String Mono.Xml.DTDObjectModel::intSubset
	String_t* ___intSubset_14;
	// System.Boolean Mono.Xml.DTDObjectModel::intSubsetHasPERef
	bool ___intSubsetHasPERef_15;
	// System.Boolean Mono.Xml.DTDObjectModel::isStandalone
	bool ___isStandalone_16;
	// System.Int32 Mono.Xml.DTDObjectModel::lineNumber
	int32_t ___lineNumber_17;
	// System.Int32 Mono.Xml.DTDObjectModel::linePosition
	int32_t ___linePosition_18;

public:
	inline static int32_t get_offset_of_factory_0() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___factory_0)); }
	inline DTDAutomataFactory_t2345474638 * get_factory_0() const { return ___factory_0; }
	inline DTDAutomataFactory_t2345474638 ** get_address_of_factory_0() { return &___factory_0; }
	inline void set_factory_0(DTDAutomataFactory_t2345474638 * value)
	{
		___factory_0 = value;
		Il2CppCodeGenWriteBarrier((&___factory_0), value);
	}

	inline static int32_t get_offset_of_elementDecls_1() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___elementDecls_1)); }
	inline DTDElementDeclarationCollection_t3839880060 * get_elementDecls_1() const { return ___elementDecls_1; }
	inline DTDElementDeclarationCollection_t3839880060 ** get_address_of_elementDecls_1() { return &___elementDecls_1; }
	inline void set_elementDecls_1(DTDElementDeclarationCollection_t3839880060 * value)
	{
		___elementDecls_1 = value;
		Il2CppCodeGenWriteBarrier((&___elementDecls_1), value);
	}

	inline static int32_t get_offset_of_attListDecls_2() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___attListDecls_2)); }
	inline DTDAttListDeclarationCollection_t4224010798 * get_attListDecls_2() const { return ___attListDecls_2; }
	inline DTDAttListDeclarationCollection_t4224010798 ** get_address_of_attListDecls_2() { return &___attListDecls_2; }
	inline void set_attListDecls_2(DTDAttListDeclarationCollection_t4224010798 * value)
	{
		___attListDecls_2 = value;
		Il2CppCodeGenWriteBarrier((&___attListDecls_2), value);
	}

	inline static int32_t get_offset_of_peDecls_3() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___peDecls_3)); }
	inline DTDParameterEntityDeclarationCollection_t430810332 * get_peDecls_3() const { return ___peDecls_3; }
	inline DTDParameterEntityDeclarationCollection_t430810332 ** get_address_of_peDecls_3() { return &___peDecls_3; }
	inline void set_peDecls_3(DTDParameterEntityDeclarationCollection_t430810332 * value)
	{
		___peDecls_3 = value;
		Il2CppCodeGenWriteBarrier((&___peDecls_3), value);
	}

	inline static int32_t get_offset_of_entityDecls_4() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___entityDecls_4)); }
	inline DTDEntityDeclarationCollection_t1347165388 * get_entityDecls_4() const { return ___entityDecls_4; }
	inline DTDEntityDeclarationCollection_t1347165388 ** get_address_of_entityDecls_4() { return &___entityDecls_4; }
	inline void set_entityDecls_4(DTDEntityDeclarationCollection_t1347165388 * value)
	{
		___entityDecls_4 = value;
		Il2CppCodeGenWriteBarrier((&___entityDecls_4), value);
	}

	inline static int32_t get_offset_of_notationDecls_5() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___notationDecls_5)); }
	inline DTDNotationDeclarationCollection_t1273717105 * get_notationDecls_5() const { return ___notationDecls_5; }
	inline DTDNotationDeclarationCollection_t1273717105 ** get_address_of_notationDecls_5() { return &___notationDecls_5; }
	inline void set_notationDecls_5(DTDNotationDeclarationCollection_t1273717105 * value)
	{
		___notationDecls_5 = value;
		Il2CppCodeGenWriteBarrier((&___notationDecls_5), value);
	}

	inline static int32_t get_offset_of_validationErrors_6() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___validationErrors_6)); }
	inline ArrayList_t815286905 * get_validationErrors_6() const { return ___validationErrors_6; }
	inline ArrayList_t815286905 ** get_address_of_validationErrors_6() { return &___validationErrors_6; }
	inline void set_validationErrors_6(ArrayList_t815286905 * value)
	{
		___validationErrors_6 = value;
		Il2CppCodeGenWriteBarrier((&___validationErrors_6), value);
	}

	inline static int32_t get_offset_of_resolver_7() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___resolver_7)); }
	inline XmlResolver_t1481695800 * get_resolver_7() const { return ___resolver_7; }
	inline XmlResolver_t1481695800 ** get_address_of_resolver_7() { return &___resolver_7; }
	inline void set_resolver_7(XmlResolver_t1481695800 * value)
	{
		___resolver_7 = value;
		Il2CppCodeGenWriteBarrier((&___resolver_7), value);
	}

	inline static int32_t get_offset_of_nameTable_8() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___nameTable_8)); }
	inline XmlNameTable_t1479426498 * get_nameTable_8() const { return ___nameTable_8; }
	inline XmlNameTable_t1479426498 ** get_address_of_nameTable_8() { return &___nameTable_8; }
	inline void set_nameTable_8(XmlNameTable_t1479426498 * value)
	{
		___nameTable_8 = value;
		Il2CppCodeGenWriteBarrier((&___nameTable_8), value);
	}

	inline static int32_t get_offset_of_externalResources_9() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___externalResources_9)); }
	inline Hashtable_t3043587435 * get_externalResources_9() const { return ___externalResources_9; }
	inline Hashtable_t3043587435 ** get_address_of_externalResources_9() { return &___externalResources_9; }
	inline void set_externalResources_9(Hashtable_t3043587435 * value)
	{
		___externalResources_9 = value;
		Il2CppCodeGenWriteBarrier((&___externalResources_9), value);
	}

	inline static int32_t get_offset_of_baseURI_10() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___baseURI_10)); }
	inline String_t* get_baseURI_10() const { return ___baseURI_10; }
	inline String_t** get_address_of_baseURI_10() { return &___baseURI_10; }
	inline void set_baseURI_10(String_t* value)
	{
		___baseURI_10 = value;
		Il2CppCodeGenWriteBarrier((&___baseURI_10), value);
	}

	inline static int32_t get_offset_of_name_11() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___name_11)); }
	inline String_t* get_name_11() const { return ___name_11; }
	inline String_t** get_address_of_name_11() { return &___name_11; }
	inline void set_name_11(String_t* value)
	{
		___name_11 = value;
		Il2CppCodeGenWriteBarrier((&___name_11), value);
	}

	inline static int32_t get_offset_of_publicId_12() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___publicId_12)); }
	inline String_t* get_publicId_12() const { return ___publicId_12; }
	inline String_t** get_address_of_publicId_12() { return &___publicId_12; }
	inline void set_publicId_12(String_t* value)
	{
		___publicId_12 = value;
		Il2CppCodeGenWriteBarrier((&___publicId_12), value);
	}

	inline static int32_t get_offset_of_systemId_13() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___systemId_13)); }
	inline String_t* get_systemId_13() const { return ___systemId_13; }
	inline String_t** get_address_of_systemId_13() { return &___systemId_13; }
	inline void set_systemId_13(String_t* value)
	{
		___systemId_13 = value;
		Il2CppCodeGenWriteBarrier((&___systemId_13), value);
	}

	inline static int32_t get_offset_of_intSubset_14() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___intSubset_14)); }
	inline String_t* get_intSubset_14() const { return ___intSubset_14; }
	inline String_t** get_address_of_intSubset_14() { return &___intSubset_14; }
	inline void set_intSubset_14(String_t* value)
	{
		___intSubset_14 = value;
		Il2CppCodeGenWriteBarrier((&___intSubset_14), value);
	}

	inline static int32_t get_offset_of_intSubsetHasPERef_15() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___intSubsetHasPERef_15)); }
	inline bool get_intSubsetHasPERef_15() const { return ___intSubsetHasPERef_15; }
	inline bool* get_address_of_intSubsetHasPERef_15() { return &___intSubsetHasPERef_15; }
	inline void set_intSubsetHasPERef_15(bool value)
	{
		___intSubsetHasPERef_15 = value;
	}

	inline static int32_t get_offset_of_isStandalone_16() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___isStandalone_16)); }
	inline bool get_isStandalone_16() const { return ___isStandalone_16; }
	inline bool* get_address_of_isStandalone_16() { return &___isStandalone_16; }
	inline void set_isStandalone_16(bool value)
	{
		___isStandalone_16 = value;
	}

	inline static int32_t get_offset_of_lineNumber_17() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___lineNumber_17)); }
	inline int32_t get_lineNumber_17() const { return ___lineNumber_17; }
	inline int32_t* get_address_of_lineNumber_17() { return &___lineNumber_17; }
	inline void set_lineNumber_17(int32_t value)
	{
		___lineNumber_17 = value;
	}

	inline static int32_t get_offset_of_linePosition_18() { return static_cast<int32_t>(offsetof(DTDObjectModel_t739056388, ___linePosition_18)); }
	inline int32_t get_linePosition_18() const { return ___linePosition_18; }
	inline int32_t* get_address_of_linePosition_18() { return &___linePosition_18; }
	inline void set_linePosition_18(int32_t value)
	{
		___linePosition_18 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDOBJECTMODEL_T739056388_H
#ifndef XMLNAMETABLE_T1479426498_H
#define XMLNAMETABLE_T1479426498_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlNameTable
struct  XmlNameTable_t1479426498  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLNAMETABLE_T1479426498_H
#ifndef XMLNODE_T482051342_H
#define XMLNODE_T482051342_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlNode
struct  XmlNode_t482051342  : public RuntimeObject
{
public:
	// System.Xml.XmlDocument System.Xml.XmlNode::ownerDocument
	XmlDocument_t2296465371 * ___ownerDocument_1;
	// System.Xml.XmlNode System.Xml.XmlNode::parentNode
	XmlNode_t482051342 * ___parentNode_2;
	// System.Xml.XmlNodeListChildren System.Xml.XmlNode::childNodes
	XmlNodeListChildren_t3100780127 * ___childNodes_3;

public:
	inline static int32_t get_offset_of_ownerDocument_1() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___ownerDocument_1)); }
	inline XmlDocument_t2296465371 * get_ownerDocument_1() const { return ___ownerDocument_1; }
	inline XmlDocument_t2296465371 ** get_address_of_ownerDocument_1() { return &___ownerDocument_1; }
	inline void set_ownerDocument_1(XmlDocument_t2296465371 * value)
	{
		___ownerDocument_1 = value;
		Il2CppCodeGenWriteBarrier((&___ownerDocument_1), value);
	}

	inline static int32_t get_offset_of_parentNode_2() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___parentNode_2)); }
	inline XmlNode_t482051342 * get_parentNode_2() const { return ___parentNode_2; }
	inline XmlNode_t482051342 ** get_address_of_parentNode_2() { return &___parentNode_2; }
	inline void set_parentNode_2(XmlNode_t482051342 * value)
	{
		___parentNode_2 = value;
		Il2CppCodeGenWriteBarrier((&___parentNode_2), value);
	}

	inline static int32_t get_offset_of_childNodes_3() { return static_cast<int32_t>(offsetof(XmlNode_t482051342, ___childNodes_3)); }
	inline XmlNodeListChildren_t3100780127 * get_childNodes_3() const { return ___childNodes_3; }
	inline XmlNodeListChildren_t3100780127 ** get_address_of_childNodes_3() { return &___childNodes_3; }
	inline void set_childNodes_3(XmlNodeListChildren_t3100780127 * value)
	{
		___childNodes_3 = value;
		Il2CppCodeGenWriteBarrier((&___childNodes_3), value);
	}
};

struct XmlNode_t482051342_StaticFields
{
public:
	// System.Xml.XmlNode/EmptyNodeList System.Xml.XmlNode::emptyList
	EmptyNodeList_t2676474877 * ___emptyList_0;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.XmlNode::<>f__switch$map44
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map44_4;

public:
	inline static int32_t get_offset_of_emptyList_0() { return static_cast<int32_t>(offsetof(XmlNode_t482051342_StaticFields, ___emptyList_0)); }
	inline EmptyNodeList_t2676474877 * get_emptyList_0() const { return ___emptyList_0; }
	inline EmptyNodeList_t2676474877 ** get_address_of_emptyList_0() { return &___emptyList_0; }
	inline void set_emptyList_0(EmptyNodeList_t2676474877 * value)
	{
		___emptyList_0 = value;
		Il2CppCodeGenWriteBarrier((&___emptyList_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map44_4() { return static_cast<int32_t>(offsetof(XmlNode_t482051342_StaticFields, ___U3CU3Ef__switchU24map44_4)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map44_4() const { return ___U3CU3Ef__switchU24map44_4; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map44_4() { return &___U3CU3Ef__switchU24map44_4; }
	inline void set_U3CU3Ef__switchU24map44_4(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map44_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map44_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLNODE_T482051342_H
#ifndef XMLNAMEDNODEMAP_T4195634320_H
#define XMLNAMEDNODEMAP_T4195634320_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlNamedNodeMap
struct  XmlNamedNodeMap_t4195634320  : public RuntimeObject
{
public:
	// System.Xml.XmlNode System.Xml.XmlNamedNodeMap::parent
	XmlNode_t482051342 * ___parent_1;
	// System.Collections.ArrayList System.Xml.XmlNamedNodeMap::nodeList
	ArrayList_t815286905 * ___nodeList_2;
	// System.Boolean System.Xml.XmlNamedNodeMap::readOnly
	bool ___readOnly_3;

public:
	inline static int32_t get_offset_of_parent_1() { return static_cast<int32_t>(offsetof(XmlNamedNodeMap_t4195634320, ___parent_1)); }
	inline XmlNode_t482051342 * get_parent_1() const { return ___parent_1; }
	inline XmlNode_t482051342 ** get_address_of_parent_1() { return &___parent_1; }
	inline void set_parent_1(XmlNode_t482051342 * value)
	{
		___parent_1 = value;
		Il2CppCodeGenWriteBarrier((&___parent_1), value);
	}

	inline static int32_t get_offset_of_nodeList_2() { return static_cast<int32_t>(offsetof(XmlNamedNodeMap_t4195634320, ___nodeList_2)); }
	inline ArrayList_t815286905 * get_nodeList_2() const { return ___nodeList_2; }
	inline ArrayList_t815286905 ** get_address_of_nodeList_2() { return &___nodeList_2; }
	inline void set_nodeList_2(ArrayList_t815286905 * value)
	{
		___nodeList_2 = value;
		Il2CppCodeGenWriteBarrier((&___nodeList_2), value);
	}

	inline static int32_t get_offset_of_readOnly_3() { return static_cast<int32_t>(offsetof(XmlNamedNodeMap_t4195634320, ___readOnly_3)); }
	inline bool get_readOnly_3() const { return ___readOnly_3; }
	inline bool* get_address_of_readOnly_3() { return &___readOnly_3; }
	inline void set_readOnly_3(bool value)
	{
		___readOnly_3 = value;
	}
};

struct XmlNamedNodeMap_t4195634320_StaticFields
{
public:
	// System.Collections.IEnumerator System.Xml.XmlNamedNodeMap::emptyEnumerator
	RuntimeObject* ___emptyEnumerator_0;

public:
	inline static int32_t get_offset_of_emptyEnumerator_0() { return static_cast<int32_t>(offsetof(XmlNamedNodeMap_t4195634320_StaticFields, ___emptyEnumerator_0)); }
	inline RuntimeObject* get_emptyEnumerator_0() const { return ___emptyEnumerator_0; }
	inline RuntimeObject** get_address_of_emptyEnumerator_0() { return &___emptyEnumerator_0; }
	inline void set_emptyEnumerator_0(RuntimeObject* value)
	{
		___emptyEnumerator_0 = value;
		Il2CppCodeGenWriteBarrier((&___emptyEnumerator_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLNAMEDNODEMAP_T4195634320_H
#ifndef VALUETYPE_T995865391_H
#define VALUETYPE_T995865391_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t995865391  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t995865391_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t995865391_marshaled_com
{
};
#endif // VALUETYPE_T995865391_H
#ifndef DTDCONTENTMODELCOLLECTION_T2794654295_H
#define DTDCONTENTMODELCOLLECTION_T2794654295_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDContentModelCollection
struct  DTDContentModelCollection_t2794654295  : public RuntimeObject
{
public:
	// System.Collections.ArrayList Mono.Xml.DTDContentModelCollection::contentModel
	ArrayList_t815286905 * ___contentModel_0;

public:
	inline static int32_t get_offset_of_contentModel_0() { return static_cast<int32_t>(offsetof(DTDContentModelCollection_t2794654295, ___contentModel_0)); }
	inline ArrayList_t815286905 * get_contentModel_0() const { return ___contentModel_0; }
	inline ArrayList_t815286905 ** get_address_of_contentModel_0() { return &___contentModel_0; }
	inline void set_contentModel_0(ArrayList_t815286905 * value)
	{
		___contentModel_0 = value;
		Il2CppCodeGenWriteBarrier((&___contentModel_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDCONTENTMODELCOLLECTION_T2794654295_H
#ifndef DTDNODE_T2342132918_H
#define DTDNODE_T2342132918_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDNode
struct  DTDNode_t2342132918  : public RuntimeObject
{
public:
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDNode::root
	DTDObjectModel_t739056388 * ___root_0;
	// System.Boolean Mono.Xml.DTDNode::isInternalSubset
	bool ___isInternalSubset_1;
	// System.String Mono.Xml.DTDNode::baseURI
	String_t* ___baseURI_2;
	// System.Int32 Mono.Xml.DTDNode::lineNumber
	int32_t ___lineNumber_3;
	// System.Int32 Mono.Xml.DTDNode::linePosition
	int32_t ___linePosition_4;

public:
	inline static int32_t get_offset_of_root_0() { return static_cast<int32_t>(offsetof(DTDNode_t2342132918, ___root_0)); }
	inline DTDObjectModel_t739056388 * get_root_0() const { return ___root_0; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_0() { return &___root_0; }
	inline void set_root_0(DTDObjectModel_t739056388 * value)
	{
		___root_0 = value;
		Il2CppCodeGenWriteBarrier((&___root_0), value);
	}

	inline static int32_t get_offset_of_isInternalSubset_1() { return static_cast<int32_t>(offsetof(DTDNode_t2342132918, ___isInternalSubset_1)); }
	inline bool get_isInternalSubset_1() const { return ___isInternalSubset_1; }
	inline bool* get_address_of_isInternalSubset_1() { return &___isInternalSubset_1; }
	inline void set_isInternalSubset_1(bool value)
	{
		___isInternalSubset_1 = value;
	}

	inline static int32_t get_offset_of_baseURI_2() { return static_cast<int32_t>(offsetof(DTDNode_t2342132918, ___baseURI_2)); }
	inline String_t* get_baseURI_2() const { return ___baseURI_2; }
	inline String_t** get_address_of_baseURI_2() { return &___baseURI_2; }
	inline void set_baseURI_2(String_t* value)
	{
		___baseURI_2 = value;
		Il2CppCodeGenWriteBarrier((&___baseURI_2), value);
	}

	inline static int32_t get_offset_of_lineNumber_3() { return static_cast<int32_t>(offsetof(DTDNode_t2342132918, ___lineNumber_3)); }
	inline int32_t get_lineNumber_3() const { return ___lineNumber_3; }
	inline int32_t* get_address_of_lineNumber_3() { return &___lineNumber_3; }
	inline void set_lineNumber_3(int32_t value)
	{
		___lineNumber_3 = value;
	}

	inline static int32_t get_offset_of_linePosition_4() { return static_cast<int32_t>(offsetof(DTDNode_t2342132918, ___linePosition_4)); }
	inline int32_t get_linePosition_4() const { return ___linePosition_4; }
	inline int32_t* get_address_of_linePosition_4() { return &___linePosition_4; }
	inline void set_linePosition_4(int32_t value)
	{
		___linePosition_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDNODE_T2342132918_H
#ifndef DTDAUTOMATAFACTORY_T2345474638_H
#define DTDAUTOMATAFACTORY_T2345474638_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDAutomataFactory
struct  DTDAutomataFactory_t2345474638  : public RuntimeObject
{
public:
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDAutomataFactory::root
	DTDObjectModel_t739056388 * ___root_0;
	// System.Collections.Hashtable Mono.Xml.DTDAutomataFactory::choiceTable
	Hashtable_t3043587435 * ___choiceTable_1;
	// System.Collections.Hashtable Mono.Xml.DTDAutomataFactory::sequenceTable
	Hashtable_t3043587435 * ___sequenceTable_2;

public:
	inline static int32_t get_offset_of_root_0() { return static_cast<int32_t>(offsetof(DTDAutomataFactory_t2345474638, ___root_0)); }
	inline DTDObjectModel_t739056388 * get_root_0() const { return ___root_0; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_0() { return &___root_0; }
	inline void set_root_0(DTDObjectModel_t739056388 * value)
	{
		___root_0 = value;
		Il2CppCodeGenWriteBarrier((&___root_0), value);
	}

	inline static int32_t get_offset_of_choiceTable_1() { return static_cast<int32_t>(offsetof(DTDAutomataFactory_t2345474638, ___choiceTable_1)); }
	inline Hashtable_t3043587435 * get_choiceTable_1() const { return ___choiceTable_1; }
	inline Hashtable_t3043587435 ** get_address_of_choiceTable_1() { return &___choiceTable_1; }
	inline void set_choiceTable_1(Hashtable_t3043587435 * value)
	{
		___choiceTable_1 = value;
		Il2CppCodeGenWriteBarrier((&___choiceTable_1), value);
	}

	inline static int32_t get_offset_of_sequenceTable_2() { return static_cast<int32_t>(offsetof(DTDAutomataFactory_t2345474638, ___sequenceTable_2)); }
	inline Hashtable_t3043587435 * get_sequenceTable_2() const { return ___sequenceTable_2; }
	inline Hashtable_t3043587435 ** get_address_of_sequenceTable_2() { return &___sequenceTable_2; }
	inline void set_sequenceTable_2(Hashtable_t3043587435 * value)
	{
		___sequenceTable_2 = value;
		Il2CppCodeGenWriteBarrier((&___sequenceTable_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDAUTOMATAFACTORY_T2345474638_H
#ifndef DTDELEMENTDECLARATION_T1082122777_H
#define DTDELEMENTDECLARATION_T1082122777_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDElementDeclaration
struct  DTDElementDeclaration_t1082122777  : public DTDNode_t2342132918
{
public:
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDElementDeclaration::root
	DTDObjectModel_t739056388 * ___root_5;
	// Mono.Xml.DTDContentModel Mono.Xml.DTDElementDeclaration::contentModel
	DTDContentModel_t2007242871 * ___contentModel_6;
	// System.String Mono.Xml.DTDElementDeclaration::name
	String_t* ___name_7;
	// System.Boolean Mono.Xml.DTDElementDeclaration::isEmpty
	bool ___isEmpty_8;
	// System.Boolean Mono.Xml.DTDElementDeclaration::isAny
	bool ___isAny_9;
	// System.Boolean Mono.Xml.DTDElementDeclaration::isMixedContent
	bool ___isMixedContent_10;

public:
	inline static int32_t get_offset_of_root_5() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___root_5)); }
	inline DTDObjectModel_t739056388 * get_root_5() const { return ___root_5; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_5() { return &___root_5; }
	inline void set_root_5(DTDObjectModel_t739056388 * value)
	{
		___root_5 = value;
		Il2CppCodeGenWriteBarrier((&___root_5), value);
	}

	inline static int32_t get_offset_of_contentModel_6() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___contentModel_6)); }
	inline DTDContentModel_t2007242871 * get_contentModel_6() const { return ___contentModel_6; }
	inline DTDContentModel_t2007242871 ** get_address_of_contentModel_6() { return &___contentModel_6; }
	inline void set_contentModel_6(DTDContentModel_t2007242871 * value)
	{
		___contentModel_6 = value;
		Il2CppCodeGenWriteBarrier((&___contentModel_6), value);
	}

	inline static int32_t get_offset_of_name_7() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___name_7)); }
	inline String_t* get_name_7() const { return ___name_7; }
	inline String_t** get_address_of_name_7() { return &___name_7; }
	inline void set_name_7(String_t* value)
	{
		___name_7 = value;
		Il2CppCodeGenWriteBarrier((&___name_7), value);
	}

	inline static int32_t get_offset_of_isEmpty_8() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___isEmpty_8)); }
	inline bool get_isEmpty_8() const { return ___isEmpty_8; }
	inline bool* get_address_of_isEmpty_8() { return &___isEmpty_8; }
	inline void set_isEmpty_8(bool value)
	{
		___isEmpty_8 = value;
	}

	inline static int32_t get_offset_of_isAny_9() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___isAny_9)); }
	inline bool get_isAny_9() const { return ___isAny_9; }
	inline bool* get_address_of_isAny_9() { return &___isAny_9; }
	inline void set_isAny_9(bool value)
	{
		___isAny_9 = value;
	}

	inline static int32_t get_offset_of_isMixedContent_10() { return static_cast<int32_t>(offsetof(DTDElementDeclaration_t1082122777, ___isMixedContent_10)); }
	inline bool get_isMixedContent_10() const { return ___isMixedContent_10; }
	inline bool* get_address_of_isMixedContent_10() { return &___isMixedContent_10; }
	inline void set_isMixedContent_10(bool value)
	{
		___isMixedContent_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDELEMENTDECLARATION_T1082122777_H
#ifndef DTDNOTATIONDECLARATION_T3875406257_H
#define DTDNOTATIONDECLARATION_T3875406257_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDNotationDeclaration
struct  DTDNotationDeclaration_t3875406257  : public DTDNode_t2342132918
{
public:
	// System.String Mono.Xml.DTDNotationDeclaration::name
	String_t* ___name_5;
	// System.String Mono.Xml.DTDNotationDeclaration::localName
	String_t* ___localName_6;
	// System.String Mono.Xml.DTDNotationDeclaration::prefix
	String_t* ___prefix_7;
	// System.String Mono.Xml.DTDNotationDeclaration::publicId
	String_t* ___publicId_8;
	// System.String Mono.Xml.DTDNotationDeclaration::systemId
	String_t* ___systemId_9;

public:
	inline static int32_t get_offset_of_name_5() { return static_cast<int32_t>(offsetof(DTDNotationDeclaration_t3875406257, ___name_5)); }
	inline String_t* get_name_5() const { return ___name_5; }
	inline String_t** get_address_of_name_5() { return &___name_5; }
	inline void set_name_5(String_t* value)
	{
		___name_5 = value;
		Il2CppCodeGenWriteBarrier((&___name_5), value);
	}

	inline static int32_t get_offset_of_localName_6() { return static_cast<int32_t>(offsetof(DTDNotationDeclaration_t3875406257, ___localName_6)); }
	inline String_t* get_localName_6() const { return ___localName_6; }
	inline String_t** get_address_of_localName_6() { return &___localName_6; }
	inline void set_localName_6(String_t* value)
	{
		___localName_6 = value;
		Il2CppCodeGenWriteBarrier((&___localName_6), value);
	}

	inline static int32_t get_offset_of_prefix_7() { return static_cast<int32_t>(offsetof(DTDNotationDeclaration_t3875406257, ___prefix_7)); }
	inline String_t* get_prefix_7() const { return ___prefix_7; }
	inline String_t** get_address_of_prefix_7() { return &___prefix_7; }
	inline void set_prefix_7(String_t* value)
	{
		___prefix_7 = value;
		Il2CppCodeGenWriteBarrier((&___prefix_7), value);
	}

	inline static int32_t get_offset_of_publicId_8() { return static_cast<int32_t>(offsetof(DTDNotationDeclaration_t3875406257, ___publicId_8)); }
	inline String_t* get_publicId_8() const { return ___publicId_8; }
	inline String_t** get_address_of_publicId_8() { return &___publicId_8; }
	inline void set_publicId_8(String_t* value)
	{
		___publicId_8 = value;
		Il2CppCodeGenWriteBarrier((&___publicId_8), value);
	}

	inline static int32_t get_offset_of_systemId_9() { return static_cast<int32_t>(offsetof(DTDNotationDeclaration_t3875406257, ___systemId_9)); }
	inline String_t* get_systemId_9() const { return ___systemId_9; }
	inline String_t** get_address_of_systemId_9() { return &___systemId_9; }
	inline void set_systemId_9(String_t* value)
	{
		___systemId_9 = value;
		Il2CppCodeGenWriteBarrier((&___systemId_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDNOTATIONDECLARATION_T3875406257_H
#ifndef XMLENUMATTRIBUTE_T1652648811_H
#define XMLENUMATTRIBUTE_T1652648811_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Serialization.XmlEnumAttribute
struct  XmlEnumAttribute_t1652648811  : public Attribute_t2363954793
{
public:
	// System.String System.Xml.Serialization.XmlEnumAttribute::name
	String_t* ___name_0;

public:
	inline static int32_t get_offset_of_name_0() { return static_cast<int32_t>(offsetof(XmlEnumAttribute_t1652648811, ___name_0)); }
	inline String_t* get_name_0() const { return ___name_0; }
	inline String_t** get_address_of_name_0() { return &___name_0; }
	inline void set_name_0(String_t* value)
	{
		___name_0 = value;
		Il2CppCodeGenWriteBarrier((&___name_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLENUMATTRIBUTE_T1652648811_H
#ifndef DTDATTLISTDECLARATION_T3156318456_H
#define DTDATTLISTDECLARATION_T3156318456_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDAttListDeclaration
struct  DTDAttListDeclaration_t3156318456  : public DTDNode_t2342132918
{
public:
	// System.String Mono.Xml.DTDAttListDeclaration::name
	String_t* ___name_5;
	// System.Collections.Hashtable Mono.Xml.DTDAttListDeclaration::attributeOrders
	Hashtable_t3043587435 * ___attributeOrders_6;
	// System.Collections.ArrayList Mono.Xml.DTDAttListDeclaration::attributes
	ArrayList_t815286905 * ___attributes_7;

public:
	inline static int32_t get_offset_of_name_5() { return static_cast<int32_t>(offsetof(DTDAttListDeclaration_t3156318456, ___name_5)); }
	inline String_t* get_name_5() const { return ___name_5; }
	inline String_t** get_address_of_name_5() { return &___name_5; }
	inline void set_name_5(String_t* value)
	{
		___name_5 = value;
		Il2CppCodeGenWriteBarrier((&___name_5), value);
	}

	inline static int32_t get_offset_of_attributeOrders_6() { return static_cast<int32_t>(offsetof(DTDAttListDeclaration_t3156318456, ___attributeOrders_6)); }
	inline Hashtable_t3043587435 * get_attributeOrders_6() const { return ___attributeOrders_6; }
	inline Hashtable_t3043587435 ** get_address_of_attributeOrders_6() { return &___attributeOrders_6; }
	inline void set_attributeOrders_6(Hashtable_t3043587435 * value)
	{
		___attributeOrders_6 = value;
		Il2CppCodeGenWriteBarrier((&___attributeOrders_6), value);
	}

	inline static int32_t get_offset_of_attributes_7() { return static_cast<int32_t>(offsetof(DTDAttListDeclaration_t3156318456, ___attributes_7)); }
	inline ArrayList_t815286905 * get_attributes_7() const { return ___attributes_7; }
	inline ArrayList_t815286905 ** get_address_of_attributes_7() { return &___attributes_7; }
	inline void set_attributes_7(ArrayList_t815286905 * value)
	{
		___attributes_7 = value;
		Il2CppCodeGenWriteBarrier((&___attributes_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDATTLISTDECLARATION_T3156318456_H
#ifndef XMLATTRIBUTEATTRIBUTE_T2923040814_H
#define XMLATTRIBUTEATTRIBUTE_T2923040814_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Serialization.XmlAttributeAttribute
struct  XmlAttributeAttribute_t2923040814  : public Attribute_t2363954793
{
public:
	// System.String System.Xml.Serialization.XmlAttributeAttribute::attributeName
	String_t* ___attributeName_0;

public:
	inline static int32_t get_offset_of_attributeName_0() { return static_cast<int32_t>(offsetof(XmlAttributeAttribute_t2923040814, ___attributeName_0)); }
	inline String_t* get_attributeName_0() const { return ___attributeName_0; }
	inline String_t** get_address_of_attributeName_0() { return &___attributeName_0; }
	inline void set_attributeName_0(String_t* value)
	{
		___attributeName_0 = value;
		Il2CppCodeGenWriteBarrier((&___attributeName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLATTRIBUTEATTRIBUTE_T2923040814_H
#ifndef XMLELEMENTATTRIBUTE_T3088997671_H
#define XMLELEMENTATTRIBUTE_T3088997671_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Serialization.XmlElementAttribute
struct  XmlElementAttribute_t3088997671  : public Attribute_t2363954793
{
public:
	// System.String System.Xml.Serialization.XmlElementAttribute::elementName
	String_t* ___elementName_0;
	// System.Type System.Xml.Serialization.XmlElementAttribute::type
	Type_t * ___type_1;
	// System.Int32 System.Xml.Serialization.XmlElementAttribute::order
	int32_t ___order_2;

public:
	inline static int32_t get_offset_of_elementName_0() { return static_cast<int32_t>(offsetof(XmlElementAttribute_t3088997671, ___elementName_0)); }
	inline String_t* get_elementName_0() const { return ___elementName_0; }
	inline String_t** get_address_of_elementName_0() { return &___elementName_0; }
	inline void set_elementName_0(String_t* value)
	{
		___elementName_0 = value;
		Il2CppCodeGenWriteBarrier((&___elementName_0), value);
	}

	inline static int32_t get_offset_of_type_1() { return static_cast<int32_t>(offsetof(XmlElementAttribute_t3088997671, ___type_1)); }
	inline Type_t * get_type_1() const { return ___type_1; }
	inline Type_t ** get_address_of_type_1() { return &___type_1; }
	inline void set_type_1(Type_t * value)
	{
		___type_1 = value;
		Il2CppCodeGenWriteBarrier((&___type_1), value);
	}

	inline static int32_t get_offset_of_order_2() { return static_cast<int32_t>(offsetof(XmlElementAttribute_t3088997671, ___order_2)); }
	inline int32_t get_order_2() const { return ___order_2; }
	inline int32_t* get_address_of_order_2() { return &___order_2; }
	inline void set_order_2(int32_t value)
	{
		___order_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLELEMENTATTRIBUTE_T3088997671_H
#ifndef NAMETABLE_T2175076138_H
#define NAMETABLE_T2175076138_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.NameTable
struct  NameTable_t2175076138  : public XmlNameTable_t1479426498
{
public:
	// System.Int32 System.Xml.NameTable::count
	int32_t ___count_0;
	// System.Xml.NameTable/Entry[] System.Xml.NameTable::buckets
	EntryU5BU5D_t3333416064* ___buckets_1;
	// System.Int32 System.Xml.NameTable::size
	int32_t ___size_2;

public:
	inline static int32_t get_offset_of_count_0() { return static_cast<int32_t>(offsetof(NameTable_t2175076138, ___count_0)); }
	inline int32_t get_count_0() const { return ___count_0; }
	inline int32_t* get_address_of_count_0() { return &___count_0; }
	inline void set_count_0(int32_t value)
	{
		___count_0 = value;
	}

	inline static int32_t get_offset_of_buckets_1() { return static_cast<int32_t>(offsetof(NameTable_t2175076138, ___buckets_1)); }
	inline EntryU5BU5D_t3333416064* get_buckets_1() const { return ___buckets_1; }
	inline EntryU5BU5D_t3333416064** get_address_of_buckets_1() { return &___buckets_1; }
	inline void set_buckets_1(EntryU5BU5D_t3333416064* value)
	{
		___buckets_1 = value;
		Il2CppCodeGenWriteBarrier((&___buckets_1), value);
	}

	inline static int32_t get_offset_of_size_2() { return static_cast<int32_t>(offsetof(NameTable_t2175076138, ___size_2)); }
	inline int32_t get_size_2() const { return ___size_2; }
	inline int32_t* get_address_of_size_2() { return &___size_2; }
	inline void set_size_2(int32_t value)
	{
		___size_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NAMETABLE_T2175076138_H
#ifndef XMLIGNOREATTRIBUTE_T124988628_H
#define XMLIGNOREATTRIBUTE_T124988628_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Serialization.XmlIgnoreAttribute
struct  XmlIgnoreAttribute_t124988628  : public Attribute_t2363954793
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLIGNOREATTRIBUTE_T124988628_H
#ifndef DTDENTITYBASE_T195196828_H
#define DTDENTITYBASE_T195196828_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDEntityBase
struct  DTDEntityBase_t195196828  : public DTDNode_t2342132918
{
public:
	// System.String Mono.Xml.DTDEntityBase::name
	String_t* ___name_5;
	// System.String Mono.Xml.DTDEntityBase::publicId
	String_t* ___publicId_6;
	// System.String Mono.Xml.DTDEntityBase::systemId
	String_t* ___systemId_7;
	// System.String Mono.Xml.DTDEntityBase::literalValue
	String_t* ___literalValue_8;
	// System.String Mono.Xml.DTDEntityBase::replacementText
	String_t* ___replacementText_9;
	// System.String Mono.Xml.DTDEntityBase::uriString
	String_t* ___uriString_10;
	// System.Uri Mono.Xml.DTDEntityBase::absUri
	Uri_t1142918117 * ___absUri_11;
	// System.Boolean Mono.Xml.DTDEntityBase::isInvalid
	bool ___isInvalid_12;
	// System.Boolean Mono.Xml.DTDEntityBase::loadFailed
	bool ___loadFailed_13;
	// System.Xml.XmlResolver Mono.Xml.DTDEntityBase::resolver
	XmlResolver_t1481695800 * ___resolver_14;

public:
	inline static int32_t get_offset_of_name_5() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___name_5)); }
	inline String_t* get_name_5() const { return ___name_5; }
	inline String_t** get_address_of_name_5() { return &___name_5; }
	inline void set_name_5(String_t* value)
	{
		___name_5 = value;
		Il2CppCodeGenWriteBarrier((&___name_5), value);
	}

	inline static int32_t get_offset_of_publicId_6() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___publicId_6)); }
	inline String_t* get_publicId_6() const { return ___publicId_6; }
	inline String_t** get_address_of_publicId_6() { return &___publicId_6; }
	inline void set_publicId_6(String_t* value)
	{
		___publicId_6 = value;
		Il2CppCodeGenWriteBarrier((&___publicId_6), value);
	}

	inline static int32_t get_offset_of_systemId_7() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___systemId_7)); }
	inline String_t* get_systemId_7() const { return ___systemId_7; }
	inline String_t** get_address_of_systemId_7() { return &___systemId_7; }
	inline void set_systemId_7(String_t* value)
	{
		___systemId_7 = value;
		Il2CppCodeGenWriteBarrier((&___systemId_7), value);
	}

	inline static int32_t get_offset_of_literalValue_8() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___literalValue_8)); }
	inline String_t* get_literalValue_8() const { return ___literalValue_8; }
	inline String_t** get_address_of_literalValue_8() { return &___literalValue_8; }
	inline void set_literalValue_8(String_t* value)
	{
		___literalValue_8 = value;
		Il2CppCodeGenWriteBarrier((&___literalValue_8), value);
	}

	inline static int32_t get_offset_of_replacementText_9() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___replacementText_9)); }
	inline String_t* get_replacementText_9() const { return ___replacementText_9; }
	inline String_t** get_address_of_replacementText_9() { return &___replacementText_9; }
	inline void set_replacementText_9(String_t* value)
	{
		___replacementText_9 = value;
		Il2CppCodeGenWriteBarrier((&___replacementText_9), value);
	}

	inline static int32_t get_offset_of_uriString_10() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___uriString_10)); }
	inline String_t* get_uriString_10() const { return ___uriString_10; }
	inline String_t** get_address_of_uriString_10() { return &___uriString_10; }
	inline void set_uriString_10(String_t* value)
	{
		___uriString_10 = value;
		Il2CppCodeGenWriteBarrier((&___uriString_10), value);
	}

	inline static int32_t get_offset_of_absUri_11() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___absUri_11)); }
	inline Uri_t1142918117 * get_absUri_11() const { return ___absUri_11; }
	inline Uri_t1142918117 ** get_address_of_absUri_11() { return &___absUri_11; }
	inline void set_absUri_11(Uri_t1142918117 * value)
	{
		___absUri_11 = value;
		Il2CppCodeGenWriteBarrier((&___absUri_11), value);
	}

	inline static int32_t get_offset_of_isInvalid_12() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___isInvalid_12)); }
	inline bool get_isInvalid_12() const { return ___isInvalid_12; }
	inline bool* get_address_of_isInvalid_12() { return &___isInvalid_12; }
	inline void set_isInvalid_12(bool value)
	{
		___isInvalid_12 = value;
	}

	inline static int32_t get_offset_of_loadFailed_13() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___loadFailed_13)); }
	inline bool get_loadFailed_13() const { return ___loadFailed_13; }
	inline bool* get_address_of_loadFailed_13() { return &___loadFailed_13; }
	inline void set_loadFailed_13(bool value)
	{
		___loadFailed_13 = value;
	}

	inline static int32_t get_offset_of_resolver_14() { return static_cast<int32_t>(offsetof(DTDEntityBase_t195196828, ___resolver_14)); }
	inline XmlResolver_t1481695800 * get_resolver_14() const { return ___resolver_14; }
	inline XmlResolver_t1481695800 ** get_address_of_resolver_14() { return &___resolver_14; }
	inline void set_resolver_14(XmlResolver_t1481695800 * value)
	{
		___resolver_14 = value;
		Il2CppCodeGenWriteBarrier((&___resolver_14), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDENTITYBASE_T195196828_H
#ifndef DICTIONARYBASE_T377618675_H
#define DICTIONARYBASE_T377618675_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DictionaryBase
struct  DictionaryBase_t377618675  : public List_1_t2398859287
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARYBASE_T377618675_H
#ifndef DTDATTRIBUTEDEFINITION_T2680882101_H
#define DTDATTRIBUTEDEFINITION_T2680882101_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDAttributeDefinition
struct  DTDAttributeDefinition_t2680882101  : public DTDNode_t2342132918
{
public:
	// System.String Mono.Xml.DTDAttributeDefinition::name
	String_t* ___name_5;
	// System.Xml.Schema.XmlSchemaDatatype Mono.Xml.DTDAttributeDefinition::datatype
	XmlSchemaDatatype_t2974024598 * ___datatype_6;
	// System.String Mono.Xml.DTDAttributeDefinition::unresolvedDefault
	String_t* ___unresolvedDefault_7;
	// System.String Mono.Xml.DTDAttributeDefinition::resolvedDefaultValue
	String_t* ___resolvedDefaultValue_8;

public:
	inline static int32_t get_offset_of_name_5() { return static_cast<int32_t>(offsetof(DTDAttributeDefinition_t2680882101, ___name_5)); }
	inline String_t* get_name_5() const { return ___name_5; }
	inline String_t** get_address_of_name_5() { return &___name_5; }
	inline void set_name_5(String_t* value)
	{
		___name_5 = value;
		Il2CppCodeGenWriteBarrier((&___name_5), value);
	}

	inline static int32_t get_offset_of_datatype_6() { return static_cast<int32_t>(offsetof(DTDAttributeDefinition_t2680882101, ___datatype_6)); }
	inline XmlSchemaDatatype_t2974024598 * get_datatype_6() const { return ___datatype_6; }
	inline XmlSchemaDatatype_t2974024598 ** get_address_of_datatype_6() { return &___datatype_6; }
	inline void set_datatype_6(XmlSchemaDatatype_t2974024598 * value)
	{
		___datatype_6 = value;
		Il2CppCodeGenWriteBarrier((&___datatype_6), value);
	}

	inline static int32_t get_offset_of_unresolvedDefault_7() { return static_cast<int32_t>(offsetof(DTDAttributeDefinition_t2680882101, ___unresolvedDefault_7)); }
	inline String_t* get_unresolvedDefault_7() const { return ___unresolvedDefault_7; }
	inline String_t** get_address_of_unresolvedDefault_7() { return &___unresolvedDefault_7; }
	inline void set_unresolvedDefault_7(String_t* value)
	{
		___unresolvedDefault_7 = value;
		Il2CppCodeGenWriteBarrier((&___unresolvedDefault_7), value);
	}

	inline static int32_t get_offset_of_resolvedDefaultValue_8() { return static_cast<int32_t>(offsetof(DTDAttributeDefinition_t2680882101, ___resolvedDefaultValue_8)); }
	inline String_t* get_resolvedDefaultValue_8() const { return ___resolvedDefaultValue_8; }
	inline String_t** get_address_of_resolvedDefaultValue_8() { return &___resolvedDefaultValue_8; }
	inline void set_resolvedDefaultValue_8(String_t* value)
	{
		___resolvedDefaultValue_8 = value;
		Il2CppCodeGenWriteBarrier((&___resolvedDefaultValue_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDATTRIBUTEDEFINITION_T2680882101_H
#ifndef XMLATTRIBUTE_T500479142_H
#define XMLATTRIBUTE_T500479142_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlAttribute
struct  XmlAttribute_t500479142  : public XmlNode_t482051342
{
public:
	// System.Xml.XmlNameEntry System.Xml.XmlAttribute::name
	XmlNameEntry_t358655993 * ___name_5;
	// System.Boolean System.Xml.XmlAttribute::isDefault
	bool ___isDefault_6;
	// System.Xml.XmlLinkedNode System.Xml.XmlAttribute::lastLinkedChild
	XmlLinkedNode_t2960487756 * ___lastLinkedChild_7;
	// System.Xml.Schema.IXmlSchemaInfo System.Xml.XmlAttribute::schemaInfo
	RuntimeObject* ___schemaInfo_8;

public:
	inline static int32_t get_offset_of_name_5() { return static_cast<int32_t>(offsetof(XmlAttribute_t500479142, ___name_5)); }
	inline XmlNameEntry_t358655993 * get_name_5() const { return ___name_5; }
	inline XmlNameEntry_t358655993 ** get_address_of_name_5() { return &___name_5; }
	inline void set_name_5(XmlNameEntry_t358655993 * value)
	{
		___name_5 = value;
		Il2CppCodeGenWriteBarrier((&___name_5), value);
	}

	inline static int32_t get_offset_of_isDefault_6() { return static_cast<int32_t>(offsetof(XmlAttribute_t500479142, ___isDefault_6)); }
	inline bool get_isDefault_6() const { return ___isDefault_6; }
	inline bool* get_address_of_isDefault_6() { return &___isDefault_6; }
	inline void set_isDefault_6(bool value)
	{
		___isDefault_6 = value;
	}

	inline static int32_t get_offset_of_lastLinkedChild_7() { return static_cast<int32_t>(offsetof(XmlAttribute_t500479142, ___lastLinkedChild_7)); }
	inline XmlLinkedNode_t2960487756 * get_lastLinkedChild_7() const { return ___lastLinkedChild_7; }
	inline XmlLinkedNode_t2960487756 ** get_address_of_lastLinkedChild_7() { return &___lastLinkedChild_7; }
	inline void set_lastLinkedChild_7(XmlLinkedNode_t2960487756 * value)
	{
		___lastLinkedChild_7 = value;
		Il2CppCodeGenWriteBarrier((&___lastLinkedChild_7), value);
	}

	inline static int32_t get_offset_of_schemaInfo_8() { return static_cast<int32_t>(offsetof(XmlAttribute_t500479142, ___schemaInfo_8)); }
	inline RuntimeObject* get_schemaInfo_8() const { return ___schemaInfo_8; }
	inline RuntimeObject** get_address_of_schemaInfo_8() { return &___schemaInfo_8; }
	inline void set_schemaInfo_8(RuntimeObject* value)
	{
		___schemaInfo_8 = value;
		Il2CppCodeGenWriteBarrier((&___schemaInfo_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLATTRIBUTE_T500479142_H
#ifndef XMLLINKEDNODE_T2960487756_H
#define XMLLINKEDNODE_T2960487756_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlLinkedNode
struct  XmlLinkedNode_t2960487756  : public XmlNode_t482051342
{
public:
	// System.Xml.XmlLinkedNode System.Xml.XmlLinkedNode::nextSibling
	XmlLinkedNode_t2960487756 * ___nextSibling_5;

public:
	inline static int32_t get_offset_of_nextSibling_5() { return static_cast<int32_t>(offsetof(XmlLinkedNode_t2960487756, ___nextSibling_5)); }
	inline XmlLinkedNode_t2960487756 * get_nextSibling_5() const { return ___nextSibling_5; }
	inline XmlLinkedNode_t2960487756 ** get_address_of_nextSibling_5() { return &___nextSibling_5; }
	inline void set_nextSibling_5(XmlLinkedNode_t2960487756 * value)
	{
		___nextSibling_5 = value;
		Il2CppCodeGenWriteBarrier((&___nextSibling_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLLINKEDNODE_T2960487756_H
#ifndef KEYVALUEPAIR_2_T2406658774_H
#define KEYVALUEPAIR_2_T2406658774_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>
struct  KeyValuePair_2_t2406658774 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	String_t* ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	DTDNode_t2342132918 * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2406658774, ___key_0)); }
	inline String_t* get_key_0() const { return ___key_0; }
	inline String_t** get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(String_t* value)
	{
		___key_0 = value;
		Il2CppCodeGenWriteBarrier((&___key_0), value);
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t2406658774, ___value_1)); }
	inline DTDNode_t2342132918 * get_value_1() const { return ___value_1; }
	inline DTDNode_t2342132918 ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(DTDNode_t2342132918 * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T2406658774_H
#ifndef ENUM_T1176231329_H
#define ENUM_T1176231329_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t1176231329  : public ValueType_t995865391
{
public:

public:
};

struct Enum_t1176231329_StaticFields
{
public:
	// System.Char[] System.Enum::split_char
	CharU5BU5D_t2772155777* ___split_char_0;

public:
	inline static int32_t get_offset_of_split_char_0() { return static_cast<int32_t>(offsetof(Enum_t1176231329_StaticFields, ___split_char_0)); }
	inline CharU5BU5D_t2772155777* get_split_char_0() const { return ___split_char_0; }
	inline CharU5BU5D_t2772155777** get_address_of_split_char_0() { return &___split_char_0; }
	inline void set_split_char_0(CharU5BU5D_t2772155777* value)
	{
		___split_char_0 = value;
		Il2CppCodeGenWriteBarrier((&___split_char_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t1176231329_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t1176231329_marshaled_com
{
};
#endif // ENUM_T1176231329_H
#ifndef XMLATTRIBUTECOLLECTION_T3899021962_H
#define XMLATTRIBUTECOLLECTION_T3899021962_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlAttributeCollection
struct  XmlAttributeCollection_t3899021962  : public XmlNamedNodeMap_t4195634320
{
public:
	// System.Xml.XmlElement System.Xml.XmlAttributeCollection::ownerElement
	XmlElement_t62277471 * ___ownerElement_4;
	// System.Xml.XmlDocument System.Xml.XmlAttributeCollection::ownerDocument
	XmlDocument_t2296465371 * ___ownerDocument_5;

public:
	inline static int32_t get_offset_of_ownerElement_4() { return static_cast<int32_t>(offsetof(XmlAttributeCollection_t3899021962, ___ownerElement_4)); }
	inline XmlElement_t62277471 * get_ownerElement_4() const { return ___ownerElement_4; }
	inline XmlElement_t62277471 ** get_address_of_ownerElement_4() { return &___ownerElement_4; }
	inline void set_ownerElement_4(XmlElement_t62277471 * value)
	{
		___ownerElement_4 = value;
		Il2CppCodeGenWriteBarrier((&___ownerElement_4), value);
	}

	inline static int32_t get_offset_of_ownerDocument_5() { return static_cast<int32_t>(offsetof(XmlAttributeCollection_t3899021962, ___ownerDocument_5)); }
	inline XmlDocument_t2296465371 * get_ownerDocument_5() const { return ___ownerDocument_5; }
	inline XmlDocument_t2296465371 ** get_address_of_ownerDocument_5() { return &___ownerDocument_5; }
	inline void set_ownerDocument_5(XmlDocument_t2296465371 * value)
	{
		___ownerDocument_5 = value;
		Il2CppCodeGenWriteBarrier((&___ownerDocument_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLATTRIBUTECOLLECTION_T3899021962_H
#ifndef GUID_T_H
#define GUID_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Guid
struct  Guid_t 
{
public:
	// System.Int32 System.Guid::_a
	int32_t ____a_0;
	// System.Int16 System.Guid::_b
	int16_t ____b_1;
	// System.Int16 System.Guid::_c
	int16_t ____c_2;
	// System.Byte System.Guid::_d
	uint8_t ____d_3;
	// System.Byte System.Guid::_e
	uint8_t ____e_4;
	// System.Byte System.Guid::_f
	uint8_t ____f_5;
	// System.Byte System.Guid::_g
	uint8_t ____g_6;
	// System.Byte System.Guid::_h
	uint8_t ____h_7;
	// System.Byte System.Guid::_i
	uint8_t ____i_8;
	// System.Byte System.Guid::_j
	uint8_t ____j_9;
	// System.Byte System.Guid::_k
	uint8_t ____k_10;

public:
	inline static int32_t get_offset_of__a_0() { return static_cast<int32_t>(offsetof(Guid_t, ____a_0)); }
	inline int32_t get__a_0() const { return ____a_0; }
	inline int32_t* get_address_of__a_0() { return &____a_0; }
	inline void set__a_0(int32_t value)
	{
		____a_0 = value;
	}

	inline static int32_t get_offset_of__b_1() { return static_cast<int32_t>(offsetof(Guid_t, ____b_1)); }
	inline int16_t get__b_1() const { return ____b_1; }
	inline int16_t* get_address_of__b_1() { return &____b_1; }
	inline void set__b_1(int16_t value)
	{
		____b_1 = value;
	}

	inline static int32_t get_offset_of__c_2() { return static_cast<int32_t>(offsetof(Guid_t, ____c_2)); }
	inline int16_t get__c_2() const { return ____c_2; }
	inline int16_t* get_address_of__c_2() { return &____c_2; }
	inline void set__c_2(int16_t value)
	{
		____c_2 = value;
	}

	inline static int32_t get_offset_of__d_3() { return static_cast<int32_t>(offsetof(Guid_t, ____d_3)); }
	inline uint8_t get__d_3() const { return ____d_3; }
	inline uint8_t* get_address_of__d_3() { return &____d_3; }
	inline void set__d_3(uint8_t value)
	{
		____d_3 = value;
	}

	inline static int32_t get_offset_of__e_4() { return static_cast<int32_t>(offsetof(Guid_t, ____e_4)); }
	inline uint8_t get__e_4() const { return ____e_4; }
	inline uint8_t* get_address_of__e_4() { return &____e_4; }
	inline void set__e_4(uint8_t value)
	{
		____e_4 = value;
	}

	inline static int32_t get_offset_of__f_5() { return static_cast<int32_t>(offsetof(Guid_t, ____f_5)); }
	inline uint8_t get__f_5() const { return ____f_5; }
	inline uint8_t* get_address_of__f_5() { return &____f_5; }
	inline void set__f_5(uint8_t value)
	{
		____f_5 = value;
	}

	inline static int32_t get_offset_of__g_6() { return static_cast<int32_t>(offsetof(Guid_t, ____g_6)); }
	inline uint8_t get__g_6() const { return ____g_6; }
	inline uint8_t* get_address_of__g_6() { return &____g_6; }
	inline void set__g_6(uint8_t value)
	{
		____g_6 = value;
	}

	inline static int32_t get_offset_of__h_7() { return static_cast<int32_t>(offsetof(Guid_t, ____h_7)); }
	inline uint8_t get__h_7() const { return ____h_7; }
	inline uint8_t* get_address_of__h_7() { return &____h_7; }
	inline void set__h_7(uint8_t value)
	{
		____h_7 = value;
	}

	inline static int32_t get_offset_of__i_8() { return static_cast<int32_t>(offsetof(Guid_t, ____i_8)); }
	inline uint8_t get__i_8() const { return ____i_8; }
	inline uint8_t* get_address_of__i_8() { return &____i_8; }
	inline void set__i_8(uint8_t value)
	{
		____i_8 = value;
	}

	inline static int32_t get_offset_of__j_9() { return static_cast<int32_t>(offsetof(Guid_t, ____j_9)); }
	inline uint8_t get__j_9() const { return ____j_9; }
	inline uint8_t* get_address_of__j_9() { return &____j_9; }
	inline void set__j_9(uint8_t value)
	{
		____j_9 = value;
	}

	inline static int32_t get_offset_of__k_10() { return static_cast<int32_t>(offsetof(Guid_t, ____k_10)); }
	inline uint8_t get__k_10() const { return ____k_10; }
	inline uint8_t* get_address_of__k_10() { return &____k_10; }
	inline void set__k_10(uint8_t value)
	{
		____k_10 = value;
	}
};

struct Guid_t_StaticFields
{
public:
	// System.Guid System.Guid::Empty
	Guid_t  ___Empty_11;
	// System.Object System.Guid::_rngAccess
	RuntimeObject * ____rngAccess_12;
	// System.Security.Cryptography.RandomNumberGenerator System.Guid::_rng
	RandomNumberGenerator_t1199705397 * ____rng_13;

public:
	inline static int32_t get_offset_of_Empty_11() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ___Empty_11)); }
	inline Guid_t  get_Empty_11() const { return ___Empty_11; }
	inline Guid_t * get_address_of_Empty_11() { return &___Empty_11; }
	inline void set_Empty_11(Guid_t  value)
	{
		___Empty_11 = value;
	}

	inline static int32_t get_offset_of__rngAccess_12() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rngAccess_12)); }
	inline RuntimeObject * get__rngAccess_12() const { return ____rngAccess_12; }
	inline RuntimeObject ** get_address_of__rngAccess_12() { return &____rngAccess_12; }
	inline void set__rngAccess_12(RuntimeObject * value)
	{
		____rngAccess_12 = value;
		Il2CppCodeGenWriteBarrier((&____rngAccess_12), value);
	}

	inline static int32_t get_offset_of__rng_13() { return static_cast<int32_t>(offsetof(Guid_t_StaticFields, ____rng_13)); }
	inline RandomNumberGenerator_t1199705397 * get__rng_13() const { return ____rng_13; }
	inline RandomNumberGenerator_t1199705397 ** get_address_of__rng_13() { return &____rng_13; }
	inline void set__rng_13(RandomNumberGenerator_t1199705397 * value)
	{
		____rng_13 = value;
		Il2CppCodeGenWriteBarrier((&____rng_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GUID_T_H
#ifndef NEWLINEHANDLING_T2956512787_H
#define NEWLINEHANDLING_T2956512787_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.NewLineHandling
struct  NewLineHandling_t2956512787 
{
public:
	// System.Int32 System.Xml.NewLineHandling::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(NewLineHandling_t2956512787, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NEWLINEHANDLING_T2956512787_H
#ifndef XMLDECLARATION_T4189685065_H
#define XMLDECLARATION_T4189685065_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlDeclaration
struct  XmlDeclaration_t4189685065  : public XmlLinkedNode_t2960487756
{
public:
	// System.String System.Xml.XmlDeclaration::encoding
	String_t* ___encoding_6;
	// System.String System.Xml.XmlDeclaration::standalone
	String_t* ___standalone_7;
	// System.String System.Xml.XmlDeclaration::version
	String_t* ___version_8;

public:
	inline static int32_t get_offset_of_encoding_6() { return static_cast<int32_t>(offsetof(XmlDeclaration_t4189685065, ___encoding_6)); }
	inline String_t* get_encoding_6() const { return ___encoding_6; }
	inline String_t** get_address_of_encoding_6() { return &___encoding_6; }
	inline void set_encoding_6(String_t* value)
	{
		___encoding_6 = value;
		Il2CppCodeGenWriteBarrier((&___encoding_6), value);
	}

	inline static int32_t get_offset_of_standalone_7() { return static_cast<int32_t>(offsetof(XmlDeclaration_t4189685065, ___standalone_7)); }
	inline String_t* get_standalone_7() const { return ___standalone_7; }
	inline String_t** get_address_of_standalone_7() { return &___standalone_7; }
	inline void set_standalone_7(String_t* value)
	{
		___standalone_7 = value;
		Il2CppCodeGenWriteBarrier((&___standalone_7), value);
	}

	inline static int32_t get_offset_of_version_8() { return static_cast<int32_t>(offsetof(XmlDeclaration_t4189685065, ___version_8)); }
	inline String_t* get_version_8() const { return ___version_8; }
	inline String_t** get_address_of_version_8() { return &___version_8; }
	inline void set_version_8(String_t* value)
	{
		___version_8 = value;
		Il2CppCodeGenWriteBarrier((&___version_8), value);
	}
};

struct XmlDeclaration_t4189685065_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.XmlDeclaration::<>f__switch$map4A
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map4A_9;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map4A_9() { return static_cast<int32_t>(offsetof(XmlDeclaration_t4189685065_StaticFields, ___U3CU3Ef__switchU24map4A_9)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map4A_9() const { return ___U3CU3Ef__switchU24map4A_9; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map4A_9() { return &___U3CU3Ef__switchU24map4A_9; }
	inline void set_U3CU3Ef__switchU24map4A_9(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map4A_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map4A_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLDECLARATION_T4189685065_H
#ifndef NAMESPACEHANDLING_T1052850511_H
#define NAMESPACEHANDLING_T1052850511_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.NamespaceHandling
struct  NamespaceHandling_t1052850511 
{
public:
	// System.Int32 System.Xml.NamespaceHandling::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(NamespaceHandling_t1052850511, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NAMESPACEHANDLING_T1052850511_H
#ifndef XMLSCHEMAVALIDITY_T228998106_H
#define XMLSCHEMAVALIDITY_T228998106_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaValidity
struct  XmlSchemaValidity_t228998106 
{
public:
	// System.Int32 System.Xml.Schema.XmlSchemaValidity::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(XmlSchemaValidity_t228998106, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAVALIDITY_T228998106_H
#ifndef XMLCHARACTERDATA_T168497055_H
#define XMLCHARACTERDATA_T168497055_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlCharacterData
struct  XmlCharacterData_t168497055  : public XmlLinkedNode_t2960487756
{
public:
	// System.String System.Xml.XmlCharacterData::data
	String_t* ___data_6;

public:
	inline static int32_t get_offset_of_data_6() { return static_cast<int32_t>(offsetof(XmlCharacterData_t168497055, ___data_6)); }
	inline String_t* get_data_6() const { return ___data_6; }
	inline String_t** get_address_of_data_6() { return &___data_6; }
	inline void set_data_6(String_t* value)
	{
		___data_6 = value;
		Il2CppCodeGenWriteBarrier((&___data_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLCHARACTERDATA_T168497055_H
#ifndef CONFORMANCELEVEL_T3681510256_H
#define CONFORMANCELEVEL_T3681510256_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.ConformanceLevel
struct  ConformanceLevel_t3681510256 
{
public:
	// System.Int32 System.Xml.ConformanceLevel::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ConformanceLevel_t3681510256, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFORMANCELEVEL_T3681510256_H
#ifndef ENUMERATOR_T3874212946_H
#define ENUMERATOR_T3874212946_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>>
struct  Enumerator_t3874212946 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1/Enumerator::l
	List_1_t2398859287 * ___l_0;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::next
	int32_t ___next_1;
	// System.Int32 System.Collections.Generic.List`1/Enumerator::ver
	int32_t ___ver_2;
	// T System.Collections.Generic.List`1/Enumerator::current
	KeyValuePair_2_t2406658774  ___current_3;

public:
	inline static int32_t get_offset_of_l_0() { return static_cast<int32_t>(offsetof(Enumerator_t3874212946, ___l_0)); }
	inline List_1_t2398859287 * get_l_0() const { return ___l_0; }
	inline List_1_t2398859287 ** get_address_of_l_0() { return &___l_0; }
	inline void set_l_0(List_1_t2398859287 * value)
	{
		___l_0 = value;
		Il2CppCodeGenWriteBarrier((&___l_0), value);
	}

	inline static int32_t get_offset_of_next_1() { return static_cast<int32_t>(offsetof(Enumerator_t3874212946, ___next_1)); }
	inline int32_t get_next_1() const { return ___next_1; }
	inline int32_t* get_address_of_next_1() { return &___next_1; }
	inline void set_next_1(int32_t value)
	{
		___next_1 = value;
	}

	inline static int32_t get_offset_of_ver_2() { return static_cast<int32_t>(offsetof(Enumerator_t3874212946, ___ver_2)); }
	inline int32_t get_ver_2() const { return ___ver_2; }
	inline int32_t* get_address_of_ver_2() { return &___ver_2; }
	inline void set_ver_2(int32_t value)
	{
		___ver_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t3874212946, ___current_3)); }
	inline KeyValuePair_2_t2406658774  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t2406658774 * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t2406658774  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T3874212946_H
#ifndef DTDCOLLECTIONBASE_T20373490_H
#define DTDCOLLECTIONBASE_T20373490_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDCollectionBase
struct  DTDCollectionBase_t20373490  : public DictionaryBase_t377618675
{
public:
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDCollectionBase::root
	DTDObjectModel_t739056388 * ___root_5;

public:
	inline static int32_t get_offset_of_root_5() { return static_cast<int32_t>(offsetof(DTDCollectionBase_t20373490, ___root_5)); }
	inline DTDObjectModel_t739056388 * get_root_5() const { return ___root_5; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_5() { return &___root_5; }
	inline void set_root_5(DTDObjectModel_t739056388 * value)
	{
		___root_5 = value;
		Il2CppCodeGenWriteBarrier((&___root_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDCOLLECTIONBASE_T20373490_H
#ifndef DATETIMESTYLES_T2220669203_H
#define DATETIMESTYLES_T2220669203_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Globalization.DateTimeStyles
struct  DateTimeStyles_t2220669203 
{
public:
	// System.Int32 System.Globalization.DateTimeStyles::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DateTimeStyles_t2220669203, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIMESTYLES_T2220669203_H
#ifndef NUMBERSTYLES_T1716173687_H
#define NUMBERSTYLES_T1716173687_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Globalization.NumberStyles
struct  NumberStyles_t1716173687 
{
public:
	// System.Int32 System.Globalization.NumberStyles::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(NumberStyles_t1716173687, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NUMBERSTYLES_T1716173687_H
#ifndef XSDWHITESPACEFACET_T1101999099_H
#define XSDWHITESPACEFACET_T1101999099_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdWhitespaceFacet
struct  XsdWhitespaceFacet_t1101999099 
{
public:
	// System.Int32 Mono.Xml.Schema.XsdWhitespaceFacet::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(XsdWhitespaceFacet_t1101999099, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDWHITESPACEFACET_T1101999099_H
#ifndef XMLSCHEMADERIVATIONMETHOD_T791382393_H
#define XMLSCHEMADERIVATIONMETHOD_T791382393_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaDerivationMethod
struct  XmlSchemaDerivationMethod_t791382393 
{
public:
	// System.Int32 System.Xml.Schema.XmlSchemaDerivationMethod::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(XmlSchemaDerivationMethod_t791382393, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMADERIVATIONMETHOD_T791382393_H
#ifndef WHITESPACEHANDLING_T997061293_H
#define WHITESPACEHANDLING_T997061293_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.WhitespaceHandling
struct  WhitespaceHandling_t997061293 
{
public:
	// System.Int32 System.Xml.WhitespaceHandling::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(WhitespaceHandling_t997061293, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WHITESPACEHANDLING_T997061293_H
#ifndef XMLSCHEMASET_T410947004_H
#define XMLSCHEMASET_T410947004_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSet
struct  XmlSchemaSet_t410947004  : public RuntimeObject
{
public:
	// System.Xml.XmlNameTable System.Xml.Schema.XmlSchemaSet::nameTable
	XmlNameTable_t1479426498 * ___nameTable_0;
	// System.Xml.XmlResolver System.Xml.Schema.XmlSchemaSet::xmlResolver
	XmlResolver_t1481695800 * ___xmlResolver_1;
	// System.Collections.ArrayList System.Xml.Schema.XmlSchemaSet::schemas
	ArrayList_t815286905 * ___schemas_2;
	// System.Xml.Schema.XmlSchemaCompilationSettings System.Xml.Schema.XmlSchemaSet::settings
	XmlSchemaCompilationSettings_t2801413820 * ___settings_3;
	// System.Guid System.Xml.Schema.XmlSchemaSet::CompilationId
	Guid_t  ___CompilationId_4;

public:
	inline static int32_t get_offset_of_nameTable_0() { return static_cast<int32_t>(offsetof(XmlSchemaSet_t410947004, ___nameTable_0)); }
	inline XmlNameTable_t1479426498 * get_nameTable_0() const { return ___nameTable_0; }
	inline XmlNameTable_t1479426498 ** get_address_of_nameTable_0() { return &___nameTable_0; }
	inline void set_nameTable_0(XmlNameTable_t1479426498 * value)
	{
		___nameTable_0 = value;
		Il2CppCodeGenWriteBarrier((&___nameTable_0), value);
	}

	inline static int32_t get_offset_of_xmlResolver_1() { return static_cast<int32_t>(offsetof(XmlSchemaSet_t410947004, ___xmlResolver_1)); }
	inline XmlResolver_t1481695800 * get_xmlResolver_1() const { return ___xmlResolver_1; }
	inline XmlResolver_t1481695800 ** get_address_of_xmlResolver_1() { return &___xmlResolver_1; }
	inline void set_xmlResolver_1(XmlResolver_t1481695800 * value)
	{
		___xmlResolver_1 = value;
		Il2CppCodeGenWriteBarrier((&___xmlResolver_1), value);
	}

	inline static int32_t get_offset_of_schemas_2() { return static_cast<int32_t>(offsetof(XmlSchemaSet_t410947004, ___schemas_2)); }
	inline ArrayList_t815286905 * get_schemas_2() const { return ___schemas_2; }
	inline ArrayList_t815286905 ** get_address_of_schemas_2() { return &___schemas_2; }
	inline void set_schemas_2(ArrayList_t815286905 * value)
	{
		___schemas_2 = value;
		Il2CppCodeGenWriteBarrier((&___schemas_2), value);
	}

	inline static int32_t get_offset_of_settings_3() { return static_cast<int32_t>(offsetof(XmlSchemaSet_t410947004, ___settings_3)); }
	inline XmlSchemaCompilationSettings_t2801413820 * get_settings_3() const { return ___settings_3; }
	inline XmlSchemaCompilationSettings_t2801413820 ** get_address_of_settings_3() { return &___settings_3; }
	inline void set_settings_3(XmlSchemaCompilationSettings_t2801413820 * value)
	{
		___settings_3 = value;
		Il2CppCodeGenWriteBarrier((&___settings_3), value);
	}

	inline static int32_t get_offset_of_CompilationId_4() { return static_cast<int32_t>(offsetof(XmlSchemaSet_t410947004, ___CompilationId_4)); }
	inline Guid_t  get_CompilationId_4() const { return ___CompilationId_4; }
	inline Guid_t * get_address_of_CompilationId_4() { return &___CompilationId_4; }
	inline void set_CompilationId_4(Guid_t  value)
	{
		___CompilationId_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASET_T410947004_H
#ifndef DTDPARAMETERENTITYDECLARATION_T2989885012_H
#define DTDPARAMETERENTITYDECLARATION_T2989885012_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDParameterEntityDeclaration
struct  DTDParameterEntityDeclaration_t2989885012  : public DTDEntityBase_t195196828
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDPARAMETERENTITYDECLARATION_T2989885012_H
#ifndef XMLSCHEMAOBJECT_T3227566618_H
#define XMLSCHEMAOBJECT_T3227566618_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaObject
struct  XmlSchemaObject_t3227566618  : public RuntimeObject
{
public:
	// System.Xml.Serialization.XmlSerializerNamespaces System.Xml.Schema.XmlSchemaObject::namespaces
	XmlSerializerNamespaces_t3956590116 * ___namespaces_0;
	// System.Collections.ArrayList System.Xml.Schema.XmlSchemaObject::unhandledAttributeList
	ArrayList_t815286905 * ___unhandledAttributeList_1;
	// System.Guid System.Xml.Schema.XmlSchemaObject::CompilationId
	Guid_t  ___CompilationId_2;

public:
	inline static int32_t get_offset_of_namespaces_0() { return static_cast<int32_t>(offsetof(XmlSchemaObject_t3227566618, ___namespaces_0)); }
	inline XmlSerializerNamespaces_t3956590116 * get_namespaces_0() const { return ___namespaces_0; }
	inline XmlSerializerNamespaces_t3956590116 ** get_address_of_namespaces_0() { return &___namespaces_0; }
	inline void set_namespaces_0(XmlSerializerNamespaces_t3956590116 * value)
	{
		___namespaces_0 = value;
		Il2CppCodeGenWriteBarrier((&___namespaces_0), value);
	}

	inline static int32_t get_offset_of_unhandledAttributeList_1() { return static_cast<int32_t>(offsetof(XmlSchemaObject_t3227566618, ___unhandledAttributeList_1)); }
	inline ArrayList_t815286905 * get_unhandledAttributeList_1() const { return ___unhandledAttributeList_1; }
	inline ArrayList_t815286905 ** get_address_of_unhandledAttributeList_1() { return &___unhandledAttributeList_1; }
	inline void set_unhandledAttributeList_1(ArrayList_t815286905 * value)
	{
		___unhandledAttributeList_1 = value;
		Il2CppCodeGenWriteBarrier((&___unhandledAttributeList_1), value);
	}

	inline static int32_t get_offset_of_CompilationId_2() { return static_cast<int32_t>(offsetof(XmlSchemaObject_t3227566618, ___CompilationId_2)); }
	inline Guid_t  get_CompilationId_2() const { return ___CompilationId_2; }
	inline Guid_t * get_address_of_CompilationId_2() { return &___CompilationId_2; }
	inline void set_CompilationId_2(Guid_t  value)
	{
		___CompilationId_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAOBJECT_T3227566618_H
#ifndef FACET_T1736138037_H
#define FACET_T1736138037_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaFacet/Facet
struct  Facet_t1736138037 
{
public:
	// System.Int32 System.Xml.Schema.XmlSchemaFacet/Facet::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(Facet_t1736138037, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FACET_T1736138037_H
#ifndef DTDCONTENTORDERTYPE_T1914538838_H
#define DTDCONTENTORDERTYPE_T1914538838_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDContentOrderType
struct  DTDContentOrderType_t1914538838 
{
public:
	// System.Int32 Mono.Xml.DTDContentOrderType::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DTDContentOrderType_t1914538838, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDCONTENTORDERTYPE_T1914538838_H
#ifndef ENTITYHANDLING_T2315249075_H
#define ENTITYHANDLING_T2315249075_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.EntityHandling
struct  EntityHandling_t2315249075 
{
public:
	// System.Int32 System.Xml.EntityHandling::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(EntityHandling_t2315249075, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENTITYHANDLING_T2315249075_H
#ifndef DTDOCCURENCE_T1530059005_H
#define DTDOCCURENCE_T1530059005_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDOccurence
struct  DTDOccurence_t1530059005 
{
public:
	// System.Int32 Mono.Xml.DTDOccurence::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(DTDOccurence_t1530059005, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDOCCURENCE_T1530059005_H
#ifndef WRITESTATE_T625744691_H
#define WRITESTATE_T625744691_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.WriteState
struct  WriteState_t625744691 
{
public:
	// System.Int32 System.Xml.WriteState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(WriteState_t625744691, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WRITESTATE_T625744691_H
#ifndef DTDENTITYDECLARATION_T586771123_H
#define DTDENTITYDECLARATION_T586771123_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDEntityDeclaration
struct  DTDEntityDeclaration_t586771123  : public DTDEntityBase_t195196828
{
public:
	// System.String Mono.Xml.DTDEntityDeclaration::entityValue
	String_t* ___entityValue_15;
	// System.String Mono.Xml.DTDEntityDeclaration::notationName
	String_t* ___notationName_16;
	// System.Collections.ArrayList Mono.Xml.DTDEntityDeclaration::ReferencingEntities
	ArrayList_t815286905 * ___ReferencingEntities_17;
	// System.Boolean Mono.Xml.DTDEntityDeclaration::scanned
	bool ___scanned_18;
	// System.Boolean Mono.Xml.DTDEntityDeclaration::recursed
	bool ___recursed_19;
	// System.Boolean Mono.Xml.DTDEntityDeclaration::hasExternalReference
	bool ___hasExternalReference_20;

public:
	inline static int32_t get_offset_of_entityValue_15() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___entityValue_15)); }
	inline String_t* get_entityValue_15() const { return ___entityValue_15; }
	inline String_t** get_address_of_entityValue_15() { return &___entityValue_15; }
	inline void set_entityValue_15(String_t* value)
	{
		___entityValue_15 = value;
		Il2CppCodeGenWriteBarrier((&___entityValue_15), value);
	}

	inline static int32_t get_offset_of_notationName_16() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___notationName_16)); }
	inline String_t* get_notationName_16() const { return ___notationName_16; }
	inline String_t** get_address_of_notationName_16() { return &___notationName_16; }
	inline void set_notationName_16(String_t* value)
	{
		___notationName_16 = value;
		Il2CppCodeGenWriteBarrier((&___notationName_16), value);
	}

	inline static int32_t get_offset_of_ReferencingEntities_17() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___ReferencingEntities_17)); }
	inline ArrayList_t815286905 * get_ReferencingEntities_17() const { return ___ReferencingEntities_17; }
	inline ArrayList_t815286905 ** get_address_of_ReferencingEntities_17() { return &___ReferencingEntities_17; }
	inline void set_ReferencingEntities_17(ArrayList_t815286905 * value)
	{
		___ReferencingEntities_17 = value;
		Il2CppCodeGenWriteBarrier((&___ReferencingEntities_17), value);
	}

	inline static int32_t get_offset_of_scanned_18() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___scanned_18)); }
	inline bool get_scanned_18() const { return ___scanned_18; }
	inline bool* get_address_of_scanned_18() { return &___scanned_18; }
	inline void set_scanned_18(bool value)
	{
		___scanned_18 = value;
	}

	inline static int32_t get_offset_of_recursed_19() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___recursed_19)); }
	inline bool get_recursed_19() const { return ___recursed_19; }
	inline bool* get_address_of_recursed_19() { return &___recursed_19; }
	inline void set_recursed_19(bool value)
	{
		___recursed_19 = value;
	}

	inline static int32_t get_offset_of_hasExternalReference_20() { return static_cast<int32_t>(offsetof(DTDEntityDeclaration_t586771123, ___hasExternalReference_20)); }
	inline bool get_hasExternalReference_20() const { return ___hasExternalReference_20; }
	inline bool* get_address_of_hasExternalReference_20() { return &___hasExternalReference_20; }
	inline void set_hasExternalReference_20(bool value)
	{
		___hasExternalReference_20 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDENTITYDECLARATION_T586771123_H
#ifndef READSTATE_T1299193502_H
#define READSTATE_T1299193502_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.ReadState
struct  ReadState_t1299193502 
{
public:
	// System.Int32 System.Xml.ReadState::value__
	int32_t ___value___1;

public:
	inline static int32_t get_offset_of_value___1() { return static_cast<int32_t>(offsetof(ReadState_t1299193502, ___value___1)); }
	inline int32_t get_value___1() const { return ___value___1; }
	inline int32_t* get_address_of_value___1() { return &___value___1; }
	inline void set_value___1(int32_t value)
	{
		___value___1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // READSTATE_T1299193502_H
#ifndef XMLCONVERT_T773442636_H
#define XMLCONVERT_T773442636_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlConvert
struct  XmlConvert_t773442636  : public RuntimeObject
{
public:

public:
};

struct XmlConvert_t773442636_StaticFields
{
public:
	// System.String[] System.Xml.XmlConvert::datetimeFormats
	StringU5BU5D_t4199878655* ___datetimeFormats_0;
	// System.String[] System.Xml.XmlConvert::defaultDateTimeFormats
	StringU5BU5D_t4199878655* ___defaultDateTimeFormats_1;
	// System.String[] System.Xml.XmlConvert::roundtripDateTimeFormats
	StringU5BU5D_t4199878655* ___roundtripDateTimeFormats_2;
	// System.String[] System.Xml.XmlConvert::localDateTimeFormats
	StringU5BU5D_t4199878655* ___localDateTimeFormats_3;
	// System.String[] System.Xml.XmlConvert::utcDateTimeFormats
	StringU5BU5D_t4199878655* ___utcDateTimeFormats_4;
	// System.String[] System.Xml.XmlConvert::unspecifiedDateTimeFormats
	StringU5BU5D_t4199878655* ___unspecifiedDateTimeFormats_5;
	// System.Globalization.DateTimeStyles System.Xml.XmlConvert::_defaultStyle
	int32_t ____defaultStyle_6;

public:
	inline static int32_t get_offset_of_datetimeFormats_0() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___datetimeFormats_0)); }
	inline StringU5BU5D_t4199878655* get_datetimeFormats_0() const { return ___datetimeFormats_0; }
	inline StringU5BU5D_t4199878655** get_address_of_datetimeFormats_0() { return &___datetimeFormats_0; }
	inline void set_datetimeFormats_0(StringU5BU5D_t4199878655* value)
	{
		___datetimeFormats_0 = value;
		Il2CppCodeGenWriteBarrier((&___datetimeFormats_0), value);
	}

	inline static int32_t get_offset_of_defaultDateTimeFormats_1() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___defaultDateTimeFormats_1)); }
	inline StringU5BU5D_t4199878655* get_defaultDateTimeFormats_1() const { return ___defaultDateTimeFormats_1; }
	inline StringU5BU5D_t4199878655** get_address_of_defaultDateTimeFormats_1() { return &___defaultDateTimeFormats_1; }
	inline void set_defaultDateTimeFormats_1(StringU5BU5D_t4199878655* value)
	{
		___defaultDateTimeFormats_1 = value;
		Il2CppCodeGenWriteBarrier((&___defaultDateTimeFormats_1), value);
	}

	inline static int32_t get_offset_of_roundtripDateTimeFormats_2() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___roundtripDateTimeFormats_2)); }
	inline StringU5BU5D_t4199878655* get_roundtripDateTimeFormats_2() const { return ___roundtripDateTimeFormats_2; }
	inline StringU5BU5D_t4199878655** get_address_of_roundtripDateTimeFormats_2() { return &___roundtripDateTimeFormats_2; }
	inline void set_roundtripDateTimeFormats_2(StringU5BU5D_t4199878655* value)
	{
		___roundtripDateTimeFormats_2 = value;
		Il2CppCodeGenWriteBarrier((&___roundtripDateTimeFormats_2), value);
	}

	inline static int32_t get_offset_of_localDateTimeFormats_3() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___localDateTimeFormats_3)); }
	inline StringU5BU5D_t4199878655* get_localDateTimeFormats_3() const { return ___localDateTimeFormats_3; }
	inline StringU5BU5D_t4199878655** get_address_of_localDateTimeFormats_3() { return &___localDateTimeFormats_3; }
	inline void set_localDateTimeFormats_3(StringU5BU5D_t4199878655* value)
	{
		___localDateTimeFormats_3 = value;
		Il2CppCodeGenWriteBarrier((&___localDateTimeFormats_3), value);
	}

	inline static int32_t get_offset_of_utcDateTimeFormats_4() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___utcDateTimeFormats_4)); }
	inline StringU5BU5D_t4199878655* get_utcDateTimeFormats_4() const { return ___utcDateTimeFormats_4; }
	inline StringU5BU5D_t4199878655** get_address_of_utcDateTimeFormats_4() { return &___utcDateTimeFormats_4; }
	inline void set_utcDateTimeFormats_4(StringU5BU5D_t4199878655* value)
	{
		___utcDateTimeFormats_4 = value;
		Il2CppCodeGenWriteBarrier((&___utcDateTimeFormats_4), value);
	}

	inline static int32_t get_offset_of_unspecifiedDateTimeFormats_5() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ___unspecifiedDateTimeFormats_5)); }
	inline StringU5BU5D_t4199878655* get_unspecifiedDateTimeFormats_5() const { return ___unspecifiedDateTimeFormats_5; }
	inline StringU5BU5D_t4199878655** get_address_of_unspecifiedDateTimeFormats_5() { return &___unspecifiedDateTimeFormats_5; }
	inline void set_unspecifiedDateTimeFormats_5(StringU5BU5D_t4199878655* value)
	{
		___unspecifiedDateTimeFormats_5 = value;
		Il2CppCodeGenWriteBarrier((&___unspecifiedDateTimeFormats_5), value);
	}

	inline static int32_t get_offset_of__defaultStyle_6() { return static_cast<int32_t>(offsetof(XmlConvert_t773442636_StaticFields, ____defaultStyle_6)); }
	inline int32_t get__defaultStyle_6() const { return ____defaultStyle_6; }
	inline int32_t* get_address_of__defaultStyle_6() { return &____defaultStyle_6; }
	inline void set__defaultStyle_6(int32_t value)
	{
		____defaultStyle_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLCONVERT_T773442636_H
#ifndef DTDCONTENTMODEL_T2007242871_H
#define DTDCONTENTMODEL_T2007242871_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDContentModel
struct  DTDContentModel_t2007242871  : public DTDNode_t2342132918
{
public:
	// Mono.Xml.DTDObjectModel Mono.Xml.DTDContentModel::root
	DTDObjectModel_t739056388 * ___root_5;
	// System.String Mono.Xml.DTDContentModel::ownerElementName
	String_t* ___ownerElementName_6;
	// System.String Mono.Xml.DTDContentModel::elementName
	String_t* ___elementName_7;
	// Mono.Xml.DTDContentOrderType Mono.Xml.DTDContentModel::orderType
	int32_t ___orderType_8;
	// Mono.Xml.DTDContentModelCollection Mono.Xml.DTDContentModel::childModels
	DTDContentModelCollection_t2794654295 * ___childModels_9;
	// Mono.Xml.DTDOccurence Mono.Xml.DTDContentModel::occurence
	int32_t ___occurence_10;

public:
	inline static int32_t get_offset_of_root_5() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___root_5)); }
	inline DTDObjectModel_t739056388 * get_root_5() const { return ___root_5; }
	inline DTDObjectModel_t739056388 ** get_address_of_root_5() { return &___root_5; }
	inline void set_root_5(DTDObjectModel_t739056388 * value)
	{
		___root_5 = value;
		Il2CppCodeGenWriteBarrier((&___root_5), value);
	}

	inline static int32_t get_offset_of_ownerElementName_6() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___ownerElementName_6)); }
	inline String_t* get_ownerElementName_6() const { return ___ownerElementName_6; }
	inline String_t** get_address_of_ownerElementName_6() { return &___ownerElementName_6; }
	inline void set_ownerElementName_6(String_t* value)
	{
		___ownerElementName_6 = value;
		Il2CppCodeGenWriteBarrier((&___ownerElementName_6), value);
	}

	inline static int32_t get_offset_of_elementName_7() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___elementName_7)); }
	inline String_t* get_elementName_7() const { return ___elementName_7; }
	inline String_t** get_address_of_elementName_7() { return &___elementName_7; }
	inline void set_elementName_7(String_t* value)
	{
		___elementName_7 = value;
		Il2CppCodeGenWriteBarrier((&___elementName_7), value);
	}

	inline static int32_t get_offset_of_orderType_8() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___orderType_8)); }
	inline int32_t get_orderType_8() const { return ___orderType_8; }
	inline int32_t* get_address_of_orderType_8() { return &___orderType_8; }
	inline void set_orderType_8(int32_t value)
	{
		___orderType_8 = value;
	}

	inline static int32_t get_offset_of_childModels_9() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___childModels_9)); }
	inline DTDContentModelCollection_t2794654295 * get_childModels_9() const { return ___childModels_9; }
	inline DTDContentModelCollection_t2794654295 ** get_address_of_childModels_9() { return &___childModels_9; }
	inline void set_childModels_9(DTDContentModelCollection_t2794654295 * value)
	{
		___childModels_9 = value;
		Il2CppCodeGenWriteBarrier((&___childModels_9), value);
	}

	inline static int32_t get_offset_of_occurence_10() { return static_cast<int32_t>(offsetof(DTDContentModel_t2007242871, ___occurence_10)); }
	inline int32_t get_occurence_10() const { return ___occurence_10; }
	inline int32_t* get_address_of_occurence_10() { return &___occurence_10; }
	inline void set_occurence_10(int32_t value)
	{
		___occurence_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDCONTENTMODEL_T2007242871_H
#ifndef DTDNOTATIONDECLARATIONCOLLECTION_T1273717105_H
#define DTDNOTATIONDECLARATIONCOLLECTION_T1273717105_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDNotationDeclarationCollection
struct  DTDNotationDeclarationCollection_t1273717105  : public DTDCollectionBase_t20373490
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDNOTATIONDECLARATIONCOLLECTION_T1273717105_H
#ifndef DTDENTITYDECLARATIONCOLLECTION_T1347165388_H
#define DTDENTITYDECLARATIONCOLLECTION_T1347165388_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDEntityDeclarationCollection
struct  DTDEntityDeclarationCollection_t1347165388  : public DTDCollectionBase_t20373490
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDENTITYDECLARATIONCOLLECTION_T1347165388_H
#ifndef DTDATTLISTDECLARATIONCOLLECTION_T4224010798_H
#define DTDATTLISTDECLARATIONCOLLECTION_T4224010798_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDAttListDeclarationCollection
struct  DTDAttListDeclarationCollection_t4224010798  : public DTDCollectionBase_t20373490
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDATTLISTDECLARATIONCOLLECTION_T4224010798_H
#ifndef XMLCDATASECTION_T3669253335_H
#define XMLCDATASECTION_T3669253335_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlCDataSection
struct  XmlCDataSection_t3669253335  : public XmlCharacterData_t168497055
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLCDATASECTION_T3669253335_H
#ifndef XMLSCHEMAANNOTATED_T791701952_H
#define XMLSCHEMAANNOTATED_T791701952_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaAnnotated
struct  XmlSchemaAnnotated_t791701952  : public XmlSchemaObject_t3227566618
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAANNOTATED_T791701952_H
#ifndef U3CU3EC__ITERATOR3_T2137737414_H
#define U3CU3EC__ITERATOR3_T2137737414_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DictionaryBase/<>c__Iterator3
struct  U3CU3Ec__Iterator3_t2137737414  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1/Enumerator<System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode>> Mono.Xml.DictionaryBase/<>c__Iterator3::<$s_431>__0
	Enumerator_t3874212946  ___U3CU24s_431U3E__0_0;
	// System.Collections.Generic.KeyValuePair`2<System.String,Mono.Xml.DTDNode> Mono.Xml.DictionaryBase/<>c__Iterator3::<p>__1
	KeyValuePair_2_t2406658774  ___U3CpU3E__1_1;
	// System.Int32 Mono.Xml.DictionaryBase/<>c__Iterator3::$PC
	int32_t ___U24PC_2;
	// Mono.Xml.DTDNode Mono.Xml.DictionaryBase/<>c__Iterator3::$current
	DTDNode_t2342132918 * ___U24current_3;
	// Mono.Xml.DictionaryBase Mono.Xml.DictionaryBase/<>c__Iterator3::<>f__this
	DictionaryBase_t377618675 * ___U3CU3Ef__this_4;

public:
	inline static int32_t get_offset_of_U3CU24s_431U3E__0_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__Iterator3_t2137737414, ___U3CU24s_431U3E__0_0)); }
	inline Enumerator_t3874212946  get_U3CU24s_431U3E__0_0() const { return ___U3CU24s_431U3E__0_0; }
	inline Enumerator_t3874212946 * get_address_of_U3CU24s_431U3E__0_0() { return &___U3CU24s_431U3E__0_0; }
	inline void set_U3CU24s_431U3E__0_0(Enumerator_t3874212946  value)
	{
		___U3CU24s_431U3E__0_0 = value;
	}

	inline static int32_t get_offset_of_U3CpU3E__1_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__Iterator3_t2137737414, ___U3CpU3E__1_1)); }
	inline KeyValuePair_2_t2406658774  get_U3CpU3E__1_1() const { return ___U3CpU3E__1_1; }
	inline KeyValuePair_2_t2406658774 * get_address_of_U3CpU3E__1_1() { return &___U3CpU3E__1_1; }
	inline void set_U3CpU3E__1_1(KeyValuePair_2_t2406658774  value)
	{
		___U3CpU3E__1_1 = value;
	}

	inline static int32_t get_offset_of_U24PC_2() { return static_cast<int32_t>(offsetof(U3CU3Ec__Iterator3_t2137737414, ___U24PC_2)); }
	inline int32_t get_U24PC_2() const { return ___U24PC_2; }
	inline int32_t* get_address_of_U24PC_2() { return &___U24PC_2; }
	inline void set_U24PC_2(int32_t value)
	{
		___U24PC_2 = value;
	}

	inline static int32_t get_offset_of_U24current_3() { return static_cast<int32_t>(offsetof(U3CU3Ec__Iterator3_t2137737414, ___U24current_3)); }
	inline DTDNode_t2342132918 * get_U24current_3() const { return ___U24current_3; }
	inline DTDNode_t2342132918 ** get_address_of_U24current_3() { return &___U24current_3; }
	inline void set_U24current_3(DTDNode_t2342132918 * value)
	{
		___U24current_3 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__this_4() { return static_cast<int32_t>(offsetof(U3CU3Ec__Iterator3_t2137737414, ___U3CU3Ef__this_4)); }
	inline DictionaryBase_t377618675 * get_U3CU3Ef__this_4() const { return ___U3CU3Ef__this_4; }
	inline DictionaryBase_t377618675 ** get_address_of_U3CU3Ef__this_4() { return &___U3CU3Ef__this_4; }
	inline void set_U3CU3Ef__this_4(DictionaryBase_t377618675 * value)
	{
		___U3CU3Ef__this_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__this_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__ITERATOR3_T2137737414_H
#ifndef XMLSCHEMADATATYPE_T2974024598_H
#define XMLSCHEMADATATYPE_T2974024598_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaDatatype
struct  XmlSchemaDatatype_t2974024598  : public RuntimeObject
{
public:
	// Mono.Xml.Schema.XsdWhitespaceFacet System.Xml.Schema.XmlSchemaDatatype::WhitespaceValue
	int32_t ___WhitespaceValue_0;
	// System.Text.StringBuilder System.Xml.Schema.XmlSchemaDatatype::sb
	StringBuilder_t1854403953 * ___sb_2;

public:
	inline static int32_t get_offset_of_WhitespaceValue_0() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598, ___WhitespaceValue_0)); }
	inline int32_t get_WhitespaceValue_0() const { return ___WhitespaceValue_0; }
	inline int32_t* get_address_of_WhitespaceValue_0() { return &___WhitespaceValue_0; }
	inline void set_WhitespaceValue_0(int32_t value)
	{
		___WhitespaceValue_0 = value;
	}

	inline static int32_t get_offset_of_sb_2() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598, ___sb_2)); }
	inline StringBuilder_t1854403953 * get_sb_2() const { return ___sb_2; }
	inline StringBuilder_t1854403953 ** get_address_of_sb_2() { return &___sb_2; }
	inline void set_sb_2(StringBuilder_t1854403953 * value)
	{
		___sb_2 = value;
		Il2CppCodeGenWriteBarrier((&___sb_2), value);
	}
};

struct XmlSchemaDatatype_t2974024598_StaticFields
{
public:
	// System.Char[] System.Xml.Schema.XmlSchemaDatatype::wsChars
	CharU5BU5D_t2772155777* ___wsChars_1;
	// Mono.Xml.Schema.XsdAnySimpleType System.Xml.Schema.XmlSchemaDatatype::datatypeAnySimpleType
	XsdAnySimpleType_t1645894131 * ___datatypeAnySimpleType_3;
	// Mono.Xml.Schema.XsdString System.Xml.Schema.XmlSchemaDatatype::datatypeString
	XsdString_t3808583524 * ___datatypeString_4;
	// Mono.Xml.Schema.XsdNormalizedString System.Xml.Schema.XmlSchemaDatatype::datatypeNormalizedString
	XsdNormalizedString_t1600426378 * ___datatypeNormalizedString_5;
	// Mono.Xml.Schema.XsdToken System.Xml.Schema.XmlSchemaDatatype::datatypeToken
	XsdToken_t508248724 * ___datatypeToken_6;
	// Mono.Xml.Schema.XsdLanguage System.Xml.Schema.XmlSchemaDatatype::datatypeLanguage
	XsdLanguage_t3150055479 * ___datatypeLanguage_7;
	// Mono.Xml.Schema.XsdNMToken System.Xml.Schema.XmlSchemaDatatype::datatypeNMToken
	XsdNMToken_t2787524133 * ___datatypeNMToken_8;
	// Mono.Xml.Schema.XsdNMTokens System.Xml.Schema.XmlSchemaDatatype::datatypeNMTokens
	XsdNMTokens_t3644935921 * ___datatypeNMTokens_9;
	// Mono.Xml.Schema.XsdName System.Xml.Schema.XmlSchemaDatatype::datatypeName
	XsdName_t2809458942 * ___datatypeName_10;
	// Mono.Xml.Schema.XsdNCName System.Xml.Schema.XmlSchemaDatatype::datatypeNCName
	XsdNCName_t2448558528 * ___datatypeNCName_11;
	// Mono.Xml.Schema.XsdID System.Xml.Schema.XmlSchemaDatatype::datatypeID
	XsdID_t3641052050 * ___datatypeID_12;
	// Mono.Xml.Schema.XsdIDRef System.Xml.Schema.XmlSchemaDatatype::datatypeIDRef
	XsdIDRef_t3533441891 * ___datatypeIDRef_13;
	// Mono.Xml.Schema.XsdIDRefs System.Xml.Schema.XmlSchemaDatatype::datatypeIDRefs
	XsdIDRefs_t4196912482 * ___datatypeIDRefs_14;
	// Mono.Xml.Schema.XsdEntity System.Xml.Schema.XmlSchemaDatatype::datatypeEntity
	XsdEntity_t2294332234 * ___datatypeEntity_15;
	// Mono.Xml.Schema.XsdEntities System.Xml.Schema.XmlSchemaDatatype::datatypeEntities
	XsdEntities_t1133855613 * ___datatypeEntities_16;
	// Mono.Xml.Schema.XsdNotation System.Xml.Schema.XmlSchemaDatatype::datatypeNotation
	XsdNotation_t2721234078 * ___datatypeNotation_17;
	// Mono.Xml.Schema.XsdDecimal System.Xml.Schema.XmlSchemaDatatype::datatypeDecimal
	XsdDecimal_t3796307291 * ___datatypeDecimal_18;
	// Mono.Xml.Schema.XsdInteger System.Xml.Schema.XmlSchemaDatatype::datatypeInteger
	XsdInteger_t1726820563 * ___datatypeInteger_19;
	// Mono.Xml.Schema.XsdLong System.Xml.Schema.XmlSchemaDatatype::datatypeLong
	XsdLong_t1719775717 * ___datatypeLong_20;
	// Mono.Xml.Schema.XsdInt System.Xml.Schema.XmlSchemaDatatype::datatypeInt
	XsdInt_t4031406130 * ___datatypeInt_21;
	// Mono.Xml.Schema.XsdShort System.Xml.Schema.XmlSchemaDatatype::datatypeShort
	XsdShort_t1466004108 * ___datatypeShort_22;
	// Mono.Xml.Schema.XsdByte System.Xml.Schema.XmlSchemaDatatype::datatypeByte
	XsdByte_t2834617523 * ___datatypeByte_23;
	// Mono.Xml.Schema.XsdNonNegativeInteger System.Xml.Schema.XmlSchemaDatatype::datatypeNonNegativeInteger
	XsdNonNegativeInteger_t2518569928 * ___datatypeNonNegativeInteger_24;
	// Mono.Xml.Schema.XsdPositiveInteger System.Xml.Schema.XmlSchemaDatatype::datatypePositiveInteger
	XsdPositiveInteger_t858890625 * ___datatypePositiveInteger_25;
	// Mono.Xml.Schema.XsdUnsignedLong System.Xml.Schema.XmlSchemaDatatype::datatypeUnsignedLong
	XsdUnsignedLong_t3088213186 * ___datatypeUnsignedLong_26;
	// Mono.Xml.Schema.XsdUnsignedInt System.Xml.Schema.XmlSchemaDatatype::datatypeUnsignedInt
	XsdUnsignedInt_t1345788448 * ___datatypeUnsignedInt_27;
	// Mono.Xml.Schema.XsdUnsignedShort System.Xml.Schema.XmlSchemaDatatype::datatypeUnsignedShort
	XsdUnsignedShort_t3040059537 * ___datatypeUnsignedShort_28;
	// Mono.Xml.Schema.XsdUnsignedByte System.Xml.Schema.XmlSchemaDatatype::datatypeUnsignedByte
	XsdUnsignedByte_t1503500326 * ___datatypeUnsignedByte_29;
	// Mono.Xml.Schema.XsdNonPositiveInteger System.Xml.Schema.XmlSchemaDatatype::datatypeNonPositiveInteger
	XsdNonPositiveInteger_t654673514 * ___datatypeNonPositiveInteger_30;
	// Mono.Xml.Schema.XsdNegativeInteger System.Xml.Schema.XmlSchemaDatatype::datatypeNegativeInteger
	XsdNegativeInteger_t145731310 * ___datatypeNegativeInteger_31;
	// Mono.Xml.Schema.XsdFloat System.Xml.Schema.XmlSchemaDatatype::datatypeFloat
	XsdFloat_t2432376376 * ___datatypeFloat_32;
	// Mono.Xml.Schema.XsdDouble System.Xml.Schema.XmlSchemaDatatype::datatypeDouble
	XsdDouble_t2405104440 * ___datatypeDouble_33;
	// Mono.Xml.Schema.XsdBase64Binary System.Xml.Schema.XmlSchemaDatatype::datatypeBase64Binary
	XsdBase64Binary_t1793769650 * ___datatypeBase64Binary_34;
	// Mono.Xml.Schema.XsdBoolean System.Xml.Schema.XmlSchemaDatatype::datatypeBoolean
	XsdBoolean_t747919005 * ___datatypeBoolean_35;
	// Mono.Xml.Schema.XsdAnyURI System.Xml.Schema.XmlSchemaDatatype::datatypeAnyURI
	XsdAnyURI_t1696333635 * ___datatypeAnyURI_36;
	// Mono.Xml.Schema.XsdDuration System.Xml.Schema.XmlSchemaDatatype::datatypeDuration
	XsdDuration_t4216890283 * ___datatypeDuration_37;
	// Mono.Xml.Schema.XsdDateTime System.Xml.Schema.XmlSchemaDatatype::datatypeDateTime
	XsdDateTime_t2878826493 * ___datatypeDateTime_38;
	// Mono.Xml.Schema.XsdDate System.Xml.Schema.XmlSchemaDatatype::datatypeDate
	XsdDate_t84799097 * ___datatypeDate_39;
	// Mono.Xml.Schema.XsdTime System.Xml.Schema.XmlSchemaDatatype::datatypeTime
	XsdTime_t194014253 * ___datatypeTime_40;
	// Mono.Xml.Schema.XsdHexBinary System.Xml.Schema.XmlSchemaDatatype::datatypeHexBinary
	XsdHexBinary_t309962759 * ___datatypeHexBinary_41;
	// Mono.Xml.Schema.XsdQName System.Xml.Schema.XmlSchemaDatatype::datatypeQName
	XsdQName_t2375427330 * ___datatypeQName_42;
	// Mono.Xml.Schema.XsdGYearMonth System.Xml.Schema.XmlSchemaDatatype::datatypeGYearMonth
	XsdGYearMonth_t4060942859 * ___datatypeGYearMonth_43;
	// Mono.Xml.Schema.XsdGMonthDay System.Xml.Schema.XmlSchemaDatatype::datatypeGMonthDay
	XsdGMonthDay_t1849750074 * ___datatypeGMonthDay_44;
	// Mono.Xml.Schema.XsdGYear System.Xml.Schema.XmlSchemaDatatype::datatypeGYear
	XsdGYear_t1626334498 * ___datatypeGYear_45;
	// Mono.Xml.Schema.XsdGMonth System.Xml.Schema.XmlSchemaDatatype::datatypeGMonth
	XsdGMonth_t1559631661 * ___datatypeGMonth_46;
	// Mono.Xml.Schema.XsdGDay System.Xml.Schema.XmlSchemaDatatype::datatypeGDay
	XsdGDay_t1637325925 * ___datatypeGDay_47;
	// Mono.Xml.Schema.XdtAnyAtomicType System.Xml.Schema.XmlSchemaDatatype::datatypeAnyAtomicType
	XdtAnyAtomicType_t2627475155 * ___datatypeAnyAtomicType_48;
	// Mono.Xml.Schema.XdtUntypedAtomic System.Xml.Schema.XmlSchemaDatatype::datatypeUntypedAtomic
	XdtUntypedAtomic_t2359648093 * ___datatypeUntypedAtomic_49;
	// Mono.Xml.Schema.XdtDayTimeDuration System.Xml.Schema.XmlSchemaDatatype::datatypeDayTimeDuration
	XdtDayTimeDuration_t597694552 * ___datatypeDayTimeDuration_50;
	// Mono.Xml.Schema.XdtYearMonthDuration System.Xml.Schema.XmlSchemaDatatype::datatypeYearMonthDuration
	XdtYearMonthDuration_t673549898 * ___datatypeYearMonthDuration_51;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.Schema.XmlSchemaDatatype::<>f__switch$map2A
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map2A_52;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.Schema.XmlSchemaDatatype::<>f__switch$map2B
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map2B_53;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.Schema.XmlSchemaDatatype::<>f__switch$map2C
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map2C_54;

public:
	inline static int32_t get_offset_of_wsChars_1() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___wsChars_1)); }
	inline CharU5BU5D_t2772155777* get_wsChars_1() const { return ___wsChars_1; }
	inline CharU5BU5D_t2772155777** get_address_of_wsChars_1() { return &___wsChars_1; }
	inline void set_wsChars_1(CharU5BU5D_t2772155777* value)
	{
		___wsChars_1 = value;
		Il2CppCodeGenWriteBarrier((&___wsChars_1), value);
	}

	inline static int32_t get_offset_of_datatypeAnySimpleType_3() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeAnySimpleType_3)); }
	inline XsdAnySimpleType_t1645894131 * get_datatypeAnySimpleType_3() const { return ___datatypeAnySimpleType_3; }
	inline XsdAnySimpleType_t1645894131 ** get_address_of_datatypeAnySimpleType_3() { return &___datatypeAnySimpleType_3; }
	inline void set_datatypeAnySimpleType_3(XsdAnySimpleType_t1645894131 * value)
	{
		___datatypeAnySimpleType_3 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeAnySimpleType_3), value);
	}

	inline static int32_t get_offset_of_datatypeString_4() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeString_4)); }
	inline XsdString_t3808583524 * get_datatypeString_4() const { return ___datatypeString_4; }
	inline XsdString_t3808583524 ** get_address_of_datatypeString_4() { return &___datatypeString_4; }
	inline void set_datatypeString_4(XsdString_t3808583524 * value)
	{
		___datatypeString_4 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeString_4), value);
	}

	inline static int32_t get_offset_of_datatypeNormalizedString_5() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNormalizedString_5)); }
	inline XsdNormalizedString_t1600426378 * get_datatypeNormalizedString_5() const { return ___datatypeNormalizedString_5; }
	inline XsdNormalizedString_t1600426378 ** get_address_of_datatypeNormalizedString_5() { return &___datatypeNormalizedString_5; }
	inline void set_datatypeNormalizedString_5(XsdNormalizedString_t1600426378 * value)
	{
		___datatypeNormalizedString_5 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNormalizedString_5), value);
	}

	inline static int32_t get_offset_of_datatypeToken_6() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeToken_6)); }
	inline XsdToken_t508248724 * get_datatypeToken_6() const { return ___datatypeToken_6; }
	inline XsdToken_t508248724 ** get_address_of_datatypeToken_6() { return &___datatypeToken_6; }
	inline void set_datatypeToken_6(XsdToken_t508248724 * value)
	{
		___datatypeToken_6 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeToken_6), value);
	}

	inline static int32_t get_offset_of_datatypeLanguage_7() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeLanguage_7)); }
	inline XsdLanguage_t3150055479 * get_datatypeLanguage_7() const { return ___datatypeLanguage_7; }
	inline XsdLanguage_t3150055479 ** get_address_of_datatypeLanguage_7() { return &___datatypeLanguage_7; }
	inline void set_datatypeLanguage_7(XsdLanguage_t3150055479 * value)
	{
		___datatypeLanguage_7 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeLanguage_7), value);
	}

	inline static int32_t get_offset_of_datatypeNMToken_8() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNMToken_8)); }
	inline XsdNMToken_t2787524133 * get_datatypeNMToken_8() const { return ___datatypeNMToken_8; }
	inline XsdNMToken_t2787524133 ** get_address_of_datatypeNMToken_8() { return &___datatypeNMToken_8; }
	inline void set_datatypeNMToken_8(XsdNMToken_t2787524133 * value)
	{
		___datatypeNMToken_8 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNMToken_8), value);
	}

	inline static int32_t get_offset_of_datatypeNMTokens_9() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNMTokens_9)); }
	inline XsdNMTokens_t3644935921 * get_datatypeNMTokens_9() const { return ___datatypeNMTokens_9; }
	inline XsdNMTokens_t3644935921 ** get_address_of_datatypeNMTokens_9() { return &___datatypeNMTokens_9; }
	inline void set_datatypeNMTokens_9(XsdNMTokens_t3644935921 * value)
	{
		___datatypeNMTokens_9 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNMTokens_9), value);
	}

	inline static int32_t get_offset_of_datatypeName_10() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeName_10)); }
	inline XsdName_t2809458942 * get_datatypeName_10() const { return ___datatypeName_10; }
	inline XsdName_t2809458942 ** get_address_of_datatypeName_10() { return &___datatypeName_10; }
	inline void set_datatypeName_10(XsdName_t2809458942 * value)
	{
		___datatypeName_10 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeName_10), value);
	}

	inline static int32_t get_offset_of_datatypeNCName_11() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNCName_11)); }
	inline XsdNCName_t2448558528 * get_datatypeNCName_11() const { return ___datatypeNCName_11; }
	inline XsdNCName_t2448558528 ** get_address_of_datatypeNCName_11() { return &___datatypeNCName_11; }
	inline void set_datatypeNCName_11(XsdNCName_t2448558528 * value)
	{
		___datatypeNCName_11 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNCName_11), value);
	}

	inline static int32_t get_offset_of_datatypeID_12() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeID_12)); }
	inline XsdID_t3641052050 * get_datatypeID_12() const { return ___datatypeID_12; }
	inline XsdID_t3641052050 ** get_address_of_datatypeID_12() { return &___datatypeID_12; }
	inline void set_datatypeID_12(XsdID_t3641052050 * value)
	{
		___datatypeID_12 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeID_12), value);
	}

	inline static int32_t get_offset_of_datatypeIDRef_13() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeIDRef_13)); }
	inline XsdIDRef_t3533441891 * get_datatypeIDRef_13() const { return ___datatypeIDRef_13; }
	inline XsdIDRef_t3533441891 ** get_address_of_datatypeIDRef_13() { return &___datatypeIDRef_13; }
	inline void set_datatypeIDRef_13(XsdIDRef_t3533441891 * value)
	{
		___datatypeIDRef_13 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeIDRef_13), value);
	}

	inline static int32_t get_offset_of_datatypeIDRefs_14() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeIDRefs_14)); }
	inline XsdIDRefs_t4196912482 * get_datatypeIDRefs_14() const { return ___datatypeIDRefs_14; }
	inline XsdIDRefs_t4196912482 ** get_address_of_datatypeIDRefs_14() { return &___datatypeIDRefs_14; }
	inline void set_datatypeIDRefs_14(XsdIDRefs_t4196912482 * value)
	{
		___datatypeIDRefs_14 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeIDRefs_14), value);
	}

	inline static int32_t get_offset_of_datatypeEntity_15() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeEntity_15)); }
	inline XsdEntity_t2294332234 * get_datatypeEntity_15() const { return ___datatypeEntity_15; }
	inline XsdEntity_t2294332234 ** get_address_of_datatypeEntity_15() { return &___datatypeEntity_15; }
	inline void set_datatypeEntity_15(XsdEntity_t2294332234 * value)
	{
		___datatypeEntity_15 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeEntity_15), value);
	}

	inline static int32_t get_offset_of_datatypeEntities_16() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeEntities_16)); }
	inline XsdEntities_t1133855613 * get_datatypeEntities_16() const { return ___datatypeEntities_16; }
	inline XsdEntities_t1133855613 ** get_address_of_datatypeEntities_16() { return &___datatypeEntities_16; }
	inline void set_datatypeEntities_16(XsdEntities_t1133855613 * value)
	{
		___datatypeEntities_16 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeEntities_16), value);
	}

	inline static int32_t get_offset_of_datatypeNotation_17() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNotation_17)); }
	inline XsdNotation_t2721234078 * get_datatypeNotation_17() const { return ___datatypeNotation_17; }
	inline XsdNotation_t2721234078 ** get_address_of_datatypeNotation_17() { return &___datatypeNotation_17; }
	inline void set_datatypeNotation_17(XsdNotation_t2721234078 * value)
	{
		___datatypeNotation_17 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNotation_17), value);
	}

	inline static int32_t get_offset_of_datatypeDecimal_18() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDecimal_18)); }
	inline XsdDecimal_t3796307291 * get_datatypeDecimal_18() const { return ___datatypeDecimal_18; }
	inline XsdDecimal_t3796307291 ** get_address_of_datatypeDecimal_18() { return &___datatypeDecimal_18; }
	inline void set_datatypeDecimal_18(XsdDecimal_t3796307291 * value)
	{
		___datatypeDecimal_18 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDecimal_18), value);
	}

	inline static int32_t get_offset_of_datatypeInteger_19() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeInteger_19)); }
	inline XsdInteger_t1726820563 * get_datatypeInteger_19() const { return ___datatypeInteger_19; }
	inline XsdInteger_t1726820563 ** get_address_of_datatypeInteger_19() { return &___datatypeInteger_19; }
	inline void set_datatypeInteger_19(XsdInteger_t1726820563 * value)
	{
		___datatypeInteger_19 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeInteger_19), value);
	}

	inline static int32_t get_offset_of_datatypeLong_20() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeLong_20)); }
	inline XsdLong_t1719775717 * get_datatypeLong_20() const { return ___datatypeLong_20; }
	inline XsdLong_t1719775717 ** get_address_of_datatypeLong_20() { return &___datatypeLong_20; }
	inline void set_datatypeLong_20(XsdLong_t1719775717 * value)
	{
		___datatypeLong_20 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeLong_20), value);
	}

	inline static int32_t get_offset_of_datatypeInt_21() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeInt_21)); }
	inline XsdInt_t4031406130 * get_datatypeInt_21() const { return ___datatypeInt_21; }
	inline XsdInt_t4031406130 ** get_address_of_datatypeInt_21() { return &___datatypeInt_21; }
	inline void set_datatypeInt_21(XsdInt_t4031406130 * value)
	{
		___datatypeInt_21 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeInt_21), value);
	}

	inline static int32_t get_offset_of_datatypeShort_22() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeShort_22)); }
	inline XsdShort_t1466004108 * get_datatypeShort_22() const { return ___datatypeShort_22; }
	inline XsdShort_t1466004108 ** get_address_of_datatypeShort_22() { return &___datatypeShort_22; }
	inline void set_datatypeShort_22(XsdShort_t1466004108 * value)
	{
		___datatypeShort_22 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeShort_22), value);
	}

	inline static int32_t get_offset_of_datatypeByte_23() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeByte_23)); }
	inline XsdByte_t2834617523 * get_datatypeByte_23() const { return ___datatypeByte_23; }
	inline XsdByte_t2834617523 ** get_address_of_datatypeByte_23() { return &___datatypeByte_23; }
	inline void set_datatypeByte_23(XsdByte_t2834617523 * value)
	{
		___datatypeByte_23 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeByte_23), value);
	}

	inline static int32_t get_offset_of_datatypeNonNegativeInteger_24() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNonNegativeInteger_24)); }
	inline XsdNonNegativeInteger_t2518569928 * get_datatypeNonNegativeInteger_24() const { return ___datatypeNonNegativeInteger_24; }
	inline XsdNonNegativeInteger_t2518569928 ** get_address_of_datatypeNonNegativeInteger_24() { return &___datatypeNonNegativeInteger_24; }
	inline void set_datatypeNonNegativeInteger_24(XsdNonNegativeInteger_t2518569928 * value)
	{
		___datatypeNonNegativeInteger_24 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNonNegativeInteger_24), value);
	}

	inline static int32_t get_offset_of_datatypePositiveInteger_25() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypePositiveInteger_25)); }
	inline XsdPositiveInteger_t858890625 * get_datatypePositiveInteger_25() const { return ___datatypePositiveInteger_25; }
	inline XsdPositiveInteger_t858890625 ** get_address_of_datatypePositiveInteger_25() { return &___datatypePositiveInteger_25; }
	inline void set_datatypePositiveInteger_25(XsdPositiveInteger_t858890625 * value)
	{
		___datatypePositiveInteger_25 = value;
		Il2CppCodeGenWriteBarrier((&___datatypePositiveInteger_25), value);
	}

	inline static int32_t get_offset_of_datatypeUnsignedLong_26() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeUnsignedLong_26)); }
	inline XsdUnsignedLong_t3088213186 * get_datatypeUnsignedLong_26() const { return ___datatypeUnsignedLong_26; }
	inline XsdUnsignedLong_t3088213186 ** get_address_of_datatypeUnsignedLong_26() { return &___datatypeUnsignedLong_26; }
	inline void set_datatypeUnsignedLong_26(XsdUnsignedLong_t3088213186 * value)
	{
		___datatypeUnsignedLong_26 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeUnsignedLong_26), value);
	}

	inline static int32_t get_offset_of_datatypeUnsignedInt_27() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeUnsignedInt_27)); }
	inline XsdUnsignedInt_t1345788448 * get_datatypeUnsignedInt_27() const { return ___datatypeUnsignedInt_27; }
	inline XsdUnsignedInt_t1345788448 ** get_address_of_datatypeUnsignedInt_27() { return &___datatypeUnsignedInt_27; }
	inline void set_datatypeUnsignedInt_27(XsdUnsignedInt_t1345788448 * value)
	{
		___datatypeUnsignedInt_27 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeUnsignedInt_27), value);
	}

	inline static int32_t get_offset_of_datatypeUnsignedShort_28() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeUnsignedShort_28)); }
	inline XsdUnsignedShort_t3040059537 * get_datatypeUnsignedShort_28() const { return ___datatypeUnsignedShort_28; }
	inline XsdUnsignedShort_t3040059537 ** get_address_of_datatypeUnsignedShort_28() { return &___datatypeUnsignedShort_28; }
	inline void set_datatypeUnsignedShort_28(XsdUnsignedShort_t3040059537 * value)
	{
		___datatypeUnsignedShort_28 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeUnsignedShort_28), value);
	}

	inline static int32_t get_offset_of_datatypeUnsignedByte_29() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeUnsignedByte_29)); }
	inline XsdUnsignedByte_t1503500326 * get_datatypeUnsignedByte_29() const { return ___datatypeUnsignedByte_29; }
	inline XsdUnsignedByte_t1503500326 ** get_address_of_datatypeUnsignedByte_29() { return &___datatypeUnsignedByte_29; }
	inline void set_datatypeUnsignedByte_29(XsdUnsignedByte_t1503500326 * value)
	{
		___datatypeUnsignedByte_29 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeUnsignedByte_29), value);
	}

	inline static int32_t get_offset_of_datatypeNonPositiveInteger_30() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNonPositiveInteger_30)); }
	inline XsdNonPositiveInteger_t654673514 * get_datatypeNonPositiveInteger_30() const { return ___datatypeNonPositiveInteger_30; }
	inline XsdNonPositiveInteger_t654673514 ** get_address_of_datatypeNonPositiveInteger_30() { return &___datatypeNonPositiveInteger_30; }
	inline void set_datatypeNonPositiveInteger_30(XsdNonPositiveInteger_t654673514 * value)
	{
		___datatypeNonPositiveInteger_30 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNonPositiveInteger_30), value);
	}

	inline static int32_t get_offset_of_datatypeNegativeInteger_31() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeNegativeInteger_31)); }
	inline XsdNegativeInteger_t145731310 * get_datatypeNegativeInteger_31() const { return ___datatypeNegativeInteger_31; }
	inline XsdNegativeInteger_t145731310 ** get_address_of_datatypeNegativeInteger_31() { return &___datatypeNegativeInteger_31; }
	inline void set_datatypeNegativeInteger_31(XsdNegativeInteger_t145731310 * value)
	{
		___datatypeNegativeInteger_31 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeNegativeInteger_31), value);
	}

	inline static int32_t get_offset_of_datatypeFloat_32() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeFloat_32)); }
	inline XsdFloat_t2432376376 * get_datatypeFloat_32() const { return ___datatypeFloat_32; }
	inline XsdFloat_t2432376376 ** get_address_of_datatypeFloat_32() { return &___datatypeFloat_32; }
	inline void set_datatypeFloat_32(XsdFloat_t2432376376 * value)
	{
		___datatypeFloat_32 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeFloat_32), value);
	}

	inline static int32_t get_offset_of_datatypeDouble_33() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDouble_33)); }
	inline XsdDouble_t2405104440 * get_datatypeDouble_33() const { return ___datatypeDouble_33; }
	inline XsdDouble_t2405104440 ** get_address_of_datatypeDouble_33() { return &___datatypeDouble_33; }
	inline void set_datatypeDouble_33(XsdDouble_t2405104440 * value)
	{
		___datatypeDouble_33 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDouble_33), value);
	}

	inline static int32_t get_offset_of_datatypeBase64Binary_34() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeBase64Binary_34)); }
	inline XsdBase64Binary_t1793769650 * get_datatypeBase64Binary_34() const { return ___datatypeBase64Binary_34; }
	inline XsdBase64Binary_t1793769650 ** get_address_of_datatypeBase64Binary_34() { return &___datatypeBase64Binary_34; }
	inline void set_datatypeBase64Binary_34(XsdBase64Binary_t1793769650 * value)
	{
		___datatypeBase64Binary_34 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeBase64Binary_34), value);
	}

	inline static int32_t get_offset_of_datatypeBoolean_35() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeBoolean_35)); }
	inline XsdBoolean_t747919005 * get_datatypeBoolean_35() const { return ___datatypeBoolean_35; }
	inline XsdBoolean_t747919005 ** get_address_of_datatypeBoolean_35() { return &___datatypeBoolean_35; }
	inline void set_datatypeBoolean_35(XsdBoolean_t747919005 * value)
	{
		___datatypeBoolean_35 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeBoolean_35), value);
	}

	inline static int32_t get_offset_of_datatypeAnyURI_36() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeAnyURI_36)); }
	inline XsdAnyURI_t1696333635 * get_datatypeAnyURI_36() const { return ___datatypeAnyURI_36; }
	inline XsdAnyURI_t1696333635 ** get_address_of_datatypeAnyURI_36() { return &___datatypeAnyURI_36; }
	inline void set_datatypeAnyURI_36(XsdAnyURI_t1696333635 * value)
	{
		___datatypeAnyURI_36 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeAnyURI_36), value);
	}

	inline static int32_t get_offset_of_datatypeDuration_37() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDuration_37)); }
	inline XsdDuration_t4216890283 * get_datatypeDuration_37() const { return ___datatypeDuration_37; }
	inline XsdDuration_t4216890283 ** get_address_of_datatypeDuration_37() { return &___datatypeDuration_37; }
	inline void set_datatypeDuration_37(XsdDuration_t4216890283 * value)
	{
		___datatypeDuration_37 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDuration_37), value);
	}

	inline static int32_t get_offset_of_datatypeDateTime_38() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDateTime_38)); }
	inline XsdDateTime_t2878826493 * get_datatypeDateTime_38() const { return ___datatypeDateTime_38; }
	inline XsdDateTime_t2878826493 ** get_address_of_datatypeDateTime_38() { return &___datatypeDateTime_38; }
	inline void set_datatypeDateTime_38(XsdDateTime_t2878826493 * value)
	{
		___datatypeDateTime_38 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDateTime_38), value);
	}

	inline static int32_t get_offset_of_datatypeDate_39() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDate_39)); }
	inline XsdDate_t84799097 * get_datatypeDate_39() const { return ___datatypeDate_39; }
	inline XsdDate_t84799097 ** get_address_of_datatypeDate_39() { return &___datatypeDate_39; }
	inline void set_datatypeDate_39(XsdDate_t84799097 * value)
	{
		___datatypeDate_39 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDate_39), value);
	}

	inline static int32_t get_offset_of_datatypeTime_40() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeTime_40)); }
	inline XsdTime_t194014253 * get_datatypeTime_40() const { return ___datatypeTime_40; }
	inline XsdTime_t194014253 ** get_address_of_datatypeTime_40() { return &___datatypeTime_40; }
	inline void set_datatypeTime_40(XsdTime_t194014253 * value)
	{
		___datatypeTime_40 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeTime_40), value);
	}

	inline static int32_t get_offset_of_datatypeHexBinary_41() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeHexBinary_41)); }
	inline XsdHexBinary_t309962759 * get_datatypeHexBinary_41() const { return ___datatypeHexBinary_41; }
	inline XsdHexBinary_t309962759 ** get_address_of_datatypeHexBinary_41() { return &___datatypeHexBinary_41; }
	inline void set_datatypeHexBinary_41(XsdHexBinary_t309962759 * value)
	{
		___datatypeHexBinary_41 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeHexBinary_41), value);
	}

	inline static int32_t get_offset_of_datatypeQName_42() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeQName_42)); }
	inline XsdQName_t2375427330 * get_datatypeQName_42() const { return ___datatypeQName_42; }
	inline XsdQName_t2375427330 ** get_address_of_datatypeQName_42() { return &___datatypeQName_42; }
	inline void set_datatypeQName_42(XsdQName_t2375427330 * value)
	{
		___datatypeQName_42 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeQName_42), value);
	}

	inline static int32_t get_offset_of_datatypeGYearMonth_43() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeGYearMonth_43)); }
	inline XsdGYearMonth_t4060942859 * get_datatypeGYearMonth_43() const { return ___datatypeGYearMonth_43; }
	inline XsdGYearMonth_t4060942859 ** get_address_of_datatypeGYearMonth_43() { return &___datatypeGYearMonth_43; }
	inline void set_datatypeGYearMonth_43(XsdGYearMonth_t4060942859 * value)
	{
		___datatypeGYearMonth_43 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeGYearMonth_43), value);
	}

	inline static int32_t get_offset_of_datatypeGMonthDay_44() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeGMonthDay_44)); }
	inline XsdGMonthDay_t1849750074 * get_datatypeGMonthDay_44() const { return ___datatypeGMonthDay_44; }
	inline XsdGMonthDay_t1849750074 ** get_address_of_datatypeGMonthDay_44() { return &___datatypeGMonthDay_44; }
	inline void set_datatypeGMonthDay_44(XsdGMonthDay_t1849750074 * value)
	{
		___datatypeGMonthDay_44 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeGMonthDay_44), value);
	}

	inline static int32_t get_offset_of_datatypeGYear_45() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeGYear_45)); }
	inline XsdGYear_t1626334498 * get_datatypeGYear_45() const { return ___datatypeGYear_45; }
	inline XsdGYear_t1626334498 ** get_address_of_datatypeGYear_45() { return &___datatypeGYear_45; }
	inline void set_datatypeGYear_45(XsdGYear_t1626334498 * value)
	{
		___datatypeGYear_45 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeGYear_45), value);
	}

	inline static int32_t get_offset_of_datatypeGMonth_46() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeGMonth_46)); }
	inline XsdGMonth_t1559631661 * get_datatypeGMonth_46() const { return ___datatypeGMonth_46; }
	inline XsdGMonth_t1559631661 ** get_address_of_datatypeGMonth_46() { return &___datatypeGMonth_46; }
	inline void set_datatypeGMonth_46(XsdGMonth_t1559631661 * value)
	{
		___datatypeGMonth_46 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeGMonth_46), value);
	}

	inline static int32_t get_offset_of_datatypeGDay_47() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeGDay_47)); }
	inline XsdGDay_t1637325925 * get_datatypeGDay_47() const { return ___datatypeGDay_47; }
	inline XsdGDay_t1637325925 ** get_address_of_datatypeGDay_47() { return &___datatypeGDay_47; }
	inline void set_datatypeGDay_47(XsdGDay_t1637325925 * value)
	{
		___datatypeGDay_47 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeGDay_47), value);
	}

	inline static int32_t get_offset_of_datatypeAnyAtomicType_48() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeAnyAtomicType_48)); }
	inline XdtAnyAtomicType_t2627475155 * get_datatypeAnyAtomicType_48() const { return ___datatypeAnyAtomicType_48; }
	inline XdtAnyAtomicType_t2627475155 ** get_address_of_datatypeAnyAtomicType_48() { return &___datatypeAnyAtomicType_48; }
	inline void set_datatypeAnyAtomicType_48(XdtAnyAtomicType_t2627475155 * value)
	{
		___datatypeAnyAtomicType_48 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeAnyAtomicType_48), value);
	}

	inline static int32_t get_offset_of_datatypeUntypedAtomic_49() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeUntypedAtomic_49)); }
	inline XdtUntypedAtomic_t2359648093 * get_datatypeUntypedAtomic_49() const { return ___datatypeUntypedAtomic_49; }
	inline XdtUntypedAtomic_t2359648093 ** get_address_of_datatypeUntypedAtomic_49() { return &___datatypeUntypedAtomic_49; }
	inline void set_datatypeUntypedAtomic_49(XdtUntypedAtomic_t2359648093 * value)
	{
		___datatypeUntypedAtomic_49 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeUntypedAtomic_49), value);
	}

	inline static int32_t get_offset_of_datatypeDayTimeDuration_50() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeDayTimeDuration_50)); }
	inline XdtDayTimeDuration_t597694552 * get_datatypeDayTimeDuration_50() const { return ___datatypeDayTimeDuration_50; }
	inline XdtDayTimeDuration_t597694552 ** get_address_of_datatypeDayTimeDuration_50() { return &___datatypeDayTimeDuration_50; }
	inline void set_datatypeDayTimeDuration_50(XdtDayTimeDuration_t597694552 * value)
	{
		___datatypeDayTimeDuration_50 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeDayTimeDuration_50), value);
	}

	inline static int32_t get_offset_of_datatypeYearMonthDuration_51() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___datatypeYearMonthDuration_51)); }
	inline XdtYearMonthDuration_t673549898 * get_datatypeYearMonthDuration_51() const { return ___datatypeYearMonthDuration_51; }
	inline XdtYearMonthDuration_t673549898 ** get_address_of_datatypeYearMonthDuration_51() { return &___datatypeYearMonthDuration_51; }
	inline void set_datatypeYearMonthDuration_51(XdtYearMonthDuration_t673549898 * value)
	{
		___datatypeYearMonthDuration_51 = value;
		Il2CppCodeGenWriteBarrier((&___datatypeYearMonthDuration_51), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map2A_52() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___U3CU3Ef__switchU24map2A_52)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map2A_52() const { return ___U3CU3Ef__switchU24map2A_52; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map2A_52() { return &___U3CU3Ef__switchU24map2A_52; }
	inline void set_U3CU3Ef__switchU24map2A_52(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map2A_52 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map2A_52), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map2B_53() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___U3CU3Ef__switchU24map2B_53)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map2B_53() const { return ___U3CU3Ef__switchU24map2B_53; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map2B_53() { return &___U3CU3Ef__switchU24map2B_53; }
	inline void set_U3CU3Ef__switchU24map2B_53(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map2B_53 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map2B_53), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map2C_54() { return static_cast<int32_t>(offsetof(XmlSchemaDatatype_t2974024598_StaticFields, ___U3CU3Ef__switchU24map2C_54)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map2C_54() const { return ___U3CU3Ef__switchU24map2C_54; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map2C_54() { return &___U3CU3Ef__switchU24map2C_54; }
	inline void set_U3CU3Ef__switchU24map2C_54(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map2C_54 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map2C_54), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMADATATYPE_T2974024598_H
#ifndef XMLCOMMENT_T683521230_H
#define XMLCOMMENT_T683521230_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.XmlComment
struct  XmlComment_t683521230  : public XmlCharacterData_t168497055
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLCOMMENT_T683521230_H
#ifndef XMLSCHEMAINFO_T1285312624_H
#define XMLSCHEMAINFO_T1285312624_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaInfo
struct  XmlSchemaInfo_t1285312624  : public RuntimeObject
{
public:
	// System.Boolean System.Xml.Schema.XmlSchemaInfo::isDefault
	bool ___isDefault_0;
	// System.Boolean System.Xml.Schema.XmlSchemaInfo::isNil
	bool ___isNil_1;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaInfo::memberType
	XmlSchemaSimpleType_t1597467585 * ___memberType_2;
	// System.Xml.Schema.XmlSchemaAttribute System.Xml.Schema.XmlSchemaInfo::attr
	XmlSchemaAttribute_t569796853 * ___attr_3;
	// System.Xml.Schema.XmlSchemaElement System.Xml.Schema.XmlSchemaInfo::elem
	XmlSchemaElement_t2407988793 * ___elem_4;
	// System.Xml.Schema.XmlSchemaType System.Xml.Schema.XmlSchemaInfo::type
	XmlSchemaType_t524866458 * ___type_5;
	// System.Xml.Schema.XmlSchemaValidity System.Xml.Schema.XmlSchemaInfo::validity
	int32_t ___validity_6;

public:
	inline static int32_t get_offset_of_isDefault_0() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___isDefault_0)); }
	inline bool get_isDefault_0() const { return ___isDefault_0; }
	inline bool* get_address_of_isDefault_0() { return &___isDefault_0; }
	inline void set_isDefault_0(bool value)
	{
		___isDefault_0 = value;
	}

	inline static int32_t get_offset_of_isNil_1() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___isNil_1)); }
	inline bool get_isNil_1() const { return ___isNil_1; }
	inline bool* get_address_of_isNil_1() { return &___isNil_1; }
	inline void set_isNil_1(bool value)
	{
		___isNil_1 = value;
	}

	inline static int32_t get_offset_of_memberType_2() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___memberType_2)); }
	inline XmlSchemaSimpleType_t1597467585 * get_memberType_2() const { return ___memberType_2; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_memberType_2() { return &___memberType_2; }
	inline void set_memberType_2(XmlSchemaSimpleType_t1597467585 * value)
	{
		___memberType_2 = value;
		Il2CppCodeGenWriteBarrier((&___memberType_2), value);
	}

	inline static int32_t get_offset_of_attr_3() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___attr_3)); }
	inline XmlSchemaAttribute_t569796853 * get_attr_3() const { return ___attr_3; }
	inline XmlSchemaAttribute_t569796853 ** get_address_of_attr_3() { return &___attr_3; }
	inline void set_attr_3(XmlSchemaAttribute_t569796853 * value)
	{
		___attr_3 = value;
		Il2CppCodeGenWriteBarrier((&___attr_3), value);
	}

	inline static int32_t get_offset_of_elem_4() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___elem_4)); }
	inline XmlSchemaElement_t2407988793 * get_elem_4() const { return ___elem_4; }
	inline XmlSchemaElement_t2407988793 ** get_address_of_elem_4() { return &___elem_4; }
	inline void set_elem_4(XmlSchemaElement_t2407988793 * value)
	{
		___elem_4 = value;
		Il2CppCodeGenWriteBarrier((&___elem_4), value);
	}

	inline static int32_t get_offset_of_type_5() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___type_5)); }
	inline XmlSchemaType_t524866458 * get_type_5() const { return ___type_5; }
	inline XmlSchemaType_t524866458 ** get_address_of_type_5() { return &___type_5; }
	inline void set_type_5(XmlSchemaType_t524866458 * value)
	{
		___type_5 = value;
		Il2CppCodeGenWriteBarrier((&___type_5), value);
	}

	inline static int32_t get_offset_of_validity_6() { return static_cast<int32_t>(offsetof(XmlSchemaInfo_t1285312624, ___validity_6)); }
	inline int32_t get_validity_6() const { return ___validity_6; }
	inline int32_t* get_address_of_validity_6() { return &___validity_6; }
	inline void set_validity_6(int32_t value)
	{
		___validity_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAINFO_T1285312624_H
#ifndef DTDELEMENTDECLARATIONCOLLECTION_T3839880060_H
#define DTDELEMENTDECLARATIONCOLLECTION_T3839880060_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.DTDElementDeclarationCollection
struct  DTDElementDeclarationCollection_t3839880060  : public DTDCollectionBase_t20373490
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DTDELEMENTDECLARATIONCOLLECTION_T3839880060_H
#ifndef XMLSCHEMAUTIL_T3375497465_H
#define XMLSCHEMAUTIL_T3375497465_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaUtil
struct  XmlSchemaUtil_t3375497465  : public RuntimeObject
{
public:

public:
};

struct XmlSchemaUtil_t3375497465_StaticFields
{
public:
	// System.Xml.Schema.XmlSchemaDerivationMethod System.Xml.Schema.XmlSchemaUtil::FinalAllowed
	int32_t ___FinalAllowed_0;
	// System.Xml.Schema.XmlSchemaDerivationMethod System.Xml.Schema.XmlSchemaUtil::ElementBlockAllowed
	int32_t ___ElementBlockAllowed_1;
	// System.Xml.Schema.XmlSchemaDerivationMethod System.Xml.Schema.XmlSchemaUtil::ComplexTypeBlockAllowed
	int32_t ___ComplexTypeBlockAllowed_2;
	// System.Boolean System.Xml.Schema.XmlSchemaUtil::StrictMsCompliant
	bool ___StrictMsCompliant_3;

public:
	inline static int32_t get_offset_of_FinalAllowed_0() { return static_cast<int32_t>(offsetof(XmlSchemaUtil_t3375497465_StaticFields, ___FinalAllowed_0)); }
	inline int32_t get_FinalAllowed_0() const { return ___FinalAllowed_0; }
	inline int32_t* get_address_of_FinalAllowed_0() { return &___FinalAllowed_0; }
	inline void set_FinalAllowed_0(int32_t value)
	{
		___FinalAllowed_0 = value;
	}

	inline static int32_t get_offset_of_ElementBlockAllowed_1() { return static_cast<int32_t>(offsetof(XmlSchemaUtil_t3375497465_StaticFields, ___ElementBlockAllowed_1)); }
	inline int32_t get_ElementBlockAllowed_1() const { return ___ElementBlockAllowed_1; }
	inline int32_t* get_address_of_ElementBlockAllowed_1() { return &___ElementBlockAllowed_1; }
	inline void set_ElementBlockAllowed_1(int32_t value)
	{
		___ElementBlockAllowed_1 = value;
	}

	inline static int32_t get_offset_of_ComplexTypeBlockAllowed_2() { return static_cast<int32_t>(offsetof(XmlSchemaUtil_t3375497465_StaticFields, ___ComplexTypeBlockAllowed_2)); }
	inline int32_t get_ComplexTypeBlockAllowed_2() const { return ___ComplexTypeBlockAllowed_2; }
	inline int32_t* get_address_of_ComplexTypeBlockAllowed_2() { return &___ComplexTypeBlockAllowed_2; }
	inline void set_ComplexTypeBlockAllowed_2(int32_t value)
	{
		___ComplexTypeBlockAllowed_2 = value;
	}

	inline static int32_t get_offset_of_StrictMsCompliant_3() { return static_cast<int32_t>(offsetof(XmlSchemaUtil_t3375497465_StaticFields, ___StrictMsCompliant_3)); }
	inline bool get_StrictMsCompliant_3() const { return ___StrictMsCompliant_3; }
	inline bool* get_address_of_StrictMsCompliant_3() { return &___StrictMsCompliant_3; }
	inline void set_StrictMsCompliant_3(bool value)
	{
		___StrictMsCompliant_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAUTIL_T3375497465_H
#ifndef XMLSCHEMATYPE_T524866458_H
#define XMLSCHEMATYPE_T524866458_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaType
struct  XmlSchemaType_t524866458  : public XmlSchemaAnnotated_t791701952
{
public:
	// System.Xml.Schema.XmlSchemaDerivationMethod System.Xml.Schema.XmlSchemaType::final
	int32_t ___final_3;
	// System.Xml.Schema.XmlSchemaType System.Xml.Schema.XmlSchemaType::BaseXmlSchemaTypeInternal
	XmlSchemaType_t524866458 * ___BaseXmlSchemaTypeInternal_4;
	// System.Xml.Schema.XmlSchemaDatatype System.Xml.Schema.XmlSchemaType::DatatypeInternal
	XmlSchemaDatatype_t2974024598 * ___DatatypeInternal_5;
	// System.Xml.XmlQualifiedName System.Xml.Schema.XmlSchemaType::QNameInternal
	XmlQualifiedName_t2861843702 * ___QNameInternal_6;

public:
	inline static int32_t get_offset_of_final_3() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458, ___final_3)); }
	inline int32_t get_final_3() const { return ___final_3; }
	inline int32_t* get_address_of_final_3() { return &___final_3; }
	inline void set_final_3(int32_t value)
	{
		___final_3 = value;
	}

	inline static int32_t get_offset_of_BaseXmlSchemaTypeInternal_4() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458, ___BaseXmlSchemaTypeInternal_4)); }
	inline XmlSchemaType_t524866458 * get_BaseXmlSchemaTypeInternal_4() const { return ___BaseXmlSchemaTypeInternal_4; }
	inline XmlSchemaType_t524866458 ** get_address_of_BaseXmlSchemaTypeInternal_4() { return &___BaseXmlSchemaTypeInternal_4; }
	inline void set_BaseXmlSchemaTypeInternal_4(XmlSchemaType_t524866458 * value)
	{
		___BaseXmlSchemaTypeInternal_4 = value;
		Il2CppCodeGenWriteBarrier((&___BaseXmlSchemaTypeInternal_4), value);
	}

	inline static int32_t get_offset_of_DatatypeInternal_5() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458, ___DatatypeInternal_5)); }
	inline XmlSchemaDatatype_t2974024598 * get_DatatypeInternal_5() const { return ___DatatypeInternal_5; }
	inline XmlSchemaDatatype_t2974024598 ** get_address_of_DatatypeInternal_5() { return &___DatatypeInternal_5; }
	inline void set_DatatypeInternal_5(XmlSchemaDatatype_t2974024598 * value)
	{
		___DatatypeInternal_5 = value;
		Il2CppCodeGenWriteBarrier((&___DatatypeInternal_5), value);
	}

	inline static int32_t get_offset_of_QNameInternal_6() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458, ___QNameInternal_6)); }
	inline XmlQualifiedName_t2861843702 * get_QNameInternal_6() const { return ___QNameInternal_6; }
	inline XmlQualifiedName_t2861843702 ** get_address_of_QNameInternal_6() { return &___QNameInternal_6; }
	inline void set_QNameInternal_6(XmlQualifiedName_t2861843702 * value)
	{
		___QNameInternal_6 = value;
		Il2CppCodeGenWriteBarrier((&___QNameInternal_6), value);
	}
};

struct XmlSchemaType_t524866458_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.Schema.XmlSchemaType::<>f__switch$map2E
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map2E_7;
	// System.Collections.Generic.Dictionary`2<System.String,System.Int32> System.Xml.Schema.XmlSchemaType::<>f__switch$map2F
	Dictionary_2_t1245616680 * ___U3CU3Ef__switchU24map2F_8;

public:
	inline static int32_t get_offset_of_U3CU3Ef__switchU24map2E_7() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458_StaticFields, ___U3CU3Ef__switchU24map2E_7)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map2E_7() const { return ___U3CU3Ef__switchU24map2E_7; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map2E_7() { return &___U3CU3Ef__switchU24map2E_7; }
	inline void set_U3CU3Ef__switchU24map2E_7(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map2E_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map2E_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__switchU24map2F_8() { return static_cast<int32_t>(offsetof(XmlSchemaType_t524866458_StaticFields, ___U3CU3Ef__switchU24map2F_8)); }
	inline Dictionary_2_t1245616680 * get_U3CU3Ef__switchU24map2F_8() const { return ___U3CU3Ef__switchU24map2F_8; }
	inline Dictionary_2_t1245616680 ** get_address_of_U3CU3Ef__switchU24map2F_8() { return &___U3CU3Ef__switchU24map2F_8; }
	inline void set_U3CU3Ef__switchU24map2F_8(Dictionary_2_t1245616680 * value)
	{
		___U3CU3Ef__switchU24map2F_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__switchU24map2F_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMATYPE_T524866458_H
#ifndef XSDANYSIMPLETYPE_T1645894131_H
#define XSDANYSIMPLETYPE_T1645894131_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdAnySimpleType
struct  XsdAnySimpleType_t1645894131  : public XmlSchemaDatatype_t2974024598
{
public:

public:
};

struct XsdAnySimpleType_t1645894131_StaticFields
{
public:
	// Mono.Xml.Schema.XsdAnySimpleType Mono.Xml.Schema.XsdAnySimpleType::instance
	XsdAnySimpleType_t1645894131 * ___instance_55;
	// System.Char[] Mono.Xml.Schema.XsdAnySimpleType::whitespaceArray
	CharU5BU5D_t2772155777* ___whitespaceArray_56;
	// System.Xml.Schema.XmlSchemaFacet/Facet Mono.Xml.Schema.XsdAnySimpleType::booleanAllowedFacets
	int32_t ___booleanAllowedFacets_57;
	// System.Xml.Schema.XmlSchemaFacet/Facet Mono.Xml.Schema.XsdAnySimpleType::decimalAllowedFacets
	int32_t ___decimalAllowedFacets_58;
	// System.Xml.Schema.XmlSchemaFacet/Facet Mono.Xml.Schema.XsdAnySimpleType::durationAllowedFacets
	int32_t ___durationAllowedFacets_59;
	// System.Xml.Schema.XmlSchemaFacet/Facet Mono.Xml.Schema.XsdAnySimpleType::stringAllowedFacets
	int32_t ___stringAllowedFacets_60;

public:
	inline static int32_t get_offset_of_instance_55() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___instance_55)); }
	inline XsdAnySimpleType_t1645894131 * get_instance_55() const { return ___instance_55; }
	inline XsdAnySimpleType_t1645894131 ** get_address_of_instance_55() { return &___instance_55; }
	inline void set_instance_55(XsdAnySimpleType_t1645894131 * value)
	{
		___instance_55 = value;
		Il2CppCodeGenWriteBarrier((&___instance_55), value);
	}

	inline static int32_t get_offset_of_whitespaceArray_56() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___whitespaceArray_56)); }
	inline CharU5BU5D_t2772155777* get_whitespaceArray_56() const { return ___whitespaceArray_56; }
	inline CharU5BU5D_t2772155777** get_address_of_whitespaceArray_56() { return &___whitespaceArray_56; }
	inline void set_whitespaceArray_56(CharU5BU5D_t2772155777* value)
	{
		___whitespaceArray_56 = value;
		Il2CppCodeGenWriteBarrier((&___whitespaceArray_56), value);
	}

	inline static int32_t get_offset_of_booleanAllowedFacets_57() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___booleanAllowedFacets_57)); }
	inline int32_t get_booleanAllowedFacets_57() const { return ___booleanAllowedFacets_57; }
	inline int32_t* get_address_of_booleanAllowedFacets_57() { return &___booleanAllowedFacets_57; }
	inline void set_booleanAllowedFacets_57(int32_t value)
	{
		___booleanAllowedFacets_57 = value;
	}

	inline static int32_t get_offset_of_decimalAllowedFacets_58() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___decimalAllowedFacets_58)); }
	inline int32_t get_decimalAllowedFacets_58() const { return ___decimalAllowedFacets_58; }
	inline int32_t* get_address_of_decimalAllowedFacets_58() { return &___decimalAllowedFacets_58; }
	inline void set_decimalAllowedFacets_58(int32_t value)
	{
		___decimalAllowedFacets_58 = value;
	}

	inline static int32_t get_offset_of_durationAllowedFacets_59() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___durationAllowedFacets_59)); }
	inline int32_t get_durationAllowedFacets_59() const { return ___durationAllowedFacets_59; }
	inline int32_t* get_address_of_durationAllowedFacets_59() { return &___durationAllowedFacets_59; }
	inline void set_durationAllowedFacets_59(int32_t value)
	{
		___durationAllowedFacets_59 = value;
	}

	inline static int32_t get_offset_of_stringAllowedFacets_60() { return static_cast<int32_t>(offsetof(XsdAnySimpleType_t1645894131_StaticFields, ___stringAllowedFacets_60)); }
	inline int32_t get_stringAllowedFacets_60() const { return ___stringAllowedFacets_60; }
	inline int32_t* get_address_of_stringAllowedFacets_60() { return &___stringAllowedFacets_60; }
	inline void set_stringAllowedFacets_60(int32_t value)
	{
		___stringAllowedFacets_60 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDANYSIMPLETYPE_T1645894131_H
#ifndef XMLSCHEMASIMPLETYPECONTENT_T554989856_H
#define XMLSCHEMASIMPLETYPECONTENT_T554989856_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSimpleTypeContent
struct  XmlSchemaSimpleTypeContent_t554989856  : public XmlSchemaAnnotated_t791701952
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASIMPLETYPECONTENT_T554989856_H
#ifndef XMLSCHEMAPARTICLE_T1280135901_H
#define XMLSCHEMAPARTICLE_T1280135901_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaParticle
struct  XmlSchemaParticle_t1280135901  : public XmlSchemaAnnotated_t791701952
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAPARTICLE_T1280135901_H
#ifndef XMLSCHEMAFACET_T1439609014_H
#define XMLSCHEMAFACET_T1439609014_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaFacet
struct  XmlSchemaFacet_t1439609014  : public XmlSchemaAnnotated_t791701952
{
public:

public:
};

struct XmlSchemaFacet_t1439609014_StaticFields
{
public:
	// System.Xml.Schema.XmlSchemaFacet/Facet System.Xml.Schema.XmlSchemaFacet::AllFacets
	int32_t ___AllFacets_3;

public:
	inline static int32_t get_offset_of_AllFacets_3() { return static_cast<int32_t>(offsetof(XmlSchemaFacet_t1439609014_StaticFields, ___AllFacets_3)); }
	inline int32_t get_AllFacets_3() const { return ___AllFacets_3; }
	inline int32_t* get_address_of_AllFacets_3() { return &___AllFacets_3; }
	inline void set_AllFacets_3(int32_t value)
	{
		___AllFacets_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAFACET_T1439609014_H
#ifndef XMLSCHEMAATTRIBUTE_T569796853_H
#define XMLSCHEMAATTRIBUTE_T569796853_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaAttribute
struct  XmlSchemaAttribute_t569796853  : public XmlSchemaAnnotated_t791701952
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAATTRIBUTE_T569796853_H
#ifndef XSDDECIMAL_T3796307291_H
#define XSDDECIMAL_T3796307291_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdDecimal
struct  XsdDecimal_t3796307291  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDDECIMAL_T3796307291_H
#ifndef XSDFLOAT_T2432376376_H
#define XSDFLOAT_T2432376376_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdFloat
struct  XsdFloat_t2432376376  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDFLOAT_T2432376376_H
#ifndef XSDDOUBLE_T2405104440_H
#define XSDDOUBLE_T2405104440_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdDouble
struct  XsdDouble_t2405104440  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDDOUBLE_T2405104440_H
#ifndef XSDHEXBINARY_T309962759_H
#define XSDHEXBINARY_T309962759_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdHexBinary
struct  XsdHexBinary_t309962759  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDHEXBINARY_T309962759_H
#ifndef XSDBOOLEAN_T747919005_H
#define XSDBOOLEAN_T747919005_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdBoolean
struct  XsdBoolean_t747919005  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDBOOLEAN_T747919005_H
#ifndef XSDDURATION_T4216890283_H
#define XSDDURATION_T4216890283_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdDuration
struct  XsdDuration_t4216890283  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDDURATION_T4216890283_H
#ifndef XSDSTRING_T3808583524_H
#define XSDSTRING_T3808583524_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdString
struct  XsdString_t3808583524  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDSTRING_T3808583524_H
#ifndef XSDDATETIME_T2878826493_H
#define XSDDATETIME_T2878826493_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdDateTime
struct  XsdDateTime_t2878826493  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDDATETIME_T2878826493_H
#ifndef XSDDATE_T84799097_H
#define XSDDATE_T84799097_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdDate
struct  XsdDate_t84799097  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDDATE_T84799097_H
#ifndef XSDGYEARMONTH_T4060942859_H
#define XSDGYEARMONTH_T4060942859_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdGYearMonth
struct  XsdGYearMonth_t4060942859  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDGYEARMONTH_T4060942859_H
#ifndef XMLSCHEMASIMPLETYPEUNION_T2683523990_H
#define XMLSCHEMASIMPLETYPEUNION_T2683523990_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSimpleTypeUnion
struct  XmlSchemaSimpleTypeUnion_t2683523990  : public XmlSchemaSimpleTypeContent_t554989856
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASIMPLETYPEUNION_T2683523990_H
#ifndef XSDGMONTHDAY_T1849750074_H
#define XSDGMONTHDAY_T1849750074_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdGMonthDay
struct  XsdGMonthDay_t1849750074  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDGMONTHDAY_T1849750074_H
#ifndef XSDGYEAR_T1626334498_H
#define XSDGYEAR_T1626334498_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdGYear
struct  XsdGYear_t1626334498  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDGYEAR_T1626334498_H
#ifndef XSDGMONTH_T1559631661_H
#define XSDGMONTH_T1559631661_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdGMonth
struct  XsdGMonth_t1559631661  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDGMONTH_T1559631661_H
#ifndef XSDGDAY_T1637325925_H
#define XSDGDAY_T1637325925_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdGDay
struct  XsdGDay_t1637325925  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDGDAY_T1637325925_H
#ifndef XMLSCHEMAELEMENT_T2407988793_H
#define XMLSCHEMAELEMENT_T2407988793_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaElement
struct  XmlSchemaElement_t2407988793  : public XmlSchemaParticle_t1280135901
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMAELEMENT_T2407988793_H
#ifndef XMLSCHEMASIMPLETYPE_T1597467585_H
#define XMLSCHEMASIMPLETYPE_T1597467585_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSimpleType
struct  XmlSchemaSimpleType_t1597467585  : public XmlSchemaType_t524866458
{
public:
	// System.Xml.Schema.XmlSchemaSimpleTypeContent System.Xml.Schema.XmlSchemaSimpleType::content
	XmlSchemaSimpleTypeContent_t554989856 * ___content_10;
	// System.Boolean System.Xml.Schema.XmlSchemaSimpleType::islocal
	bool ___islocal_11;
	// System.Xml.Schema.XmlSchemaDerivationMethod System.Xml.Schema.XmlSchemaSimpleType::variety
	int32_t ___variety_12;

public:
	inline static int32_t get_offset_of_content_10() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585, ___content_10)); }
	inline XmlSchemaSimpleTypeContent_t554989856 * get_content_10() const { return ___content_10; }
	inline XmlSchemaSimpleTypeContent_t554989856 ** get_address_of_content_10() { return &___content_10; }
	inline void set_content_10(XmlSchemaSimpleTypeContent_t554989856 * value)
	{
		___content_10 = value;
		Il2CppCodeGenWriteBarrier((&___content_10), value);
	}

	inline static int32_t get_offset_of_islocal_11() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585, ___islocal_11)); }
	inline bool get_islocal_11() const { return ___islocal_11; }
	inline bool* get_address_of_islocal_11() { return &___islocal_11; }
	inline void set_islocal_11(bool value)
	{
		___islocal_11 = value;
	}

	inline static int32_t get_offset_of_variety_12() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585, ___variety_12)); }
	inline int32_t get_variety_12() const { return ___variety_12; }
	inline int32_t* get_address_of_variety_12() { return &___variety_12; }
	inline void set_variety_12(int32_t value)
	{
		___variety_12 = value;
	}
};

struct XmlSchemaSimpleType_t1597467585_StaticFields
{
public:
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::schemaLocationType
	XmlSchemaSimpleType_t1597467585 * ___schemaLocationType_9;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsAnySimpleType
	XmlSchemaSimpleType_t1597467585 * ___XsAnySimpleType_13;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsString
	XmlSchemaSimpleType_t1597467585 * ___XsString_14;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsBoolean
	XmlSchemaSimpleType_t1597467585 * ___XsBoolean_15;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsDecimal
	XmlSchemaSimpleType_t1597467585 * ___XsDecimal_16;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsFloat
	XmlSchemaSimpleType_t1597467585 * ___XsFloat_17;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsDouble
	XmlSchemaSimpleType_t1597467585 * ___XsDouble_18;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsDuration
	XmlSchemaSimpleType_t1597467585 * ___XsDuration_19;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsDateTime
	XmlSchemaSimpleType_t1597467585 * ___XsDateTime_20;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsTime
	XmlSchemaSimpleType_t1597467585 * ___XsTime_21;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsDate
	XmlSchemaSimpleType_t1597467585 * ___XsDate_22;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsGYearMonth
	XmlSchemaSimpleType_t1597467585 * ___XsGYearMonth_23;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsGYear
	XmlSchemaSimpleType_t1597467585 * ___XsGYear_24;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsGMonthDay
	XmlSchemaSimpleType_t1597467585 * ___XsGMonthDay_25;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsGDay
	XmlSchemaSimpleType_t1597467585 * ___XsGDay_26;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsGMonth
	XmlSchemaSimpleType_t1597467585 * ___XsGMonth_27;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsHexBinary
	XmlSchemaSimpleType_t1597467585 * ___XsHexBinary_28;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsBase64Binary
	XmlSchemaSimpleType_t1597467585 * ___XsBase64Binary_29;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsAnyUri
	XmlSchemaSimpleType_t1597467585 * ___XsAnyUri_30;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsQName
	XmlSchemaSimpleType_t1597467585 * ___XsQName_31;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNotation
	XmlSchemaSimpleType_t1597467585 * ___XsNotation_32;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNormalizedString
	XmlSchemaSimpleType_t1597467585 * ___XsNormalizedString_33;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsToken
	XmlSchemaSimpleType_t1597467585 * ___XsToken_34;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsLanguage
	XmlSchemaSimpleType_t1597467585 * ___XsLanguage_35;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNMToken
	XmlSchemaSimpleType_t1597467585 * ___XsNMToken_36;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNMTokens
	XmlSchemaSimpleType_t1597467585 * ___XsNMTokens_37;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsName
	XmlSchemaSimpleType_t1597467585 * ___XsName_38;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNCName
	XmlSchemaSimpleType_t1597467585 * ___XsNCName_39;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsID
	XmlSchemaSimpleType_t1597467585 * ___XsID_40;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsIDRef
	XmlSchemaSimpleType_t1597467585 * ___XsIDRef_41;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsIDRefs
	XmlSchemaSimpleType_t1597467585 * ___XsIDRefs_42;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsEntity
	XmlSchemaSimpleType_t1597467585 * ___XsEntity_43;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsEntities
	XmlSchemaSimpleType_t1597467585 * ___XsEntities_44;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsInteger
	XmlSchemaSimpleType_t1597467585 * ___XsInteger_45;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNonPositiveInteger
	XmlSchemaSimpleType_t1597467585 * ___XsNonPositiveInteger_46;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNegativeInteger
	XmlSchemaSimpleType_t1597467585 * ___XsNegativeInteger_47;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsLong
	XmlSchemaSimpleType_t1597467585 * ___XsLong_48;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsInt
	XmlSchemaSimpleType_t1597467585 * ___XsInt_49;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsShort
	XmlSchemaSimpleType_t1597467585 * ___XsShort_50;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsByte
	XmlSchemaSimpleType_t1597467585 * ___XsByte_51;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsNonNegativeInteger
	XmlSchemaSimpleType_t1597467585 * ___XsNonNegativeInteger_52;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsUnsignedLong
	XmlSchemaSimpleType_t1597467585 * ___XsUnsignedLong_53;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsUnsignedInt
	XmlSchemaSimpleType_t1597467585 * ___XsUnsignedInt_54;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsUnsignedShort
	XmlSchemaSimpleType_t1597467585 * ___XsUnsignedShort_55;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsUnsignedByte
	XmlSchemaSimpleType_t1597467585 * ___XsUnsignedByte_56;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XsPositiveInteger
	XmlSchemaSimpleType_t1597467585 * ___XsPositiveInteger_57;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XdtUntypedAtomic
	XmlSchemaSimpleType_t1597467585 * ___XdtUntypedAtomic_58;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XdtAnyAtomicType
	XmlSchemaSimpleType_t1597467585 * ___XdtAnyAtomicType_59;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XdtYearMonthDuration
	XmlSchemaSimpleType_t1597467585 * ___XdtYearMonthDuration_60;
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleType::XdtDayTimeDuration
	XmlSchemaSimpleType_t1597467585 * ___XdtDayTimeDuration_61;

public:
	inline static int32_t get_offset_of_schemaLocationType_9() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___schemaLocationType_9)); }
	inline XmlSchemaSimpleType_t1597467585 * get_schemaLocationType_9() const { return ___schemaLocationType_9; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_schemaLocationType_9() { return &___schemaLocationType_9; }
	inline void set_schemaLocationType_9(XmlSchemaSimpleType_t1597467585 * value)
	{
		___schemaLocationType_9 = value;
		Il2CppCodeGenWriteBarrier((&___schemaLocationType_9), value);
	}

	inline static int32_t get_offset_of_XsAnySimpleType_13() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsAnySimpleType_13)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsAnySimpleType_13() const { return ___XsAnySimpleType_13; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsAnySimpleType_13() { return &___XsAnySimpleType_13; }
	inline void set_XsAnySimpleType_13(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsAnySimpleType_13 = value;
		Il2CppCodeGenWriteBarrier((&___XsAnySimpleType_13), value);
	}

	inline static int32_t get_offset_of_XsString_14() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsString_14)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsString_14() const { return ___XsString_14; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsString_14() { return &___XsString_14; }
	inline void set_XsString_14(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsString_14 = value;
		Il2CppCodeGenWriteBarrier((&___XsString_14), value);
	}

	inline static int32_t get_offset_of_XsBoolean_15() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsBoolean_15)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsBoolean_15() const { return ___XsBoolean_15; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsBoolean_15() { return &___XsBoolean_15; }
	inline void set_XsBoolean_15(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsBoolean_15 = value;
		Il2CppCodeGenWriteBarrier((&___XsBoolean_15), value);
	}

	inline static int32_t get_offset_of_XsDecimal_16() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsDecimal_16)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsDecimal_16() const { return ___XsDecimal_16; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsDecimal_16() { return &___XsDecimal_16; }
	inline void set_XsDecimal_16(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsDecimal_16 = value;
		Il2CppCodeGenWriteBarrier((&___XsDecimal_16), value);
	}

	inline static int32_t get_offset_of_XsFloat_17() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsFloat_17)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsFloat_17() const { return ___XsFloat_17; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsFloat_17() { return &___XsFloat_17; }
	inline void set_XsFloat_17(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsFloat_17 = value;
		Il2CppCodeGenWriteBarrier((&___XsFloat_17), value);
	}

	inline static int32_t get_offset_of_XsDouble_18() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsDouble_18)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsDouble_18() const { return ___XsDouble_18; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsDouble_18() { return &___XsDouble_18; }
	inline void set_XsDouble_18(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsDouble_18 = value;
		Il2CppCodeGenWriteBarrier((&___XsDouble_18), value);
	}

	inline static int32_t get_offset_of_XsDuration_19() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsDuration_19)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsDuration_19() const { return ___XsDuration_19; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsDuration_19() { return &___XsDuration_19; }
	inline void set_XsDuration_19(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsDuration_19 = value;
		Il2CppCodeGenWriteBarrier((&___XsDuration_19), value);
	}

	inline static int32_t get_offset_of_XsDateTime_20() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsDateTime_20)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsDateTime_20() const { return ___XsDateTime_20; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsDateTime_20() { return &___XsDateTime_20; }
	inline void set_XsDateTime_20(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsDateTime_20 = value;
		Il2CppCodeGenWriteBarrier((&___XsDateTime_20), value);
	}

	inline static int32_t get_offset_of_XsTime_21() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsTime_21)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsTime_21() const { return ___XsTime_21; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsTime_21() { return &___XsTime_21; }
	inline void set_XsTime_21(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsTime_21 = value;
		Il2CppCodeGenWriteBarrier((&___XsTime_21), value);
	}

	inline static int32_t get_offset_of_XsDate_22() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsDate_22)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsDate_22() const { return ___XsDate_22; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsDate_22() { return &___XsDate_22; }
	inline void set_XsDate_22(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsDate_22 = value;
		Il2CppCodeGenWriteBarrier((&___XsDate_22), value);
	}

	inline static int32_t get_offset_of_XsGYearMonth_23() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsGYearMonth_23)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsGYearMonth_23() const { return ___XsGYearMonth_23; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsGYearMonth_23() { return &___XsGYearMonth_23; }
	inline void set_XsGYearMonth_23(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsGYearMonth_23 = value;
		Il2CppCodeGenWriteBarrier((&___XsGYearMonth_23), value);
	}

	inline static int32_t get_offset_of_XsGYear_24() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsGYear_24)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsGYear_24() const { return ___XsGYear_24; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsGYear_24() { return &___XsGYear_24; }
	inline void set_XsGYear_24(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsGYear_24 = value;
		Il2CppCodeGenWriteBarrier((&___XsGYear_24), value);
	}

	inline static int32_t get_offset_of_XsGMonthDay_25() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsGMonthDay_25)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsGMonthDay_25() const { return ___XsGMonthDay_25; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsGMonthDay_25() { return &___XsGMonthDay_25; }
	inline void set_XsGMonthDay_25(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsGMonthDay_25 = value;
		Il2CppCodeGenWriteBarrier((&___XsGMonthDay_25), value);
	}

	inline static int32_t get_offset_of_XsGDay_26() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsGDay_26)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsGDay_26() const { return ___XsGDay_26; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsGDay_26() { return &___XsGDay_26; }
	inline void set_XsGDay_26(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsGDay_26 = value;
		Il2CppCodeGenWriteBarrier((&___XsGDay_26), value);
	}

	inline static int32_t get_offset_of_XsGMonth_27() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsGMonth_27)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsGMonth_27() const { return ___XsGMonth_27; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsGMonth_27() { return &___XsGMonth_27; }
	inline void set_XsGMonth_27(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsGMonth_27 = value;
		Il2CppCodeGenWriteBarrier((&___XsGMonth_27), value);
	}

	inline static int32_t get_offset_of_XsHexBinary_28() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsHexBinary_28)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsHexBinary_28() const { return ___XsHexBinary_28; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsHexBinary_28() { return &___XsHexBinary_28; }
	inline void set_XsHexBinary_28(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsHexBinary_28 = value;
		Il2CppCodeGenWriteBarrier((&___XsHexBinary_28), value);
	}

	inline static int32_t get_offset_of_XsBase64Binary_29() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsBase64Binary_29)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsBase64Binary_29() const { return ___XsBase64Binary_29; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsBase64Binary_29() { return &___XsBase64Binary_29; }
	inline void set_XsBase64Binary_29(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsBase64Binary_29 = value;
		Il2CppCodeGenWriteBarrier((&___XsBase64Binary_29), value);
	}

	inline static int32_t get_offset_of_XsAnyUri_30() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsAnyUri_30)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsAnyUri_30() const { return ___XsAnyUri_30; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsAnyUri_30() { return &___XsAnyUri_30; }
	inline void set_XsAnyUri_30(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsAnyUri_30 = value;
		Il2CppCodeGenWriteBarrier((&___XsAnyUri_30), value);
	}

	inline static int32_t get_offset_of_XsQName_31() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsQName_31)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsQName_31() const { return ___XsQName_31; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsQName_31() { return &___XsQName_31; }
	inline void set_XsQName_31(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsQName_31 = value;
		Il2CppCodeGenWriteBarrier((&___XsQName_31), value);
	}

	inline static int32_t get_offset_of_XsNotation_32() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNotation_32)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNotation_32() const { return ___XsNotation_32; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNotation_32() { return &___XsNotation_32; }
	inline void set_XsNotation_32(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNotation_32 = value;
		Il2CppCodeGenWriteBarrier((&___XsNotation_32), value);
	}

	inline static int32_t get_offset_of_XsNormalizedString_33() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNormalizedString_33)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNormalizedString_33() const { return ___XsNormalizedString_33; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNormalizedString_33() { return &___XsNormalizedString_33; }
	inline void set_XsNormalizedString_33(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNormalizedString_33 = value;
		Il2CppCodeGenWriteBarrier((&___XsNormalizedString_33), value);
	}

	inline static int32_t get_offset_of_XsToken_34() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsToken_34)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsToken_34() const { return ___XsToken_34; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsToken_34() { return &___XsToken_34; }
	inline void set_XsToken_34(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsToken_34 = value;
		Il2CppCodeGenWriteBarrier((&___XsToken_34), value);
	}

	inline static int32_t get_offset_of_XsLanguage_35() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsLanguage_35)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsLanguage_35() const { return ___XsLanguage_35; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsLanguage_35() { return &___XsLanguage_35; }
	inline void set_XsLanguage_35(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsLanguage_35 = value;
		Il2CppCodeGenWriteBarrier((&___XsLanguage_35), value);
	}

	inline static int32_t get_offset_of_XsNMToken_36() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNMToken_36)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNMToken_36() const { return ___XsNMToken_36; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNMToken_36() { return &___XsNMToken_36; }
	inline void set_XsNMToken_36(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNMToken_36 = value;
		Il2CppCodeGenWriteBarrier((&___XsNMToken_36), value);
	}

	inline static int32_t get_offset_of_XsNMTokens_37() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNMTokens_37)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNMTokens_37() const { return ___XsNMTokens_37; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNMTokens_37() { return &___XsNMTokens_37; }
	inline void set_XsNMTokens_37(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNMTokens_37 = value;
		Il2CppCodeGenWriteBarrier((&___XsNMTokens_37), value);
	}

	inline static int32_t get_offset_of_XsName_38() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsName_38)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsName_38() const { return ___XsName_38; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsName_38() { return &___XsName_38; }
	inline void set_XsName_38(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsName_38 = value;
		Il2CppCodeGenWriteBarrier((&___XsName_38), value);
	}

	inline static int32_t get_offset_of_XsNCName_39() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNCName_39)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNCName_39() const { return ___XsNCName_39; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNCName_39() { return &___XsNCName_39; }
	inline void set_XsNCName_39(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNCName_39 = value;
		Il2CppCodeGenWriteBarrier((&___XsNCName_39), value);
	}

	inline static int32_t get_offset_of_XsID_40() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsID_40)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsID_40() const { return ___XsID_40; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsID_40() { return &___XsID_40; }
	inline void set_XsID_40(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsID_40 = value;
		Il2CppCodeGenWriteBarrier((&___XsID_40), value);
	}

	inline static int32_t get_offset_of_XsIDRef_41() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsIDRef_41)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsIDRef_41() const { return ___XsIDRef_41; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsIDRef_41() { return &___XsIDRef_41; }
	inline void set_XsIDRef_41(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsIDRef_41 = value;
		Il2CppCodeGenWriteBarrier((&___XsIDRef_41), value);
	}

	inline static int32_t get_offset_of_XsIDRefs_42() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsIDRefs_42)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsIDRefs_42() const { return ___XsIDRefs_42; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsIDRefs_42() { return &___XsIDRefs_42; }
	inline void set_XsIDRefs_42(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsIDRefs_42 = value;
		Il2CppCodeGenWriteBarrier((&___XsIDRefs_42), value);
	}

	inline static int32_t get_offset_of_XsEntity_43() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsEntity_43)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsEntity_43() const { return ___XsEntity_43; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsEntity_43() { return &___XsEntity_43; }
	inline void set_XsEntity_43(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsEntity_43 = value;
		Il2CppCodeGenWriteBarrier((&___XsEntity_43), value);
	}

	inline static int32_t get_offset_of_XsEntities_44() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsEntities_44)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsEntities_44() const { return ___XsEntities_44; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsEntities_44() { return &___XsEntities_44; }
	inline void set_XsEntities_44(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsEntities_44 = value;
		Il2CppCodeGenWriteBarrier((&___XsEntities_44), value);
	}

	inline static int32_t get_offset_of_XsInteger_45() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsInteger_45)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsInteger_45() const { return ___XsInteger_45; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsInteger_45() { return &___XsInteger_45; }
	inline void set_XsInteger_45(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsInteger_45 = value;
		Il2CppCodeGenWriteBarrier((&___XsInteger_45), value);
	}

	inline static int32_t get_offset_of_XsNonPositiveInteger_46() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNonPositiveInteger_46)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNonPositiveInteger_46() const { return ___XsNonPositiveInteger_46; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNonPositiveInteger_46() { return &___XsNonPositiveInteger_46; }
	inline void set_XsNonPositiveInteger_46(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNonPositiveInteger_46 = value;
		Il2CppCodeGenWriteBarrier((&___XsNonPositiveInteger_46), value);
	}

	inline static int32_t get_offset_of_XsNegativeInteger_47() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNegativeInteger_47)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNegativeInteger_47() const { return ___XsNegativeInteger_47; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNegativeInteger_47() { return &___XsNegativeInteger_47; }
	inline void set_XsNegativeInteger_47(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNegativeInteger_47 = value;
		Il2CppCodeGenWriteBarrier((&___XsNegativeInteger_47), value);
	}

	inline static int32_t get_offset_of_XsLong_48() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsLong_48)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsLong_48() const { return ___XsLong_48; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsLong_48() { return &___XsLong_48; }
	inline void set_XsLong_48(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsLong_48 = value;
		Il2CppCodeGenWriteBarrier((&___XsLong_48), value);
	}

	inline static int32_t get_offset_of_XsInt_49() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsInt_49)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsInt_49() const { return ___XsInt_49; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsInt_49() { return &___XsInt_49; }
	inline void set_XsInt_49(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsInt_49 = value;
		Il2CppCodeGenWriteBarrier((&___XsInt_49), value);
	}

	inline static int32_t get_offset_of_XsShort_50() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsShort_50)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsShort_50() const { return ___XsShort_50; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsShort_50() { return &___XsShort_50; }
	inline void set_XsShort_50(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsShort_50 = value;
		Il2CppCodeGenWriteBarrier((&___XsShort_50), value);
	}

	inline static int32_t get_offset_of_XsByte_51() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsByte_51)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsByte_51() const { return ___XsByte_51; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsByte_51() { return &___XsByte_51; }
	inline void set_XsByte_51(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsByte_51 = value;
		Il2CppCodeGenWriteBarrier((&___XsByte_51), value);
	}

	inline static int32_t get_offset_of_XsNonNegativeInteger_52() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsNonNegativeInteger_52)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsNonNegativeInteger_52() const { return ___XsNonNegativeInteger_52; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsNonNegativeInteger_52() { return &___XsNonNegativeInteger_52; }
	inline void set_XsNonNegativeInteger_52(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsNonNegativeInteger_52 = value;
		Il2CppCodeGenWriteBarrier((&___XsNonNegativeInteger_52), value);
	}

	inline static int32_t get_offset_of_XsUnsignedLong_53() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsUnsignedLong_53)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsUnsignedLong_53() const { return ___XsUnsignedLong_53; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsUnsignedLong_53() { return &___XsUnsignedLong_53; }
	inline void set_XsUnsignedLong_53(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsUnsignedLong_53 = value;
		Il2CppCodeGenWriteBarrier((&___XsUnsignedLong_53), value);
	}

	inline static int32_t get_offset_of_XsUnsignedInt_54() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsUnsignedInt_54)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsUnsignedInt_54() const { return ___XsUnsignedInt_54; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsUnsignedInt_54() { return &___XsUnsignedInt_54; }
	inline void set_XsUnsignedInt_54(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsUnsignedInt_54 = value;
		Il2CppCodeGenWriteBarrier((&___XsUnsignedInt_54), value);
	}

	inline static int32_t get_offset_of_XsUnsignedShort_55() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsUnsignedShort_55)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsUnsignedShort_55() const { return ___XsUnsignedShort_55; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsUnsignedShort_55() { return &___XsUnsignedShort_55; }
	inline void set_XsUnsignedShort_55(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsUnsignedShort_55 = value;
		Il2CppCodeGenWriteBarrier((&___XsUnsignedShort_55), value);
	}

	inline static int32_t get_offset_of_XsUnsignedByte_56() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsUnsignedByte_56)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsUnsignedByte_56() const { return ___XsUnsignedByte_56; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsUnsignedByte_56() { return &___XsUnsignedByte_56; }
	inline void set_XsUnsignedByte_56(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsUnsignedByte_56 = value;
		Il2CppCodeGenWriteBarrier((&___XsUnsignedByte_56), value);
	}

	inline static int32_t get_offset_of_XsPositiveInteger_57() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XsPositiveInteger_57)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XsPositiveInteger_57() const { return ___XsPositiveInteger_57; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XsPositiveInteger_57() { return &___XsPositiveInteger_57; }
	inline void set_XsPositiveInteger_57(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XsPositiveInteger_57 = value;
		Il2CppCodeGenWriteBarrier((&___XsPositiveInteger_57), value);
	}

	inline static int32_t get_offset_of_XdtUntypedAtomic_58() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XdtUntypedAtomic_58)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XdtUntypedAtomic_58() const { return ___XdtUntypedAtomic_58; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XdtUntypedAtomic_58() { return &___XdtUntypedAtomic_58; }
	inline void set_XdtUntypedAtomic_58(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XdtUntypedAtomic_58 = value;
		Il2CppCodeGenWriteBarrier((&___XdtUntypedAtomic_58), value);
	}

	inline static int32_t get_offset_of_XdtAnyAtomicType_59() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XdtAnyAtomicType_59)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XdtAnyAtomicType_59() const { return ___XdtAnyAtomicType_59; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XdtAnyAtomicType_59() { return &___XdtAnyAtomicType_59; }
	inline void set_XdtAnyAtomicType_59(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XdtAnyAtomicType_59 = value;
		Il2CppCodeGenWriteBarrier((&___XdtAnyAtomicType_59), value);
	}

	inline static int32_t get_offset_of_XdtYearMonthDuration_60() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XdtYearMonthDuration_60)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XdtYearMonthDuration_60() const { return ___XdtYearMonthDuration_60; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XdtYearMonthDuration_60() { return &___XdtYearMonthDuration_60; }
	inline void set_XdtYearMonthDuration_60(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XdtYearMonthDuration_60 = value;
		Il2CppCodeGenWriteBarrier((&___XdtYearMonthDuration_60), value);
	}

	inline static int32_t get_offset_of_XdtDayTimeDuration_61() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleType_t1597467585_StaticFields, ___XdtDayTimeDuration_61)); }
	inline XmlSchemaSimpleType_t1597467585 * get_XdtDayTimeDuration_61() const { return ___XdtDayTimeDuration_61; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_XdtDayTimeDuration_61() { return &___XdtDayTimeDuration_61; }
	inline void set_XdtDayTimeDuration_61(XmlSchemaSimpleType_t1597467585 * value)
	{
		___XdtDayTimeDuration_61 = value;
		Il2CppCodeGenWriteBarrier((&___XdtDayTimeDuration_61), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASIMPLETYPE_T1597467585_H
#ifndef XMLSCHEMASIMPLETYPELIST_T3026176917_H
#define XMLSCHEMASIMPLETYPELIST_T3026176917_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSimpleTypeList
struct  XmlSchemaSimpleTypeList_t3026176917  : public XmlSchemaSimpleTypeContent_t554989856
{
public:
	// System.Xml.Schema.XmlSchemaSimpleType System.Xml.Schema.XmlSchemaSimpleTypeList::itemType
	XmlSchemaSimpleType_t1597467585 * ___itemType_3;
	// System.Xml.XmlQualifiedName System.Xml.Schema.XmlSchemaSimpleTypeList::itemTypeName
	XmlQualifiedName_t2861843702 * ___itemTypeName_4;

public:
	inline static int32_t get_offset_of_itemType_3() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleTypeList_t3026176917, ___itemType_3)); }
	inline XmlSchemaSimpleType_t1597467585 * get_itemType_3() const { return ___itemType_3; }
	inline XmlSchemaSimpleType_t1597467585 ** get_address_of_itemType_3() { return &___itemType_3; }
	inline void set_itemType_3(XmlSchemaSimpleType_t1597467585 * value)
	{
		___itemType_3 = value;
		Il2CppCodeGenWriteBarrier((&___itemType_3), value);
	}

	inline static int32_t get_offset_of_itemTypeName_4() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleTypeList_t3026176917, ___itemTypeName_4)); }
	inline XmlQualifiedName_t2861843702 * get_itemTypeName_4() const { return ___itemTypeName_4; }
	inline XmlQualifiedName_t2861843702 ** get_address_of_itemTypeName_4() { return &___itemTypeName_4; }
	inline void set_itemTypeName_4(XmlQualifiedName_t2861843702 * value)
	{
		___itemTypeName_4 = value;
		Il2CppCodeGenWriteBarrier((&___itemTypeName_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASIMPLETYPELIST_T3026176917_H
#ifndef XSDTIME_T194014253_H
#define XSDTIME_T194014253_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdTime
struct  XsdTime_t194014253  : public XsdAnySimpleType_t1645894131
{
public:

public:
};

struct XsdTime_t194014253_StaticFields
{
public:
	// System.String[] Mono.Xml.Schema.XsdTime::timeFormats
	StringU5BU5D_t4199878655* ___timeFormats_61;

public:
	inline static int32_t get_offset_of_timeFormats_61() { return static_cast<int32_t>(offsetof(XsdTime_t194014253_StaticFields, ___timeFormats_61)); }
	inline StringU5BU5D_t4199878655* get_timeFormats_61() const { return ___timeFormats_61; }
	inline StringU5BU5D_t4199878655** get_address_of_timeFormats_61() { return &___timeFormats_61; }
	inline void set_timeFormats_61(StringU5BU5D_t4199878655* value)
	{
		___timeFormats_61 = value;
		Il2CppCodeGenWriteBarrier((&___timeFormats_61), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDTIME_T194014253_H
#ifndef XMLSCHEMASIMPLETYPERESTRICTION_T1399347856_H
#define XMLSCHEMASIMPLETYPERESTRICTION_T1399347856_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Xml.Schema.XmlSchemaSimpleTypeRestriction
struct  XmlSchemaSimpleTypeRestriction_t1399347856  : public XmlSchemaSimpleTypeContent_t554989856
{
public:

public:
};

struct XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields
{
public:
	// System.Globalization.NumberStyles System.Xml.Schema.XmlSchemaSimpleTypeRestriction::lengthStyle
	int32_t ___lengthStyle_3;
	// System.Xml.Schema.XmlSchemaFacet/Facet System.Xml.Schema.XmlSchemaSimpleTypeRestriction::listFacets
	int32_t ___listFacets_4;

public:
	inline static int32_t get_offset_of_lengthStyle_3() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields, ___lengthStyle_3)); }
	inline int32_t get_lengthStyle_3() const { return ___lengthStyle_3; }
	inline int32_t* get_address_of_lengthStyle_3() { return &___lengthStyle_3; }
	inline void set_lengthStyle_3(int32_t value)
	{
		___lengthStyle_3 = value;
	}

	inline static int32_t get_offset_of_listFacets_4() { return static_cast<int32_t>(offsetof(XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields, ___listFacets_4)); }
	inline int32_t get_listFacets_4() const { return ___listFacets_4; }
	inline int32_t* get_address_of_listFacets_4() { return &___listFacets_4; }
	inline void set_listFacets_4(int32_t value)
	{
		___listFacets_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XMLSCHEMASIMPLETYPERESTRICTION_T1399347856_H
#ifndef XSDNORMALIZEDSTRING_T1600426378_H
#define XSDNORMALIZEDSTRING_T1600426378_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdNormalizedString
struct  XsdNormalizedString_t1600426378  : public XsdString_t3808583524
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDNORMALIZEDSTRING_T1600426378_H
#ifndef XDTYEARMONTHDURATION_T673549898_H
#define XDTYEARMONTHDURATION_T673549898_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XdtYearMonthDuration
struct  XdtYearMonthDuration_t673549898  : public XsdDuration_t4216890283
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XDTYEARMONTHDURATION_T673549898_H
#ifndef XDTDAYTIMEDURATION_T597694552_H
#define XDTDAYTIMEDURATION_T597694552_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XdtDayTimeDuration
struct  XdtDayTimeDuration_t597694552  : public XsdDuration_t4216890283
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XDTDAYTIMEDURATION_T597694552_H
#ifndef XSDANYURI_T1696333635_H
#define XSDANYURI_T1696333635_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdAnyURI
struct  XsdAnyURI_t1696333635  : public XsdString_t3808583524
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDANYURI_T1696333635_H
#ifndef XSDBASE64BINARY_T1793769650_H
#define XSDBASE64BINARY_T1793769650_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdBase64Binary
struct  XsdBase64Binary_t1793769650  : public XsdString_t3808583524
{
public:

public:
};

struct XsdBase64Binary_t1793769650_StaticFields
{
public:
	// System.String Mono.Xml.Schema.XsdBase64Binary::ALPHABET
	String_t* ___ALPHABET_61;
	// System.Byte[] Mono.Xml.Schema.XsdBase64Binary::decodeTable
	ByteU5BU5D_t2643433246* ___decodeTable_62;

public:
	inline static int32_t get_offset_of_ALPHABET_61() { return static_cast<int32_t>(offsetof(XsdBase64Binary_t1793769650_StaticFields, ___ALPHABET_61)); }
	inline String_t* get_ALPHABET_61() const { return ___ALPHABET_61; }
	inline String_t** get_address_of_ALPHABET_61() { return &___ALPHABET_61; }
	inline void set_ALPHABET_61(String_t* value)
	{
		___ALPHABET_61 = value;
		Il2CppCodeGenWriteBarrier((&___ALPHABET_61), value);
	}

	inline static int32_t get_offset_of_decodeTable_62() { return static_cast<int32_t>(offsetof(XsdBase64Binary_t1793769650_StaticFields, ___decodeTable_62)); }
	inline ByteU5BU5D_t2643433246* get_decodeTable_62() const { return ___decodeTable_62; }
	inline ByteU5BU5D_t2643433246** get_address_of_decodeTable_62() { return &___decodeTable_62; }
	inline void set_decodeTable_62(ByteU5BU5D_t2643433246* value)
	{
		___decodeTable_62 = value;
		Il2CppCodeGenWriteBarrier((&___decodeTable_62), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDBASE64BINARY_T1793769650_H
#ifndef XSDINTEGER_T1726820563_H
#define XSDINTEGER_T1726820563_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdInteger
struct  XsdInteger_t1726820563  : public XsdDecimal_t3796307291
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDINTEGER_T1726820563_H
#ifndef XSDTOKEN_T508248724_H
#define XSDTOKEN_T508248724_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdToken
struct  XsdToken_t508248724  : public XsdNormalizedString_t1600426378
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDTOKEN_T508248724_H
#ifndef XSDNONNEGATIVEINTEGER_T2518569928_H
#define XSDNONNEGATIVEINTEGER_T2518569928_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdNonNegativeInteger
struct  XsdNonNegativeInteger_t2518569928  : public XsdInteger_t1726820563
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDNONNEGATIVEINTEGER_T2518569928_H
#ifndef XSDLONG_T1719775717_H
#define XSDLONG_T1719775717_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdLong
struct  XsdLong_t1719775717  : public XsdInteger_t1726820563
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDLONG_T1719775717_H
#ifndef XSDNONPOSITIVEINTEGER_T654673514_H
#define XSDNONPOSITIVEINTEGER_T654673514_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdNonPositiveInteger
struct  XsdNonPositiveInteger_t654673514  : public XsdInteger_t1726820563
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDNONPOSITIVEINTEGER_T654673514_H
#ifndef XSDPOSITIVEINTEGER_T858890625_H
#define XSDPOSITIVEINTEGER_T858890625_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdPositiveInteger
struct  XsdPositiveInteger_t858890625  : public XsdNonNegativeInteger_t2518569928
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDPOSITIVEINTEGER_T858890625_H
#ifndef XSDNEGATIVEINTEGER_T145731310_H
#define XSDNEGATIVEINTEGER_T145731310_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdNegativeInteger
struct  XsdNegativeInteger_t145731310  : public XsdNonPositiveInteger_t654673514
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDNEGATIVEINTEGER_T145731310_H
#ifndef XSDUNSIGNEDLONG_T3088213186_H
#define XSDUNSIGNEDLONG_T3088213186_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdUnsignedLong
struct  XsdUnsignedLong_t3088213186  : public XsdNonNegativeInteger_t2518569928
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDUNSIGNEDLONG_T3088213186_H
#ifndef XSDINT_T4031406130_H
#define XSDINT_T4031406130_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdInt
struct  XsdInt_t4031406130  : public XsdLong_t1719775717
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDINT_T4031406130_H
#ifndef XSDNAME_T2809458942_H
#define XSDNAME_T2809458942_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdName
struct  XsdName_t2809458942  : public XsdToken_t508248724
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDNAME_T2809458942_H
#ifndef XSDUNSIGNEDINT_T1345788448_H
#define XSDUNSIGNEDINT_T1345788448_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdUnsignedInt
struct  XsdUnsignedInt_t1345788448  : public XsdUnsignedLong_t3088213186
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDUNSIGNEDINT_T1345788448_H
#ifndef XSDQNAME_T2375427330_H
#define XSDQNAME_T2375427330_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdQName
struct  XsdQName_t2375427330  : public XsdName_t2809458942
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDQNAME_T2375427330_H
#ifndef XSDSHORT_T1466004108_H
#define XSDSHORT_T1466004108_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdShort
struct  XsdShort_t1466004108  : public XsdInt_t4031406130
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDSHORT_T1466004108_H
#ifndef XSDUNSIGNEDSHORT_T3040059537_H
#define XSDUNSIGNEDSHORT_T3040059537_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdUnsignedShort
struct  XsdUnsignedShort_t3040059537  : public XsdUnsignedInt_t1345788448
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDUNSIGNEDSHORT_T3040059537_H
#ifndef XSDBYTE_T2834617523_H
#define XSDBYTE_T2834617523_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdByte
struct  XsdByte_t2834617523  : public XsdShort_t1466004108
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDBYTE_T2834617523_H
#ifndef XSDUNSIGNEDBYTE_T1503500326_H
#define XSDUNSIGNEDBYTE_T1503500326_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Mono.Xml.Schema.XsdUnsignedByte
struct  XsdUnsignedByte_t1503500326  : public XsdUnsignedShort_t3040059537
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XSDUNSIGNEDBYTE_T1503500326_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1700 = { sizeof (XsdLong_t1719775717), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1701 = { sizeof (XsdInt_t4031406130), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1702 = { sizeof (XsdShort_t1466004108), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1703 = { sizeof (XsdByte_t2834617523), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1704 = { sizeof (XsdNonNegativeInteger_t2518569928), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1705 = { sizeof (XsdUnsignedLong_t3088213186), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1706 = { sizeof (XsdUnsignedInt_t1345788448), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1707 = { sizeof (XsdUnsignedShort_t3040059537), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1708 = { sizeof (XsdUnsignedByte_t1503500326), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1709 = { sizeof (XsdPositiveInteger_t858890625), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1710 = { sizeof (XsdNonPositiveInteger_t654673514), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1711 = { sizeof (XsdNegativeInteger_t145731310), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1712 = { sizeof (XsdFloat_t2432376376), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1713 = { sizeof (XsdDouble_t2405104440), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1714 = { sizeof (XsdBase64Binary_t1793769650), -1, sizeof(XsdBase64Binary_t1793769650_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1714[2] = 
{
	XsdBase64Binary_t1793769650_StaticFields::get_offset_of_ALPHABET_61(),
	XsdBase64Binary_t1793769650_StaticFields::get_offset_of_decodeTable_62(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1715 = { sizeof (XsdHexBinary_t309962759), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1716 = { sizeof (XsdQName_t2375427330), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1717 = { sizeof (XsdBoolean_t747919005), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1718 = { sizeof (XsdAnyURI_t1696333635), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1719 = { sizeof (XsdDuration_t4216890283), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1720 = { sizeof (XdtDayTimeDuration_t597694552), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1721 = { sizeof (XdtYearMonthDuration_t673549898), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1722 = { sizeof (XsdDateTime_t2878826493), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1723 = { sizeof (XsdDate_t84799097), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1724 = { sizeof (XsdTime_t194014253), -1, sizeof(XsdTime_t194014253_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1724[1] = 
{
	XsdTime_t194014253_StaticFields::get_offset_of_timeFormats_61(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1725 = { sizeof (XsdGYearMonth_t4060942859), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1726 = { sizeof (XsdGMonthDay_t1849750074), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1727 = { sizeof (XsdGYear_t1626334498), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1728 = { sizeof (XsdGMonth_t1559631661), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1729 = { sizeof (XsdGDay_t1637325925), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1730 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1731 = { sizeof (XmlSchemaAnnotated_t791701952), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1732 = { sizeof (XmlSchemaAttribute_t569796853), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1733 = { sizeof (XmlSchemaCompilationSettings_t2801413820), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1733[1] = 
{
	XmlSchemaCompilationSettings_t2801413820::get_offset_of_enable_upa_check_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1734 = { sizeof (XmlSchemaDatatype_t2974024598), -1, sizeof(XmlSchemaDatatype_t2974024598_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1734[55] = 
{
	XmlSchemaDatatype_t2974024598::get_offset_of_WhitespaceValue_0(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_wsChars_1(),
	XmlSchemaDatatype_t2974024598::get_offset_of_sb_2(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeAnySimpleType_3(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeString_4(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNormalizedString_5(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeToken_6(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeLanguage_7(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNMToken_8(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNMTokens_9(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeName_10(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNCName_11(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeID_12(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeIDRef_13(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeIDRefs_14(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeEntity_15(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeEntities_16(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNotation_17(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDecimal_18(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeInteger_19(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeLong_20(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeInt_21(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeShort_22(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeByte_23(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNonNegativeInteger_24(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypePositiveInteger_25(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeUnsignedLong_26(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeUnsignedInt_27(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeUnsignedShort_28(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeUnsignedByte_29(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNonPositiveInteger_30(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeNegativeInteger_31(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeFloat_32(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDouble_33(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeBase64Binary_34(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeBoolean_35(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeAnyURI_36(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDuration_37(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDateTime_38(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDate_39(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeTime_40(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeHexBinary_41(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeQName_42(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeGYearMonth_43(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeGMonthDay_44(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeGYear_45(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeGMonth_46(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeGDay_47(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeAnyAtomicType_48(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeUntypedAtomic_49(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeDayTimeDuration_50(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_datatypeYearMonthDuration_51(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_U3CU3Ef__switchU24map2A_52(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_U3CU3Ef__switchU24map2B_53(),
	XmlSchemaDatatype_t2974024598_StaticFields::get_offset_of_U3CU3Ef__switchU24map2C_54(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1735 = { sizeof (XmlSchemaDerivationMethod_t791382393)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1735[9] = 
{
	XmlSchemaDerivationMethod_t791382393::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1736 = { sizeof (XmlSchemaElement_t2407988793), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1737 = { sizeof (XmlSchemaFacet_t1439609014), -1, sizeof(XmlSchemaFacet_t1439609014_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1737[1] = 
{
	XmlSchemaFacet_t1439609014_StaticFields::get_offset_of_AllFacets_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1738 = { sizeof (Facet_t1736138037)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1738[14] = 
{
	Facet_t1736138037::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1739 = { sizeof (XmlSchemaInfo_t1285312624), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1739[7] = 
{
	XmlSchemaInfo_t1285312624::get_offset_of_isDefault_0(),
	XmlSchemaInfo_t1285312624::get_offset_of_isNil_1(),
	XmlSchemaInfo_t1285312624::get_offset_of_memberType_2(),
	XmlSchemaInfo_t1285312624::get_offset_of_attr_3(),
	XmlSchemaInfo_t1285312624::get_offset_of_elem_4(),
	XmlSchemaInfo_t1285312624::get_offset_of_type_5(),
	XmlSchemaInfo_t1285312624::get_offset_of_validity_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1740 = { sizeof (XmlSchemaObject_t3227566618), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1740[3] = 
{
	XmlSchemaObject_t3227566618::get_offset_of_namespaces_0(),
	XmlSchemaObject_t3227566618::get_offset_of_unhandledAttributeList_1(),
	XmlSchemaObject_t3227566618::get_offset_of_CompilationId_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1741 = { sizeof (XmlSchemaParticle_t1280135901), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1742 = { sizeof (XmlSchemaSet_t410947004), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1742[5] = 
{
	XmlSchemaSet_t410947004::get_offset_of_nameTable_0(),
	XmlSchemaSet_t410947004::get_offset_of_xmlResolver_1(),
	XmlSchemaSet_t410947004::get_offset_of_schemas_2(),
	XmlSchemaSet_t410947004::get_offset_of_settings_3(),
	XmlSchemaSet_t410947004::get_offset_of_CompilationId_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1743 = { sizeof (XmlSchemaSimpleType_t1597467585), -1, sizeof(XmlSchemaSimpleType_t1597467585_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1743[53] = 
{
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_schemaLocationType_9(),
	XmlSchemaSimpleType_t1597467585::get_offset_of_content_10(),
	XmlSchemaSimpleType_t1597467585::get_offset_of_islocal_11(),
	XmlSchemaSimpleType_t1597467585::get_offset_of_variety_12(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsAnySimpleType_13(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsString_14(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsBoolean_15(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsDecimal_16(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsFloat_17(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsDouble_18(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsDuration_19(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsDateTime_20(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsTime_21(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsDate_22(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsGYearMonth_23(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsGYear_24(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsGMonthDay_25(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsGDay_26(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsGMonth_27(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsHexBinary_28(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsBase64Binary_29(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsAnyUri_30(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsQName_31(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNotation_32(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNormalizedString_33(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsToken_34(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsLanguage_35(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNMToken_36(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNMTokens_37(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsName_38(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNCName_39(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsID_40(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsIDRef_41(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsIDRefs_42(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsEntity_43(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsEntities_44(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsInteger_45(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNonPositiveInteger_46(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNegativeInteger_47(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsLong_48(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsInt_49(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsShort_50(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsByte_51(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsNonNegativeInteger_52(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsUnsignedLong_53(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsUnsignedInt_54(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsUnsignedShort_55(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsUnsignedByte_56(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XsPositiveInteger_57(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XdtUntypedAtomic_58(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XdtAnyAtomicType_59(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XdtYearMonthDuration_60(),
	XmlSchemaSimpleType_t1597467585_StaticFields::get_offset_of_XdtDayTimeDuration_61(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1744 = { sizeof (XmlSchemaSimpleTypeContent_t554989856), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1745 = { sizeof (XmlSchemaSimpleTypeList_t3026176917), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1745[2] = 
{
	XmlSchemaSimpleTypeList_t3026176917::get_offset_of_itemType_3(),
	XmlSchemaSimpleTypeList_t3026176917::get_offset_of_itemTypeName_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1746 = { sizeof (XmlSchemaSimpleTypeRestriction_t1399347856), -1, sizeof(XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1746[2] = 
{
	XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields::get_offset_of_lengthStyle_3(),
	XmlSchemaSimpleTypeRestriction_t1399347856_StaticFields::get_offset_of_listFacets_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1747 = { sizeof (XmlSchemaSimpleTypeUnion_t2683523990), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1748 = { sizeof (XmlSchemaType_t524866458), -1, sizeof(XmlSchemaType_t524866458_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1748[6] = 
{
	XmlSchemaType_t524866458::get_offset_of_final_3(),
	XmlSchemaType_t524866458::get_offset_of_BaseXmlSchemaTypeInternal_4(),
	XmlSchemaType_t524866458::get_offset_of_DatatypeInternal_5(),
	XmlSchemaType_t524866458::get_offset_of_QNameInternal_6(),
	XmlSchemaType_t524866458_StaticFields::get_offset_of_U3CU3Ef__switchU24map2E_7(),
	XmlSchemaType_t524866458_StaticFields::get_offset_of_U3CU3Ef__switchU24map2F_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1749 = { sizeof (XmlSchemaUtil_t3375497465), -1, sizeof(XmlSchemaUtil_t3375497465_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1749[4] = 
{
	XmlSchemaUtil_t3375497465_StaticFields::get_offset_of_FinalAllowed_0(),
	XmlSchemaUtil_t3375497465_StaticFields::get_offset_of_ElementBlockAllowed_1(),
	XmlSchemaUtil_t3375497465_StaticFields::get_offset_of_ComplexTypeBlockAllowed_2(),
	XmlSchemaUtil_t3375497465_StaticFields::get_offset_of_StrictMsCompliant_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1750 = { sizeof (XmlSchemaValidity_t228998106)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1750[4] = 
{
	XmlSchemaValidity_t228998106::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1751 = { sizeof (XmlAttributeAttribute_t2923040814), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1751[1] = 
{
	XmlAttributeAttribute_t2923040814::get_offset_of_attributeName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1752 = { sizeof (XmlElementAttribute_t3088997671), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1752[3] = 
{
	XmlElementAttribute_t3088997671::get_offset_of_elementName_0(),
	XmlElementAttribute_t3088997671::get_offset_of_type_1(),
	XmlElementAttribute_t3088997671::get_offset_of_order_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1753 = { sizeof (XmlEnumAttribute_t1652648811), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1753[1] = 
{
	XmlEnumAttribute_t1652648811::get_offset_of_name_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1754 = { sizeof (XmlIgnoreAttribute_t124988628), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1755 = { sizeof (XmlSerializerNamespaces_t3956590116), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1755[1] = 
{
	XmlSerializerNamespaces_t3956590116::get_offset_of_namespaces_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1756 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1757 = { sizeof (ConformanceLevel_t3681510256)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1757[4] = 
{
	ConformanceLevel_t3681510256::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1758 = { sizeof (DTDAutomataFactory_t2345474638), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1758[3] = 
{
	DTDAutomataFactory_t2345474638::get_offset_of_root_0(),
	DTDAutomataFactory_t2345474638::get_offset_of_choiceTable_1(),
	DTDAutomataFactory_t2345474638::get_offset_of_sequenceTable_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1759 = { sizeof (DTDObjectModel_t739056388), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1759[19] = 
{
	DTDObjectModel_t739056388::get_offset_of_factory_0(),
	DTDObjectModel_t739056388::get_offset_of_elementDecls_1(),
	DTDObjectModel_t739056388::get_offset_of_attListDecls_2(),
	DTDObjectModel_t739056388::get_offset_of_peDecls_3(),
	DTDObjectModel_t739056388::get_offset_of_entityDecls_4(),
	DTDObjectModel_t739056388::get_offset_of_notationDecls_5(),
	DTDObjectModel_t739056388::get_offset_of_validationErrors_6(),
	DTDObjectModel_t739056388::get_offset_of_resolver_7(),
	DTDObjectModel_t739056388::get_offset_of_nameTable_8(),
	DTDObjectModel_t739056388::get_offset_of_externalResources_9(),
	DTDObjectModel_t739056388::get_offset_of_baseURI_10(),
	DTDObjectModel_t739056388::get_offset_of_name_11(),
	DTDObjectModel_t739056388::get_offset_of_publicId_12(),
	DTDObjectModel_t739056388::get_offset_of_systemId_13(),
	DTDObjectModel_t739056388::get_offset_of_intSubset_14(),
	DTDObjectModel_t739056388::get_offset_of_intSubsetHasPERef_15(),
	DTDObjectModel_t739056388::get_offset_of_isStandalone_16(),
	DTDObjectModel_t739056388::get_offset_of_lineNumber_17(),
	DTDObjectModel_t739056388::get_offset_of_linePosition_18(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1760 = { sizeof (DictionaryBase_t377618675), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1761 = { sizeof (U3CU3Ec__Iterator3_t2137737414), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1761[5] = 
{
	U3CU3Ec__Iterator3_t2137737414::get_offset_of_U3CU24s_431U3E__0_0(),
	U3CU3Ec__Iterator3_t2137737414::get_offset_of_U3CpU3E__1_1(),
	U3CU3Ec__Iterator3_t2137737414::get_offset_of_U24PC_2(),
	U3CU3Ec__Iterator3_t2137737414::get_offset_of_U24current_3(),
	U3CU3Ec__Iterator3_t2137737414::get_offset_of_U3CU3Ef__this_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1762 = { sizeof (DTDCollectionBase_t20373490), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1762[1] = 
{
	DTDCollectionBase_t20373490::get_offset_of_root_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1763 = { sizeof (DTDElementDeclarationCollection_t3839880060), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1764 = { sizeof (DTDAttListDeclarationCollection_t4224010798), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1765 = { sizeof (DTDEntityDeclarationCollection_t1347165388), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1766 = { sizeof (DTDNotationDeclarationCollection_t1273717105), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1767 = { sizeof (DTDContentModel_t2007242871), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1767[6] = 
{
	DTDContentModel_t2007242871::get_offset_of_root_5(),
	DTDContentModel_t2007242871::get_offset_of_ownerElementName_6(),
	DTDContentModel_t2007242871::get_offset_of_elementName_7(),
	DTDContentModel_t2007242871::get_offset_of_orderType_8(),
	DTDContentModel_t2007242871::get_offset_of_childModels_9(),
	DTDContentModel_t2007242871::get_offset_of_occurence_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1768 = { sizeof (DTDContentModelCollection_t2794654295), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1768[1] = 
{
	DTDContentModelCollection_t2794654295::get_offset_of_contentModel_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1769 = { sizeof (DTDNode_t2342132918), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1769[5] = 
{
	DTDNode_t2342132918::get_offset_of_root_0(),
	DTDNode_t2342132918::get_offset_of_isInternalSubset_1(),
	DTDNode_t2342132918::get_offset_of_baseURI_2(),
	DTDNode_t2342132918::get_offset_of_lineNumber_3(),
	DTDNode_t2342132918::get_offset_of_linePosition_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1770 = { sizeof (DTDElementDeclaration_t1082122777), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1770[6] = 
{
	DTDElementDeclaration_t1082122777::get_offset_of_root_5(),
	DTDElementDeclaration_t1082122777::get_offset_of_contentModel_6(),
	DTDElementDeclaration_t1082122777::get_offset_of_name_7(),
	DTDElementDeclaration_t1082122777::get_offset_of_isEmpty_8(),
	DTDElementDeclaration_t1082122777::get_offset_of_isAny_9(),
	DTDElementDeclaration_t1082122777::get_offset_of_isMixedContent_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1771 = { sizeof (DTDAttributeDefinition_t2680882101), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1771[4] = 
{
	DTDAttributeDefinition_t2680882101::get_offset_of_name_5(),
	DTDAttributeDefinition_t2680882101::get_offset_of_datatype_6(),
	DTDAttributeDefinition_t2680882101::get_offset_of_unresolvedDefault_7(),
	DTDAttributeDefinition_t2680882101::get_offset_of_resolvedDefaultValue_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1772 = { sizeof (DTDAttListDeclaration_t3156318456), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1772[3] = 
{
	DTDAttListDeclaration_t3156318456::get_offset_of_name_5(),
	DTDAttListDeclaration_t3156318456::get_offset_of_attributeOrders_6(),
	DTDAttListDeclaration_t3156318456::get_offset_of_attributes_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1773 = { sizeof (DTDEntityBase_t195196828), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1773[10] = 
{
	DTDEntityBase_t195196828::get_offset_of_name_5(),
	DTDEntityBase_t195196828::get_offset_of_publicId_6(),
	DTDEntityBase_t195196828::get_offset_of_systemId_7(),
	DTDEntityBase_t195196828::get_offset_of_literalValue_8(),
	DTDEntityBase_t195196828::get_offset_of_replacementText_9(),
	DTDEntityBase_t195196828::get_offset_of_uriString_10(),
	DTDEntityBase_t195196828::get_offset_of_absUri_11(),
	DTDEntityBase_t195196828::get_offset_of_isInvalid_12(),
	DTDEntityBase_t195196828::get_offset_of_loadFailed_13(),
	DTDEntityBase_t195196828::get_offset_of_resolver_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1774 = { sizeof (DTDEntityDeclaration_t586771123), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1774[6] = 
{
	DTDEntityDeclaration_t586771123::get_offset_of_entityValue_15(),
	DTDEntityDeclaration_t586771123::get_offset_of_notationName_16(),
	DTDEntityDeclaration_t586771123::get_offset_of_ReferencingEntities_17(),
	DTDEntityDeclaration_t586771123::get_offset_of_scanned_18(),
	DTDEntityDeclaration_t586771123::get_offset_of_recursed_19(),
	DTDEntityDeclaration_t586771123::get_offset_of_hasExternalReference_20(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1775 = { sizeof (DTDNotationDeclaration_t3875406257), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1775[5] = 
{
	DTDNotationDeclaration_t3875406257::get_offset_of_name_5(),
	DTDNotationDeclaration_t3875406257::get_offset_of_localName_6(),
	DTDNotationDeclaration_t3875406257::get_offset_of_prefix_7(),
	DTDNotationDeclaration_t3875406257::get_offset_of_publicId_8(),
	DTDNotationDeclaration_t3875406257::get_offset_of_systemId_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1776 = { sizeof (DTDParameterEntityDeclarationCollection_t430810332), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1776[2] = 
{
	DTDParameterEntityDeclarationCollection_t430810332::get_offset_of_peDecls_0(),
	DTDParameterEntityDeclarationCollection_t430810332::get_offset_of_root_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1777 = { sizeof (DTDParameterEntityDeclaration_t2989885012), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1778 = { sizeof (DTDContentOrderType_t1914538838)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1778[4] = 
{
	DTDContentOrderType_t1914538838::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1779 = { sizeof (DTDOccurence_t1530059005)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1779[5] = 
{
	DTDOccurence_t1530059005::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1780 = { sizeof (DTDReader_t2281877084), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1780[14] = 
{
	DTDReader_t2281877084::get_offset_of_currentInput_0(),
	DTDReader_t2281877084::get_offset_of_parserInputStack_1(),
	DTDReader_t2281877084::get_offset_of_nameBuffer_2(),
	DTDReader_t2281877084::get_offset_of_nameLength_3(),
	DTDReader_t2281877084::get_offset_of_nameCapacity_4(),
	DTDReader_t2281877084::get_offset_of_valueBuffer_5(),
	DTDReader_t2281877084::get_offset_of_currentLinkedNodeLineNumber_6(),
	DTDReader_t2281877084::get_offset_of_currentLinkedNodeLinePosition_7(),
	DTDReader_t2281877084::get_offset_of_dtdIncludeSect_8(),
	DTDReader_t2281877084::get_offset_of_normalization_9(),
	DTDReader_t2281877084::get_offset_of_processingInternalSubset_10(),
	DTDReader_t2281877084::get_offset_of_cachedPublicId_11(),
	DTDReader_t2281877084::get_offset_of_cachedSystemId_12(),
	DTDReader_t2281877084::get_offset_of_DTD_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1781 = { sizeof (EntityHandling_t2315249075)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1781[3] = 
{
	EntityHandling_t2315249075::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1782 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1783 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1784 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1785 = { sizeof (NameTable_t2175076138), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1785[3] = 
{
	NameTable_t2175076138::get_offset_of_count_0(),
	NameTable_t2175076138::get_offset_of_buckets_1(),
	NameTable_t2175076138::get_offset_of_size_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1786 = { sizeof (Entry_t4088204333), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1786[4] = 
{
	Entry_t4088204333::get_offset_of_str_0(),
	Entry_t4088204333::get_offset_of_hash_1(),
	Entry_t4088204333::get_offset_of_len_2(),
	Entry_t4088204333::get_offset_of_next_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1787 = { sizeof (NamespaceHandling_t1052850511)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1787[3] = 
{
	NamespaceHandling_t1052850511::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1788 = { sizeof (NewLineHandling_t2956512787)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1788[4] = 
{
	NewLineHandling_t2956512787::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1789 = { sizeof (ReadState_t1299193502)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1789[6] = 
{
	ReadState_t1299193502::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1790 = { sizeof (WhitespaceHandling_t997061293)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1790[4] = 
{
	WhitespaceHandling_t997061293::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1791 = { sizeof (WriteState_t625744691)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable1791[8] = 
{
	WriteState_t625744691::get_offset_of_value___1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1792 = { sizeof (XmlAttribute_t500479142), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1792[4] = 
{
	XmlAttribute_t500479142::get_offset_of_name_5(),
	XmlAttribute_t500479142::get_offset_of_isDefault_6(),
	XmlAttribute_t500479142::get_offset_of_lastLinkedChild_7(),
	XmlAttribute_t500479142::get_offset_of_schemaInfo_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1793 = { sizeof (XmlAttributeCollection_t3899021962), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1793[2] = 
{
	XmlAttributeCollection_t3899021962::get_offset_of_ownerElement_4(),
	XmlAttributeCollection_t3899021962::get_offset_of_ownerDocument_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1794 = { sizeof (XmlCDataSection_t3669253335), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1795 = { sizeof (XmlChar_t1412824432), -1, sizeof(XmlChar_t1412824432_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1795[5] = 
{
	XmlChar_t1412824432_StaticFields::get_offset_of_WhitespaceChars_0(),
	XmlChar_t1412824432_StaticFields::get_offset_of_firstNamePages_1(),
	XmlChar_t1412824432_StaticFields::get_offset_of_namePages_2(),
	XmlChar_t1412824432_StaticFields::get_offset_of_nameBitmap_3(),
	XmlChar_t1412824432_StaticFields::get_offset_of_U3CU3Ef__switchU24map47_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1796 = { sizeof (XmlCharacterData_t168497055), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable1796[1] = 
{
	XmlCharacterData_t168497055::get_offset_of_data_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1797 = { sizeof (XmlComment_t683521230), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1798 = { sizeof (XmlConvert_t773442636), -1, sizeof(XmlConvert_t773442636_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1798[7] = 
{
	XmlConvert_t773442636_StaticFields::get_offset_of_datetimeFormats_0(),
	XmlConvert_t773442636_StaticFields::get_offset_of_defaultDateTimeFormats_1(),
	XmlConvert_t773442636_StaticFields::get_offset_of_roundtripDateTimeFormats_2(),
	XmlConvert_t773442636_StaticFields::get_offset_of_localDateTimeFormats_3(),
	XmlConvert_t773442636_StaticFields::get_offset_of_utcDateTimeFormats_4(),
	XmlConvert_t773442636_StaticFields::get_offset_of_unspecifiedDateTimeFormats_5(),
	XmlConvert_t773442636_StaticFields::get_offset_of__defaultStyle_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize1799 = { sizeof (XmlDeclaration_t4189685065), -1, sizeof(XmlDeclaration_t4189685065_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable1799[4] = 
{
	XmlDeclaration_t4189685065::get_offset_of_encoding_6(),
	XmlDeclaration_t4189685065::get_offset_of_standalone_7(),
	XmlDeclaration_t4189685065::get_offset_of_version_8(),
	XmlDeclaration_t4189685065_StaticFields::get_offset_of_U3CU3Ef__switchU24map4A_9(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
