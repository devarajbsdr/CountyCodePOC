﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"




extern const Il2CppType RuntimeObject_0_0_0;
extern const Il2CppType Int32_t2946131084_0_0_0;
extern const Il2CppType Char_t4123521152_0_0_0;
extern const Il2CppType Int64_t2942533987_0_0_0;
extern const Il2CppType UInt32_t1505113534_0_0_0;
extern const Il2CppType UInt64_t4149917651_0_0_0;
extern const Il2CppType Byte_t2596701031_0_0_0;
extern const Il2CppType SByte_t669469354_0_0_0;
extern const Il2CppType Int16_t612759502_0_0_0;
extern const Il2CppType UInt16_t1912811313_0_0_0;
extern const Il2CppType String_t_0_0_0;
extern const Il2CppType IConvertible_t2202553971_0_0_0;
extern const Il2CppType IComparable_t320313411_0_0_0;
extern const Il2CppType IEnumerable_t3475459086_0_0_0;
extern const Il2CppType ICloneable_t773452278_0_0_0;
extern const Il2CppType IComparable_1_t1912058747_0_0_0;
extern const Il2CppType IEquatable_1_t2100626540_0_0_0;
extern const Il2CppType Type_t_0_0_0;
extern const Il2CppType IReflect_t3588352395_0_0_0;
extern const Il2CppType _Type_t2237274337_0_0_0;
extern const Il2CppType MemberInfo_t_0_0_0;
extern const Il2CppType ICustomAttributeProvider_t3739891389_0_0_0;
extern const Il2CppType _MemberInfo_t2009121772_0_0_0;
extern const Il2CppType Double_t4024153389_0_0_0;
extern const Il2CppType Single_t2594644343_0_0_0;
extern const Il2CppType Decimal_t3889304405_0_0_0;
extern const Il2CppType Boolean_t2724601657_0_0_0;
extern const Il2CppType Delegate_t1444972694_0_0_0;
extern const Il2CppType ISerializable_t3088316472_0_0_0;
extern const Il2CppType ParameterInfo_t4224039251_0_0_0;
extern const Il2CppType _ParameterInfo_t408303849_0_0_0;
extern const Il2CppType FieldInfo_t_0_0_0;
extern const Il2CppType _FieldInfo_t2172126836_0_0_0;
extern const Il2CppType ParameterModifier_t3430991034_0_0_0;
extern const Il2CppType MethodInfo_t_0_0_0;
extern const Il2CppType _MethodInfo_t2957008391_0_0_0;
extern const Il2CppType MethodBase_t1529082644_0_0_0;
extern const Il2CppType _MethodBase_t6414478_0_0_0;
extern const Il2CppType ConstructorInfo_t1000193748_0_0_0;
extern const Il2CppType _ConstructorInfo_t238983269_0_0_0;
extern const Il2CppType IntPtr_t_0_0_0;
extern const Il2CppType TableRange_t985732536_0_0_0;
extern const Il2CppType TailoringInfo_t3490008366_0_0_0;
extern const Il2CppType KeyValuePair_2_t3150225156_0_0_0;
extern const Il2CppType Link_t2954686504_0_0_0;
extern const Il2CppType DictionaryEntry_t299448291_0_0_0;
extern const Il2CppType KeyValuePair_2_t3010656940_0_0_0;
extern const Il2CppType Contraction_t780417899_0_0_0;
extern const Il2CppType Level2Map_t373027516_0_0_0;
extern const Il2CppType BigInteger_t1659319351_0_0_0;
extern const Il2CppType KeySizes_t2881154755_0_0_0;
extern const Il2CppType KeyValuePair_2_t3005528154_0_0_0;
extern const Il2CppType Slot_t3729905400_0_0_0;
extern const Il2CppType Slot_t2894400404_0_0_0;
extern const Il2CppType StackFrame_t1830301115_0_0_0;
extern const Il2CppType Calendar_t3859479017_0_0_0;
extern const Il2CppType ModuleBuilder_t1725157840_0_0_0;
extern const Il2CppType _ModuleBuilder_t1204975354_0_0_0;
extern const Il2CppType Module_t2831991231_0_0_0;
extern const Il2CppType _Module_t3287617630_0_0_0;
extern const Il2CppType ParameterBuilder_t2723302902_0_0_0;
extern const Il2CppType _ParameterBuilder_t626099656_0_0_0;
extern const Il2CppType TypeU5BU5D_t4189288004_0_0_0;
extern const Il2CppType RuntimeArray_0_0_0;
extern const Il2CppType ICollection_t3498861635_0_0_0;
extern const Il2CppType IList_t4241283331_0_0_0;
extern const Il2CppType IList_1_t4127410026_0_0_0;
extern const Il2CppType ICollection_1_t362053986_0_0_0;
extern const Il2CppType IEnumerable_1_t2665815806_0_0_0;
extern const Il2CppType IList_1_t2735078972_0_0_0;
extern const Il2CppType ICollection_1_t3264690228_0_0_0;
extern const Il2CppType IEnumerable_1_t1273484752_0_0_0;
extern const Il2CppType IList_1_t1384000914_0_0_0;
extern const Il2CppType ICollection_1_t1913612170_0_0_0;
extern const Il2CppType IEnumerable_1_t4217373990_0_0_0;
extern const Il2CppType IList_1_t3973997_0_0_0;
extern const Il2CppType ICollection_1_t533585253_0_0_0;
extern const Il2CppType IEnumerable_1_t2837347073_0_0_0;
extern const Il2CppType IList_1_t2886617966_0_0_0;
extern const Il2CppType ICollection_1_t3416229222_0_0_0;
extern const Il2CppType IEnumerable_1_t1425023746_0_0_0;
extern const Il2CppType IList_1_t1155848349_0_0_0;
extern const Il2CppType ICollection_1_t1685459605_0_0_0;
extern const Il2CppType IEnumerable_1_t3989221425_0_0_0;
extern const Il2CppType IList_1_t1948160659_0_0_0;
extern const Il2CppType ICollection_1_t2477771915_0_0_0;
extern const Il2CppType IEnumerable_1_t486566439_0_0_0;
extern const Il2CppType ILTokenInfo_t4080941797_0_0_0;
extern const Il2CppType LabelData_t3378720351_0_0_0;
extern const Il2CppType LabelFixup_t3442793709_0_0_0;
extern const Il2CppType GenericTypeParameterBuilder_t3165304919_0_0_0;
extern const Il2CppType CustomAttributeBuilder_t3519735045_0_0_0;
extern const Il2CppType _CustomAttributeBuilder_t508271582_0_0_0;
extern const Il2CppType RefEmitPermissionSet_t3776199698_0_0_0;
extern const Il2CppType TypeBuilder_t428610841_0_0_0;
extern const Il2CppType _TypeBuilder_t1888918970_0_0_0;
extern const Il2CppType MethodBuilder_t2550065105_0_0_0;
extern const Il2CppType _MethodBuilder_t51529510_0_0_0;
extern const Il2CppType FieldBuilder_t1795031134_0_0_0;
extern const Il2CppType _FieldBuilder_t2176048174_0_0_0;
extern const Il2CppType MonoResource_t110510560_0_0_0;
extern const Il2CppType ConstructorBuilder_t3862957018_0_0_0;
extern const Il2CppType _ConstructorBuilder_t10194797_0_0_0;
extern const Il2CppType PropertyBuilder_t444456996_0_0_0;
extern const Il2CppType _PropertyBuilder_t2034357485_0_0_0;
extern const Il2CppType PropertyInfo_t_0_0_0;
extern const Il2CppType _PropertyInfo_t3778442912_0_0_0;
extern const Il2CppType EventBuilder_t3271757496_0_0_0;
extern const Il2CppType _EventBuilder_t360474911_0_0_0;
extern const Il2CppType CustomAttributeTypedArgument_t437198719_0_0_0;
extern const Il2CppType CustomAttributeNamedArgument_t3066689011_0_0_0;
extern const Il2CppType CustomAttributeData_t2415778318_0_0_0;
extern const Il2CppType ResourceInfo_t26720911_0_0_0;
extern const Il2CppType ResourceCacheItem_t2684218735_0_0_0;
extern const Il2CppType IContextProperty_t3454453605_0_0_0;
extern const Il2CppType Header_t4048742355_0_0_0;
extern const Il2CppType ITrackingHandler_t3982758781_0_0_0;
extern const Il2CppType IContextAttribute_t1709749317_0_0_0;
extern const Il2CppType DateTime_t4019639461_0_0_0;
extern const Il2CppType TimeSpan_t2594328967_0_0_0;
extern const Il2CppType TypeTag_t696993974_0_0_0;
extern const Il2CppType MonoType_t_0_0_0;
extern const Il2CppType StrongName_t2807758910_0_0_0;
extern const Il2CppType IBuiltInEvidence_t4053645731_0_0_0;
extern const Il2CppType IIdentityPermissionFactory_t3236790479_0_0_0;
extern const Il2CppType DateTimeOffset_t2136805232_0_0_0;
extern const Il2CppType Guid_t_0_0_0;
extern const Il2CppType Version_t506497972_0_0_0;
extern const Il2CppType BigInteger_t1659319352_0_0_0;
extern const Il2CppType ByteU5BU5D_t2643433246_0_0_0;
extern const Il2CppType IList_1_t1743427608_0_0_0;
extern const Il2CppType ICollection_1_t2273038864_0_0_0;
extern const Il2CppType IEnumerable_1_t281833388_0_0_0;
extern const Il2CppType X509Certificate_t953704339_0_0_0;
extern const Il2CppType IDeserializationCallback_t3942415194_0_0_0;
extern const Il2CppType ClientCertificateType_t1963204790_0_0_0;
extern const Il2CppType X509ChainStatus_t1563713867_0_0_0;
extern const Il2CppType IPAddress_t1944286148_0_0_0;
extern const Il2CppType ArraySegment_1_t2744003576_0_0_0;
extern const Il2CppType Cookie_t2357423313_0_0_0;
extern const Il2CppType KeyValuePair_2_t2928695729_0_0_0;
extern const Il2CppType KeyValuePair_2_t2789127513_0_0_0;
extern const Il2CppType Capture_t2838260575_0_0_0;
extern const Il2CppType Group_t2467218104_0_0_0;
extern const Il2CppType Mark_t1992438718_0_0_0;
extern const Il2CppType UriScheme_t649781592_0_0_0;
extern const Il2CppType Link_t3921545329_0_0_0;
extern const Il2CppType AsyncOperation_t3810459996_0_0_0;
extern const Il2CppType Camera_t274442537_0_0_0;
extern const Il2CppType Behaviour_t789096462_0_0_0;
extern const Il2CppType Component_t3460329512_0_0_0;
extern const Il2CppType Object_t3285695601_0_0_0;
extern const Il2CppType Display_t3775361438_0_0_0;
extern const Il2CppType Keyframe_t1299923720_0_0_0;
extern const Il2CppType Vector3_t2486370225_0_0_0;
extern const Il2CppType Vector4_t4214292213_0_0_0;
extern const Il2CppType Vector2_t1743417791_0_0_0;
extern const Il2CppType Color32_t1281607702_0_0_0;
extern const Il2CppType Playable_t1563095691_0_0_0;
extern const Il2CppType PlayableOutput_t2224788333_0_0_0;
extern const Il2CppType Scene_t2429659677_0_0_0;
extern const Il2CppType LoadSceneMode_t38367264_0_0_0;
extern const Il2CppType SpriteAtlas_t2907583744_0_0_0;
extern const Il2CppType DisallowMultipleComponent_t1485140390_0_0_0;
extern const Il2CppType Attribute_t2363954793_0_0_0;
extern const Il2CppType _Attribute_t705991232_0_0_0;
extern const Il2CppType ExecuteInEditMode_t2060420173_0_0_0;
extern const Il2CppType RequireComponent_t2601444532_0_0_0;
extern const Il2CppType HitInfo_t3242551441_0_0_0;
extern const Il2CppType PersistentCall_t1303572475_0_0_0;
extern const Il2CppType BaseInvokableCall_t1790754149_0_0_0;
extern const Il2CppType WorkRequest_t1627094759_0_0_0;
extern const Il2CppType PlayableBinding_t2631396557_0_0_0;
extern const Il2CppType MessageTypeSubscribers_t3519534061_0_0_0;
extern const Il2CppType MessageEventArgs_t583925932_0_0_0;
extern const Il2CppType WeakReference_t842734143_0_0_0;
extern const Il2CppType KeyValuePair_2_t573483709_0_0_0;
extern const Il2CppType KeyValuePair_2_t2909751066_0_0_0;
extern const Il2CppType AudioSpatializerExtensionDefinition_t3945920284_0_0_0;
extern const Il2CppType AudioAmbisonicExtensionDefinition_t308490681_0_0_0;
extern const Il2CppType AudioSourceExtension_t3646449378_0_0_0;
extern const Il2CppType ScriptableObject_t2661394107_0_0_0;
extern const Il2CppType AudioMixerPlayable_t4111045564_0_0_0;
extern const Il2CppType AudioClipPlayable_t1629551309_0_0_0;
extern const Il2CppType Rigidbody2D_t1473351060_0_0_0;
extern const Il2CppType Font_t82789257_0_0_0;
extern const Il2CppType UIVertex_t3704361653_0_0_0;
extern const Il2CppType UICharInfo_t498913270_0_0_0;
extern const Il2CppType UILineInfo_t2500817891_0_0_0;
extern const Il2CppType AnimationClipPlayable_t1300644386_0_0_0;
extern const Il2CppType AnimationLayerMixerPlayable_t1849272991_0_0_0;
extern const Il2CppType AnimationMixerPlayable_t904356521_0_0_0;
extern const Il2CppType AnimationOffsetPlayable_t1324066292_0_0_0;
extern const Il2CppType AnimatorControllerPlayable_t567321136_0_0_0;
extern const Il2CppType AchievementDescription_t1798731768_0_0_0;
extern const Il2CppType IAchievementDescription_t3768105385_0_0_0;
extern const Il2CppType UserProfile_t2681963727_0_0_0;
extern const Il2CppType IUserProfile_t509133715_0_0_0;
extern const Il2CppType GcLeaderboard_t3783886338_0_0_0;
extern const Il2CppType IAchievementDescriptionU5BU5D_t2469250452_0_0_0;
extern const Il2CppType IAchievementU5BU5D_t3797953173_0_0_0;
extern const Il2CppType IAchievement_t564068860_0_0_0;
extern const Il2CppType GcAchievementData_t1914197125_0_0_0;
extern const Il2CppType Achievement_t1636619461_0_0_0;
extern const Il2CppType IScoreU5BU5D_t768188392_0_0_0;
extern const Il2CppType IScore_t2787079909_0_0_0;
extern const Il2CppType GcScoreData_t3281375178_0_0_0;
extern const Il2CppType Score_t2475763700_0_0_0;
extern const Il2CppType IUserProfileU5BU5D_t859854018_0_0_0;
extern const Il2CppType GUILayoutOption_t3642022624_0_0_0;
extern const Il2CppType LayoutCache_t3050666578_0_0_0;
extern const Il2CppType KeyValuePair_2_t501915592_0_0_0;
extern const Il2CppType KeyValuePair_2_t751148088_0_0_0;
extern const Il2CppType GUILayoutEntry_t3409609005_0_0_0;
extern const Il2CppType Exception_t3056413322_0_0_0;
extern const Il2CppType GUIStyle_t1817005639_0_0_0;
extern const Il2CppType KeyValuePair_2_t1881531495_0_0_0;
extern const Il2CppType KeyValuePair_2_t2865959938_0_0_0;
extern const Il2CppType KeyValuePair_2_t2406658774_0_0_0;
extern const Il2CppType DTDNode_t2342132918_0_0_0;
extern const Il2CppType IXmlLineInfo_t3461124495_0_0_0;
extern const Il2CppType Entry_t4088204333_0_0_0;
extern const Il2CppType XmlNode_t482051342_0_0_0;
extern const Il2CppType IXPathNavigable_t3807597221_0_0_0;
extern const Il2CppType NsDecl_t2771301075_0_0_0;
extern const Il2CppType NsScope_t1210418454_0_0_0;
extern const Il2CppType XmlAttributeTokenInfo_t768028006_0_0_0;
extern const Il2CppType XmlTokenInfo_t2877013752_0_0_0;
extern const Il2CppType TagName_t1900555770_0_0_0;
extern const Il2CppType XmlNodeInfo_t3772009616_0_0_0;
extern const Il2CppType EventSystem_t2763469419_0_0_0;
extern const Il2CppType UIBehaviour_t2911488490_0_0_0;
extern const Il2CppType MonoBehaviour_t2760964972_0_0_0;
extern const Il2CppType BaseInputModule_t3188708927_0_0_0;
extern const Il2CppType RaycastResult_t3064114207_0_0_0;
extern const Il2CppType IDeselectHandler_t3080839654_0_0_0;
extern const Il2CppType IEventSystemHandler_t2937428598_0_0_0;
extern const Il2CppType List_1_t2929629111_0_0_0;
extern const Il2CppType List_1_t2793634595_0_0_0;
extern const Il2CppType List_1_t3452530025_0_0_0;
extern const Il2CppType ISelectHandler_t2239037249_0_0_0;
extern const Il2CppType BaseRaycaster_t3516132962_0_0_0;
extern const Il2CppType Entry_t165374421_0_0_0;
extern const Il2CppType BaseEventData_t2898106447_0_0_0;
extern const Il2CppType IPointerEnterHandler_t1495392573_0_0_0;
extern const Il2CppType IPointerExitHandler_t458397702_0_0_0;
extern const Il2CppType IPointerDownHandler_t3926188968_0_0_0;
extern const Il2CppType IPointerUpHandler_t3642990532_0_0_0;
extern const Il2CppType IPointerClickHandler_t4152680922_0_0_0;
extern const Il2CppType IInitializePotentialDragHandler_t2460353812_0_0_0;
extern const Il2CppType IBeginDragHandler_t2985217986_0_0_0;
extern const Il2CppType IDragHandler_t1695179672_0_0_0;
extern const Il2CppType IEndDragHandler_t2034818176_0_0_0;
extern const Il2CppType IDropHandler_t3227688416_0_0_0;
extern const Il2CppType IScrollHandler_t3788224089_0_0_0;
extern const Il2CppType IUpdateSelectedHandler_t3604511566_0_0_0;
extern const Il2CppType IMoveHandler_t2371195586_0_0_0;
extern const Il2CppType ISubmitHandler_t4239390985_0_0_0;
extern const Il2CppType ICancelHandler_t881167290_0_0_0;
extern const Il2CppType Transform_t98390630_0_0_0;
extern const Il2CppType GameObject_t1069409312_0_0_0;
extern const Il2CppType BaseInput_t2347852_0_0_0;
extern const Il2CppType PointerEventData_t110851018_0_0_0;
extern const Il2CppType AbstractEventData_t2094041248_0_0_0;
extern const Il2CppType KeyValuePair_2_t2106299824_0_0_0;
extern const Il2CppType ButtonState_t3919583657_0_0_0;
extern const Il2CppType RaycastHit2D_t3641439068_0_0_0;
extern const Il2CppType RaycastHit_t1862035074_0_0_0;
extern const Il2CppType Color_t2395139082_0_0_0;
extern const Il2CppType ICanvasElement_t1506473672_0_0_0;
extern const Il2CppType ColorBlock_t2528874620_0_0_0;
extern const Il2CppType OptionData_t308902495_0_0_0;
extern const Il2CppType DropdownItem_t1280764085_0_0_0;
extern const Il2CppType FloatTween_t718194525_0_0_0;
extern const Il2CppType Sprite_t825958079_0_0_0;
extern const Il2CppType Canvas_t1472555277_0_0_0;
extern const Il2CppType List_1_t1464755790_0_0_0;
extern const Il2CppType HashSet_1_t2760900715_0_0_0;
extern const Il2CppType Text_t40276147_0_0_0;
extern const Il2CppType Link_t1160387394_0_0_0;
extern const Il2CppType ILayoutElement_t3083897574_0_0_0;
extern const Il2CppType MaskableGraphic_t829384950_0_0_0;
extern const Il2CppType IClippable_t2595653578_0_0_0;
extern const Il2CppType IMaskable_t3116280729_0_0_0;
extern const Il2CppType IMaterialModifier_t2659437676_0_0_0;
extern const Il2CppType Graphic_t3934133196_0_0_0;
extern const Il2CppType KeyValuePair_2_t1061748416_0_0_0;
extern const Il2CppType ColorTween_t2126108860_0_0_0;
extern const Il2CppType IndexedSet_1_t3732760996_0_0_0;
extern const Il2CppType KeyValuePair_2_t3977119717_0_0_0;
extern const Il2CppType KeyValuePair_2_t2513357362_0_0_0;
extern const Il2CppType KeyValuePair_2_t3644430278_0_0_0;
extern const Il2CppType Type_t3482946342_0_0_0;
extern const Il2CppType FillMethod_t1967692376_0_0_0;
extern const Il2CppType ContentType_t1949393164_0_0_0;
extern const Il2CppType LineType_t1704015161_0_0_0;
extern const Il2CppType InputType_t3552287731_0_0_0;
extern const Il2CppType TouchScreenKeyboardType_t1115125102_0_0_0;
extern const Il2CppType CharacterValidation_t1615951991_0_0_0;
extern const Il2CppType Mask_t4273450599_0_0_0;
extern const Il2CppType ICanvasRaycastFilter_t1727583418_0_0_0;
extern const Il2CppType List_1_t4265651112_0_0_0;
extern const Il2CppType RectMask2D_t2940363972_0_0_0;
extern const Il2CppType IClipper_t3640166804_0_0_0;
extern const Il2CppType List_1_t2932564485_0_0_0;
extern const Il2CppType Navigation_t2650002304_0_0_0;
extern const Il2CppType Link_t3715764825_0_0_0;
extern const Il2CppType Direction_t2220972688_0_0_0;
extern const Il2CppType Selectable_t704361702_0_0_0;
extern const Il2CppType Transition_t3996285674_0_0_0;
extern const Il2CppType SpriteState_t3463583707_0_0_0;
extern const Il2CppType CanvasGroup_t4004672386_0_0_0;
extern const Il2CppType Direction_t169952706_0_0_0;
extern const Il2CppType MatEntry_t3924390953_0_0_0;
extern const Il2CppType Toggle_t2394373767_0_0_0;
extern const Il2CppType KeyValuePair_2_t659768394_0_0_0;
extern const Il2CppType AspectMode_t2894845584_0_0_0;
extern const Il2CppType FitMode_t303797140_0_0_0;
extern const Il2CppType RectTransform_t3170355171_0_0_0;
extern const Il2CppType LayoutRebuilder_t2138051633_0_0_0;
extern const Il2CppType List_1_t2478570738_0_0_0;
extern const Il2CppType List_1_t1273808215_0_0_0;
extern const Il2CppType List_1_t1735618304_0_0_0;
extern const Il2CppType List_1_t4206492726_0_0_0;
extern const Il2CppType List_1_t2938331597_0_0_0;
extern const Il2CppType List_1_t3696562166_0_0_0;
extern const Il2CppType FieldWithTarget_t2008555883_0_0_0;
extern const Il2CppType IEnumerable_1_t3472824768_gp_0_0_0_0;
extern const Il2CppType Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m375360748_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m3222092194_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m3222092194_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m2933720515_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m1007327534_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m1007327534_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m2280519164_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m3079444734_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m3079444734_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m465496297_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m703600137_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m703600137_gp_1_0_0_0;
extern const Il2CppType Array_Sort_m884212515_gp_0_0_0_0;
extern const Il2CppType Array_Sort_m2398395411_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m3664970149_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m3664970149_gp_1_0_0_0;
extern const Il2CppType Array_compare_m2643025574_gp_0_0_0_0;
extern const Il2CppType Array_qsort_m2860849171_gp_0_0_0_0;
extern const Il2CppType Array_Resize_m1319191173_gp_0_0_0_0;
extern const Il2CppType Array_TrueForAll_m3279624529_gp_0_0_0_0;
extern const Il2CppType Array_ForEach_m3065220158_gp_0_0_0_0;
extern const Il2CppType Array_ConvertAll_m4162873343_gp_0_0_0_0;
extern const Il2CppType Array_ConvertAll_m4162873343_gp_1_0_0_0;
extern const Il2CppType Array_FindLastIndex_m1231288529_gp_0_0_0_0;
extern const Il2CppType Array_FindLastIndex_m253241084_gp_0_0_0_0;
extern const Il2CppType Array_FindLastIndex_m3979318220_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m2771346406_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m1435567717_gp_0_0_0_0;
extern const Il2CppType Array_FindIndex_m541082306_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m210446113_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m2725795785_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m236397454_gp_0_0_0_0;
extern const Il2CppType Array_BinarySearch_m670715820_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m1478543517_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m2800774269_gp_0_0_0_0;
extern const Il2CppType Array_IndexOf_m1657565370_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m3259903814_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m2114823285_gp_0_0_0_0;
extern const Il2CppType Array_LastIndexOf_m3033490990_gp_0_0_0_0;
extern const Il2CppType Array_FindAll_m2935868350_gp_0_0_0_0;
extern const Il2CppType Array_Exists_m2513116021_gp_0_0_0_0;
extern const Il2CppType Array_AsReadOnly_m1269368112_gp_0_0_0_0;
extern const Il2CppType Array_Find_m3798369552_gp_0_0_0_0;
extern const Il2CppType Array_FindLast_m451745637_gp_0_0_0_0;
extern const Il2CppType InternalEnumerator_1_t3198792400_gp_0_0_0_0;
extern const Il2CppType ArrayReadOnlyList_1_t875796540_gp_0_0_0_0;
extern const Il2CppType U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0;
extern const Il2CppType IList_1_t3283297292_gp_0_0_0_0;
extern const Il2CppType ICollection_1_t3247531716_gp_0_0_0_0;
extern const Il2CppType Nullable_1_t3469261872_gp_0_0_0_0;
extern const Il2CppType Comparer_1_t2365096000_gp_0_0_0_0;
extern const Il2CppType DefaultComparer_t325514881_gp_0_0_0_0;
extern const Il2CppType GenericComparer_1_t1985017584_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_t2809050045_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_t2809050045_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t373669827_0_0_0;
extern const Il2CppType Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0;
extern const Il2CppType Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0;
extern const Il2CppType ShimEnumerator_t3580966704_gp_0_0_0_0;
extern const Il2CppType ShimEnumerator_t3580966704_gp_1_0_0_0;
extern const Il2CppType Enumerator_t3554107356_gp_0_0_0_0;
extern const Il2CppType Enumerator_t3554107356_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t4151003239_0_0_0;
extern const Il2CppType KeyCollection_t3609397419_gp_0_0_0_0;
extern const Il2CppType KeyCollection_t3609397419_gp_1_0_0_0;
extern const Il2CppType Enumerator_t1298455868_gp_0_0_0_0;
extern const Il2CppType Enumerator_t1298455868_gp_1_0_0_0;
extern const Il2CppType ValueCollection_t59155699_gp_0_0_0_0;
extern const Il2CppType ValueCollection_t59155699_gp_1_0_0_0;
extern const Il2CppType Enumerator_t3190540399_gp_0_0_0_0;
extern const Il2CppType Enumerator_t3190540399_gp_1_0_0_0;
extern const Il2CppType EqualityComparer_1_t1605754411_gp_0_0_0_0;
extern const Il2CppType DefaultComparer_t790800357_gp_0_0_0_0;
extern const Il2CppType GenericEqualityComparer_1_t692778042_gp_0_0_0_0;
extern const Il2CppType KeyValuePair_2_t2431883363_0_0_0;
extern const Il2CppType IDictionary_2_t4171839189_gp_0_0_0_0;
extern const Il2CppType IDictionary_2_t4171839189_gp_1_0_0_0;
extern const Il2CppType KeyValuePair_2_t917785449_gp_0_0_0_0;
extern const Il2CppType KeyValuePair_2_t917785449_gp_1_0_0_0;
extern const Il2CppType List_1_t1768017692_gp_0_0_0_0;
extern const Il2CppType Enumerator_t924438735_gp_0_0_0_0;
extern const Il2CppType Collection_1_t3943914114_gp_0_0_0_0;
extern const Il2CppType ReadOnlyCollection_1_t3380407612_gp_0_0_0_0;
extern const Il2CppType MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0;
extern const Il2CppType MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0;
extern const Il2CppType MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0;
extern const Il2CppType ArraySegment_1_t1939258092_gp_0_0_0_0;
extern const Il2CppType Queue_1_t1750955003_gp_0_0_0_0;
extern const Il2CppType Enumerator_t2644889458_gp_0_0_0_0;
extern const Il2CppType Stack_1_t3976444548_gp_0_0_0_0;
extern const Il2CppType Enumerator_t3983460471_gp_0_0_0_0;
extern const Il2CppType HashSet_1_t182226283_gp_0_0_0_0;
extern const Il2CppType Enumerator_t2669265363_gp_0_0_0_0;
extern const Il2CppType PrimeHelper_t4001087760_gp_0_0_0_0;
extern const Il2CppType Enumerable_Any_m3044489537_gp_0_0_0_0;
extern const Il2CppType Enumerable_Where_m509811445_gp_0_0_0_0;
extern const Il2CppType Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0;
extern const Il2CppType U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentInChildren_m1658374531_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0;
extern const Il2CppType Component_GetComponentsInParent_m2393957797_gp_0_0_0_0;
extern const Il2CppType Component_GetComponents_m1510131101_gp_0_0_0_0;
extern const Il2CppType Component_GetComponents_m2882340512_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponents_m318279657_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0;
extern const Il2CppType GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0;
extern const Il2CppType Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0;
extern const Il2CppType Mesh_SafeLength_m1544801684_gp_0_0_0_0;
extern const Il2CppType Mesh_SetListForChannel_m131533298_gp_0_0_0_0;
extern const Il2CppType Mesh_SetListForChannel_m326208384_gp_0_0_0_0;
extern const Il2CppType Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0;
extern const Il2CppType InvokableCall_1_t3177580188_gp_0_0_0_0;
extern const Il2CppType UnityAction_1_t1512030109_0_0_0;
extern const Il2CppType InvokableCall_2_t4177718962_gp_0_0_0_0;
extern const Il2CppType InvokableCall_2_t4177718962_gp_1_0_0_0;
extern const Il2CppType InvokableCall_3_t1109707351_gp_0_0_0_0;
extern const Il2CppType InvokableCall_3_t1109707351_gp_1_0_0_0;
extern const Il2CppType InvokableCall_3_t1109707351_gp_2_0_0_0;
extern const Il2CppType InvokableCall_4_t2839234570_gp_0_0_0_0;
extern const Il2CppType InvokableCall_4_t2839234570_gp_1_0_0_0;
extern const Il2CppType InvokableCall_4_t2839234570_gp_2_0_0_0;
extern const Il2CppType InvokableCall_4_t2839234570_gp_3_0_0_0;
extern const Il2CppType CachedInvokableCall_1_t1763259375_gp_0_0_0_0;
extern const Il2CppType UnityEvent_1_t2513023335_gp_0_0_0_0;
extern const Il2CppType UnityEvent_2_t3919372254_gp_0_0_0_0;
extern const Il2CppType UnityEvent_2_t3919372254_gp_1_0_0_0;
extern const Il2CppType UnityEvent_3_t2232704357_gp_0_0_0_0;
extern const Il2CppType UnityEvent_3_t2232704357_gp_1_0_0_0;
extern const Il2CppType UnityEvent_3_t2232704357_gp_2_0_0_0;
extern const Il2CppType UnityEvent_4_t4058827200_gp_0_0_0_0;
extern const Il2CppType UnityEvent_4_t4058827200_gp_1_0_0_0;
extern const Il2CppType UnityEvent_4_t4058827200_gp_2_0_0_0;
extern const Il2CppType UnityEvent_4_t4058827200_gp_3_0_0_0;
extern const Il2CppType ExecuteEvents_Execute_m3971585966_gp_0_0_0_0;
extern const Il2CppType ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0;
extern const Il2CppType ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0;
extern const Il2CppType ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0;
extern const Il2CppType ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0;
extern const Il2CppType TweenRunner_1_t2568776171_gp_0_0_0_0;
extern const Il2CppType Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0;
extern const Il2CppType SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0;
extern const Il2CppType IndexedSet_1_t2472654987_gp_0_0_0_0;
extern const Il2CppType ListPool_1_t3291784397_gp_0_0_0_0;
extern const Il2CppType List_1_t3931617359_0_0_0;
extern const Il2CppType ObjectPool_1_t1412409661_gp_0_0_0_0;
extern const Il2CppType DefaultExecutionOrder_t533427438_0_0_0;
extern const Il2CppType PlayerConnection_t3376987642_0_0_0;
extern const Il2CppType GUILayer_t368266309_0_0_0;
extern const Il2CppType AxisEventData_t2495346144_0_0_0;
extern const Il2CppType SpriteRenderer_t924888996_0_0_0;
extern const Il2CppType Image_t325497262_0_0_0;
extern const Il2CppType Button_t1951982026_0_0_0;
extern const Il2CppType RawImage_t2311903931_0_0_0;
extern const Il2CppType Slider_t599575794_0_0_0;
extern const Il2CppType Scrollbar_t2833447691_0_0_0;
extern const Il2CppType InputField_t1009335159_0_0_0;
extern const Il2CppType ScrollRect_t1909087471_0_0_0;
extern const Il2CppType Dropdown_t532982771_0_0_0;
extern const Il2CppType GraphicRaycaster_t3206056917_0_0_0;
extern const Il2CppType CanvasRenderer_t3614328869_0_0_0;
extern const Il2CppType Corner_t2478443190_0_0_0;
extern const Il2CppType Axis_t3769150349_0_0_0;
extern const Il2CppType Constraint_t2227253834_0_0_0;
extern const Il2CppType SubmitEvent_t984659408_0_0_0;
extern const Il2CppType OnChangeEvent_t425979699_0_0_0;
extern const Il2CppType OnValidateInput_t3315013029_0_0_0;
extern const Il2CppType LayoutElement_t530979270_0_0_0;
extern const Il2CppType RectOffset_t2531911544_0_0_0;
extern const Il2CppType TextAnchor_t1172919424_0_0_0;
extern const Il2CppType AnimationTriggers_t1273266827_0_0_0;
extern const Il2CppType Animator_t4196124252_0_0_0;




static const RuntimeType* GenInst_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0 = { 1, GenInst_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0 = { 1, GenInst_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_Char_t4123521152_0_0_0_Types[] = { (&Char_t4123521152_0_0_0) };
extern const Il2CppGenericInst GenInst_Char_t4123521152_0_0_0 = { 1, GenInst_Char_t4123521152_0_0_0_Types };
static const RuntimeType* GenInst_Int64_t2942533987_0_0_0_Types[] = { (&Int64_t2942533987_0_0_0) };
extern const Il2CppGenericInst GenInst_Int64_t2942533987_0_0_0 = { 1, GenInst_Int64_t2942533987_0_0_0_Types };
static const RuntimeType* GenInst_UInt32_t1505113534_0_0_0_Types[] = { (&UInt32_t1505113534_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt32_t1505113534_0_0_0 = { 1, GenInst_UInt32_t1505113534_0_0_0_Types };
static const RuntimeType* GenInst_UInt64_t4149917651_0_0_0_Types[] = { (&UInt64_t4149917651_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt64_t4149917651_0_0_0 = { 1, GenInst_UInt64_t4149917651_0_0_0_Types };
static const RuntimeType* GenInst_Byte_t2596701031_0_0_0_Types[] = { (&Byte_t2596701031_0_0_0) };
extern const Il2CppGenericInst GenInst_Byte_t2596701031_0_0_0 = { 1, GenInst_Byte_t2596701031_0_0_0_Types };
static const RuntimeType* GenInst_SByte_t669469354_0_0_0_Types[] = { (&SByte_t669469354_0_0_0) };
extern const Il2CppGenericInst GenInst_SByte_t669469354_0_0_0 = { 1, GenInst_SByte_t669469354_0_0_0_Types };
static const RuntimeType* GenInst_Int16_t612759502_0_0_0_Types[] = { (&Int16_t612759502_0_0_0) };
extern const Il2CppGenericInst GenInst_Int16_t612759502_0_0_0 = { 1, GenInst_Int16_t612759502_0_0_0_Types };
static const RuntimeType* GenInst_UInt16_t1912811313_0_0_0_Types[] = { (&UInt16_t1912811313_0_0_0) };
extern const Il2CppGenericInst GenInst_UInt16_t1912811313_0_0_0 = { 1, GenInst_UInt16_t1912811313_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Types[] = { (&String_t_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0 = { 1, GenInst_String_t_0_0_0_Types };
static const RuntimeType* GenInst_IConvertible_t2202553971_0_0_0_Types[] = { (&IConvertible_t2202553971_0_0_0) };
extern const Il2CppGenericInst GenInst_IConvertible_t2202553971_0_0_0 = { 1, GenInst_IConvertible_t2202553971_0_0_0_Types };
static const RuntimeType* GenInst_IComparable_t320313411_0_0_0_Types[] = { (&IComparable_t320313411_0_0_0) };
extern const Il2CppGenericInst GenInst_IComparable_t320313411_0_0_0 = { 1, GenInst_IComparable_t320313411_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_t3475459086_0_0_0_Types[] = { (&IEnumerable_t3475459086_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_t3475459086_0_0_0 = { 1, GenInst_IEnumerable_t3475459086_0_0_0_Types };
static const RuntimeType* GenInst_ICloneable_t773452278_0_0_0_Types[] = { (&ICloneable_t773452278_0_0_0) };
extern const Il2CppGenericInst GenInst_ICloneable_t773452278_0_0_0 = { 1, GenInst_ICloneable_t773452278_0_0_0_Types };
static const RuntimeType* GenInst_IComparable_1_t1912058747_0_0_0_Types[] = { (&IComparable_1_t1912058747_0_0_0) };
extern const Il2CppGenericInst GenInst_IComparable_1_t1912058747_0_0_0 = { 1, GenInst_IComparable_1_t1912058747_0_0_0_Types };
static const RuntimeType* GenInst_IEquatable_1_t2100626540_0_0_0_Types[] = { (&IEquatable_1_t2100626540_0_0_0) };
extern const Il2CppGenericInst GenInst_IEquatable_1_t2100626540_0_0_0 = { 1, GenInst_IEquatable_1_t2100626540_0_0_0_Types };
static const RuntimeType* GenInst_Type_t_0_0_0_Types[] = { (&Type_t_0_0_0) };
extern const Il2CppGenericInst GenInst_Type_t_0_0_0 = { 1, GenInst_Type_t_0_0_0_Types };
static const RuntimeType* GenInst_IReflect_t3588352395_0_0_0_Types[] = { (&IReflect_t3588352395_0_0_0) };
extern const Il2CppGenericInst GenInst_IReflect_t3588352395_0_0_0 = { 1, GenInst_IReflect_t3588352395_0_0_0_Types };
static const RuntimeType* GenInst__Type_t2237274337_0_0_0_Types[] = { (&_Type_t2237274337_0_0_0) };
extern const Il2CppGenericInst GenInst__Type_t2237274337_0_0_0 = { 1, GenInst__Type_t2237274337_0_0_0_Types };
static const RuntimeType* GenInst_MemberInfo_t_0_0_0_Types[] = { (&MemberInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MemberInfo_t_0_0_0 = { 1, GenInst_MemberInfo_t_0_0_0_Types };
static const RuntimeType* GenInst_ICustomAttributeProvider_t3739891389_0_0_0_Types[] = { (&ICustomAttributeProvider_t3739891389_0_0_0) };
extern const Il2CppGenericInst GenInst_ICustomAttributeProvider_t3739891389_0_0_0 = { 1, GenInst_ICustomAttributeProvider_t3739891389_0_0_0_Types };
static const RuntimeType* GenInst__MemberInfo_t2009121772_0_0_0_Types[] = { (&_MemberInfo_t2009121772_0_0_0) };
extern const Il2CppGenericInst GenInst__MemberInfo_t2009121772_0_0_0 = { 1, GenInst__MemberInfo_t2009121772_0_0_0_Types };
static const RuntimeType* GenInst_Double_t4024153389_0_0_0_Types[] = { (&Double_t4024153389_0_0_0) };
extern const Il2CppGenericInst GenInst_Double_t4024153389_0_0_0 = { 1, GenInst_Double_t4024153389_0_0_0_Types };
static const RuntimeType* GenInst_Single_t2594644343_0_0_0_Types[] = { (&Single_t2594644343_0_0_0) };
extern const Il2CppGenericInst GenInst_Single_t2594644343_0_0_0 = { 1, GenInst_Single_t2594644343_0_0_0_Types };
static const RuntimeType* GenInst_Decimal_t3889304405_0_0_0_Types[] = { (&Decimal_t3889304405_0_0_0) };
extern const Il2CppGenericInst GenInst_Decimal_t3889304405_0_0_0 = { 1, GenInst_Decimal_t3889304405_0_0_0_Types };
static const RuntimeType* GenInst_Boolean_t2724601657_0_0_0_Types[] = { (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Boolean_t2724601657_0_0_0 = { 1, GenInst_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_Delegate_t1444972694_0_0_0_Types[] = { (&Delegate_t1444972694_0_0_0) };
extern const Il2CppGenericInst GenInst_Delegate_t1444972694_0_0_0 = { 1, GenInst_Delegate_t1444972694_0_0_0_Types };
static const RuntimeType* GenInst_ISerializable_t3088316472_0_0_0_Types[] = { (&ISerializable_t3088316472_0_0_0) };
extern const Il2CppGenericInst GenInst_ISerializable_t3088316472_0_0_0 = { 1, GenInst_ISerializable_t3088316472_0_0_0_Types };
static const RuntimeType* GenInst_ParameterInfo_t4224039251_0_0_0_Types[] = { (&ParameterInfo_t4224039251_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterInfo_t4224039251_0_0_0 = { 1, GenInst_ParameterInfo_t4224039251_0_0_0_Types };
static const RuntimeType* GenInst__ParameterInfo_t408303849_0_0_0_Types[] = { (&_ParameterInfo_t408303849_0_0_0) };
extern const Il2CppGenericInst GenInst__ParameterInfo_t408303849_0_0_0 = { 1, GenInst__ParameterInfo_t408303849_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_FieldInfo_t_0_0_0_Types[] = { (&FieldInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldInfo_t_0_0_0 = { 1, GenInst_FieldInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__FieldInfo_t2172126836_0_0_0_Types[] = { (&_FieldInfo_t2172126836_0_0_0) };
extern const Il2CppGenericInst GenInst__FieldInfo_t2172126836_0_0_0 = { 1, GenInst__FieldInfo_t2172126836_0_0_0_Types };
static const RuntimeType* GenInst_ParameterModifier_t3430991034_0_0_0_Types[] = { (&ParameterModifier_t3430991034_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterModifier_t3430991034_0_0_0 = { 1, GenInst_ParameterModifier_t3430991034_0_0_0_Types };
static const RuntimeType* GenInst_MethodInfo_t_0_0_0_Types[] = { (&MethodInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodInfo_t_0_0_0 = { 1, GenInst_MethodInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__MethodInfo_t2957008391_0_0_0_Types[] = { (&_MethodInfo_t2957008391_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodInfo_t2957008391_0_0_0 = { 1, GenInst__MethodInfo_t2957008391_0_0_0_Types };
static const RuntimeType* GenInst_MethodBase_t1529082644_0_0_0_Types[] = { (&MethodBase_t1529082644_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodBase_t1529082644_0_0_0 = { 1, GenInst_MethodBase_t1529082644_0_0_0_Types };
static const RuntimeType* GenInst__MethodBase_t6414478_0_0_0_Types[] = { (&_MethodBase_t6414478_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodBase_t6414478_0_0_0 = { 1, GenInst__MethodBase_t6414478_0_0_0_Types };
static const RuntimeType* GenInst_ConstructorInfo_t1000193748_0_0_0_Types[] = { (&ConstructorInfo_t1000193748_0_0_0) };
extern const Il2CppGenericInst GenInst_ConstructorInfo_t1000193748_0_0_0 = { 1, GenInst_ConstructorInfo_t1000193748_0_0_0_Types };
static const RuntimeType* GenInst__ConstructorInfo_t238983269_0_0_0_Types[] = { (&_ConstructorInfo_t238983269_0_0_0) };
extern const Il2CppGenericInst GenInst__ConstructorInfo_t238983269_0_0_0 = { 1, GenInst__ConstructorInfo_t238983269_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_Types[] = { (&IntPtr_t_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0 = { 1, GenInst_IntPtr_t_0_0_0_Types };
static const RuntimeType* GenInst_TableRange_t985732536_0_0_0_Types[] = { (&TableRange_t985732536_0_0_0) };
extern const Il2CppGenericInst GenInst_TableRange_t985732536_0_0_0 = { 1, GenInst_TableRange_t985732536_0_0_0_Types };
static const RuntimeType* GenInst_TailoringInfo_t3490008366_0_0_0_Types[] = { (&TailoringInfo_t3490008366_0_0_0) };
extern const Il2CppGenericInst GenInst_TailoringInfo_t3490008366_0_0_0 = { 1, GenInst_TailoringInfo_t3490008366_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3150225156_0_0_0_Types[] = { (&KeyValuePair_2_t3150225156_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3150225156_0_0_0 = { 1, GenInst_KeyValuePair_2_t3150225156_0_0_0_Types };
static const RuntimeType* GenInst_Link_t2954686504_0_0_0_Types[] = { (&Link_t2954686504_0_0_0) };
extern const Il2CppGenericInst GenInst_Link_t2954686504_0_0_0 = { 1, GenInst_Link_t2954686504_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_DictionaryEntry_t299448291_0_0_0_Types[] = { (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_DictionaryEntry_t299448291_0_0_0 = { 1, GenInst_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3150225156_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0), (&KeyValuePair_2_t3150225156_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3150225156_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3150225156_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t2946131084_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3010656940_0_0_0_Types[] = { (&KeyValuePair_2_t3010656940_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3010656940_0_0_0 = { 1, GenInst_KeyValuePair_2_t3010656940_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3010656940_0_0_0_Types[] = { (&String_t_0_0_0), (&Int32_t2946131084_0_0_0), (&KeyValuePair_2_t3010656940_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3010656940_0_0_0 = { 3, GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3010656940_0_0_0_Types };
static const RuntimeType* GenInst_Contraction_t780417899_0_0_0_Types[] = { (&Contraction_t780417899_0_0_0) };
extern const Il2CppGenericInst GenInst_Contraction_t780417899_0_0_0 = { 1, GenInst_Contraction_t780417899_0_0_0_Types };
static const RuntimeType* GenInst_Level2Map_t373027516_0_0_0_Types[] = { (&Level2Map_t373027516_0_0_0) };
extern const Il2CppGenericInst GenInst_Level2Map_t373027516_0_0_0 = { 1, GenInst_Level2Map_t373027516_0_0_0_Types };
static const RuntimeType* GenInst_BigInteger_t1659319351_0_0_0_Types[] = { (&BigInteger_t1659319351_0_0_0) };
extern const Il2CppGenericInst GenInst_BigInteger_t1659319351_0_0_0 = { 1, GenInst_BigInteger_t1659319351_0_0_0_Types };
static const RuntimeType* GenInst_KeySizes_t2881154755_0_0_0_Types[] = { (&KeySizes_t2881154755_0_0_0) };
extern const Il2CppGenericInst GenInst_KeySizes_t2881154755_0_0_0 = { 1, GenInst_KeySizes_t2881154755_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3005528154_0_0_0_Types[] = { (&KeyValuePair_2_t3005528154_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3005528154_0_0_0 = { 1, GenInst_KeyValuePair_2_t3005528154_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3005528154_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t3005528154_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3005528154_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3005528154_0_0_0_Types };
static const RuntimeType* GenInst_Slot_t3729905400_0_0_0_Types[] = { (&Slot_t3729905400_0_0_0) };
extern const Il2CppGenericInst GenInst_Slot_t3729905400_0_0_0 = { 1, GenInst_Slot_t3729905400_0_0_0_Types };
static const RuntimeType* GenInst_Slot_t2894400404_0_0_0_Types[] = { (&Slot_t2894400404_0_0_0) };
extern const Il2CppGenericInst GenInst_Slot_t2894400404_0_0_0 = { 1, GenInst_Slot_t2894400404_0_0_0_Types };
static const RuntimeType* GenInst_StackFrame_t1830301115_0_0_0_Types[] = { (&StackFrame_t1830301115_0_0_0) };
extern const Il2CppGenericInst GenInst_StackFrame_t1830301115_0_0_0 = { 1, GenInst_StackFrame_t1830301115_0_0_0_Types };
static const RuntimeType* GenInst_Calendar_t3859479017_0_0_0_Types[] = { (&Calendar_t3859479017_0_0_0) };
extern const Il2CppGenericInst GenInst_Calendar_t3859479017_0_0_0 = { 1, GenInst_Calendar_t3859479017_0_0_0_Types };
static const RuntimeType* GenInst_ModuleBuilder_t1725157840_0_0_0_Types[] = { (&ModuleBuilder_t1725157840_0_0_0) };
extern const Il2CppGenericInst GenInst_ModuleBuilder_t1725157840_0_0_0 = { 1, GenInst_ModuleBuilder_t1725157840_0_0_0_Types };
static const RuntimeType* GenInst__ModuleBuilder_t1204975354_0_0_0_Types[] = { (&_ModuleBuilder_t1204975354_0_0_0) };
extern const Il2CppGenericInst GenInst__ModuleBuilder_t1204975354_0_0_0 = { 1, GenInst__ModuleBuilder_t1204975354_0_0_0_Types };
static const RuntimeType* GenInst_Module_t2831991231_0_0_0_Types[] = { (&Module_t2831991231_0_0_0) };
extern const Il2CppGenericInst GenInst_Module_t2831991231_0_0_0 = { 1, GenInst_Module_t2831991231_0_0_0_Types };
static const RuntimeType* GenInst__Module_t3287617630_0_0_0_Types[] = { (&_Module_t3287617630_0_0_0) };
extern const Il2CppGenericInst GenInst__Module_t3287617630_0_0_0 = { 1, GenInst__Module_t3287617630_0_0_0_Types };
static const RuntimeType* GenInst_ParameterBuilder_t2723302902_0_0_0_Types[] = { (&ParameterBuilder_t2723302902_0_0_0) };
extern const Il2CppGenericInst GenInst_ParameterBuilder_t2723302902_0_0_0 = { 1, GenInst_ParameterBuilder_t2723302902_0_0_0_Types };
static const RuntimeType* GenInst__ParameterBuilder_t626099656_0_0_0_Types[] = { (&_ParameterBuilder_t626099656_0_0_0) };
extern const Il2CppGenericInst GenInst__ParameterBuilder_t626099656_0_0_0 = { 1, GenInst__ParameterBuilder_t626099656_0_0_0_Types };
static const RuntimeType* GenInst_TypeU5BU5D_t4189288004_0_0_0_Types[] = { (&TypeU5BU5D_t4189288004_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeU5BU5D_t4189288004_0_0_0 = { 1, GenInst_TypeU5BU5D_t4189288004_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeArray_0_0_0_Types[] = { (&RuntimeArray_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeArray_0_0_0 = { 1, GenInst_RuntimeArray_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_t3498861635_0_0_0_Types[] = { (&ICollection_t3498861635_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_t3498861635_0_0_0 = { 1, GenInst_ICollection_t3498861635_0_0_0_Types };
static const RuntimeType* GenInst_IList_t4241283331_0_0_0_Types[] = { (&IList_t4241283331_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_t4241283331_0_0_0 = { 1, GenInst_IList_t4241283331_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t4127410026_0_0_0_Types[] = { (&IList_1_t4127410026_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t4127410026_0_0_0 = { 1, GenInst_IList_1_t4127410026_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t362053986_0_0_0_Types[] = { (&ICollection_1_t362053986_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t362053986_0_0_0 = { 1, GenInst_ICollection_1_t362053986_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t2665815806_0_0_0_Types[] = { (&IEnumerable_1_t2665815806_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t2665815806_0_0_0 = { 1, GenInst_IEnumerable_1_t2665815806_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t2735078972_0_0_0_Types[] = { (&IList_1_t2735078972_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t2735078972_0_0_0 = { 1, GenInst_IList_1_t2735078972_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t3264690228_0_0_0_Types[] = { (&ICollection_1_t3264690228_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t3264690228_0_0_0 = { 1, GenInst_ICollection_1_t3264690228_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t1273484752_0_0_0_Types[] = { (&IEnumerable_1_t1273484752_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t1273484752_0_0_0 = { 1, GenInst_IEnumerable_1_t1273484752_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1384000914_0_0_0_Types[] = { (&IList_1_t1384000914_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1384000914_0_0_0 = { 1, GenInst_IList_1_t1384000914_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t1913612170_0_0_0_Types[] = { (&ICollection_1_t1913612170_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t1913612170_0_0_0 = { 1, GenInst_ICollection_1_t1913612170_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t4217373990_0_0_0_Types[] = { (&IEnumerable_1_t4217373990_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t4217373990_0_0_0 = { 1, GenInst_IEnumerable_1_t4217373990_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t3973997_0_0_0_Types[] = { (&IList_1_t3973997_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t3973997_0_0_0 = { 1, GenInst_IList_1_t3973997_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t533585253_0_0_0_Types[] = { (&ICollection_1_t533585253_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t533585253_0_0_0 = { 1, GenInst_ICollection_1_t533585253_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t2837347073_0_0_0_Types[] = { (&IEnumerable_1_t2837347073_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t2837347073_0_0_0 = { 1, GenInst_IEnumerable_1_t2837347073_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t2886617966_0_0_0_Types[] = { (&IList_1_t2886617966_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t2886617966_0_0_0 = { 1, GenInst_IList_1_t2886617966_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t3416229222_0_0_0_Types[] = { (&ICollection_1_t3416229222_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t3416229222_0_0_0 = { 1, GenInst_ICollection_1_t3416229222_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t1425023746_0_0_0_Types[] = { (&IEnumerable_1_t1425023746_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t1425023746_0_0_0 = { 1, GenInst_IEnumerable_1_t1425023746_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1155848349_0_0_0_Types[] = { (&IList_1_t1155848349_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1155848349_0_0_0 = { 1, GenInst_IList_1_t1155848349_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t1685459605_0_0_0_Types[] = { (&ICollection_1_t1685459605_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t1685459605_0_0_0 = { 1, GenInst_ICollection_1_t1685459605_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t3989221425_0_0_0_Types[] = { (&IEnumerable_1_t3989221425_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t3989221425_0_0_0 = { 1, GenInst_IEnumerable_1_t3989221425_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1948160659_0_0_0_Types[] = { (&IList_1_t1948160659_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1948160659_0_0_0 = { 1, GenInst_IList_1_t1948160659_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t2477771915_0_0_0_Types[] = { (&ICollection_1_t2477771915_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t2477771915_0_0_0 = { 1, GenInst_ICollection_1_t2477771915_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t486566439_0_0_0_Types[] = { (&IEnumerable_1_t486566439_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t486566439_0_0_0 = { 1, GenInst_IEnumerable_1_t486566439_0_0_0_Types };
static const RuntimeType* GenInst_ILTokenInfo_t4080941797_0_0_0_Types[] = { (&ILTokenInfo_t4080941797_0_0_0) };
extern const Il2CppGenericInst GenInst_ILTokenInfo_t4080941797_0_0_0 = { 1, GenInst_ILTokenInfo_t4080941797_0_0_0_Types };
static const RuntimeType* GenInst_LabelData_t3378720351_0_0_0_Types[] = { (&LabelData_t3378720351_0_0_0) };
extern const Il2CppGenericInst GenInst_LabelData_t3378720351_0_0_0 = { 1, GenInst_LabelData_t3378720351_0_0_0_Types };
static const RuntimeType* GenInst_LabelFixup_t3442793709_0_0_0_Types[] = { (&LabelFixup_t3442793709_0_0_0) };
extern const Il2CppGenericInst GenInst_LabelFixup_t3442793709_0_0_0 = { 1, GenInst_LabelFixup_t3442793709_0_0_0_Types };
static const RuntimeType* GenInst_GenericTypeParameterBuilder_t3165304919_0_0_0_Types[] = { (&GenericTypeParameterBuilder_t3165304919_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericTypeParameterBuilder_t3165304919_0_0_0 = { 1, GenInst_GenericTypeParameterBuilder_t3165304919_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeBuilder_t3519735045_0_0_0_Types[] = { (&CustomAttributeBuilder_t3519735045_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeBuilder_t3519735045_0_0_0 = { 1, GenInst_CustomAttributeBuilder_t3519735045_0_0_0_Types };
static const RuntimeType* GenInst__CustomAttributeBuilder_t508271582_0_0_0_Types[] = { (&_CustomAttributeBuilder_t508271582_0_0_0) };
extern const Il2CppGenericInst GenInst__CustomAttributeBuilder_t508271582_0_0_0 = { 1, GenInst__CustomAttributeBuilder_t508271582_0_0_0_Types };
static const RuntimeType* GenInst_RefEmitPermissionSet_t3776199698_0_0_0_Types[] = { (&RefEmitPermissionSet_t3776199698_0_0_0) };
extern const Il2CppGenericInst GenInst_RefEmitPermissionSet_t3776199698_0_0_0 = { 1, GenInst_RefEmitPermissionSet_t3776199698_0_0_0_Types };
static const RuntimeType* GenInst_TypeBuilder_t428610841_0_0_0_Types[] = { (&TypeBuilder_t428610841_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeBuilder_t428610841_0_0_0 = { 1, GenInst_TypeBuilder_t428610841_0_0_0_Types };
static const RuntimeType* GenInst__TypeBuilder_t1888918970_0_0_0_Types[] = { (&_TypeBuilder_t1888918970_0_0_0) };
extern const Il2CppGenericInst GenInst__TypeBuilder_t1888918970_0_0_0 = { 1, GenInst__TypeBuilder_t1888918970_0_0_0_Types };
static const RuntimeType* GenInst_MethodBuilder_t2550065105_0_0_0_Types[] = { (&MethodBuilder_t2550065105_0_0_0) };
extern const Il2CppGenericInst GenInst_MethodBuilder_t2550065105_0_0_0 = { 1, GenInst_MethodBuilder_t2550065105_0_0_0_Types };
static const RuntimeType* GenInst__MethodBuilder_t51529510_0_0_0_Types[] = { (&_MethodBuilder_t51529510_0_0_0) };
extern const Il2CppGenericInst GenInst__MethodBuilder_t51529510_0_0_0 = { 1, GenInst__MethodBuilder_t51529510_0_0_0_Types };
static const RuntimeType* GenInst_FieldBuilder_t1795031134_0_0_0_Types[] = { (&FieldBuilder_t1795031134_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldBuilder_t1795031134_0_0_0 = { 1, GenInst_FieldBuilder_t1795031134_0_0_0_Types };
static const RuntimeType* GenInst__FieldBuilder_t2176048174_0_0_0_Types[] = { (&_FieldBuilder_t2176048174_0_0_0) };
extern const Il2CppGenericInst GenInst__FieldBuilder_t2176048174_0_0_0 = { 1, GenInst__FieldBuilder_t2176048174_0_0_0_Types };
static const RuntimeType* GenInst_MonoResource_t110510560_0_0_0_Types[] = { (&MonoResource_t110510560_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoResource_t110510560_0_0_0 = { 1, GenInst_MonoResource_t110510560_0_0_0_Types };
static const RuntimeType* GenInst_ConstructorBuilder_t3862957018_0_0_0_Types[] = { (&ConstructorBuilder_t3862957018_0_0_0) };
extern const Il2CppGenericInst GenInst_ConstructorBuilder_t3862957018_0_0_0 = { 1, GenInst_ConstructorBuilder_t3862957018_0_0_0_Types };
static const RuntimeType* GenInst__ConstructorBuilder_t10194797_0_0_0_Types[] = { (&_ConstructorBuilder_t10194797_0_0_0) };
extern const Il2CppGenericInst GenInst__ConstructorBuilder_t10194797_0_0_0 = { 1, GenInst__ConstructorBuilder_t10194797_0_0_0_Types };
static const RuntimeType* GenInst_PropertyBuilder_t444456996_0_0_0_Types[] = { (&PropertyBuilder_t444456996_0_0_0) };
extern const Il2CppGenericInst GenInst_PropertyBuilder_t444456996_0_0_0 = { 1, GenInst_PropertyBuilder_t444456996_0_0_0_Types };
static const RuntimeType* GenInst__PropertyBuilder_t2034357485_0_0_0_Types[] = { (&_PropertyBuilder_t2034357485_0_0_0) };
extern const Il2CppGenericInst GenInst__PropertyBuilder_t2034357485_0_0_0 = { 1, GenInst__PropertyBuilder_t2034357485_0_0_0_Types };
static const RuntimeType* GenInst_PropertyInfo_t_0_0_0_Types[] = { (&PropertyInfo_t_0_0_0) };
extern const Il2CppGenericInst GenInst_PropertyInfo_t_0_0_0 = { 1, GenInst_PropertyInfo_t_0_0_0_Types };
static const RuntimeType* GenInst__PropertyInfo_t3778442912_0_0_0_Types[] = { (&_PropertyInfo_t3778442912_0_0_0) };
extern const Il2CppGenericInst GenInst__PropertyInfo_t3778442912_0_0_0 = { 1, GenInst__PropertyInfo_t3778442912_0_0_0_Types };
static const RuntimeType* GenInst_EventBuilder_t3271757496_0_0_0_Types[] = { (&EventBuilder_t3271757496_0_0_0) };
extern const Il2CppGenericInst GenInst_EventBuilder_t3271757496_0_0_0 = { 1, GenInst_EventBuilder_t3271757496_0_0_0_Types };
static const RuntimeType* GenInst__EventBuilder_t360474911_0_0_0_Types[] = { (&_EventBuilder_t360474911_0_0_0) };
extern const Il2CppGenericInst GenInst__EventBuilder_t360474911_0_0_0 = { 1, GenInst__EventBuilder_t360474911_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_Types[] = { (&CustomAttributeTypedArgument_t437198719_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeTypedArgument_t437198719_0_0_0 = { 1, GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_Types[] = { (&CustomAttributeNamedArgument_t3066689011_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0 = { 1, GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeData_t2415778318_0_0_0_Types[] = { (&CustomAttributeData_t2415778318_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeData_t2415778318_0_0_0 = { 1, GenInst_CustomAttributeData_t2415778318_0_0_0_Types };
static const RuntimeType* GenInst_ResourceInfo_t26720911_0_0_0_Types[] = { (&ResourceInfo_t26720911_0_0_0) };
extern const Il2CppGenericInst GenInst_ResourceInfo_t26720911_0_0_0 = { 1, GenInst_ResourceInfo_t26720911_0_0_0_Types };
static const RuntimeType* GenInst_ResourceCacheItem_t2684218735_0_0_0_Types[] = { (&ResourceCacheItem_t2684218735_0_0_0) };
extern const Il2CppGenericInst GenInst_ResourceCacheItem_t2684218735_0_0_0 = { 1, GenInst_ResourceCacheItem_t2684218735_0_0_0_Types };
static const RuntimeType* GenInst_IContextProperty_t3454453605_0_0_0_Types[] = { (&IContextProperty_t3454453605_0_0_0) };
extern const Il2CppGenericInst GenInst_IContextProperty_t3454453605_0_0_0 = { 1, GenInst_IContextProperty_t3454453605_0_0_0_Types };
static const RuntimeType* GenInst_Header_t4048742355_0_0_0_Types[] = { (&Header_t4048742355_0_0_0) };
extern const Il2CppGenericInst GenInst_Header_t4048742355_0_0_0 = { 1, GenInst_Header_t4048742355_0_0_0_Types };
static const RuntimeType* GenInst_ITrackingHandler_t3982758781_0_0_0_Types[] = { (&ITrackingHandler_t3982758781_0_0_0) };
extern const Il2CppGenericInst GenInst_ITrackingHandler_t3982758781_0_0_0 = { 1, GenInst_ITrackingHandler_t3982758781_0_0_0_Types };
static const RuntimeType* GenInst_IContextAttribute_t1709749317_0_0_0_Types[] = { (&IContextAttribute_t1709749317_0_0_0) };
extern const Il2CppGenericInst GenInst_IContextAttribute_t1709749317_0_0_0 = { 1, GenInst_IContextAttribute_t1709749317_0_0_0_Types };
static const RuntimeType* GenInst_DateTime_t4019639461_0_0_0_Types[] = { (&DateTime_t4019639461_0_0_0) };
extern const Il2CppGenericInst GenInst_DateTime_t4019639461_0_0_0 = { 1, GenInst_DateTime_t4019639461_0_0_0_Types };
static const RuntimeType* GenInst_TimeSpan_t2594328967_0_0_0_Types[] = { (&TimeSpan_t2594328967_0_0_0) };
extern const Il2CppGenericInst GenInst_TimeSpan_t2594328967_0_0_0 = { 1, GenInst_TimeSpan_t2594328967_0_0_0_Types };
static const RuntimeType* GenInst_TypeTag_t696993974_0_0_0_Types[] = { (&TypeTag_t696993974_0_0_0) };
extern const Il2CppGenericInst GenInst_TypeTag_t696993974_0_0_0 = { 1, GenInst_TypeTag_t696993974_0_0_0_Types };
static const RuntimeType* GenInst_MonoType_t_0_0_0_Types[] = { (&MonoType_t_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoType_t_0_0_0 = { 1, GenInst_MonoType_t_0_0_0_Types };
static const RuntimeType* GenInst_StrongName_t2807758910_0_0_0_Types[] = { (&StrongName_t2807758910_0_0_0) };
extern const Il2CppGenericInst GenInst_StrongName_t2807758910_0_0_0 = { 1, GenInst_StrongName_t2807758910_0_0_0_Types };
static const RuntimeType* GenInst_IBuiltInEvidence_t4053645731_0_0_0_Types[] = { (&IBuiltInEvidence_t4053645731_0_0_0) };
extern const Il2CppGenericInst GenInst_IBuiltInEvidence_t4053645731_0_0_0 = { 1, GenInst_IBuiltInEvidence_t4053645731_0_0_0_Types };
static const RuntimeType* GenInst_IIdentityPermissionFactory_t3236790479_0_0_0_Types[] = { (&IIdentityPermissionFactory_t3236790479_0_0_0) };
extern const Il2CppGenericInst GenInst_IIdentityPermissionFactory_t3236790479_0_0_0 = { 1, GenInst_IIdentityPermissionFactory_t3236790479_0_0_0_Types };
static const RuntimeType* GenInst_DateTimeOffset_t2136805232_0_0_0_Types[] = { (&DateTimeOffset_t2136805232_0_0_0) };
extern const Il2CppGenericInst GenInst_DateTimeOffset_t2136805232_0_0_0 = { 1, GenInst_DateTimeOffset_t2136805232_0_0_0_Types };
static const RuntimeType* GenInst_Guid_t_0_0_0_Types[] = { (&Guid_t_0_0_0) };
extern const Il2CppGenericInst GenInst_Guid_t_0_0_0 = { 1, GenInst_Guid_t_0_0_0_Types };
static const RuntimeType* GenInst_Version_t506497972_0_0_0_Types[] = { (&Version_t506497972_0_0_0) };
extern const Il2CppGenericInst GenInst_Version_t506497972_0_0_0 = { 1, GenInst_Version_t506497972_0_0_0_Types };
static const RuntimeType* GenInst_BigInteger_t1659319352_0_0_0_Types[] = { (&BigInteger_t1659319352_0_0_0) };
extern const Il2CppGenericInst GenInst_BigInteger_t1659319352_0_0_0 = { 1, GenInst_BigInteger_t1659319352_0_0_0_Types };
static const RuntimeType* GenInst_ByteU5BU5D_t2643433246_0_0_0_Types[] = { (&ByteU5BU5D_t2643433246_0_0_0) };
extern const Il2CppGenericInst GenInst_ByteU5BU5D_t2643433246_0_0_0 = { 1, GenInst_ByteU5BU5D_t2643433246_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t1743427608_0_0_0_Types[] = { (&IList_1_t1743427608_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t1743427608_0_0_0 = { 1, GenInst_IList_1_t1743427608_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t2273038864_0_0_0_Types[] = { (&ICollection_1_t2273038864_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t2273038864_0_0_0 = { 1, GenInst_ICollection_1_t2273038864_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t281833388_0_0_0_Types[] = { (&IEnumerable_1_t281833388_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t281833388_0_0_0 = { 1, GenInst_IEnumerable_1_t281833388_0_0_0_Types };
static const RuntimeType* GenInst_X509Certificate_t953704339_0_0_0_Types[] = { (&X509Certificate_t953704339_0_0_0) };
extern const Il2CppGenericInst GenInst_X509Certificate_t953704339_0_0_0 = { 1, GenInst_X509Certificate_t953704339_0_0_0_Types };
static const RuntimeType* GenInst_IDeserializationCallback_t3942415194_0_0_0_Types[] = { (&IDeserializationCallback_t3942415194_0_0_0) };
extern const Il2CppGenericInst GenInst_IDeserializationCallback_t3942415194_0_0_0 = { 1, GenInst_IDeserializationCallback_t3942415194_0_0_0_Types };
static const RuntimeType* GenInst_ClientCertificateType_t1963204790_0_0_0_Types[] = { (&ClientCertificateType_t1963204790_0_0_0) };
extern const Il2CppGenericInst GenInst_ClientCertificateType_t1963204790_0_0_0 = { 1, GenInst_ClientCertificateType_t1963204790_0_0_0_Types };
static const RuntimeType* GenInst_X509ChainStatus_t1563713867_0_0_0_Types[] = { (&X509ChainStatus_t1563713867_0_0_0) };
extern const Il2CppGenericInst GenInst_X509ChainStatus_t1563713867_0_0_0 = { 1, GenInst_X509ChainStatus_t1563713867_0_0_0_Types };
static const RuntimeType* GenInst_IPAddress_t1944286148_0_0_0_Types[] = { (&IPAddress_t1944286148_0_0_0) };
extern const Il2CppGenericInst GenInst_IPAddress_t1944286148_0_0_0 = { 1, GenInst_IPAddress_t1944286148_0_0_0_Types };
static const RuntimeType* GenInst_ArraySegment_1_t2744003576_0_0_0_Types[] = { (&ArraySegment_1_t2744003576_0_0_0) };
extern const Il2CppGenericInst GenInst_ArraySegment_1_t2744003576_0_0_0 = { 1, GenInst_ArraySegment_1_t2744003576_0_0_0_Types };
static const RuntimeType* GenInst_Cookie_t2357423313_0_0_0_Types[] = { (&Cookie_t2357423313_0_0_0) };
extern const Il2CppGenericInst GenInst_Cookie_t2357423313_0_0_0 = { 1, GenInst_Cookie_t2357423313_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2928695729_0_0_0_Types[] = { (&KeyValuePair_2_t2928695729_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2928695729_0_0_0 = { 1, GenInst_KeyValuePair_2_t2928695729_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t2724601657_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t2724601657_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t2724601657_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2928695729_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Boolean_t2724601657_0_0_0), (&KeyValuePair_2_t2928695729_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2928695729_0_0_0 = { 3, GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2928695729_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t2724601657_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2789127513_0_0_0_Types[] = { (&KeyValuePair_2_t2789127513_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2789127513_0_0_0 = { 1, GenInst_KeyValuePair_2_t2789127513_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2789127513_0_0_0_Types[] = { (&String_t_0_0_0), (&Boolean_t2724601657_0_0_0), (&KeyValuePair_2_t2789127513_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2789127513_0_0_0 = { 3, GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2789127513_0_0_0_Types };
static const RuntimeType* GenInst_Capture_t2838260575_0_0_0_Types[] = { (&Capture_t2838260575_0_0_0) };
extern const Il2CppGenericInst GenInst_Capture_t2838260575_0_0_0 = { 1, GenInst_Capture_t2838260575_0_0_0_Types };
static const RuntimeType* GenInst_Group_t2467218104_0_0_0_Types[] = { (&Group_t2467218104_0_0_0) };
extern const Il2CppGenericInst GenInst_Group_t2467218104_0_0_0 = { 1, GenInst_Group_t2467218104_0_0_0_Types };
static const RuntimeType* GenInst_Mark_t1992438718_0_0_0_Types[] = { (&Mark_t1992438718_0_0_0) };
extern const Il2CppGenericInst GenInst_Mark_t1992438718_0_0_0 = { 1, GenInst_Mark_t1992438718_0_0_0_Types };
static const RuntimeType* GenInst_UriScheme_t649781592_0_0_0_Types[] = { (&UriScheme_t649781592_0_0_0) };
extern const Il2CppGenericInst GenInst_UriScheme_t649781592_0_0_0 = { 1, GenInst_UriScheme_t649781592_0_0_0_Types };
static const RuntimeType* GenInst_Link_t3921545329_0_0_0_Types[] = { (&Link_t3921545329_0_0_0) };
extern const Il2CppGenericInst GenInst_Link_t3921545329_0_0_0 = { 1, GenInst_Link_t3921545329_0_0_0_Types };
static const RuntimeType* GenInst_AsyncOperation_t3810459996_0_0_0_Types[] = { (&AsyncOperation_t3810459996_0_0_0) };
extern const Il2CppGenericInst GenInst_AsyncOperation_t3810459996_0_0_0 = { 1, GenInst_AsyncOperation_t3810459996_0_0_0_Types };
static const RuntimeType* GenInst_Camera_t274442537_0_0_0_Types[] = { (&Camera_t274442537_0_0_0) };
extern const Il2CppGenericInst GenInst_Camera_t274442537_0_0_0 = { 1, GenInst_Camera_t274442537_0_0_0_Types };
static const RuntimeType* GenInst_Behaviour_t789096462_0_0_0_Types[] = { (&Behaviour_t789096462_0_0_0) };
extern const Il2CppGenericInst GenInst_Behaviour_t789096462_0_0_0 = { 1, GenInst_Behaviour_t789096462_0_0_0_Types };
static const RuntimeType* GenInst_Component_t3460329512_0_0_0_Types[] = { (&Component_t3460329512_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_t3460329512_0_0_0 = { 1, GenInst_Component_t3460329512_0_0_0_Types };
static const RuntimeType* GenInst_Object_t3285695601_0_0_0_Types[] = { (&Object_t3285695601_0_0_0) };
extern const Il2CppGenericInst GenInst_Object_t3285695601_0_0_0 = { 1, GenInst_Object_t3285695601_0_0_0_Types };
static const RuntimeType* GenInst_Display_t3775361438_0_0_0_Types[] = { (&Display_t3775361438_0_0_0) };
extern const Il2CppGenericInst GenInst_Display_t3775361438_0_0_0 = { 1, GenInst_Display_t3775361438_0_0_0_Types };
static const RuntimeType* GenInst_Keyframe_t1299923720_0_0_0_Types[] = { (&Keyframe_t1299923720_0_0_0) };
extern const Il2CppGenericInst GenInst_Keyframe_t1299923720_0_0_0 = { 1, GenInst_Keyframe_t1299923720_0_0_0_Types };
static const RuntimeType* GenInst_Vector3_t2486370225_0_0_0_Types[] = { (&Vector3_t2486370225_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector3_t2486370225_0_0_0 = { 1, GenInst_Vector3_t2486370225_0_0_0_Types };
static const RuntimeType* GenInst_Vector4_t4214292213_0_0_0_Types[] = { (&Vector4_t4214292213_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector4_t4214292213_0_0_0 = { 1, GenInst_Vector4_t4214292213_0_0_0_Types };
static const RuntimeType* GenInst_Vector2_t1743417791_0_0_0_Types[] = { (&Vector2_t1743417791_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector2_t1743417791_0_0_0 = { 1, GenInst_Vector2_t1743417791_0_0_0_Types };
static const RuntimeType* GenInst_Color32_t1281607702_0_0_0_Types[] = { (&Color32_t1281607702_0_0_0) };
extern const Il2CppGenericInst GenInst_Color32_t1281607702_0_0_0 = { 1, GenInst_Color32_t1281607702_0_0_0_Types };
static const RuntimeType* GenInst_Playable_t1563095691_0_0_0_Types[] = { (&Playable_t1563095691_0_0_0) };
extern const Il2CppGenericInst GenInst_Playable_t1563095691_0_0_0 = { 1, GenInst_Playable_t1563095691_0_0_0_Types };
static const RuntimeType* GenInst_PlayableOutput_t2224788333_0_0_0_Types[] = { (&PlayableOutput_t2224788333_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayableOutput_t2224788333_0_0_0 = { 1, GenInst_PlayableOutput_t2224788333_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2429659677_0_0_0_LoadSceneMode_t38367264_0_0_0_Types[] = { (&Scene_t2429659677_0_0_0), (&LoadSceneMode_t38367264_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2429659677_0_0_0_LoadSceneMode_t38367264_0_0_0 = { 2, GenInst_Scene_t2429659677_0_0_0_LoadSceneMode_t38367264_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2429659677_0_0_0_Types[] = { (&Scene_t2429659677_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2429659677_0_0_0 = { 1, GenInst_Scene_t2429659677_0_0_0_Types };
static const RuntimeType* GenInst_Scene_t2429659677_0_0_0_Scene_t2429659677_0_0_0_Types[] = { (&Scene_t2429659677_0_0_0), (&Scene_t2429659677_0_0_0) };
extern const Il2CppGenericInst GenInst_Scene_t2429659677_0_0_0_Scene_t2429659677_0_0_0 = { 2, GenInst_Scene_t2429659677_0_0_0_Scene_t2429659677_0_0_0_Types };
static const RuntimeType* GenInst_SpriteAtlas_t2907583744_0_0_0_Types[] = { (&SpriteAtlas_t2907583744_0_0_0) };
extern const Il2CppGenericInst GenInst_SpriteAtlas_t2907583744_0_0_0 = { 1, GenInst_SpriteAtlas_t2907583744_0_0_0_Types };
static const RuntimeType* GenInst_DisallowMultipleComponent_t1485140390_0_0_0_Types[] = { (&DisallowMultipleComponent_t1485140390_0_0_0) };
extern const Il2CppGenericInst GenInst_DisallowMultipleComponent_t1485140390_0_0_0 = { 1, GenInst_DisallowMultipleComponent_t1485140390_0_0_0_Types };
static const RuntimeType* GenInst_Attribute_t2363954793_0_0_0_Types[] = { (&Attribute_t2363954793_0_0_0) };
extern const Il2CppGenericInst GenInst_Attribute_t2363954793_0_0_0 = { 1, GenInst_Attribute_t2363954793_0_0_0_Types };
static const RuntimeType* GenInst__Attribute_t705991232_0_0_0_Types[] = { (&_Attribute_t705991232_0_0_0) };
extern const Il2CppGenericInst GenInst__Attribute_t705991232_0_0_0 = { 1, GenInst__Attribute_t705991232_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteInEditMode_t2060420173_0_0_0_Types[] = { (&ExecuteInEditMode_t2060420173_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteInEditMode_t2060420173_0_0_0 = { 1, GenInst_ExecuteInEditMode_t2060420173_0_0_0_Types };
static const RuntimeType* GenInst_RequireComponent_t2601444532_0_0_0_Types[] = { (&RequireComponent_t2601444532_0_0_0) };
extern const Il2CppGenericInst GenInst_RequireComponent_t2601444532_0_0_0 = { 1, GenInst_RequireComponent_t2601444532_0_0_0_Types };
static const RuntimeType* GenInst_HitInfo_t3242551441_0_0_0_Types[] = { (&HitInfo_t3242551441_0_0_0) };
extern const Il2CppGenericInst GenInst_HitInfo_t3242551441_0_0_0 = { 1, GenInst_HitInfo_t3242551441_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 4, GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_PersistentCall_t1303572475_0_0_0_Types[] = { (&PersistentCall_t1303572475_0_0_0) };
extern const Il2CppGenericInst GenInst_PersistentCall_t1303572475_0_0_0 = { 1, GenInst_PersistentCall_t1303572475_0_0_0_Types };
static const RuntimeType* GenInst_BaseInvokableCall_t1790754149_0_0_0_Types[] = { (&BaseInvokableCall_t1790754149_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseInvokableCall_t1790754149_0_0_0 = { 1, GenInst_BaseInvokableCall_t1790754149_0_0_0_Types };
static const RuntimeType* GenInst_WorkRequest_t1627094759_0_0_0_Types[] = { (&WorkRequest_t1627094759_0_0_0) };
extern const Il2CppGenericInst GenInst_WorkRequest_t1627094759_0_0_0 = { 1, GenInst_WorkRequest_t1627094759_0_0_0_Types };
static const RuntimeType* GenInst_PlayableBinding_t2631396557_0_0_0_Types[] = { (&PlayableBinding_t2631396557_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayableBinding_t2631396557_0_0_0 = { 1, GenInst_PlayableBinding_t2631396557_0_0_0_Types };
static const RuntimeType* GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Types[] = { (&MessageTypeSubscribers_t3519534061_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageTypeSubscribers_t3519534061_0_0_0 = { 1, GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Types };
static const RuntimeType* GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&MessageTypeSubscribers_t3519534061_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_MessageEventArgs_t583925932_0_0_0_Types[] = { (&MessageEventArgs_t583925932_0_0_0) };
extern const Il2CppGenericInst GenInst_MessageEventArgs_t583925932_0_0_0 = { 1, GenInst_MessageEventArgs_t583925932_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t842734143_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0 = { 2, GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t573483709_0_0_0_Types[] = { (&KeyValuePair_2_t573483709_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t573483709_0_0_0 = { 1, GenInst_KeyValuePair_2_t573483709_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_IntPtr_t_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&IntPtr_t_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_IntPtr_t_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_IntPtr_t_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t573483709_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t573483709_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t573483709_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t573483709_0_0_0_Types };
static const RuntimeType* GenInst_WeakReference_t842734143_0_0_0_Types[] = { (&WeakReference_t842734143_0_0_0) };
extern const Il2CppGenericInst GenInst_WeakReference_t842734143_0_0_0 = { 1, GenInst_WeakReference_t842734143_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t842734143_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2909751066_0_0_0_Types[] = { (&KeyValuePair_2_t2909751066_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2909751066_0_0_0 = { 1, GenInst_KeyValuePair_2_t2909751066_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_KeyValuePair_2_t2909751066_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&WeakReference_t842734143_0_0_0), (&KeyValuePair_2_t2909751066_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_KeyValuePair_2_t2909751066_0_0_0 = { 3, GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_KeyValuePair_2_t2909751066_0_0_0_Types };
static const RuntimeType* GenInst_AudioSpatializerExtensionDefinition_t3945920284_0_0_0_Types[] = { (&AudioSpatializerExtensionDefinition_t3945920284_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioSpatializerExtensionDefinition_t3945920284_0_0_0 = { 1, GenInst_AudioSpatializerExtensionDefinition_t3945920284_0_0_0_Types };
static const RuntimeType* GenInst_AudioAmbisonicExtensionDefinition_t308490681_0_0_0_Types[] = { (&AudioAmbisonicExtensionDefinition_t308490681_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioAmbisonicExtensionDefinition_t308490681_0_0_0 = { 1, GenInst_AudioAmbisonicExtensionDefinition_t308490681_0_0_0_Types };
static const RuntimeType* GenInst_AudioSourceExtension_t3646449378_0_0_0_Types[] = { (&AudioSourceExtension_t3646449378_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioSourceExtension_t3646449378_0_0_0 = { 1, GenInst_AudioSourceExtension_t3646449378_0_0_0_Types };
static const RuntimeType* GenInst_ScriptableObject_t2661394107_0_0_0_Types[] = { (&ScriptableObject_t2661394107_0_0_0) };
extern const Il2CppGenericInst GenInst_ScriptableObject_t2661394107_0_0_0 = { 1, GenInst_ScriptableObject_t2661394107_0_0_0_Types };
static const RuntimeType* GenInst_AudioMixerPlayable_t4111045564_0_0_0_Types[] = { (&AudioMixerPlayable_t4111045564_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioMixerPlayable_t4111045564_0_0_0 = { 1, GenInst_AudioMixerPlayable_t4111045564_0_0_0_Types };
static const RuntimeType* GenInst_AudioClipPlayable_t1629551309_0_0_0_Types[] = { (&AudioClipPlayable_t1629551309_0_0_0) };
extern const Il2CppGenericInst GenInst_AudioClipPlayable_t1629551309_0_0_0 = { 1, GenInst_AudioClipPlayable_t1629551309_0_0_0_Types };
static const RuntimeType* GenInst_Rigidbody2D_t1473351060_0_0_0_Types[] = { (&Rigidbody2D_t1473351060_0_0_0) };
extern const Il2CppGenericInst GenInst_Rigidbody2D_t1473351060_0_0_0 = { 1, GenInst_Rigidbody2D_t1473351060_0_0_0_Types };
static const RuntimeType* GenInst_Font_t82789257_0_0_0_Types[] = { (&Font_t82789257_0_0_0) };
extern const Il2CppGenericInst GenInst_Font_t82789257_0_0_0 = { 1, GenInst_Font_t82789257_0_0_0_Types };
static const RuntimeType* GenInst_UIVertex_t3704361653_0_0_0_Types[] = { (&UIVertex_t3704361653_0_0_0) };
extern const Il2CppGenericInst GenInst_UIVertex_t3704361653_0_0_0 = { 1, GenInst_UIVertex_t3704361653_0_0_0_Types };
static const RuntimeType* GenInst_UICharInfo_t498913270_0_0_0_Types[] = { (&UICharInfo_t498913270_0_0_0) };
extern const Il2CppGenericInst GenInst_UICharInfo_t498913270_0_0_0 = { 1, GenInst_UICharInfo_t498913270_0_0_0_Types };
static const RuntimeType* GenInst_UILineInfo_t2500817891_0_0_0_Types[] = { (&UILineInfo_t2500817891_0_0_0) };
extern const Il2CppGenericInst GenInst_UILineInfo_t2500817891_0_0_0 = { 1, GenInst_UILineInfo_t2500817891_0_0_0_Types };
static const RuntimeType* GenInst_AnimationClipPlayable_t1300644386_0_0_0_Types[] = { (&AnimationClipPlayable_t1300644386_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimationClipPlayable_t1300644386_0_0_0 = { 1, GenInst_AnimationClipPlayable_t1300644386_0_0_0_Types };
static const RuntimeType* GenInst_AnimationLayerMixerPlayable_t1849272991_0_0_0_Types[] = { (&AnimationLayerMixerPlayable_t1849272991_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimationLayerMixerPlayable_t1849272991_0_0_0 = { 1, GenInst_AnimationLayerMixerPlayable_t1849272991_0_0_0_Types };
static const RuntimeType* GenInst_AnimationMixerPlayable_t904356521_0_0_0_Types[] = { (&AnimationMixerPlayable_t904356521_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimationMixerPlayable_t904356521_0_0_0 = { 1, GenInst_AnimationMixerPlayable_t904356521_0_0_0_Types };
static const RuntimeType* GenInst_AnimationOffsetPlayable_t1324066292_0_0_0_Types[] = { (&AnimationOffsetPlayable_t1324066292_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimationOffsetPlayable_t1324066292_0_0_0 = { 1, GenInst_AnimationOffsetPlayable_t1324066292_0_0_0_Types };
static const RuntimeType* GenInst_AnimatorControllerPlayable_t567321136_0_0_0_Types[] = { (&AnimatorControllerPlayable_t567321136_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimatorControllerPlayable_t567321136_0_0_0 = { 1, GenInst_AnimatorControllerPlayable_t567321136_0_0_0_Types };
static const RuntimeType* GenInst_Boolean_t2724601657_0_0_0_String_t_0_0_0_Types[] = { (&Boolean_t2724601657_0_0_0), (&String_t_0_0_0) };
extern const Il2CppGenericInst GenInst_Boolean_t2724601657_0_0_0_String_t_0_0_0 = { 2, GenInst_Boolean_t2724601657_0_0_0_String_t_0_0_0_Types };
static const RuntimeType* GenInst_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0_Types[] = { (&Boolean_t2724601657_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_AchievementDescription_t1798731768_0_0_0_Types[] = { (&AchievementDescription_t1798731768_0_0_0) };
extern const Il2CppGenericInst GenInst_AchievementDescription_t1798731768_0_0_0 = { 1, GenInst_AchievementDescription_t1798731768_0_0_0_Types };
static const RuntimeType* GenInst_IAchievementDescription_t3768105385_0_0_0_Types[] = { (&IAchievementDescription_t3768105385_0_0_0) };
extern const Il2CppGenericInst GenInst_IAchievementDescription_t3768105385_0_0_0 = { 1, GenInst_IAchievementDescription_t3768105385_0_0_0_Types };
static const RuntimeType* GenInst_UserProfile_t2681963727_0_0_0_Types[] = { (&UserProfile_t2681963727_0_0_0) };
extern const Il2CppGenericInst GenInst_UserProfile_t2681963727_0_0_0 = { 1, GenInst_UserProfile_t2681963727_0_0_0_Types };
static const RuntimeType* GenInst_IUserProfile_t509133715_0_0_0_Types[] = { (&IUserProfile_t509133715_0_0_0) };
extern const Il2CppGenericInst GenInst_IUserProfile_t509133715_0_0_0 = { 1, GenInst_IUserProfile_t509133715_0_0_0_Types };
static const RuntimeType* GenInst_GcLeaderboard_t3783886338_0_0_0_Types[] = { (&GcLeaderboard_t3783886338_0_0_0) };
extern const Il2CppGenericInst GenInst_GcLeaderboard_t3783886338_0_0_0 = { 1, GenInst_GcLeaderboard_t3783886338_0_0_0_Types };
static const RuntimeType* GenInst_IAchievementDescriptionU5BU5D_t2469250452_0_0_0_Types[] = { (&IAchievementDescriptionU5BU5D_t2469250452_0_0_0) };
extern const Il2CppGenericInst GenInst_IAchievementDescriptionU5BU5D_t2469250452_0_0_0 = { 1, GenInst_IAchievementDescriptionU5BU5D_t2469250452_0_0_0_Types };
static const RuntimeType* GenInst_IAchievementU5BU5D_t3797953173_0_0_0_Types[] = { (&IAchievementU5BU5D_t3797953173_0_0_0) };
extern const Il2CppGenericInst GenInst_IAchievementU5BU5D_t3797953173_0_0_0 = { 1, GenInst_IAchievementU5BU5D_t3797953173_0_0_0_Types };
static const RuntimeType* GenInst_IAchievement_t564068860_0_0_0_Types[] = { (&IAchievement_t564068860_0_0_0) };
extern const Il2CppGenericInst GenInst_IAchievement_t564068860_0_0_0 = { 1, GenInst_IAchievement_t564068860_0_0_0_Types };
static const RuntimeType* GenInst_GcAchievementData_t1914197125_0_0_0_Types[] = { (&GcAchievementData_t1914197125_0_0_0) };
extern const Il2CppGenericInst GenInst_GcAchievementData_t1914197125_0_0_0 = { 1, GenInst_GcAchievementData_t1914197125_0_0_0_Types };
static const RuntimeType* GenInst_Achievement_t1636619461_0_0_0_Types[] = { (&Achievement_t1636619461_0_0_0) };
extern const Il2CppGenericInst GenInst_Achievement_t1636619461_0_0_0 = { 1, GenInst_Achievement_t1636619461_0_0_0_Types };
static const RuntimeType* GenInst_IScoreU5BU5D_t768188392_0_0_0_Types[] = { (&IScoreU5BU5D_t768188392_0_0_0) };
extern const Il2CppGenericInst GenInst_IScoreU5BU5D_t768188392_0_0_0 = { 1, GenInst_IScoreU5BU5D_t768188392_0_0_0_Types };
static const RuntimeType* GenInst_IScore_t2787079909_0_0_0_Types[] = { (&IScore_t2787079909_0_0_0) };
extern const Il2CppGenericInst GenInst_IScore_t2787079909_0_0_0 = { 1, GenInst_IScore_t2787079909_0_0_0_Types };
static const RuntimeType* GenInst_GcScoreData_t3281375178_0_0_0_Types[] = { (&GcScoreData_t3281375178_0_0_0) };
extern const Il2CppGenericInst GenInst_GcScoreData_t3281375178_0_0_0 = { 1, GenInst_GcScoreData_t3281375178_0_0_0_Types };
static const RuntimeType* GenInst_Score_t2475763700_0_0_0_Types[] = { (&Score_t2475763700_0_0_0) };
extern const Il2CppGenericInst GenInst_Score_t2475763700_0_0_0 = { 1, GenInst_Score_t2475763700_0_0_0_Types };
static const RuntimeType* GenInst_IUserProfileU5BU5D_t859854018_0_0_0_Types[] = { (&IUserProfileU5BU5D_t859854018_0_0_0) };
extern const Il2CppGenericInst GenInst_IUserProfileU5BU5D_t859854018_0_0_0 = { 1, GenInst_IUserProfileU5BU5D_t859854018_0_0_0_Types };
static const RuntimeType* GenInst_GUILayoutOption_t3642022624_0_0_0_Types[] = { (&GUILayoutOption_t3642022624_0_0_0) };
extern const Il2CppGenericInst GenInst_GUILayoutOption_t3642022624_0_0_0 = { 1, GenInst_GUILayoutOption_t3642022624_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&LayoutCache_t3050666578_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0 = { 2, GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t501915592_0_0_0_Types[] = { (&KeyValuePair_2_t501915592_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t501915592_0_0_0 = { 1, GenInst_KeyValuePair_2_t501915592_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t501915592_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t501915592_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t501915592_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t501915592_0_0_0_Types };
static const RuntimeType* GenInst_LayoutCache_t3050666578_0_0_0_Types[] = { (&LayoutCache_t3050666578_0_0_0) };
extern const Il2CppGenericInst GenInst_LayoutCache_t3050666578_0_0_0 = { 1, GenInst_LayoutCache_t3050666578_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&LayoutCache_t3050666578_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t751148088_0_0_0_Types[] = { (&KeyValuePair_2_t751148088_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t751148088_0_0_0 = { 1, GenInst_KeyValuePair_2_t751148088_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_KeyValuePair_2_t751148088_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&LayoutCache_t3050666578_0_0_0), (&KeyValuePair_2_t751148088_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_KeyValuePair_2_t751148088_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_KeyValuePair_2_t751148088_0_0_0_Types };
static const RuntimeType* GenInst_GUILayoutEntry_t3409609005_0_0_0_Types[] = { (&GUILayoutEntry_t3409609005_0_0_0) };
extern const Il2CppGenericInst GenInst_GUILayoutEntry_t3409609005_0_0_0 = { 1, GenInst_GUILayoutEntry_t3409609005_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_IntPtr_t_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&IntPtr_t_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_IntPtr_t_0_0_0_Boolean_t2724601657_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_IntPtr_t_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_Exception_t3056413322_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Exception_t3056413322_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Exception_t3056413322_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_Exception_t3056413322_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_GUIStyle_t1817005639_0_0_0_Types[] = { (&GUIStyle_t1817005639_0_0_0) };
extern const Il2CppGenericInst GenInst_GUIStyle_t1817005639_0_0_0 = { 1, GenInst_GUIStyle_t1817005639_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_Types[] = { (&String_t_0_0_0), (&GUIStyle_t1817005639_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0 = { 2, GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&String_t_0_0_0), (&GUIStyle_t1817005639_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t1881531495_0_0_0_Types[] = { (&KeyValuePair_2_t1881531495_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t1881531495_0_0_0 = { 1, GenInst_KeyValuePair_2_t1881531495_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_KeyValuePair_2_t1881531495_0_0_0_Types[] = { (&String_t_0_0_0), (&GUIStyle_t1817005639_0_0_0), (&KeyValuePair_2_t1881531495_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_KeyValuePair_2_t1881531495_0_0_0 = { 3, GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_KeyValuePair_2_t1881531495_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2865959938_0_0_0_Types[] = { (&KeyValuePair_2_t2865959938_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2865959938_0_0_0 = { 1, GenInst_KeyValuePair_2_t2865959938_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2406658774_0_0_0_Types[] = { (&KeyValuePair_2_t2406658774_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2406658774_0_0_0 = { 1, GenInst_KeyValuePair_2_t2406658774_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_DTDNode_t2342132918_0_0_0_Types[] = { (&String_t_0_0_0), (&DTDNode_t2342132918_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_DTDNode_t2342132918_0_0_0 = { 2, GenInst_String_t_0_0_0_DTDNode_t2342132918_0_0_0_Types };
static const RuntimeType* GenInst_DTDNode_t2342132918_0_0_0_Types[] = { (&DTDNode_t2342132918_0_0_0) };
extern const Il2CppGenericInst GenInst_DTDNode_t2342132918_0_0_0 = { 1, GenInst_DTDNode_t2342132918_0_0_0_Types };
static const RuntimeType* GenInst_IXmlLineInfo_t3461124495_0_0_0_Types[] = { (&IXmlLineInfo_t3461124495_0_0_0) };
extern const Il2CppGenericInst GenInst_IXmlLineInfo_t3461124495_0_0_0 = { 1, GenInst_IXmlLineInfo_t3461124495_0_0_0_Types };
static const RuntimeType* GenInst_Entry_t4088204333_0_0_0_Types[] = { (&Entry_t4088204333_0_0_0) };
extern const Il2CppGenericInst GenInst_Entry_t4088204333_0_0_0 = { 1, GenInst_Entry_t4088204333_0_0_0_Types };
static const RuntimeType* GenInst_XmlNode_t482051342_0_0_0_Types[] = { (&XmlNode_t482051342_0_0_0) };
extern const Il2CppGenericInst GenInst_XmlNode_t482051342_0_0_0 = { 1, GenInst_XmlNode_t482051342_0_0_0_Types };
static const RuntimeType* GenInst_IXPathNavigable_t3807597221_0_0_0_Types[] = { (&IXPathNavigable_t3807597221_0_0_0) };
extern const Il2CppGenericInst GenInst_IXPathNavigable_t3807597221_0_0_0 = { 1, GenInst_IXPathNavigable_t3807597221_0_0_0_Types };
static const RuntimeType* GenInst_NsDecl_t2771301075_0_0_0_Types[] = { (&NsDecl_t2771301075_0_0_0) };
extern const Il2CppGenericInst GenInst_NsDecl_t2771301075_0_0_0 = { 1, GenInst_NsDecl_t2771301075_0_0_0_Types };
static const RuntimeType* GenInst_NsScope_t1210418454_0_0_0_Types[] = { (&NsScope_t1210418454_0_0_0) };
extern const Il2CppGenericInst GenInst_NsScope_t1210418454_0_0_0 = { 1, GenInst_NsScope_t1210418454_0_0_0_Types };
static const RuntimeType* GenInst_XmlAttributeTokenInfo_t768028006_0_0_0_Types[] = { (&XmlAttributeTokenInfo_t768028006_0_0_0) };
extern const Il2CppGenericInst GenInst_XmlAttributeTokenInfo_t768028006_0_0_0 = { 1, GenInst_XmlAttributeTokenInfo_t768028006_0_0_0_Types };
static const RuntimeType* GenInst_XmlTokenInfo_t2877013752_0_0_0_Types[] = { (&XmlTokenInfo_t2877013752_0_0_0) };
extern const Il2CppGenericInst GenInst_XmlTokenInfo_t2877013752_0_0_0 = { 1, GenInst_XmlTokenInfo_t2877013752_0_0_0_Types };
static const RuntimeType* GenInst_TagName_t1900555770_0_0_0_Types[] = { (&TagName_t1900555770_0_0_0) };
extern const Il2CppGenericInst GenInst_TagName_t1900555770_0_0_0 = { 1, GenInst_TagName_t1900555770_0_0_0_Types };
static const RuntimeType* GenInst_XmlNodeInfo_t3772009616_0_0_0_Types[] = { (&XmlNodeInfo_t3772009616_0_0_0) };
extern const Il2CppGenericInst GenInst_XmlNodeInfo_t3772009616_0_0_0 = { 1, GenInst_XmlNodeInfo_t3772009616_0_0_0_Types };
static const RuntimeType* GenInst_EventSystem_t2763469419_0_0_0_Types[] = { (&EventSystem_t2763469419_0_0_0) };
extern const Il2CppGenericInst GenInst_EventSystem_t2763469419_0_0_0 = { 1, GenInst_EventSystem_t2763469419_0_0_0_Types };
static const RuntimeType* GenInst_UIBehaviour_t2911488490_0_0_0_Types[] = { (&UIBehaviour_t2911488490_0_0_0) };
extern const Il2CppGenericInst GenInst_UIBehaviour_t2911488490_0_0_0 = { 1, GenInst_UIBehaviour_t2911488490_0_0_0_Types };
static const RuntimeType* GenInst_MonoBehaviour_t2760964972_0_0_0_Types[] = { (&MonoBehaviour_t2760964972_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoBehaviour_t2760964972_0_0_0 = { 1, GenInst_MonoBehaviour_t2760964972_0_0_0_Types };
static const RuntimeType* GenInst_BaseInputModule_t3188708927_0_0_0_Types[] = { (&BaseInputModule_t3188708927_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseInputModule_t3188708927_0_0_0 = { 1, GenInst_BaseInputModule_t3188708927_0_0_0_Types };
static const RuntimeType* GenInst_RaycastResult_t3064114207_0_0_0_Types[] = { (&RaycastResult_t3064114207_0_0_0) };
extern const Il2CppGenericInst GenInst_RaycastResult_t3064114207_0_0_0 = { 1, GenInst_RaycastResult_t3064114207_0_0_0_Types };
static const RuntimeType* GenInst_IDeselectHandler_t3080839654_0_0_0_Types[] = { (&IDeselectHandler_t3080839654_0_0_0) };
extern const Il2CppGenericInst GenInst_IDeselectHandler_t3080839654_0_0_0 = { 1, GenInst_IDeselectHandler_t3080839654_0_0_0_Types };
static const RuntimeType* GenInst_IEventSystemHandler_t2937428598_0_0_0_Types[] = { (&IEventSystemHandler_t2937428598_0_0_0) };
extern const Il2CppGenericInst GenInst_IEventSystemHandler_t2937428598_0_0_0 = { 1, GenInst_IEventSystemHandler_t2937428598_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2929629111_0_0_0_Types[] = { (&List_1_t2929629111_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2929629111_0_0_0 = { 1, GenInst_List_1_t2929629111_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2793634595_0_0_0_Types[] = { (&List_1_t2793634595_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2793634595_0_0_0 = { 1, GenInst_List_1_t2793634595_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t3452530025_0_0_0_Types[] = { (&List_1_t3452530025_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t3452530025_0_0_0 = { 1, GenInst_List_1_t3452530025_0_0_0_Types };
static const RuntimeType* GenInst_ISelectHandler_t2239037249_0_0_0_Types[] = { (&ISelectHandler_t2239037249_0_0_0) };
extern const Il2CppGenericInst GenInst_ISelectHandler_t2239037249_0_0_0 = { 1, GenInst_ISelectHandler_t2239037249_0_0_0_Types };
static const RuntimeType* GenInst_BaseRaycaster_t3516132962_0_0_0_Types[] = { (&BaseRaycaster_t3516132962_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseRaycaster_t3516132962_0_0_0 = { 1, GenInst_BaseRaycaster_t3516132962_0_0_0_Types };
static const RuntimeType* GenInst_Entry_t165374421_0_0_0_Types[] = { (&Entry_t165374421_0_0_0) };
extern const Il2CppGenericInst GenInst_Entry_t165374421_0_0_0 = { 1, GenInst_Entry_t165374421_0_0_0_Types };
static const RuntimeType* GenInst_BaseEventData_t2898106447_0_0_0_Types[] = { (&BaseEventData_t2898106447_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseEventData_t2898106447_0_0_0 = { 1, GenInst_BaseEventData_t2898106447_0_0_0_Types };
static const RuntimeType* GenInst_IPointerEnterHandler_t1495392573_0_0_0_Types[] = { (&IPointerEnterHandler_t1495392573_0_0_0) };
extern const Il2CppGenericInst GenInst_IPointerEnterHandler_t1495392573_0_0_0 = { 1, GenInst_IPointerEnterHandler_t1495392573_0_0_0_Types };
static const RuntimeType* GenInst_IPointerExitHandler_t458397702_0_0_0_Types[] = { (&IPointerExitHandler_t458397702_0_0_0) };
extern const Il2CppGenericInst GenInst_IPointerExitHandler_t458397702_0_0_0 = { 1, GenInst_IPointerExitHandler_t458397702_0_0_0_Types };
static const RuntimeType* GenInst_IPointerDownHandler_t3926188968_0_0_0_Types[] = { (&IPointerDownHandler_t3926188968_0_0_0) };
extern const Il2CppGenericInst GenInst_IPointerDownHandler_t3926188968_0_0_0 = { 1, GenInst_IPointerDownHandler_t3926188968_0_0_0_Types };
static const RuntimeType* GenInst_IPointerUpHandler_t3642990532_0_0_0_Types[] = { (&IPointerUpHandler_t3642990532_0_0_0) };
extern const Il2CppGenericInst GenInst_IPointerUpHandler_t3642990532_0_0_0 = { 1, GenInst_IPointerUpHandler_t3642990532_0_0_0_Types };
static const RuntimeType* GenInst_IPointerClickHandler_t4152680922_0_0_0_Types[] = { (&IPointerClickHandler_t4152680922_0_0_0) };
extern const Il2CppGenericInst GenInst_IPointerClickHandler_t4152680922_0_0_0 = { 1, GenInst_IPointerClickHandler_t4152680922_0_0_0_Types };
static const RuntimeType* GenInst_IInitializePotentialDragHandler_t2460353812_0_0_0_Types[] = { (&IInitializePotentialDragHandler_t2460353812_0_0_0) };
extern const Il2CppGenericInst GenInst_IInitializePotentialDragHandler_t2460353812_0_0_0 = { 1, GenInst_IInitializePotentialDragHandler_t2460353812_0_0_0_Types };
static const RuntimeType* GenInst_IBeginDragHandler_t2985217986_0_0_0_Types[] = { (&IBeginDragHandler_t2985217986_0_0_0) };
extern const Il2CppGenericInst GenInst_IBeginDragHandler_t2985217986_0_0_0 = { 1, GenInst_IBeginDragHandler_t2985217986_0_0_0_Types };
static const RuntimeType* GenInst_IDragHandler_t1695179672_0_0_0_Types[] = { (&IDragHandler_t1695179672_0_0_0) };
extern const Il2CppGenericInst GenInst_IDragHandler_t1695179672_0_0_0 = { 1, GenInst_IDragHandler_t1695179672_0_0_0_Types };
static const RuntimeType* GenInst_IEndDragHandler_t2034818176_0_0_0_Types[] = { (&IEndDragHandler_t2034818176_0_0_0) };
extern const Il2CppGenericInst GenInst_IEndDragHandler_t2034818176_0_0_0 = { 1, GenInst_IEndDragHandler_t2034818176_0_0_0_Types };
static const RuntimeType* GenInst_IDropHandler_t3227688416_0_0_0_Types[] = { (&IDropHandler_t3227688416_0_0_0) };
extern const Il2CppGenericInst GenInst_IDropHandler_t3227688416_0_0_0 = { 1, GenInst_IDropHandler_t3227688416_0_0_0_Types };
static const RuntimeType* GenInst_IScrollHandler_t3788224089_0_0_0_Types[] = { (&IScrollHandler_t3788224089_0_0_0) };
extern const Il2CppGenericInst GenInst_IScrollHandler_t3788224089_0_0_0 = { 1, GenInst_IScrollHandler_t3788224089_0_0_0_Types };
static const RuntimeType* GenInst_IUpdateSelectedHandler_t3604511566_0_0_0_Types[] = { (&IUpdateSelectedHandler_t3604511566_0_0_0) };
extern const Il2CppGenericInst GenInst_IUpdateSelectedHandler_t3604511566_0_0_0 = { 1, GenInst_IUpdateSelectedHandler_t3604511566_0_0_0_Types };
static const RuntimeType* GenInst_IMoveHandler_t2371195586_0_0_0_Types[] = { (&IMoveHandler_t2371195586_0_0_0) };
extern const Il2CppGenericInst GenInst_IMoveHandler_t2371195586_0_0_0 = { 1, GenInst_IMoveHandler_t2371195586_0_0_0_Types };
static const RuntimeType* GenInst_ISubmitHandler_t4239390985_0_0_0_Types[] = { (&ISubmitHandler_t4239390985_0_0_0) };
extern const Il2CppGenericInst GenInst_ISubmitHandler_t4239390985_0_0_0 = { 1, GenInst_ISubmitHandler_t4239390985_0_0_0_Types };
static const RuntimeType* GenInst_ICancelHandler_t881167290_0_0_0_Types[] = { (&ICancelHandler_t881167290_0_0_0) };
extern const Il2CppGenericInst GenInst_ICancelHandler_t881167290_0_0_0 = { 1, GenInst_ICancelHandler_t881167290_0_0_0_Types };
static const RuntimeType* GenInst_Transform_t98390630_0_0_0_Types[] = { (&Transform_t98390630_0_0_0) };
extern const Il2CppGenericInst GenInst_Transform_t98390630_0_0_0 = { 1, GenInst_Transform_t98390630_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_t1069409312_0_0_0_Types[] = { (&GameObject_t1069409312_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_t1069409312_0_0_0 = { 1, GenInst_GameObject_t1069409312_0_0_0_Types };
static const RuntimeType* GenInst_BaseInput_t2347852_0_0_0_Types[] = { (&BaseInput_t2347852_0_0_0) };
extern const Il2CppGenericInst GenInst_BaseInput_t2347852_0_0_0 = { 1, GenInst_BaseInput_t2347852_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&PointerEventData_t110851018_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0 = { 2, GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_Types };
static const RuntimeType* GenInst_PointerEventData_t110851018_0_0_0_Types[] = { (&PointerEventData_t110851018_0_0_0) };
extern const Il2CppGenericInst GenInst_PointerEventData_t110851018_0_0_0 = { 1, GenInst_PointerEventData_t110851018_0_0_0_Types };
static const RuntimeType* GenInst_AbstractEventData_t2094041248_0_0_0_Types[] = { (&AbstractEventData_t2094041248_0_0_0) };
extern const Il2CppGenericInst GenInst_AbstractEventData_t2094041248_0_0_0 = { 1, GenInst_AbstractEventData_t2094041248_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&PointerEventData_t110851018_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2106299824_0_0_0_Types[] = { (&KeyValuePair_2_t2106299824_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2106299824_0_0_0 = { 1, GenInst_KeyValuePair_2_t2106299824_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_KeyValuePair_2_t2106299824_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&PointerEventData_t110851018_0_0_0), (&KeyValuePair_2_t2106299824_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_KeyValuePair_2_t2106299824_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_KeyValuePair_2_t2106299824_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_PointerEventData_t110851018_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&PointerEventData_t110851018_0_0_0), (&PointerEventData_t110851018_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_PointerEventData_t110851018_0_0_0 = { 3, GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_PointerEventData_t110851018_0_0_0_Types };
static const RuntimeType* GenInst_ButtonState_t3919583657_0_0_0_Types[] = { (&ButtonState_t3919583657_0_0_0) };
extern const Il2CppGenericInst GenInst_ButtonState_t3919583657_0_0_0 = { 1, GenInst_ButtonState_t3919583657_0_0_0_Types };
static const RuntimeType* GenInst_RaycastHit2D_t3641439068_0_0_0_Types[] = { (&RaycastHit2D_t3641439068_0_0_0) };
extern const Il2CppGenericInst GenInst_RaycastHit2D_t3641439068_0_0_0 = { 1, GenInst_RaycastHit2D_t3641439068_0_0_0_Types };
static const RuntimeType* GenInst_RaycastHit_t1862035074_0_0_0_Types[] = { (&RaycastHit_t1862035074_0_0_0) };
extern const Il2CppGenericInst GenInst_RaycastHit_t1862035074_0_0_0 = { 1, GenInst_RaycastHit_t1862035074_0_0_0_Types };
static const RuntimeType* GenInst_Color_t2395139082_0_0_0_Types[] = { (&Color_t2395139082_0_0_0) };
extern const Il2CppGenericInst GenInst_Color_t2395139082_0_0_0 = { 1, GenInst_Color_t2395139082_0_0_0_Types };
static const RuntimeType* GenInst_ICanvasElement_t1506473672_0_0_0_Types[] = { (&ICanvasElement_t1506473672_0_0_0) };
extern const Il2CppGenericInst GenInst_ICanvasElement_t1506473672_0_0_0 = { 1, GenInst_ICanvasElement_t1506473672_0_0_0_Types };
static const RuntimeType* GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&ICanvasElement_t1506473672_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&ICanvasElement_t1506473672_0_0_0), (&Int32_t2946131084_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_ColorBlock_t2528874620_0_0_0_Types[] = { (&ColorBlock_t2528874620_0_0_0) };
extern const Il2CppGenericInst GenInst_ColorBlock_t2528874620_0_0_0 = { 1, GenInst_ColorBlock_t2528874620_0_0_0_Types };
static const RuntimeType* GenInst_OptionData_t308902495_0_0_0_Types[] = { (&OptionData_t308902495_0_0_0) };
extern const Il2CppGenericInst GenInst_OptionData_t308902495_0_0_0 = { 1, GenInst_OptionData_t308902495_0_0_0_Types };
static const RuntimeType* GenInst_DropdownItem_t1280764085_0_0_0_Types[] = { (&DropdownItem_t1280764085_0_0_0) };
extern const Il2CppGenericInst GenInst_DropdownItem_t1280764085_0_0_0 = { 1, GenInst_DropdownItem_t1280764085_0_0_0_Types };
static const RuntimeType* GenInst_FloatTween_t718194525_0_0_0_Types[] = { (&FloatTween_t718194525_0_0_0) };
extern const Il2CppGenericInst GenInst_FloatTween_t718194525_0_0_0 = { 1, GenInst_FloatTween_t718194525_0_0_0_Types };
static const RuntimeType* GenInst_Sprite_t825958079_0_0_0_Types[] = { (&Sprite_t825958079_0_0_0) };
extern const Il2CppGenericInst GenInst_Sprite_t825958079_0_0_0 = { 1, GenInst_Sprite_t825958079_0_0_0_Types };
static const RuntimeType* GenInst_Canvas_t1472555277_0_0_0_Types[] = { (&Canvas_t1472555277_0_0_0) };
extern const Il2CppGenericInst GenInst_Canvas_t1472555277_0_0_0 = { 1, GenInst_Canvas_t1472555277_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t1464755790_0_0_0_Types[] = { (&List_1_t1464755790_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t1464755790_0_0_0 = { 1, GenInst_List_1_t1464755790_0_0_0_Types };
static const RuntimeType* GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_Types[] = { (&Font_t82789257_0_0_0), (&HashSet_1_t2760900715_0_0_0) };
extern const Il2CppGenericInst GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0 = { 2, GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_Types };
static const RuntimeType* GenInst_Text_t40276147_0_0_0_Types[] = { (&Text_t40276147_0_0_0) };
extern const Il2CppGenericInst GenInst_Text_t40276147_0_0_0 = { 1, GenInst_Text_t40276147_0_0_0_Types };
static const RuntimeType* GenInst_Link_t1160387394_0_0_0_Types[] = { (&Link_t1160387394_0_0_0) };
extern const Il2CppGenericInst GenInst_Link_t1160387394_0_0_0 = { 1, GenInst_Link_t1160387394_0_0_0_Types };
static const RuntimeType* GenInst_ILayoutElement_t3083897574_0_0_0_Types[] = { (&ILayoutElement_t3083897574_0_0_0) };
extern const Il2CppGenericInst GenInst_ILayoutElement_t3083897574_0_0_0 = { 1, GenInst_ILayoutElement_t3083897574_0_0_0_Types };
static const RuntimeType* GenInst_MaskableGraphic_t829384950_0_0_0_Types[] = { (&MaskableGraphic_t829384950_0_0_0) };
extern const Il2CppGenericInst GenInst_MaskableGraphic_t829384950_0_0_0 = { 1, GenInst_MaskableGraphic_t829384950_0_0_0_Types };
static const RuntimeType* GenInst_IClippable_t2595653578_0_0_0_Types[] = { (&IClippable_t2595653578_0_0_0) };
extern const Il2CppGenericInst GenInst_IClippable_t2595653578_0_0_0 = { 1, GenInst_IClippable_t2595653578_0_0_0_Types };
static const RuntimeType* GenInst_IMaskable_t3116280729_0_0_0_Types[] = { (&IMaskable_t3116280729_0_0_0) };
extern const Il2CppGenericInst GenInst_IMaskable_t3116280729_0_0_0 = { 1, GenInst_IMaskable_t3116280729_0_0_0_Types };
static const RuntimeType* GenInst_IMaterialModifier_t2659437676_0_0_0_Types[] = { (&IMaterialModifier_t2659437676_0_0_0) };
extern const Il2CppGenericInst GenInst_IMaterialModifier_t2659437676_0_0_0 = { 1, GenInst_IMaterialModifier_t2659437676_0_0_0_Types };
static const RuntimeType* GenInst_Graphic_t3934133196_0_0_0_Types[] = { (&Graphic_t3934133196_0_0_0) };
extern const Il2CppGenericInst GenInst_Graphic_t3934133196_0_0_0 = { 1, GenInst_Graphic_t3934133196_0_0_0_Types };
static const RuntimeType* GenInst_HashSet_1_t2760900715_0_0_0_Types[] = { (&HashSet_1_t2760900715_0_0_0) };
extern const Il2CppGenericInst GenInst_HashSet_1_t2760900715_0_0_0 = { 1, GenInst_HashSet_1_t2760900715_0_0_0_Types };
static const RuntimeType* GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Font_t82789257_0_0_0), (&HashSet_1_t2760900715_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t1061748416_0_0_0_Types[] = { (&KeyValuePair_2_t1061748416_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t1061748416_0_0_0 = { 1, GenInst_KeyValuePair_2_t1061748416_0_0_0_Types };
static const RuntimeType* GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_KeyValuePair_2_t1061748416_0_0_0_Types[] = { (&Font_t82789257_0_0_0), (&HashSet_1_t2760900715_0_0_0), (&KeyValuePair_2_t1061748416_0_0_0) };
extern const Il2CppGenericInst GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_KeyValuePair_2_t1061748416_0_0_0 = { 3, GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_KeyValuePair_2_t1061748416_0_0_0_Types };
static const RuntimeType* GenInst_ColorTween_t2126108860_0_0_0_Types[] = { (&ColorTween_t2126108860_0_0_0) };
extern const Il2CppGenericInst GenInst_ColorTween_t2126108860_0_0_0 = { 1, GenInst_ColorTween_t2126108860_0_0_0_Types };
static const RuntimeType* GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_Types[] = { (&Canvas_t1472555277_0_0_0), (&IndexedSet_1_t3732760996_0_0_0) };
extern const Il2CppGenericInst GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0 = { 2, GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_Types };
static const RuntimeType* GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&Graphic_t3934133196_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Graphic_t3934133196_0_0_0), (&Int32_t2946131084_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_IndexedSet_1_t3732760996_0_0_0_Types[] = { (&IndexedSet_1_t3732760996_0_0_0) };
extern const Il2CppGenericInst GenInst_IndexedSet_1_t3732760996_0_0_0 = { 1, GenInst_IndexedSet_1_t3732760996_0_0_0_Types };
static const RuntimeType* GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Canvas_t1472555277_0_0_0), (&IndexedSet_1_t3732760996_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3977119717_0_0_0_Types[] = { (&KeyValuePair_2_t3977119717_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3977119717_0_0_0 = { 1, GenInst_KeyValuePair_2_t3977119717_0_0_0_Types };
static const RuntimeType* GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_KeyValuePair_2_t3977119717_0_0_0_Types[] = { (&Canvas_t1472555277_0_0_0), (&IndexedSet_1_t3732760996_0_0_0), (&KeyValuePair_2_t3977119717_0_0_0) };
extern const Il2CppGenericInst GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_KeyValuePair_2_t3977119717_0_0_0 = { 3, GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_KeyValuePair_2_t3977119717_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2513357362_0_0_0_Types[] = { (&KeyValuePair_2_t2513357362_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2513357362_0_0_0 = { 1, GenInst_KeyValuePair_2_t2513357362_0_0_0_Types };
static const RuntimeType* GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t2513357362_0_0_0_Types[] = { (&Graphic_t3934133196_0_0_0), (&Int32_t2946131084_0_0_0), (&KeyValuePair_2_t2513357362_0_0_0) };
extern const Il2CppGenericInst GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t2513357362_0_0_0 = { 3, GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t2513357362_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3644430278_0_0_0_Types[] = { (&KeyValuePair_2_t3644430278_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3644430278_0_0_0 = { 1, GenInst_KeyValuePair_2_t3644430278_0_0_0_Types };
static const RuntimeType* GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3644430278_0_0_0_Types[] = { (&ICanvasElement_t1506473672_0_0_0), (&Int32_t2946131084_0_0_0), (&KeyValuePair_2_t3644430278_0_0_0) };
extern const Il2CppGenericInst GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3644430278_0_0_0 = { 3, GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3644430278_0_0_0_Types };
static const RuntimeType* GenInst_Type_t3482946342_0_0_0_Types[] = { (&Type_t3482946342_0_0_0) };
extern const Il2CppGenericInst GenInst_Type_t3482946342_0_0_0 = { 1, GenInst_Type_t3482946342_0_0_0_Types };
static const RuntimeType* GenInst_FillMethod_t1967692376_0_0_0_Types[] = { (&FillMethod_t1967692376_0_0_0) };
extern const Il2CppGenericInst GenInst_FillMethod_t1967692376_0_0_0 = { 1, GenInst_FillMethod_t1967692376_0_0_0_Types };
static const RuntimeType* GenInst_ContentType_t1949393164_0_0_0_Types[] = { (&ContentType_t1949393164_0_0_0) };
extern const Il2CppGenericInst GenInst_ContentType_t1949393164_0_0_0 = { 1, GenInst_ContentType_t1949393164_0_0_0_Types };
static const RuntimeType* GenInst_LineType_t1704015161_0_0_0_Types[] = { (&LineType_t1704015161_0_0_0) };
extern const Il2CppGenericInst GenInst_LineType_t1704015161_0_0_0 = { 1, GenInst_LineType_t1704015161_0_0_0_Types };
static const RuntimeType* GenInst_InputType_t3552287731_0_0_0_Types[] = { (&InputType_t3552287731_0_0_0) };
extern const Il2CppGenericInst GenInst_InputType_t3552287731_0_0_0 = { 1, GenInst_InputType_t3552287731_0_0_0_Types };
static const RuntimeType* GenInst_TouchScreenKeyboardType_t1115125102_0_0_0_Types[] = { (&TouchScreenKeyboardType_t1115125102_0_0_0) };
extern const Il2CppGenericInst GenInst_TouchScreenKeyboardType_t1115125102_0_0_0 = { 1, GenInst_TouchScreenKeyboardType_t1115125102_0_0_0_Types };
static const RuntimeType* GenInst_CharacterValidation_t1615951991_0_0_0_Types[] = { (&CharacterValidation_t1615951991_0_0_0) };
extern const Il2CppGenericInst GenInst_CharacterValidation_t1615951991_0_0_0 = { 1, GenInst_CharacterValidation_t1615951991_0_0_0_Types };
static const RuntimeType* GenInst_Mask_t4273450599_0_0_0_Types[] = { (&Mask_t4273450599_0_0_0) };
extern const Il2CppGenericInst GenInst_Mask_t4273450599_0_0_0 = { 1, GenInst_Mask_t4273450599_0_0_0_Types };
static const RuntimeType* GenInst_ICanvasRaycastFilter_t1727583418_0_0_0_Types[] = { (&ICanvasRaycastFilter_t1727583418_0_0_0) };
extern const Il2CppGenericInst GenInst_ICanvasRaycastFilter_t1727583418_0_0_0 = { 1, GenInst_ICanvasRaycastFilter_t1727583418_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t4265651112_0_0_0_Types[] = { (&List_1_t4265651112_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t4265651112_0_0_0 = { 1, GenInst_List_1_t4265651112_0_0_0_Types };
static const RuntimeType* GenInst_RectMask2D_t2940363972_0_0_0_Types[] = { (&RectMask2D_t2940363972_0_0_0) };
extern const Il2CppGenericInst GenInst_RectMask2D_t2940363972_0_0_0 = { 1, GenInst_RectMask2D_t2940363972_0_0_0_Types };
static const RuntimeType* GenInst_IClipper_t3640166804_0_0_0_Types[] = { (&IClipper_t3640166804_0_0_0) };
extern const Il2CppGenericInst GenInst_IClipper_t3640166804_0_0_0 = { 1, GenInst_IClipper_t3640166804_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2932564485_0_0_0_Types[] = { (&List_1_t2932564485_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2932564485_0_0_0 = { 1, GenInst_List_1_t2932564485_0_0_0_Types };
static const RuntimeType* GenInst_Navigation_t2650002304_0_0_0_Types[] = { (&Navigation_t2650002304_0_0_0) };
extern const Il2CppGenericInst GenInst_Navigation_t2650002304_0_0_0 = { 1, GenInst_Navigation_t2650002304_0_0_0_Types };
static const RuntimeType* GenInst_Link_t3715764825_0_0_0_Types[] = { (&Link_t3715764825_0_0_0) };
extern const Il2CppGenericInst GenInst_Link_t3715764825_0_0_0 = { 1, GenInst_Link_t3715764825_0_0_0_Types };
static const RuntimeType* GenInst_Direction_t2220972688_0_0_0_Types[] = { (&Direction_t2220972688_0_0_0) };
extern const Il2CppGenericInst GenInst_Direction_t2220972688_0_0_0 = { 1, GenInst_Direction_t2220972688_0_0_0_Types };
static const RuntimeType* GenInst_Selectable_t704361702_0_0_0_Types[] = { (&Selectable_t704361702_0_0_0) };
extern const Il2CppGenericInst GenInst_Selectable_t704361702_0_0_0 = { 1, GenInst_Selectable_t704361702_0_0_0_Types };
static const RuntimeType* GenInst_Transition_t3996285674_0_0_0_Types[] = { (&Transition_t3996285674_0_0_0) };
extern const Il2CppGenericInst GenInst_Transition_t3996285674_0_0_0 = { 1, GenInst_Transition_t3996285674_0_0_0_Types };
static const RuntimeType* GenInst_SpriteState_t3463583707_0_0_0_Types[] = { (&SpriteState_t3463583707_0_0_0) };
extern const Il2CppGenericInst GenInst_SpriteState_t3463583707_0_0_0 = { 1, GenInst_SpriteState_t3463583707_0_0_0_Types };
static const RuntimeType* GenInst_CanvasGroup_t4004672386_0_0_0_Types[] = { (&CanvasGroup_t4004672386_0_0_0) };
extern const Il2CppGenericInst GenInst_CanvasGroup_t4004672386_0_0_0 = { 1, GenInst_CanvasGroup_t4004672386_0_0_0_Types };
static const RuntimeType* GenInst_Direction_t169952706_0_0_0_Types[] = { (&Direction_t169952706_0_0_0) };
extern const Il2CppGenericInst GenInst_Direction_t169952706_0_0_0 = { 1, GenInst_Direction_t169952706_0_0_0_Types };
static const RuntimeType* GenInst_MatEntry_t3924390953_0_0_0_Types[] = { (&MatEntry_t3924390953_0_0_0) };
extern const Il2CppGenericInst GenInst_MatEntry_t3924390953_0_0_0 = { 1, GenInst_MatEntry_t3924390953_0_0_0_Types };
static const RuntimeType* GenInst_Toggle_t2394373767_0_0_0_Types[] = { (&Toggle_t2394373767_0_0_0) };
extern const Il2CppGenericInst GenInst_Toggle_t2394373767_0_0_0 = { 1, GenInst_Toggle_t2394373767_0_0_0_Types };
static const RuntimeType* GenInst_Toggle_t2394373767_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Toggle_t2394373767_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Toggle_t2394373767_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_Toggle_t2394373767_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&IClipper_t3640166804_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&IClipper_t3640166804_0_0_0), (&Int32_t2946131084_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t659768394_0_0_0_Types[] = { (&KeyValuePair_2_t659768394_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t659768394_0_0_0 = { 1, GenInst_KeyValuePair_2_t659768394_0_0_0_Types };
static const RuntimeType* GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t659768394_0_0_0_Types[] = { (&IClipper_t3640166804_0_0_0), (&Int32_t2946131084_0_0_0), (&KeyValuePair_2_t659768394_0_0_0) };
extern const Il2CppGenericInst GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t659768394_0_0_0 = { 3, GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t659768394_0_0_0_Types };
static const RuntimeType* GenInst_AspectMode_t2894845584_0_0_0_Types[] = { (&AspectMode_t2894845584_0_0_0) };
extern const Il2CppGenericInst GenInst_AspectMode_t2894845584_0_0_0 = { 1, GenInst_AspectMode_t2894845584_0_0_0_Types };
static const RuntimeType* GenInst_FitMode_t303797140_0_0_0_Types[] = { (&FitMode_t303797140_0_0_0) };
extern const Il2CppGenericInst GenInst_FitMode_t303797140_0_0_0 = { 1, GenInst_FitMode_t303797140_0_0_0_Types };
static const RuntimeType* GenInst_RectTransform_t3170355171_0_0_0_Types[] = { (&RectTransform_t3170355171_0_0_0) };
extern const Il2CppGenericInst GenInst_RectTransform_t3170355171_0_0_0 = { 1, GenInst_RectTransform_t3170355171_0_0_0_Types };
static const RuntimeType* GenInst_LayoutRebuilder_t2138051633_0_0_0_Types[] = { (&LayoutRebuilder_t2138051633_0_0_0) };
extern const Il2CppGenericInst GenInst_LayoutRebuilder_t2138051633_0_0_0 = { 1, GenInst_LayoutRebuilder_t2138051633_0_0_0_Types };
static const RuntimeType* GenInst_ILayoutElement_t3083897574_0_0_0_Single_t2594644343_0_0_0_Types[] = { (&ILayoutElement_t3083897574_0_0_0), (&Single_t2594644343_0_0_0) };
extern const Il2CppGenericInst GenInst_ILayoutElement_t3083897574_0_0_0_Single_t2594644343_0_0_0 = { 2, GenInst_ILayoutElement_t3083897574_0_0_0_Single_t2594644343_0_0_0_Types };
static const RuntimeType* GenInst_RuntimeObject_0_0_0_Single_t2594644343_0_0_0_Types[] = { (&RuntimeObject_0_0_0), (&Single_t2594644343_0_0_0) };
extern const Il2CppGenericInst GenInst_RuntimeObject_0_0_0_Single_t2594644343_0_0_0 = { 2, GenInst_RuntimeObject_0_0_0_Single_t2594644343_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2478570738_0_0_0_Types[] = { (&List_1_t2478570738_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2478570738_0_0_0 = { 1, GenInst_List_1_t2478570738_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t1273808215_0_0_0_Types[] = { (&List_1_t1273808215_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t1273808215_0_0_0 = { 1, GenInst_List_1_t1273808215_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t1735618304_0_0_0_Types[] = { (&List_1_t1735618304_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t1735618304_0_0_0 = { 1, GenInst_List_1_t1735618304_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t4206492726_0_0_0_Types[] = { (&List_1_t4206492726_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t4206492726_0_0_0 = { 1, GenInst_List_1_t4206492726_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t2938331597_0_0_0_Types[] = { (&List_1_t2938331597_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t2938331597_0_0_0 = { 1, GenInst_List_1_t2938331597_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t3696562166_0_0_0_Types[] = { (&List_1_t3696562166_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t3696562166_0_0_0 = { 1, GenInst_List_1_t3696562166_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2865959938_0_0_0_Types[] = { (&String_t_0_0_0), (&RuntimeObject_0_0_0), (&KeyValuePair_2_t2865959938_0_0_0) };
extern const Il2CppGenericInst GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2865959938_0_0_0 = { 3, GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2865959938_0_0_0_Types };
static const RuntimeType* GenInst_FieldWithTarget_t2008555883_0_0_0_Types[] = { (&FieldWithTarget_t2008555883_0_0_0) };
extern const Il2CppGenericInst GenInst_FieldWithTarget_t2008555883_0_0_0 = { 1, GenInst_FieldWithTarget_t2008555883_0_0_0_Types };
static const RuntimeType* GenInst_IEnumerable_1_t3472824768_gp_0_0_0_0_Types[] = { (&IEnumerable_1_t3472824768_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_IEnumerable_1_t3472824768_gp_0_0_0_0 = { 1, GenInst_IEnumerable_1_t3472824768_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0_Types[] = { (&Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0 = { 1, GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m375360748_gp_0_0_0_0_Array_Sort_m375360748_gp_0_0_0_0_Types[] = { (&Array_Sort_m375360748_gp_0_0_0_0), (&Array_Sort_m375360748_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m375360748_gp_0_0_0_0_Array_Sort_m375360748_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m375360748_gp_0_0_0_0_Array_Sort_m375360748_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m3222092194_gp_0_0_0_0_Array_Sort_m3222092194_gp_1_0_0_0_Types[] = { (&Array_Sort_m3222092194_gp_0_0_0_0), (&Array_Sort_m3222092194_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m3222092194_gp_0_0_0_0_Array_Sort_m3222092194_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m3222092194_gp_0_0_0_0_Array_Sort_m3222092194_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Types[] = { (&Array_Sort_m2933720515_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2933720515_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Array_Sort_m2933720515_gp_0_0_0_0_Types[] = { (&Array_Sort_m2933720515_gp_0_0_0_0), (&Array_Sort_m2933720515_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Array_Sort_m2933720515_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Array_Sort_m2933720515_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Types[] = { (&Array_Sort_m1007327534_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m1007327534_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Array_Sort_m1007327534_gp_1_0_0_0_Types[] = { (&Array_Sort_m1007327534_gp_0_0_0_0), (&Array_Sort_m1007327534_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Array_Sort_m1007327534_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Array_Sort_m1007327534_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2280519164_gp_0_0_0_0_Array_Sort_m2280519164_gp_0_0_0_0_Types[] = { (&Array_Sort_m2280519164_gp_0_0_0_0), (&Array_Sort_m2280519164_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2280519164_gp_0_0_0_0_Array_Sort_m2280519164_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m2280519164_gp_0_0_0_0_Array_Sort_m2280519164_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m3079444734_gp_0_0_0_0_Array_Sort_m3079444734_gp_1_0_0_0_Types[] = { (&Array_Sort_m3079444734_gp_0_0_0_0), (&Array_Sort_m3079444734_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m3079444734_gp_0_0_0_0_Array_Sort_m3079444734_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m3079444734_gp_0_0_0_0_Array_Sort_m3079444734_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m465496297_gp_0_0_0_0_Types[] = { (&Array_Sort_m465496297_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m465496297_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m465496297_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m465496297_gp_0_0_0_0_Array_Sort_m465496297_gp_0_0_0_0_Types[] = { (&Array_Sort_m465496297_gp_0_0_0_0), (&Array_Sort_m465496297_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m465496297_gp_0_0_0_0_Array_Sort_m465496297_gp_0_0_0_0 = { 2, GenInst_Array_Sort_m465496297_gp_0_0_0_0_Array_Sort_m465496297_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m703600137_gp_0_0_0_0_Types[] = { (&Array_Sort_m703600137_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m703600137_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m703600137_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m703600137_gp_1_0_0_0_Types[] = { (&Array_Sort_m703600137_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m703600137_gp_1_0_0_0 = { 1, GenInst_Array_Sort_m703600137_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m703600137_gp_0_0_0_0_Array_Sort_m703600137_gp_1_0_0_0_Types[] = { (&Array_Sort_m703600137_gp_0_0_0_0), (&Array_Sort_m703600137_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m703600137_gp_0_0_0_0_Array_Sort_m703600137_gp_1_0_0_0 = { 2, GenInst_Array_Sort_m703600137_gp_0_0_0_0_Array_Sort_m703600137_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m884212515_gp_0_0_0_0_Types[] = { (&Array_Sort_m884212515_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m884212515_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m884212515_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Sort_m2398395411_gp_0_0_0_0_Types[] = { (&Array_Sort_m2398395411_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Sort_m2398395411_gp_0_0_0_0 = { 1, GenInst_Array_Sort_m2398395411_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Types[] = { (&Array_qsort_m3664970149_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m3664970149_gp_0_0_0_0 = { 1, GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Array_qsort_m3664970149_gp_1_0_0_0_Types[] = { (&Array_qsort_m3664970149_gp_0_0_0_0), (&Array_qsort_m3664970149_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Array_qsort_m3664970149_gp_1_0_0_0 = { 2, GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Array_qsort_m3664970149_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_compare_m2643025574_gp_0_0_0_0_Types[] = { (&Array_compare_m2643025574_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_compare_m2643025574_gp_0_0_0_0 = { 1, GenInst_Array_compare_m2643025574_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_qsort_m2860849171_gp_0_0_0_0_Types[] = { (&Array_qsort_m2860849171_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_qsort_m2860849171_gp_0_0_0_0 = { 1, GenInst_Array_qsort_m2860849171_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Resize_m1319191173_gp_0_0_0_0_Types[] = { (&Array_Resize_m1319191173_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Resize_m1319191173_gp_0_0_0_0 = { 1, GenInst_Array_Resize_m1319191173_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_TrueForAll_m3279624529_gp_0_0_0_0_Types[] = { (&Array_TrueForAll_m3279624529_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_TrueForAll_m3279624529_gp_0_0_0_0 = { 1, GenInst_Array_TrueForAll_m3279624529_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_ForEach_m3065220158_gp_0_0_0_0_Types[] = { (&Array_ForEach_m3065220158_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_ForEach_m3065220158_gp_0_0_0_0 = { 1, GenInst_Array_ForEach_m3065220158_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_ConvertAll_m4162873343_gp_0_0_0_0_Array_ConvertAll_m4162873343_gp_1_0_0_0_Types[] = { (&Array_ConvertAll_m4162873343_gp_0_0_0_0), (&Array_ConvertAll_m4162873343_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_ConvertAll_m4162873343_gp_0_0_0_0_Array_ConvertAll_m4162873343_gp_1_0_0_0 = { 2, GenInst_Array_ConvertAll_m4162873343_gp_0_0_0_0_Array_ConvertAll_m4162873343_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m1231288529_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m1231288529_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m1231288529_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m1231288529_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m253241084_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m253241084_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m253241084_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m253241084_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLastIndex_m3979318220_gp_0_0_0_0_Types[] = { (&Array_FindLastIndex_m3979318220_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLastIndex_m3979318220_gp_0_0_0_0 = { 1, GenInst_Array_FindLastIndex_m3979318220_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m2771346406_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m2771346406_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m2771346406_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m2771346406_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m1435567717_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m1435567717_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m1435567717_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m1435567717_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindIndex_m541082306_gp_0_0_0_0_Types[] = { (&Array_FindIndex_m541082306_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindIndex_m541082306_gp_0_0_0_0 = { 1, GenInst_Array_FindIndex_m541082306_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m210446113_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m210446113_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m210446113_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m210446113_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m2725795785_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m2725795785_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m2725795785_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m2725795785_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m236397454_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m236397454_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m236397454_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m236397454_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_BinarySearch_m670715820_gp_0_0_0_0_Types[] = { (&Array_BinarySearch_m670715820_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_BinarySearch_m670715820_gp_0_0_0_0 = { 1, GenInst_Array_BinarySearch_m670715820_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m1478543517_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m1478543517_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m1478543517_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m1478543517_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m2800774269_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m2800774269_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m2800774269_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m2800774269_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_IndexOf_m1657565370_gp_0_0_0_0_Types[] = { (&Array_IndexOf_m1657565370_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_IndexOf_m1657565370_gp_0_0_0_0 = { 1, GenInst_Array_IndexOf_m1657565370_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m3259903814_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m3259903814_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m3259903814_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m3259903814_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m2114823285_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m2114823285_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m2114823285_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m2114823285_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_LastIndexOf_m3033490990_gp_0_0_0_0_Types[] = { (&Array_LastIndexOf_m3033490990_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_LastIndexOf_m3033490990_gp_0_0_0_0 = { 1, GenInst_Array_LastIndexOf_m3033490990_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindAll_m2935868350_gp_0_0_0_0_Types[] = { (&Array_FindAll_m2935868350_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindAll_m2935868350_gp_0_0_0_0 = { 1, GenInst_Array_FindAll_m2935868350_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Exists_m2513116021_gp_0_0_0_0_Types[] = { (&Array_Exists_m2513116021_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Exists_m2513116021_gp_0_0_0_0 = { 1, GenInst_Array_Exists_m2513116021_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_AsReadOnly_m1269368112_gp_0_0_0_0_Types[] = { (&Array_AsReadOnly_m1269368112_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_AsReadOnly_m1269368112_gp_0_0_0_0 = { 1, GenInst_Array_AsReadOnly_m1269368112_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_Find_m3798369552_gp_0_0_0_0_Types[] = { (&Array_Find_m3798369552_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_Find_m3798369552_gp_0_0_0_0 = { 1, GenInst_Array_Find_m3798369552_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Array_FindLast_m451745637_gp_0_0_0_0_Types[] = { (&Array_FindLast_m451745637_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Array_FindLast_m451745637_gp_0_0_0_0 = { 1, GenInst_Array_FindLast_m451745637_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InternalEnumerator_1_t3198792400_gp_0_0_0_0_Types[] = { (&InternalEnumerator_1_t3198792400_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InternalEnumerator_1_t3198792400_gp_0_0_0_0 = { 1, GenInst_InternalEnumerator_1_t3198792400_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ArrayReadOnlyList_1_t875796540_gp_0_0_0_0_Types[] = { (&ArrayReadOnlyList_1_t875796540_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ArrayReadOnlyList_1_t875796540_gp_0_0_0_0 = { 1, GenInst_ArrayReadOnlyList_1_t875796540_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0_Types[] = { (&U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0 = { 1, GenInst_U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_IList_1_t3283297292_gp_0_0_0_0_Types[] = { (&IList_1_t3283297292_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_IList_1_t3283297292_gp_0_0_0_0 = { 1, GenInst_IList_1_t3283297292_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ICollection_1_t3247531716_gp_0_0_0_0_Types[] = { (&ICollection_1_t3247531716_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ICollection_1_t3247531716_gp_0_0_0_0 = { 1, GenInst_ICollection_1_t3247531716_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Nullable_1_t3469261872_gp_0_0_0_0_Types[] = { (&Nullable_1_t3469261872_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Nullable_1_t3469261872_gp_0_0_0_0 = { 1, GenInst_Nullable_1_t3469261872_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Comparer_1_t2365096000_gp_0_0_0_0_Types[] = { (&Comparer_1_t2365096000_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Comparer_1_t2365096000_gp_0_0_0_0 = { 1, GenInst_Comparer_1_t2365096000_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_DefaultComparer_t325514881_gp_0_0_0_0_Types[] = { (&DefaultComparer_t325514881_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultComparer_t325514881_gp_0_0_0_0 = { 1, GenInst_DefaultComparer_t325514881_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GenericComparer_1_t1985017584_gp_0_0_0_0_Types[] = { (&GenericComparer_1_t1985017584_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericComparer_1_t1985017584_gp_0_0_0_0 = { 1, GenInst_GenericComparer_1_t1985017584_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0 = { 1, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0), (&Dictionary_2_t2809050045_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0 = { 2, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t373669827_0_0_0_Types[] = { (&KeyValuePair_2_t373669827_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t373669827_0_0_0 = { 1, GenInst_KeyValuePair_2_t373669827_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0), (&Dictionary_2_t2809050045_gp_1_0_0_0), (&Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0 = { 3, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0), (&Dictionary_2_t2809050045_gp_1_0_0_0), (&Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0 = { 3, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_RuntimeObject_0_0_0_Types[] = { (&Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0), (&Dictionary_2_t2809050045_gp_1_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 3, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_ShimEnumerator_t3580966704_gp_0_0_0_0_ShimEnumerator_t3580966704_gp_1_0_0_0_Types[] = { (&ShimEnumerator_t3580966704_gp_0_0_0_0), (&ShimEnumerator_t3580966704_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ShimEnumerator_t3580966704_gp_0_0_0_0_ShimEnumerator_t3580966704_gp_1_0_0_0 = { 2, GenInst_ShimEnumerator_t3580966704_gp_0_0_0_0_ShimEnumerator_t3580966704_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t3554107356_gp_0_0_0_0_Enumerator_t3554107356_gp_1_0_0_0_Types[] = { (&Enumerator_t3554107356_gp_0_0_0_0), (&Enumerator_t3554107356_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t3554107356_gp_0_0_0_0_Enumerator_t3554107356_gp_1_0_0_0 = { 2, GenInst_Enumerator_t3554107356_gp_0_0_0_0_Enumerator_t3554107356_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t4151003239_0_0_0_Types[] = { (&KeyValuePair_2_t4151003239_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t4151003239_0_0_0 = { 1, GenInst_KeyValuePair_2_t4151003239_0_0_0_Types };
static const RuntimeType* GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_Types[] = { (&KeyCollection_t3609397419_gp_0_0_0_0), (&KeyCollection_t3609397419_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0 = { 2, GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyCollection_t3609397419_gp_0_0_0_0_Types[] = { (&KeyCollection_t3609397419_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyCollection_t3609397419_gp_0_0_0_0 = { 1, GenInst_KeyCollection_t3609397419_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t1298455868_gp_0_0_0_0_Enumerator_t1298455868_gp_1_0_0_0_Types[] = { (&Enumerator_t1298455868_gp_0_0_0_0), (&Enumerator_t1298455868_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t1298455868_gp_0_0_0_0_Enumerator_t1298455868_gp_1_0_0_0 = { 2, GenInst_Enumerator_t1298455868_gp_0_0_0_0_Enumerator_t1298455868_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t1298455868_gp_0_0_0_0_Types[] = { (&Enumerator_t1298455868_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t1298455868_gp_0_0_0_0 = { 1, GenInst_Enumerator_t1298455868_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0_Types[] = { (&KeyCollection_t3609397419_gp_0_0_0_0), (&KeyCollection_t3609397419_gp_1_0_0_0), (&KeyCollection_t3609397419_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0 = { 3, GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0_Types[] = { (&KeyCollection_t3609397419_gp_0_0_0_0), (&KeyCollection_t3609397419_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0 = { 2, GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types[] = { (&ValueCollection_t59155699_gp_0_0_0_0), (&ValueCollection_t59155699_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0 = { 2, GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_ValueCollection_t59155699_gp_1_0_0_0_Types[] = { (&ValueCollection_t59155699_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ValueCollection_t59155699_gp_1_0_0_0 = { 1, GenInst_ValueCollection_t59155699_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t3190540399_gp_0_0_0_0_Enumerator_t3190540399_gp_1_0_0_0_Types[] = { (&Enumerator_t3190540399_gp_0_0_0_0), (&Enumerator_t3190540399_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t3190540399_gp_0_0_0_0_Enumerator_t3190540399_gp_1_0_0_0 = { 2, GenInst_Enumerator_t3190540399_gp_0_0_0_0_Enumerator_t3190540399_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t3190540399_gp_1_0_0_0_Types[] = { (&Enumerator_t3190540399_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t3190540399_gp_1_0_0_0 = { 1, GenInst_Enumerator_t3190540399_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types[] = { (&ValueCollection_t59155699_gp_0_0_0_0), (&ValueCollection_t59155699_gp_1_0_0_0), (&ValueCollection_t59155699_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0 = { 3, GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types[] = { (&ValueCollection_t59155699_gp_1_0_0_0), (&ValueCollection_t59155699_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0 = { 2, GenInst_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_DictionaryEntry_t299448291_0_0_0_DictionaryEntry_t299448291_0_0_0_Types[] = { (&DictionaryEntry_t299448291_0_0_0), (&DictionaryEntry_t299448291_0_0_0) };
extern const Il2CppGenericInst GenInst_DictionaryEntry_t299448291_0_0_0_DictionaryEntry_t299448291_0_0_0 = { 2, GenInst_DictionaryEntry_t299448291_0_0_0_DictionaryEntry_t299448291_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_KeyValuePair_2_t373669827_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_0_0_0_0), (&Dictionary_2_t2809050045_gp_1_0_0_0), (&KeyValuePair_2_t373669827_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_KeyValuePair_2_t373669827_0_0_0 = { 3, GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_KeyValuePair_2_t373669827_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t373669827_0_0_0_KeyValuePair_2_t373669827_0_0_0_Types[] = { (&KeyValuePair_2_t373669827_0_0_0), (&KeyValuePair_2_t373669827_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t373669827_0_0_0_KeyValuePair_2_t373669827_0_0_0 = { 2, GenInst_KeyValuePair_2_t373669827_0_0_0_KeyValuePair_2_t373669827_0_0_0_Types };
static const RuntimeType* GenInst_Dictionary_2_t2809050045_gp_1_0_0_0_Types[] = { (&Dictionary_2_t2809050045_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_Dictionary_2_t2809050045_gp_1_0_0_0 = { 1, GenInst_Dictionary_2_t2809050045_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_EqualityComparer_1_t1605754411_gp_0_0_0_0_Types[] = { (&EqualityComparer_1_t1605754411_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_EqualityComparer_1_t1605754411_gp_0_0_0_0 = { 1, GenInst_EqualityComparer_1_t1605754411_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_DefaultComparer_t790800357_gp_0_0_0_0_Types[] = { (&DefaultComparer_t790800357_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultComparer_t790800357_gp_0_0_0_0 = { 1, GenInst_DefaultComparer_t790800357_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GenericEqualityComparer_1_t692778042_gp_0_0_0_0_Types[] = { (&GenericEqualityComparer_1_t692778042_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GenericEqualityComparer_1_t692778042_gp_0_0_0_0 = { 1, GenInst_GenericEqualityComparer_1_t692778042_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2431883363_0_0_0_Types[] = { (&KeyValuePair_2_t2431883363_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2431883363_0_0_0 = { 1, GenInst_KeyValuePair_2_t2431883363_0_0_0_Types };
static const RuntimeType* GenInst_IDictionary_2_t4171839189_gp_0_0_0_0_IDictionary_2_t4171839189_gp_1_0_0_0_Types[] = { (&IDictionary_2_t4171839189_gp_0_0_0_0), (&IDictionary_2_t4171839189_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_IDictionary_2_t4171839189_gp_0_0_0_0_IDictionary_2_t4171839189_gp_1_0_0_0 = { 2, GenInst_IDictionary_2_t4171839189_gp_0_0_0_0_IDictionary_2_t4171839189_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t917785449_gp_0_0_0_0_KeyValuePair_2_t917785449_gp_1_0_0_0_Types[] = { (&KeyValuePair_2_t917785449_gp_0_0_0_0), (&KeyValuePair_2_t917785449_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t917785449_gp_0_0_0_0_KeyValuePair_2_t917785449_gp_1_0_0_0 = { 2, GenInst_KeyValuePair_2_t917785449_gp_0_0_0_0_KeyValuePair_2_t917785449_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t1768017692_gp_0_0_0_0_Types[] = { (&List_1_t1768017692_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t1768017692_gp_0_0_0_0 = { 1, GenInst_List_1_t1768017692_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t924438735_gp_0_0_0_0_Types[] = { (&Enumerator_t924438735_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t924438735_gp_0_0_0_0 = { 1, GenInst_Enumerator_t924438735_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Collection_1_t3943914114_gp_0_0_0_0_Types[] = { (&Collection_1_t3943914114_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Collection_1_t3943914114_gp_0_0_0_0 = { 1, GenInst_Collection_1_t3943914114_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ReadOnlyCollection_1_t3380407612_gp_0_0_0_0_Types[] = { (&ReadOnlyCollection_1_t3380407612_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ReadOnlyCollection_1_t3380407612_gp_0_0_0_0 = { 1, GenInst_ReadOnlyCollection_1_t3380407612_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0_Types[] = { (&MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0), (&MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0 = { 2, GenInst_MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0_Types[] = { (&MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0 = { 1, GenInst_MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ArraySegment_1_t1939258092_gp_0_0_0_0_Types[] = { (&ArraySegment_1_t1939258092_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ArraySegment_1_t1939258092_gp_0_0_0_0 = { 1, GenInst_ArraySegment_1_t1939258092_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Queue_1_t1750955003_gp_0_0_0_0_Types[] = { (&Queue_1_t1750955003_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Queue_1_t1750955003_gp_0_0_0_0 = { 1, GenInst_Queue_1_t1750955003_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t2644889458_gp_0_0_0_0_Types[] = { (&Enumerator_t2644889458_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t2644889458_gp_0_0_0_0 = { 1, GenInst_Enumerator_t2644889458_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Stack_1_t3976444548_gp_0_0_0_0_Types[] = { (&Stack_1_t3976444548_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Stack_1_t3976444548_gp_0_0_0_0 = { 1, GenInst_Stack_1_t3976444548_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t3983460471_gp_0_0_0_0_Types[] = { (&Enumerator_t3983460471_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t3983460471_gp_0_0_0_0 = { 1, GenInst_Enumerator_t3983460471_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_HashSet_1_t182226283_gp_0_0_0_0_Types[] = { (&HashSet_1_t182226283_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_HashSet_1_t182226283_gp_0_0_0_0 = { 1, GenInst_HashSet_1_t182226283_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerator_t2669265363_gp_0_0_0_0_Types[] = { (&Enumerator_t2669265363_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerator_t2669265363_gp_0_0_0_0 = { 1, GenInst_Enumerator_t2669265363_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_PrimeHelper_t4001087760_gp_0_0_0_0_Types[] = { (&PrimeHelper_t4001087760_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_PrimeHelper_t4001087760_gp_0_0_0_0 = { 1, GenInst_PrimeHelper_t4001087760_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Any_m3044489537_gp_0_0_0_0_Types[] = { (&Enumerable_Any_m3044489537_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Any_m3044489537_gp_0_0_0_0 = { 1, GenInst_Enumerable_Any_m3044489537_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Types[] = { (&Enumerable_Where_m509811445_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Where_m509811445_gp_0_0_0_0 = { 1, GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Enumerable_Where_m509811445_gp_0_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Types[] = { (&Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0 = { 1, GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Types[] = { (&U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0 = { 1, GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentInChildren_m1658374531_gp_0_0_0_0_Types[] = { (&Component_GetComponentInChildren_m1658374531_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentInChildren_m1658374531_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentInChildren_m1658374531_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponentsInParent_m2393957797_gp_0_0_0_0_Types[] = { (&Component_GetComponentsInParent_m2393957797_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponentsInParent_m2393957797_gp_0_0_0_0 = { 1, GenInst_Component_GetComponentsInParent_m2393957797_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponents_m1510131101_gp_0_0_0_0_Types[] = { (&Component_GetComponents_m1510131101_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponents_m1510131101_gp_0_0_0_0 = { 1, GenInst_Component_GetComponents_m1510131101_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Component_GetComponents_m2882340512_gp_0_0_0_0_Types[] = { (&Component_GetComponents_m2882340512_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Component_GetComponents_m2882340512_gp_0_0_0_0 = { 1, GenInst_Component_GetComponents_m2882340512_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0_Types[] = { (&GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponents_m318279657_gp_0_0_0_0_Types[] = { (&GameObject_GetComponents_m318279657_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponents_m318279657_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponents_m318279657_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0_Types[] = { (&GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0_Types[] = { (&GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0 = { 1, GenInst_GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0_Types[] = { (&Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0 = { 1, GenInst_Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Mesh_SafeLength_m1544801684_gp_0_0_0_0_Types[] = { (&Mesh_SafeLength_m1544801684_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Mesh_SafeLength_m1544801684_gp_0_0_0_0 = { 1, GenInst_Mesh_SafeLength_m1544801684_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Mesh_SetListForChannel_m131533298_gp_0_0_0_0_Types[] = { (&Mesh_SetListForChannel_m131533298_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Mesh_SetListForChannel_m131533298_gp_0_0_0_0 = { 1, GenInst_Mesh_SetListForChannel_m131533298_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Mesh_SetListForChannel_m326208384_gp_0_0_0_0_Types[] = { (&Mesh_SetListForChannel_m326208384_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Mesh_SetListForChannel_m326208384_gp_0_0_0_0 = { 1, GenInst_Mesh_SetListForChannel_m326208384_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0_Types[] = { (&Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0 = { 1, GenInst_Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_1_t3177580188_gp_0_0_0_0_Types[] = { (&InvokableCall_1_t3177580188_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_1_t3177580188_gp_0_0_0_0 = { 1, GenInst_InvokableCall_1_t3177580188_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityAction_1_t1512030109_0_0_0_Types[] = { (&UnityAction_1_t1512030109_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityAction_1_t1512030109_0_0_0 = { 1, GenInst_UnityAction_1_t1512030109_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_InvokableCall_2_t4177718962_gp_1_0_0_0_Types[] = { (&InvokableCall_2_t4177718962_gp_0_0_0_0), (&InvokableCall_2_t4177718962_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_InvokableCall_2_t4177718962_gp_1_0_0_0 = { 2, GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_InvokableCall_2_t4177718962_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_Types[] = { (&InvokableCall_2_t4177718962_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0 = { 1, GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_2_t4177718962_gp_1_0_0_0_Types[] = { (&InvokableCall_2_t4177718962_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_2_t4177718962_gp_1_0_0_0 = { 1, GenInst_InvokableCall_2_t4177718962_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_InvokableCall_3_t1109707351_gp_1_0_0_0_InvokableCall_3_t1109707351_gp_2_0_0_0_Types[] = { (&InvokableCall_3_t1109707351_gp_0_0_0_0), (&InvokableCall_3_t1109707351_gp_1_0_0_0), (&InvokableCall_3_t1109707351_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_InvokableCall_3_t1109707351_gp_1_0_0_0_InvokableCall_3_t1109707351_gp_2_0_0_0 = { 3, GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_InvokableCall_3_t1109707351_gp_1_0_0_0_InvokableCall_3_t1109707351_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_Types[] = { (&InvokableCall_3_t1109707351_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0 = { 1, GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t1109707351_gp_1_0_0_0_Types[] = { (&InvokableCall_3_t1109707351_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t1109707351_gp_1_0_0_0 = { 1, GenInst_InvokableCall_3_t1109707351_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_3_t1109707351_gp_2_0_0_0_Types[] = { (&InvokableCall_3_t1109707351_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_3_t1109707351_gp_2_0_0_0 = { 1, GenInst_InvokableCall_3_t1109707351_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_InvokableCall_4_t2839234570_gp_1_0_0_0_InvokableCall_4_t2839234570_gp_2_0_0_0_InvokableCall_4_t2839234570_gp_3_0_0_0_Types[] = { (&InvokableCall_4_t2839234570_gp_0_0_0_0), (&InvokableCall_4_t2839234570_gp_1_0_0_0), (&InvokableCall_4_t2839234570_gp_2_0_0_0), (&InvokableCall_4_t2839234570_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_InvokableCall_4_t2839234570_gp_1_0_0_0_InvokableCall_4_t2839234570_gp_2_0_0_0_InvokableCall_4_t2839234570_gp_3_0_0_0 = { 4, GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_InvokableCall_4_t2839234570_gp_1_0_0_0_InvokableCall_4_t2839234570_gp_2_0_0_0_InvokableCall_4_t2839234570_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_Types[] = { (&InvokableCall_4_t2839234570_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0 = { 1, GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t2839234570_gp_1_0_0_0_Types[] = { (&InvokableCall_4_t2839234570_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t2839234570_gp_1_0_0_0 = { 1, GenInst_InvokableCall_4_t2839234570_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t2839234570_gp_2_0_0_0_Types[] = { (&InvokableCall_4_t2839234570_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t2839234570_gp_2_0_0_0 = { 1, GenInst_InvokableCall_4_t2839234570_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_InvokableCall_4_t2839234570_gp_3_0_0_0_Types[] = { (&InvokableCall_4_t2839234570_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_InvokableCall_4_t2839234570_gp_3_0_0_0 = { 1, GenInst_InvokableCall_4_t2839234570_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_CachedInvokableCall_1_t1763259375_gp_0_0_0_0_Types[] = { (&CachedInvokableCall_1_t1763259375_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_CachedInvokableCall_1_t1763259375_gp_0_0_0_0 = { 1, GenInst_CachedInvokableCall_1_t1763259375_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_1_t2513023335_gp_0_0_0_0_Types[] = { (&UnityEvent_1_t2513023335_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_1_t2513023335_gp_0_0_0_0 = { 1, GenInst_UnityEvent_1_t2513023335_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_2_t3919372254_gp_0_0_0_0_UnityEvent_2_t3919372254_gp_1_0_0_0_Types[] = { (&UnityEvent_2_t3919372254_gp_0_0_0_0), (&UnityEvent_2_t3919372254_gp_1_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_2_t3919372254_gp_0_0_0_0_UnityEvent_2_t3919372254_gp_1_0_0_0 = { 2, GenInst_UnityEvent_2_t3919372254_gp_0_0_0_0_UnityEvent_2_t3919372254_gp_1_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_3_t2232704357_gp_0_0_0_0_UnityEvent_3_t2232704357_gp_1_0_0_0_UnityEvent_3_t2232704357_gp_2_0_0_0_Types[] = { (&UnityEvent_3_t2232704357_gp_0_0_0_0), (&UnityEvent_3_t2232704357_gp_1_0_0_0), (&UnityEvent_3_t2232704357_gp_2_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_3_t2232704357_gp_0_0_0_0_UnityEvent_3_t2232704357_gp_1_0_0_0_UnityEvent_3_t2232704357_gp_2_0_0_0 = { 3, GenInst_UnityEvent_3_t2232704357_gp_0_0_0_0_UnityEvent_3_t2232704357_gp_1_0_0_0_UnityEvent_3_t2232704357_gp_2_0_0_0_Types };
static const RuntimeType* GenInst_UnityEvent_4_t4058827200_gp_0_0_0_0_UnityEvent_4_t4058827200_gp_1_0_0_0_UnityEvent_4_t4058827200_gp_2_0_0_0_UnityEvent_4_t4058827200_gp_3_0_0_0_Types[] = { (&UnityEvent_4_t4058827200_gp_0_0_0_0), (&UnityEvent_4_t4058827200_gp_1_0_0_0), (&UnityEvent_4_t4058827200_gp_2_0_0_0), (&UnityEvent_4_t4058827200_gp_3_0_0_0) };
extern const Il2CppGenericInst GenInst_UnityEvent_4_t4058827200_gp_0_0_0_0_UnityEvent_4_t4058827200_gp_1_0_0_0_UnityEvent_4_t4058827200_gp_2_0_0_0_UnityEvent_4_t4058827200_gp_3_0_0_0 = { 4, GenInst_UnityEvent_4_t4058827200_gp_0_0_0_0_UnityEvent_4_t4058827200_gp_1_0_0_0_UnityEvent_4_t4058827200_gp_2_0_0_0_UnityEvent_4_t4058827200_gp_3_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteEvents_Execute_m3971585966_gp_0_0_0_0_Types[] = { (&ExecuteEvents_Execute_m3971585966_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteEvents_Execute_m3971585966_gp_0_0_0_0 = { 1, GenInst_ExecuteEvents_Execute_m3971585966_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0_Types[] = { (&ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0 = { 1, GenInst_ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0_Types[] = { (&ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0 = { 1, GenInst_ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0_Types[] = { (&ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0 = { 1, GenInst_ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0_Types[] = { (&ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0 = { 1, GenInst_ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_TweenRunner_1_t2568776171_gp_0_0_0_0_Types[] = { (&TweenRunner_1_t2568776171_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_TweenRunner_1_t2568776171_gp_0_0_0_0 = { 1, GenInst_TweenRunner_1_t2568776171_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0_Types[] = { (&Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0 = { 1, GenInst_Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0_Types[] = { (&SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0 = { 1, GenInst_SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Types[] = { (&IndexedSet_1_t2472654987_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0 = { 1, GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&IndexedSet_1_t2472654987_gp_0_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_ListPool_1_t3291784397_gp_0_0_0_0_Types[] = { (&ListPool_1_t3291784397_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ListPool_1_t3291784397_gp_0_0_0_0 = { 1, GenInst_ListPool_1_t3291784397_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_List_1_t3931617359_0_0_0_Types[] = { (&List_1_t3931617359_0_0_0) };
extern const Il2CppGenericInst GenInst_List_1_t3931617359_0_0_0 = { 1, GenInst_List_1_t3931617359_0_0_0_Types };
static const RuntimeType* GenInst_ObjectPool_1_t1412409661_gp_0_0_0_0_Types[] = { (&ObjectPool_1_t1412409661_gp_0_0_0_0) };
extern const Il2CppGenericInst GenInst_ObjectPool_1_t1412409661_gp_0_0_0_0 = { 1, GenInst_ObjectPool_1_t1412409661_gp_0_0_0_0_Types };
static const RuntimeType* GenInst_DefaultExecutionOrder_t533427438_0_0_0_Types[] = { (&DefaultExecutionOrder_t533427438_0_0_0) };
extern const Il2CppGenericInst GenInst_DefaultExecutionOrder_t533427438_0_0_0 = { 1, GenInst_DefaultExecutionOrder_t533427438_0_0_0_Types };
static const RuntimeType* GenInst_PlayerConnection_t3376987642_0_0_0_Types[] = { (&PlayerConnection_t3376987642_0_0_0) };
extern const Il2CppGenericInst GenInst_PlayerConnection_t3376987642_0_0_0 = { 1, GenInst_PlayerConnection_t3376987642_0_0_0_Types };
static const RuntimeType* GenInst_GUILayer_t368266309_0_0_0_Types[] = { (&GUILayer_t368266309_0_0_0) };
extern const Il2CppGenericInst GenInst_GUILayer_t368266309_0_0_0 = { 1, GenInst_GUILayer_t368266309_0_0_0_Types };
static const RuntimeType* GenInst_AxisEventData_t2495346144_0_0_0_Types[] = { (&AxisEventData_t2495346144_0_0_0) };
extern const Il2CppGenericInst GenInst_AxisEventData_t2495346144_0_0_0 = { 1, GenInst_AxisEventData_t2495346144_0_0_0_Types };
static const RuntimeType* GenInst_SpriteRenderer_t924888996_0_0_0_Types[] = { (&SpriteRenderer_t924888996_0_0_0) };
extern const Il2CppGenericInst GenInst_SpriteRenderer_t924888996_0_0_0 = { 1, GenInst_SpriteRenderer_t924888996_0_0_0_Types };
static const RuntimeType* GenInst_Image_t325497262_0_0_0_Types[] = { (&Image_t325497262_0_0_0) };
extern const Il2CppGenericInst GenInst_Image_t325497262_0_0_0 = { 1, GenInst_Image_t325497262_0_0_0_Types };
static const RuntimeType* GenInst_Button_t1951982026_0_0_0_Types[] = { (&Button_t1951982026_0_0_0) };
extern const Il2CppGenericInst GenInst_Button_t1951982026_0_0_0 = { 1, GenInst_Button_t1951982026_0_0_0_Types };
static const RuntimeType* GenInst_RawImage_t2311903931_0_0_0_Types[] = { (&RawImage_t2311903931_0_0_0) };
extern const Il2CppGenericInst GenInst_RawImage_t2311903931_0_0_0 = { 1, GenInst_RawImage_t2311903931_0_0_0_Types };
static const RuntimeType* GenInst_Slider_t599575794_0_0_0_Types[] = { (&Slider_t599575794_0_0_0) };
extern const Il2CppGenericInst GenInst_Slider_t599575794_0_0_0 = { 1, GenInst_Slider_t599575794_0_0_0_Types };
static const RuntimeType* GenInst_Scrollbar_t2833447691_0_0_0_Types[] = { (&Scrollbar_t2833447691_0_0_0) };
extern const Il2CppGenericInst GenInst_Scrollbar_t2833447691_0_0_0 = { 1, GenInst_Scrollbar_t2833447691_0_0_0_Types };
static const RuntimeType* GenInst_InputField_t1009335159_0_0_0_Types[] = { (&InputField_t1009335159_0_0_0) };
extern const Il2CppGenericInst GenInst_InputField_t1009335159_0_0_0 = { 1, GenInst_InputField_t1009335159_0_0_0_Types };
static const RuntimeType* GenInst_ScrollRect_t1909087471_0_0_0_Types[] = { (&ScrollRect_t1909087471_0_0_0) };
extern const Il2CppGenericInst GenInst_ScrollRect_t1909087471_0_0_0 = { 1, GenInst_ScrollRect_t1909087471_0_0_0_Types };
static const RuntimeType* GenInst_Dropdown_t532982771_0_0_0_Types[] = { (&Dropdown_t532982771_0_0_0) };
extern const Il2CppGenericInst GenInst_Dropdown_t532982771_0_0_0 = { 1, GenInst_Dropdown_t532982771_0_0_0_Types };
static const RuntimeType* GenInst_GraphicRaycaster_t3206056917_0_0_0_Types[] = { (&GraphicRaycaster_t3206056917_0_0_0) };
extern const Il2CppGenericInst GenInst_GraphicRaycaster_t3206056917_0_0_0 = { 1, GenInst_GraphicRaycaster_t3206056917_0_0_0_Types };
static const RuntimeType* GenInst_CanvasRenderer_t3614328869_0_0_0_Types[] = { (&CanvasRenderer_t3614328869_0_0_0) };
extern const Il2CppGenericInst GenInst_CanvasRenderer_t3614328869_0_0_0 = { 1, GenInst_CanvasRenderer_t3614328869_0_0_0_Types };
static const RuntimeType* GenInst_Corner_t2478443190_0_0_0_Types[] = { (&Corner_t2478443190_0_0_0) };
extern const Il2CppGenericInst GenInst_Corner_t2478443190_0_0_0 = { 1, GenInst_Corner_t2478443190_0_0_0_Types };
static const RuntimeType* GenInst_Axis_t3769150349_0_0_0_Types[] = { (&Axis_t3769150349_0_0_0) };
extern const Il2CppGenericInst GenInst_Axis_t3769150349_0_0_0 = { 1, GenInst_Axis_t3769150349_0_0_0_Types };
static const RuntimeType* GenInst_Constraint_t2227253834_0_0_0_Types[] = { (&Constraint_t2227253834_0_0_0) };
extern const Il2CppGenericInst GenInst_Constraint_t2227253834_0_0_0 = { 1, GenInst_Constraint_t2227253834_0_0_0_Types };
static const RuntimeType* GenInst_SubmitEvent_t984659408_0_0_0_Types[] = { (&SubmitEvent_t984659408_0_0_0) };
extern const Il2CppGenericInst GenInst_SubmitEvent_t984659408_0_0_0 = { 1, GenInst_SubmitEvent_t984659408_0_0_0_Types };
static const RuntimeType* GenInst_OnChangeEvent_t425979699_0_0_0_Types[] = { (&OnChangeEvent_t425979699_0_0_0) };
extern const Il2CppGenericInst GenInst_OnChangeEvent_t425979699_0_0_0 = { 1, GenInst_OnChangeEvent_t425979699_0_0_0_Types };
static const RuntimeType* GenInst_OnValidateInput_t3315013029_0_0_0_Types[] = { (&OnValidateInput_t3315013029_0_0_0) };
extern const Il2CppGenericInst GenInst_OnValidateInput_t3315013029_0_0_0 = { 1, GenInst_OnValidateInput_t3315013029_0_0_0_Types };
static const RuntimeType* GenInst_LayoutElement_t530979270_0_0_0_Types[] = { (&LayoutElement_t530979270_0_0_0) };
extern const Il2CppGenericInst GenInst_LayoutElement_t530979270_0_0_0 = { 1, GenInst_LayoutElement_t530979270_0_0_0_Types };
static const RuntimeType* GenInst_RectOffset_t2531911544_0_0_0_Types[] = { (&RectOffset_t2531911544_0_0_0) };
extern const Il2CppGenericInst GenInst_RectOffset_t2531911544_0_0_0 = { 1, GenInst_RectOffset_t2531911544_0_0_0_Types };
static const RuntimeType* GenInst_TextAnchor_t1172919424_0_0_0_Types[] = { (&TextAnchor_t1172919424_0_0_0) };
extern const Il2CppGenericInst GenInst_TextAnchor_t1172919424_0_0_0 = { 1, GenInst_TextAnchor_t1172919424_0_0_0_Types };
static const RuntimeType* GenInst_AnimationTriggers_t1273266827_0_0_0_Types[] = { (&AnimationTriggers_t1273266827_0_0_0) };
extern const Il2CppGenericInst GenInst_AnimationTriggers_t1273266827_0_0_0 = { 1, GenInst_AnimationTriggers_t1273266827_0_0_0_Types };
static const RuntimeType* GenInst_Animator_t4196124252_0_0_0_Types[] = { (&Animator_t4196124252_0_0_0) };
extern const Il2CppGenericInst GenInst_Animator_t4196124252_0_0_0 = { 1, GenInst_Animator_t4196124252_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3005528154_0_0_0_KeyValuePair_2_t3005528154_0_0_0_Types[] = { (&KeyValuePair_2_t3005528154_0_0_0), (&KeyValuePair_2_t3005528154_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3005528154_0_0_0_KeyValuePair_2_t3005528154_0_0_0 = { 2, GenInst_KeyValuePair_2_t3005528154_0_0_0_KeyValuePair_2_t3005528154_0_0_0_Types };
static const RuntimeType* GenInst_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0_Types[] = { (&Int32_t2946131084_0_0_0), (&Int32_t2946131084_0_0_0) };
extern const Il2CppGenericInst GenInst_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0 = { 2, GenInst_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_CustomAttributeNamedArgument_t3066689011_0_0_0_Types[] = { (&CustomAttributeNamedArgument_t3066689011_0_0_0), (&CustomAttributeNamedArgument_t3066689011_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_CustomAttributeNamedArgument_t3066689011_0_0_0 = { 2, GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_CustomAttributeNamedArgument_t3066689011_0_0_0_Types };
static const RuntimeType* GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_CustomAttributeTypedArgument_t437198719_0_0_0_Types[] = { (&CustomAttributeTypedArgument_t437198719_0_0_0), (&CustomAttributeTypedArgument_t437198719_0_0_0) };
extern const Il2CppGenericInst GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_CustomAttributeTypedArgument_t437198719_0_0_0 = { 2, GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_CustomAttributeTypedArgument_t437198719_0_0_0_Types };
static const RuntimeType* GenInst_Color32_t1281607702_0_0_0_Color32_t1281607702_0_0_0_Types[] = { (&Color32_t1281607702_0_0_0), (&Color32_t1281607702_0_0_0) };
extern const Il2CppGenericInst GenInst_Color32_t1281607702_0_0_0_Color32_t1281607702_0_0_0 = { 2, GenInst_Color32_t1281607702_0_0_0_Color32_t1281607702_0_0_0_Types };
static const RuntimeType* GenInst_RaycastResult_t3064114207_0_0_0_RaycastResult_t3064114207_0_0_0_Types[] = { (&RaycastResult_t3064114207_0_0_0), (&RaycastResult_t3064114207_0_0_0) };
extern const Il2CppGenericInst GenInst_RaycastResult_t3064114207_0_0_0_RaycastResult_t3064114207_0_0_0 = { 2, GenInst_RaycastResult_t3064114207_0_0_0_RaycastResult_t3064114207_0_0_0_Types };
static const RuntimeType* GenInst_UICharInfo_t498913270_0_0_0_UICharInfo_t498913270_0_0_0_Types[] = { (&UICharInfo_t498913270_0_0_0), (&UICharInfo_t498913270_0_0_0) };
extern const Il2CppGenericInst GenInst_UICharInfo_t498913270_0_0_0_UICharInfo_t498913270_0_0_0 = { 2, GenInst_UICharInfo_t498913270_0_0_0_UICharInfo_t498913270_0_0_0_Types };
static const RuntimeType* GenInst_UILineInfo_t2500817891_0_0_0_UILineInfo_t2500817891_0_0_0_Types[] = { (&UILineInfo_t2500817891_0_0_0), (&UILineInfo_t2500817891_0_0_0) };
extern const Il2CppGenericInst GenInst_UILineInfo_t2500817891_0_0_0_UILineInfo_t2500817891_0_0_0 = { 2, GenInst_UILineInfo_t2500817891_0_0_0_UILineInfo_t2500817891_0_0_0_Types };
static const RuntimeType* GenInst_UIVertex_t3704361653_0_0_0_UIVertex_t3704361653_0_0_0_Types[] = { (&UIVertex_t3704361653_0_0_0), (&UIVertex_t3704361653_0_0_0) };
extern const Il2CppGenericInst GenInst_UIVertex_t3704361653_0_0_0_UIVertex_t3704361653_0_0_0 = { 2, GenInst_UIVertex_t3704361653_0_0_0_UIVertex_t3704361653_0_0_0_Types };
static const RuntimeType* GenInst_Vector2_t1743417791_0_0_0_Vector2_t1743417791_0_0_0_Types[] = { (&Vector2_t1743417791_0_0_0), (&Vector2_t1743417791_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector2_t1743417791_0_0_0_Vector2_t1743417791_0_0_0 = { 2, GenInst_Vector2_t1743417791_0_0_0_Vector2_t1743417791_0_0_0_Types };
static const RuntimeType* GenInst_Vector3_t2486370225_0_0_0_Vector3_t2486370225_0_0_0_Types[] = { (&Vector3_t2486370225_0_0_0), (&Vector3_t2486370225_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector3_t2486370225_0_0_0_Vector3_t2486370225_0_0_0 = { 2, GenInst_Vector3_t2486370225_0_0_0_Vector3_t2486370225_0_0_0_Types };
static const RuntimeType* GenInst_Vector4_t4214292213_0_0_0_Vector4_t4214292213_0_0_0_Types[] = { (&Vector4_t4214292213_0_0_0), (&Vector4_t4214292213_0_0_0) };
extern const Il2CppGenericInst GenInst_Vector4_t4214292213_0_0_0_Vector4_t4214292213_0_0_0 = { 2, GenInst_Vector4_t4214292213_0_0_0_Vector4_t4214292213_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t501915592_0_0_0_KeyValuePair_2_t501915592_0_0_0_Types[] = { (&KeyValuePair_2_t501915592_0_0_0), (&KeyValuePair_2_t501915592_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t501915592_0_0_0_KeyValuePair_2_t501915592_0_0_0 = { 2, GenInst_KeyValuePair_2_t501915592_0_0_0_KeyValuePair_2_t501915592_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t501915592_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t501915592_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t501915592_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t501915592_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t573483709_0_0_0_KeyValuePair_2_t573483709_0_0_0_Types[] = { (&KeyValuePair_2_t573483709_0_0_0), (&KeyValuePair_2_t573483709_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t573483709_0_0_0_KeyValuePair_2_t573483709_0_0_0 = { 2, GenInst_KeyValuePair_2_t573483709_0_0_0_KeyValuePair_2_t573483709_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t573483709_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t573483709_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t573483709_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t573483709_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_IntPtr_t_0_0_0_IntPtr_t_0_0_0_Types[] = { (&IntPtr_t_0_0_0), (&IntPtr_t_0_0_0) };
extern const Il2CppGenericInst GenInst_IntPtr_t_0_0_0_IntPtr_t_0_0_0 = { 2, GenInst_IntPtr_t_0_0_0_IntPtr_t_0_0_0_Types };
static const RuntimeType* GenInst_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0_Types[] = { (&Boolean_t2724601657_0_0_0), (&Boolean_t2724601657_0_0_0) };
extern const Il2CppGenericInst GenInst_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0 = { 2, GenInst_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2928695729_0_0_0_KeyValuePair_2_t2928695729_0_0_0_Types[] = { (&KeyValuePair_2_t2928695729_0_0_0), (&KeyValuePair_2_t2928695729_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2928695729_0_0_0_KeyValuePair_2_t2928695729_0_0_0 = { 2, GenInst_KeyValuePair_2_t2928695729_0_0_0_KeyValuePair_2_t2928695729_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t2928695729_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t2928695729_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t2928695729_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t2928695729_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3150225156_0_0_0_KeyValuePair_2_t3150225156_0_0_0_Types[] = { (&KeyValuePair_2_t3150225156_0_0_0), (&KeyValuePair_2_t3150225156_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3150225156_0_0_0_KeyValuePair_2_t3150225156_0_0_0 = { 2, GenInst_KeyValuePair_2_t3150225156_0_0_0_KeyValuePair_2_t3150225156_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3150225156_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t3150225156_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3150225156_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t3150225156_0_0_0_RuntimeObject_0_0_0_Types };
static const RuntimeType* GenInst_KeyValuePair_2_t3005528154_0_0_0_RuntimeObject_0_0_0_Types[] = { (&KeyValuePair_2_t3005528154_0_0_0), (&RuntimeObject_0_0_0) };
extern const Il2CppGenericInst GenInst_KeyValuePair_2_t3005528154_0_0_0_RuntimeObject_0_0_0 = { 2, GenInst_KeyValuePair_2_t3005528154_0_0_0_RuntimeObject_0_0_0_Types };
extern const Il2CppGenericInst* const g_Il2CppGenericInstTable[602] = 
{
	&GenInst_RuntimeObject_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0,
	&GenInst_Char_t4123521152_0_0_0,
	&GenInst_Int64_t2942533987_0_0_0,
	&GenInst_UInt32_t1505113534_0_0_0,
	&GenInst_UInt64_t4149917651_0_0_0,
	&GenInst_Byte_t2596701031_0_0_0,
	&GenInst_SByte_t669469354_0_0_0,
	&GenInst_Int16_t612759502_0_0_0,
	&GenInst_UInt16_t1912811313_0_0_0,
	&GenInst_String_t_0_0_0,
	&GenInst_IConvertible_t2202553971_0_0_0,
	&GenInst_IComparable_t320313411_0_0_0,
	&GenInst_IEnumerable_t3475459086_0_0_0,
	&GenInst_ICloneable_t773452278_0_0_0,
	&GenInst_IComparable_1_t1912058747_0_0_0,
	&GenInst_IEquatable_1_t2100626540_0_0_0,
	&GenInst_Type_t_0_0_0,
	&GenInst_IReflect_t3588352395_0_0_0,
	&GenInst__Type_t2237274337_0_0_0,
	&GenInst_MemberInfo_t_0_0_0,
	&GenInst_ICustomAttributeProvider_t3739891389_0_0_0,
	&GenInst__MemberInfo_t2009121772_0_0_0,
	&GenInst_Double_t4024153389_0_0_0,
	&GenInst_Single_t2594644343_0_0_0,
	&GenInst_Decimal_t3889304405_0_0_0,
	&GenInst_Boolean_t2724601657_0_0_0,
	&GenInst_Delegate_t1444972694_0_0_0,
	&GenInst_ISerializable_t3088316472_0_0_0,
	&GenInst_ParameterInfo_t4224039251_0_0_0,
	&GenInst__ParameterInfo_t408303849_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_FieldInfo_t_0_0_0,
	&GenInst__FieldInfo_t2172126836_0_0_0,
	&GenInst_ParameterModifier_t3430991034_0_0_0,
	&GenInst_MethodInfo_t_0_0_0,
	&GenInst__MethodInfo_t2957008391_0_0_0,
	&GenInst_MethodBase_t1529082644_0_0_0,
	&GenInst__MethodBase_t6414478_0_0_0,
	&GenInst_ConstructorInfo_t1000193748_0_0_0,
	&GenInst__ConstructorInfo_t238983269_0_0_0,
	&GenInst_IntPtr_t_0_0_0,
	&GenInst_TableRange_t985732536_0_0_0,
	&GenInst_TailoringInfo_t3490008366_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_KeyValuePair_2_t3150225156_0_0_0,
	&GenInst_Link_t2954686504_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_DictionaryEntry_t299448291_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3150225156_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t3010656940_0_0_0,
	&GenInst_String_t_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3010656940_0_0_0,
	&GenInst_Contraction_t780417899_0_0_0,
	&GenInst_Level2Map_t373027516_0_0_0,
	&GenInst_BigInteger_t1659319351_0_0_0,
	&GenInst_KeySizes_t2881154755_0_0_0,
	&GenInst_KeyValuePair_2_t3005528154_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t3005528154_0_0_0,
	&GenInst_Slot_t3729905400_0_0_0,
	&GenInst_Slot_t2894400404_0_0_0,
	&GenInst_StackFrame_t1830301115_0_0_0,
	&GenInst_Calendar_t3859479017_0_0_0,
	&GenInst_ModuleBuilder_t1725157840_0_0_0,
	&GenInst__ModuleBuilder_t1204975354_0_0_0,
	&GenInst_Module_t2831991231_0_0_0,
	&GenInst__Module_t3287617630_0_0_0,
	&GenInst_ParameterBuilder_t2723302902_0_0_0,
	&GenInst__ParameterBuilder_t626099656_0_0_0,
	&GenInst_TypeU5BU5D_t4189288004_0_0_0,
	&GenInst_RuntimeArray_0_0_0,
	&GenInst_ICollection_t3498861635_0_0_0,
	&GenInst_IList_t4241283331_0_0_0,
	&GenInst_IList_1_t4127410026_0_0_0,
	&GenInst_ICollection_1_t362053986_0_0_0,
	&GenInst_IEnumerable_1_t2665815806_0_0_0,
	&GenInst_IList_1_t2735078972_0_0_0,
	&GenInst_ICollection_1_t3264690228_0_0_0,
	&GenInst_IEnumerable_1_t1273484752_0_0_0,
	&GenInst_IList_1_t1384000914_0_0_0,
	&GenInst_ICollection_1_t1913612170_0_0_0,
	&GenInst_IEnumerable_1_t4217373990_0_0_0,
	&GenInst_IList_1_t3973997_0_0_0,
	&GenInst_ICollection_1_t533585253_0_0_0,
	&GenInst_IEnumerable_1_t2837347073_0_0_0,
	&GenInst_IList_1_t2886617966_0_0_0,
	&GenInst_ICollection_1_t3416229222_0_0_0,
	&GenInst_IEnumerable_1_t1425023746_0_0_0,
	&GenInst_IList_1_t1155848349_0_0_0,
	&GenInst_ICollection_1_t1685459605_0_0_0,
	&GenInst_IEnumerable_1_t3989221425_0_0_0,
	&GenInst_IList_1_t1948160659_0_0_0,
	&GenInst_ICollection_1_t2477771915_0_0_0,
	&GenInst_IEnumerable_1_t486566439_0_0_0,
	&GenInst_ILTokenInfo_t4080941797_0_0_0,
	&GenInst_LabelData_t3378720351_0_0_0,
	&GenInst_LabelFixup_t3442793709_0_0_0,
	&GenInst_GenericTypeParameterBuilder_t3165304919_0_0_0,
	&GenInst_CustomAttributeBuilder_t3519735045_0_0_0,
	&GenInst__CustomAttributeBuilder_t508271582_0_0_0,
	&GenInst_RefEmitPermissionSet_t3776199698_0_0_0,
	&GenInst_TypeBuilder_t428610841_0_0_0,
	&GenInst__TypeBuilder_t1888918970_0_0_0,
	&GenInst_MethodBuilder_t2550065105_0_0_0,
	&GenInst__MethodBuilder_t51529510_0_0_0,
	&GenInst_FieldBuilder_t1795031134_0_0_0,
	&GenInst__FieldBuilder_t2176048174_0_0_0,
	&GenInst_MonoResource_t110510560_0_0_0,
	&GenInst_ConstructorBuilder_t3862957018_0_0_0,
	&GenInst__ConstructorBuilder_t10194797_0_0_0,
	&GenInst_PropertyBuilder_t444456996_0_0_0,
	&GenInst__PropertyBuilder_t2034357485_0_0_0,
	&GenInst_PropertyInfo_t_0_0_0,
	&GenInst__PropertyInfo_t3778442912_0_0_0,
	&GenInst_EventBuilder_t3271757496_0_0_0,
	&GenInst__EventBuilder_t360474911_0_0_0,
	&GenInst_CustomAttributeTypedArgument_t437198719_0_0_0,
	&GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0,
	&GenInst_CustomAttributeData_t2415778318_0_0_0,
	&GenInst_ResourceInfo_t26720911_0_0_0,
	&GenInst_ResourceCacheItem_t2684218735_0_0_0,
	&GenInst_IContextProperty_t3454453605_0_0_0,
	&GenInst_Header_t4048742355_0_0_0,
	&GenInst_ITrackingHandler_t3982758781_0_0_0,
	&GenInst_IContextAttribute_t1709749317_0_0_0,
	&GenInst_DateTime_t4019639461_0_0_0,
	&GenInst_TimeSpan_t2594328967_0_0_0,
	&GenInst_TypeTag_t696993974_0_0_0,
	&GenInst_MonoType_t_0_0_0,
	&GenInst_StrongName_t2807758910_0_0_0,
	&GenInst_IBuiltInEvidence_t4053645731_0_0_0,
	&GenInst_IIdentityPermissionFactory_t3236790479_0_0_0,
	&GenInst_DateTimeOffset_t2136805232_0_0_0,
	&GenInst_Guid_t_0_0_0,
	&GenInst_Version_t506497972_0_0_0,
	&GenInst_BigInteger_t1659319352_0_0_0,
	&GenInst_ByteU5BU5D_t2643433246_0_0_0,
	&GenInst_IList_1_t1743427608_0_0_0,
	&GenInst_ICollection_1_t2273038864_0_0_0,
	&GenInst_IEnumerable_1_t281833388_0_0_0,
	&GenInst_X509Certificate_t953704339_0_0_0,
	&GenInst_IDeserializationCallback_t3942415194_0_0_0,
	&GenInst_ClientCertificateType_t1963204790_0_0_0,
	&GenInst_X509ChainStatus_t1563713867_0_0_0,
	&GenInst_IPAddress_t1944286148_0_0_0,
	&GenInst_ArraySegment_1_t2744003576_0_0_0,
	&GenInst_Cookie_t2357423313_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_KeyValuePair_2_t2928695729_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2928695729_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t2789127513_0_0_0,
	&GenInst_String_t_0_0_0_Boolean_t2724601657_0_0_0_KeyValuePair_2_t2789127513_0_0_0,
	&GenInst_Capture_t2838260575_0_0_0,
	&GenInst_Group_t2467218104_0_0_0,
	&GenInst_Mark_t1992438718_0_0_0,
	&GenInst_UriScheme_t649781592_0_0_0,
	&GenInst_Link_t3921545329_0_0_0,
	&GenInst_AsyncOperation_t3810459996_0_0_0,
	&GenInst_Camera_t274442537_0_0_0,
	&GenInst_Behaviour_t789096462_0_0_0,
	&GenInst_Component_t3460329512_0_0_0,
	&GenInst_Object_t3285695601_0_0_0,
	&GenInst_Display_t3775361438_0_0_0,
	&GenInst_Keyframe_t1299923720_0_0_0,
	&GenInst_Vector3_t2486370225_0_0_0,
	&GenInst_Vector4_t4214292213_0_0_0,
	&GenInst_Vector2_t1743417791_0_0_0,
	&GenInst_Color32_t1281607702_0_0_0,
	&GenInst_Playable_t1563095691_0_0_0,
	&GenInst_PlayableOutput_t2224788333_0_0_0,
	&GenInst_Scene_t2429659677_0_0_0_LoadSceneMode_t38367264_0_0_0,
	&GenInst_Scene_t2429659677_0_0_0,
	&GenInst_Scene_t2429659677_0_0_0_Scene_t2429659677_0_0_0,
	&GenInst_SpriteAtlas_t2907583744_0_0_0,
	&GenInst_DisallowMultipleComponent_t1485140390_0_0_0,
	&GenInst_Attribute_t2363954793_0_0_0,
	&GenInst__Attribute_t705991232_0_0_0,
	&GenInst_ExecuteInEditMode_t2060420173_0_0_0,
	&GenInst_RequireComponent_t2601444532_0_0_0,
	&GenInst_HitInfo_t3242551441_0_0_0,
	&GenInst_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_PersistentCall_t1303572475_0_0_0,
	&GenInst_BaseInvokableCall_t1790754149_0_0_0,
	&GenInst_WorkRequest_t1627094759_0_0_0,
	&GenInst_PlayableBinding_t2631396557_0_0_0,
	&GenInst_MessageTypeSubscribers_t3519534061_0_0_0,
	&GenInst_MessageTypeSubscribers_t3519534061_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_MessageEventArgs_t583925932_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t573483709_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_IntPtr_t_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_IntPtr_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t573483709_0_0_0,
	&GenInst_WeakReference_t842734143_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t2909751066_0_0_0,
	&GenInst_IntPtr_t_0_0_0_WeakReference_t842734143_0_0_0_KeyValuePair_2_t2909751066_0_0_0,
	&GenInst_AudioSpatializerExtensionDefinition_t3945920284_0_0_0,
	&GenInst_AudioAmbisonicExtensionDefinition_t308490681_0_0_0,
	&GenInst_AudioSourceExtension_t3646449378_0_0_0,
	&GenInst_ScriptableObject_t2661394107_0_0_0,
	&GenInst_AudioMixerPlayable_t4111045564_0_0_0,
	&GenInst_AudioClipPlayable_t1629551309_0_0_0,
	&GenInst_Rigidbody2D_t1473351060_0_0_0,
	&GenInst_Font_t82789257_0_0_0,
	&GenInst_UIVertex_t3704361653_0_0_0,
	&GenInst_UICharInfo_t498913270_0_0_0,
	&GenInst_UILineInfo_t2500817891_0_0_0,
	&GenInst_AnimationClipPlayable_t1300644386_0_0_0,
	&GenInst_AnimationLayerMixerPlayable_t1849272991_0_0_0,
	&GenInst_AnimationMixerPlayable_t904356521_0_0_0,
	&GenInst_AnimationOffsetPlayable_t1324066292_0_0_0,
	&GenInst_AnimatorControllerPlayable_t567321136_0_0_0,
	&GenInst_Boolean_t2724601657_0_0_0_String_t_0_0_0,
	&GenInst_Boolean_t2724601657_0_0_0_RuntimeObject_0_0_0,
	&GenInst_AchievementDescription_t1798731768_0_0_0,
	&GenInst_IAchievementDescription_t3768105385_0_0_0,
	&GenInst_UserProfile_t2681963727_0_0_0,
	&GenInst_IUserProfile_t509133715_0_0_0,
	&GenInst_GcLeaderboard_t3783886338_0_0_0,
	&GenInst_IAchievementDescriptionU5BU5D_t2469250452_0_0_0,
	&GenInst_IAchievementU5BU5D_t3797953173_0_0_0,
	&GenInst_IAchievement_t564068860_0_0_0,
	&GenInst_GcAchievementData_t1914197125_0_0_0,
	&GenInst_Achievement_t1636619461_0_0_0,
	&GenInst_IScoreU5BU5D_t768188392_0_0_0,
	&GenInst_IScore_t2787079909_0_0_0,
	&GenInst_GcScoreData_t3281375178_0_0_0,
	&GenInst_Score_t2475763700_0_0_0,
	&GenInst_IUserProfileU5BU5D_t859854018_0_0_0,
	&GenInst_GUILayoutOption_t3642022624_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t501915592_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_RuntimeObject_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t501915592_0_0_0,
	&GenInst_LayoutCache_t3050666578_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t751148088_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_LayoutCache_t3050666578_0_0_0_KeyValuePair_2_t751148088_0_0_0,
	&GenInst_GUILayoutEntry_t3409609005_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_IntPtr_t_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_Exception_t3056413322_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_GUIStyle_t1817005639_0_0_0,
	&GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0,
	&GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t1881531495_0_0_0,
	&GenInst_String_t_0_0_0_GUIStyle_t1817005639_0_0_0_KeyValuePair_2_t1881531495_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t2865959938_0_0_0,
	&GenInst_KeyValuePair_2_t2406658774_0_0_0,
	&GenInst_String_t_0_0_0_DTDNode_t2342132918_0_0_0,
	&GenInst_DTDNode_t2342132918_0_0_0,
	&GenInst_IXmlLineInfo_t3461124495_0_0_0,
	&GenInst_Entry_t4088204333_0_0_0,
	&GenInst_XmlNode_t482051342_0_0_0,
	&GenInst_IXPathNavigable_t3807597221_0_0_0,
	&GenInst_NsDecl_t2771301075_0_0_0,
	&GenInst_NsScope_t1210418454_0_0_0,
	&GenInst_XmlAttributeTokenInfo_t768028006_0_0_0,
	&GenInst_XmlTokenInfo_t2877013752_0_0_0,
	&GenInst_TagName_t1900555770_0_0_0,
	&GenInst_XmlNodeInfo_t3772009616_0_0_0,
	&GenInst_EventSystem_t2763469419_0_0_0,
	&GenInst_UIBehaviour_t2911488490_0_0_0,
	&GenInst_MonoBehaviour_t2760964972_0_0_0,
	&GenInst_BaseInputModule_t3188708927_0_0_0,
	&GenInst_RaycastResult_t3064114207_0_0_0,
	&GenInst_IDeselectHandler_t3080839654_0_0_0,
	&GenInst_IEventSystemHandler_t2937428598_0_0_0,
	&GenInst_List_1_t2929629111_0_0_0,
	&GenInst_List_1_t2793634595_0_0_0,
	&GenInst_List_1_t3452530025_0_0_0,
	&GenInst_ISelectHandler_t2239037249_0_0_0,
	&GenInst_BaseRaycaster_t3516132962_0_0_0,
	&GenInst_Entry_t165374421_0_0_0,
	&GenInst_BaseEventData_t2898106447_0_0_0,
	&GenInst_IPointerEnterHandler_t1495392573_0_0_0,
	&GenInst_IPointerExitHandler_t458397702_0_0_0,
	&GenInst_IPointerDownHandler_t3926188968_0_0_0,
	&GenInst_IPointerUpHandler_t3642990532_0_0_0,
	&GenInst_IPointerClickHandler_t4152680922_0_0_0,
	&GenInst_IInitializePotentialDragHandler_t2460353812_0_0_0,
	&GenInst_IBeginDragHandler_t2985217986_0_0_0,
	&GenInst_IDragHandler_t1695179672_0_0_0,
	&GenInst_IEndDragHandler_t2034818176_0_0_0,
	&GenInst_IDropHandler_t3227688416_0_0_0,
	&GenInst_IScrollHandler_t3788224089_0_0_0,
	&GenInst_IUpdateSelectedHandler_t3604511566_0_0_0,
	&GenInst_IMoveHandler_t2371195586_0_0_0,
	&GenInst_ISubmitHandler_t4239390985_0_0_0,
	&GenInst_ICancelHandler_t881167290_0_0_0,
	&GenInst_Transform_t98390630_0_0_0,
	&GenInst_GameObject_t1069409312_0_0_0,
	&GenInst_BaseInput_t2347852_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0,
	&GenInst_PointerEventData_t110851018_0_0_0,
	&GenInst_AbstractEventData_t2094041248_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t2106299824_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_KeyValuePair_2_t2106299824_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_PointerEventData_t110851018_0_0_0_PointerEventData_t110851018_0_0_0,
	&GenInst_ButtonState_t3919583657_0_0_0,
	&GenInst_RaycastHit2D_t3641439068_0_0_0,
	&GenInst_RaycastHit_t1862035074_0_0_0,
	&GenInst_Color_t2395139082_0_0_0,
	&GenInst_ICanvasElement_t1506473672_0_0_0,
	&GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_ColorBlock_t2528874620_0_0_0,
	&GenInst_OptionData_t308902495_0_0_0,
	&GenInst_DropdownItem_t1280764085_0_0_0,
	&GenInst_FloatTween_t718194525_0_0_0,
	&GenInst_Sprite_t825958079_0_0_0,
	&GenInst_Canvas_t1472555277_0_0_0,
	&GenInst_List_1_t1464755790_0_0_0,
	&GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0,
	&GenInst_Text_t40276147_0_0_0,
	&GenInst_Link_t1160387394_0_0_0,
	&GenInst_ILayoutElement_t3083897574_0_0_0,
	&GenInst_MaskableGraphic_t829384950_0_0_0,
	&GenInst_IClippable_t2595653578_0_0_0,
	&GenInst_IMaskable_t3116280729_0_0_0,
	&GenInst_IMaterialModifier_t2659437676_0_0_0,
	&GenInst_Graphic_t3934133196_0_0_0,
	&GenInst_HashSet_1_t2760900715_0_0_0,
	&GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t1061748416_0_0_0,
	&GenInst_Font_t82789257_0_0_0_HashSet_1_t2760900715_0_0_0_KeyValuePair_2_t1061748416_0_0_0,
	&GenInst_ColorTween_t2126108860_0_0_0,
	&GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0,
	&GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_IndexedSet_1_t3732760996_0_0_0,
	&GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t3977119717_0_0_0,
	&GenInst_Canvas_t1472555277_0_0_0_IndexedSet_1_t3732760996_0_0_0_KeyValuePair_2_t3977119717_0_0_0,
	&GenInst_KeyValuePair_2_t2513357362_0_0_0,
	&GenInst_Graphic_t3934133196_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t2513357362_0_0_0,
	&GenInst_KeyValuePair_2_t3644430278_0_0_0,
	&GenInst_ICanvasElement_t1506473672_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t3644430278_0_0_0,
	&GenInst_Type_t3482946342_0_0_0,
	&GenInst_FillMethod_t1967692376_0_0_0,
	&GenInst_ContentType_t1949393164_0_0_0,
	&GenInst_LineType_t1704015161_0_0_0,
	&GenInst_InputType_t3552287731_0_0_0,
	&GenInst_TouchScreenKeyboardType_t1115125102_0_0_0,
	&GenInst_CharacterValidation_t1615951991_0_0_0,
	&GenInst_Mask_t4273450599_0_0_0,
	&GenInst_ICanvasRaycastFilter_t1727583418_0_0_0,
	&GenInst_List_1_t4265651112_0_0_0,
	&GenInst_RectMask2D_t2940363972_0_0_0,
	&GenInst_IClipper_t3640166804_0_0_0,
	&GenInst_List_1_t2932564485_0_0_0,
	&GenInst_Navigation_t2650002304_0_0_0,
	&GenInst_Link_t3715764825_0_0_0,
	&GenInst_Direction_t2220972688_0_0_0,
	&GenInst_Selectable_t704361702_0_0_0,
	&GenInst_Transition_t3996285674_0_0_0,
	&GenInst_SpriteState_t3463583707_0_0_0,
	&GenInst_CanvasGroup_t4004672386_0_0_0,
	&GenInst_Direction_t169952706_0_0_0,
	&GenInst_MatEntry_t3924390953_0_0_0,
	&GenInst_Toggle_t2394373767_0_0_0,
	&GenInst_Toggle_t2394373767_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_KeyValuePair_2_t659768394_0_0_0,
	&GenInst_IClipper_t3640166804_0_0_0_Int32_t2946131084_0_0_0_KeyValuePair_2_t659768394_0_0_0,
	&GenInst_AspectMode_t2894845584_0_0_0,
	&GenInst_FitMode_t303797140_0_0_0,
	&GenInst_RectTransform_t3170355171_0_0_0,
	&GenInst_LayoutRebuilder_t2138051633_0_0_0,
	&GenInst_ILayoutElement_t3083897574_0_0_0_Single_t2594644343_0_0_0,
	&GenInst_RuntimeObject_0_0_0_Single_t2594644343_0_0_0,
	&GenInst_List_1_t2478570738_0_0_0,
	&GenInst_List_1_t1273808215_0_0_0,
	&GenInst_List_1_t1735618304_0_0_0,
	&GenInst_List_1_t4206492726_0_0_0,
	&GenInst_List_1_t2938331597_0_0_0,
	&GenInst_List_1_t3696562166_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_String_t_0_0_0_RuntimeObject_0_0_0_KeyValuePair_2_t2865959938_0_0_0,
	&GenInst_FieldWithTarget_t2008555883_0_0_0,
	&GenInst_IEnumerable_1_t3472824768_gp_0_0_0_0,
	&GenInst_Array_InternalArray__IEnumerable_GetEnumerator_m544686167_gp_0_0_0_0,
	&GenInst_Array_Sort_m375360748_gp_0_0_0_0_Array_Sort_m375360748_gp_0_0_0_0,
	&GenInst_Array_Sort_m3222092194_gp_0_0_0_0_Array_Sort_m3222092194_gp_1_0_0_0,
	&GenInst_Array_Sort_m2933720515_gp_0_0_0_0,
	&GenInst_Array_Sort_m2933720515_gp_0_0_0_0_Array_Sort_m2933720515_gp_0_0_0_0,
	&GenInst_Array_Sort_m1007327534_gp_0_0_0_0,
	&GenInst_Array_Sort_m1007327534_gp_0_0_0_0_Array_Sort_m1007327534_gp_1_0_0_0,
	&GenInst_Array_Sort_m2280519164_gp_0_0_0_0_Array_Sort_m2280519164_gp_0_0_0_0,
	&GenInst_Array_Sort_m3079444734_gp_0_0_0_0_Array_Sort_m3079444734_gp_1_0_0_0,
	&GenInst_Array_Sort_m465496297_gp_0_0_0_0,
	&GenInst_Array_Sort_m465496297_gp_0_0_0_0_Array_Sort_m465496297_gp_0_0_0_0,
	&GenInst_Array_Sort_m703600137_gp_0_0_0_0,
	&GenInst_Array_Sort_m703600137_gp_1_0_0_0,
	&GenInst_Array_Sort_m703600137_gp_0_0_0_0_Array_Sort_m703600137_gp_1_0_0_0,
	&GenInst_Array_Sort_m884212515_gp_0_0_0_0,
	&GenInst_Array_Sort_m2398395411_gp_0_0_0_0,
	&GenInst_Array_qsort_m3664970149_gp_0_0_0_0,
	&GenInst_Array_qsort_m3664970149_gp_0_0_0_0_Array_qsort_m3664970149_gp_1_0_0_0,
	&GenInst_Array_compare_m2643025574_gp_0_0_0_0,
	&GenInst_Array_qsort_m2860849171_gp_0_0_0_0,
	&GenInst_Array_Resize_m1319191173_gp_0_0_0_0,
	&GenInst_Array_TrueForAll_m3279624529_gp_0_0_0_0,
	&GenInst_Array_ForEach_m3065220158_gp_0_0_0_0,
	&GenInst_Array_ConvertAll_m4162873343_gp_0_0_0_0_Array_ConvertAll_m4162873343_gp_1_0_0_0,
	&GenInst_Array_FindLastIndex_m1231288529_gp_0_0_0_0,
	&GenInst_Array_FindLastIndex_m253241084_gp_0_0_0_0,
	&GenInst_Array_FindLastIndex_m3979318220_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m2771346406_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m1435567717_gp_0_0_0_0,
	&GenInst_Array_FindIndex_m541082306_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m210446113_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m2725795785_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m236397454_gp_0_0_0_0,
	&GenInst_Array_BinarySearch_m670715820_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m1478543517_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m2800774269_gp_0_0_0_0,
	&GenInst_Array_IndexOf_m1657565370_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m3259903814_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m2114823285_gp_0_0_0_0,
	&GenInst_Array_LastIndexOf_m3033490990_gp_0_0_0_0,
	&GenInst_Array_FindAll_m2935868350_gp_0_0_0_0,
	&GenInst_Array_Exists_m2513116021_gp_0_0_0_0,
	&GenInst_Array_AsReadOnly_m1269368112_gp_0_0_0_0,
	&GenInst_Array_Find_m3798369552_gp_0_0_0_0,
	&GenInst_Array_FindLast_m451745637_gp_0_0_0_0,
	&GenInst_InternalEnumerator_1_t3198792400_gp_0_0_0_0,
	&GenInst_ArrayReadOnlyList_1_t875796540_gp_0_0_0_0,
	&GenInst_U3CGetEnumeratorU3Ec__Iterator0_t4192919887_gp_0_0_0_0,
	&GenInst_IList_1_t3283297292_gp_0_0_0_0,
	&GenInst_ICollection_1_t3247531716_gp_0_0_0_0,
	&GenInst_Nullable_1_t3469261872_gp_0_0_0_0,
	&GenInst_Comparer_1_t2365096000_gp_0_0_0_0,
	&GenInst_DefaultComparer_t325514881_gp_0_0_0_0,
	&GenInst_GenericComparer_1_t1985017584_gp_0_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t373669827_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_CopyTo_m195049171_gp_0_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0,
	&GenInst_Dictionary_2_Do_ICollectionCopyTo_m2557603219_gp_0_0_0_0_RuntimeObject_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_ShimEnumerator_t3580966704_gp_0_0_0_0_ShimEnumerator_t3580966704_gp_1_0_0_0,
	&GenInst_Enumerator_t3554107356_gp_0_0_0_0_Enumerator_t3554107356_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t4151003239_0_0_0,
	&GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0,
	&GenInst_KeyCollection_t3609397419_gp_0_0_0_0,
	&GenInst_Enumerator_t1298455868_gp_0_0_0_0_Enumerator_t1298455868_gp_1_0_0_0,
	&GenInst_Enumerator_t1298455868_gp_0_0_0_0,
	&GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_1_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0,
	&GenInst_KeyCollection_t3609397419_gp_0_0_0_0_KeyCollection_t3609397419_gp_0_0_0_0,
	&GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0,
	&GenInst_ValueCollection_t59155699_gp_1_0_0_0,
	&GenInst_Enumerator_t3190540399_gp_0_0_0_0_Enumerator_t3190540399_gp_1_0_0_0,
	&GenInst_Enumerator_t3190540399_gp_1_0_0_0,
	&GenInst_ValueCollection_t59155699_gp_0_0_0_0_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0,
	&GenInst_ValueCollection_t59155699_gp_1_0_0_0_ValueCollection_t59155699_gp_1_0_0_0,
	&GenInst_DictionaryEntry_t299448291_0_0_0_DictionaryEntry_t299448291_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_0_0_0_0_Dictionary_2_t2809050045_gp_1_0_0_0_KeyValuePair_2_t373669827_0_0_0,
	&GenInst_KeyValuePair_2_t373669827_0_0_0_KeyValuePair_2_t373669827_0_0_0,
	&GenInst_Dictionary_2_t2809050045_gp_1_0_0_0,
	&GenInst_EqualityComparer_1_t1605754411_gp_0_0_0_0,
	&GenInst_DefaultComparer_t790800357_gp_0_0_0_0,
	&GenInst_GenericEqualityComparer_1_t692778042_gp_0_0_0_0,
	&GenInst_KeyValuePair_2_t2431883363_0_0_0,
	&GenInst_IDictionary_2_t4171839189_gp_0_0_0_0_IDictionary_2_t4171839189_gp_1_0_0_0,
	&GenInst_KeyValuePair_2_t917785449_gp_0_0_0_0_KeyValuePair_2_t917785449_gp_1_0_0_0,
	&GenInst_List_1_t1768017692_gp_0_0_0_0,
	&GenInst_Enumerator_t924438735_gp_0_0_0_0,
	&GenInst_Collection_1_t3943914114_gp_0_0_0_0,
	&GenInst_ReadOnlyCollection_1_t3380407612_gp_0_0_0_0,
	&GenInst_MonoProperty_GetterAdapterFrame_m2051008860_gp_0_0_0_0_MonoProperty_GetterAdapterFrame_m2051008860_gp_1_0_0_0,
	&GenInst_MonoProperty_StaticGetterAdapterFrame_m917588249_gp_0_0_0_0,
	&GenInst_ArraySegment_1_t1939258092_gp_0_0_0_0,
	&GenInst_Queue_1_t1750955003_gp_0_0_0_0,
	&GenInst_Enumerator_t2644889458_gp_0_0_0_0,
	&GenInst_Stack_1_t3976444548_gp_0_0_0_0,
	&GenInst_Enumerator_t3983460471_gp_0_0_0_0,
	&GenInst_HashSet_1_t182226283_gp_0_0_0_0,
	&GenInst_Enumerator_t2669265363_gp_0_0_0_0,
	&GenInst_PrimeHelper_t4001087760_gp_0_0_0_0,
	&GenInst_Enumerable_Any_m3044489537_gp_0_0_0_0,
	&GenInst_Enumerable_Where_m509811445_gp_0_0_0_0,
	&GenInst_Enumerable_Where_m509811445_gp_0_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0,
	&GenInst_Enumerable_CreateWhereIterator_m909986173_gp_0_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0,
	&GenInst_U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2658276713_gp_0_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_Component_GetComponentInChildren_m1658374531_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m2409095013_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInChildren_m1003519990_gp_0_0_0_0,
	&GenInst_Component_GetComponentsInParent_m2393957797_gp_0_0_0_0,
	&GenInst_Component_GetComponents_m1510131101_gp_0_0_0_0,
	&GenInst_Component_GetComponents_m2882340512_gp_0_0_0_0,
	&GenInst_GameObject_GetComponentInChildren_m3537761720_gp_0_0_0_0,
	&GenInst_GameObject_GetComponents_m318279657_gp_0_0_0_0,
	&GenInst_GameObject_GetComponentsInChildren_m3606144874_gp_0_0_0_0,
	&GenInst_GameObject_GetComponentsInParent_m2573141489_gp_0_0_0_0,
	&GenInst_Mesh_GetAllocArrayFromChannel_m1940325218_gp_0_0_0_0,
	&GenInst_Mesh_SafeLength_m1544801684_gp_0_0_0_0,
	&GenInst_Mesh_SetListForChannel_m131533298_gp_0_0_0_0,
	&GenInst_Mesh_SetListForChannel_m326208384_gp_0_0_0_0,
	&GenInst_Mesh_SetUvsImpl_m1911943115_gp_0_0_0_0,
	&GenInst_InvokableCall_1_t3177580188_gp_0_0_0_0,
	&GenInst_UnityAction_1_t1512030109_0_0_0,
	&GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0_InvokableCall_2_t4177718962_gp_1_0_0_0,
	&GenInst_InvokableCall_2_t4177718962_gp_0_0_0_0,
	&GenInst_InvokableCall_2_t4177718962_gp_1_0_0_0,
	&GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0_InvokableCall_3_t1109707351_gp_1_0_0_0_InvokableCall_3_t1109707351_gp_2_0_0_0,
	&GenInst_InvokableCall_3_t1109707351_gp_0_0_0_0,
	&GenInst_InvokableCall_3_t1109707351_gp_1_0_0_0,
	&GenInst_InvokableCall_3_t1109707351_gp_2_0_0_0,
	&GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0_InvokableCall_4_t2839234570_gp_1_0_0_0_InvokableCall_4_t2839234570_gp_2_0_0_0_InvokableCall_4_t2839234570_gp_3_0_0_0,
	&GenInst_InvokableCall_4_t2839234570_gp_0_0_0_0,
	&GenInst_InvokableCall_4_t2839234570_gp_1_0_0_0,
	&GenInst_InvokableCall_4_t2839234570_gp_2_0_0_0,
	&GenInst_InvokableCall_4_t2839234570_gp_3_0_0_0,
	&GenInst_CachedInvokableCall_1_t1763259375_gp_0_0_0_0,
	&GenInst_UnityEvent_1_t2513023335_gp_0_0_0_0,
	&GenInst_UnityEvent_2_t3919372254_gp_0_0_0_0_UnityEvent_2_t3919372254_gp_1_0_0_0,
	&GenInst_UnityEvent_3_t2232704357_gp_0_0_0_0_UnityEvent_3_t2232704357_gp_1_0_0_0_UnityEvent_3_t2232704357_gp_2_0_0_0,
	&GenInst_UnityEvent_4_t4058827200_gp_0_0_0_0_UnityEvent_4_t4058827200_gp_1_0_0_0_UnityEvent_4_t4058827200_gp_2_0_0_0_UnityEvent_4_t4058827200_gp_3_0_0_0,
	&GenInst_ExecuteEvents_Execute_m3971585966_gp_0_0_0_0,
	&GenInst_ExecuteEvents_ExecuteHierarchy_m2307797766_gp_0_0_0_0,
	&GenInst_ExecuteEvents_GetEventList_m3902255235_gp_0_0_0_0,
	&GenInst_ExecuteEvents_CanHandleEvent_m661080578_gp_0_0_0_0,
	&GenInst_ExecuteEvents_GetEventHandler_m2040237166_gp_0_0_0_0,
	&GenInst_TweenRunner_1_t2568776171_gp_0_0_0_0,
	&GenInst_Dropdown_GetOrAddComponent_m3363996183_gp_0_0_0_0,
	&GenInst_SetPropertyUtility_SetStruct_m3324360834_gp_0_0_0_0,
	&GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0,
	&GenInst_IndexedSet_1_t2472654987_gp_0_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_ListPool_1_t3291784397_gp_0_0_0_0,
	&GenInst_List_1_t3931617359_0_0_0,
	&GenInst_ObjectPool_1_t1412409661_gp_0_0_0_0,
	&GenInst_DefaultExecutionOrder_t533427438_0_0_0,
	&GenInst_PlayerConnection_t3376987642_0_0_0,
	&GenInst_GUILayer_t368266309_0_0_0,
	&GenInst_AxisEventData_t2495346144_0_0_0,
	&GenInst_SpriteRenderer_t924888996_0_0_0,
	&GenInst_Image_t325497262_0_0_0,
	&GenInst_Button_t1951982026_0_0_0,
	&GenInst_RawImage_t2311903931_0_0_0,
	&GenInst_Slider_t599575794_0_0_0,
	&GenInst_Scrollbar_t2833447691_0_0_0,
	&GenInst_InputField_t1009335159_0_0_0,
	&GenInst_ScrollRect_t1909087471_0_0_0,
	&GenInst_Dropdown_t532982771_0_0_0,
	&GenInst_GraphicRaycaster_t3206056917_0_0_0,
	&GenInst_CanvasRenderer_t3614328869_0_0_0,
	&GenInst_Corner_t2478443190_0_0_0,
	&GenInst_Axis_t3769150349_0_0_0,
	&GenInst_Constraint_t2227253834_0_0_0,
	&GenInst_SubmitEvent_t984659408_0_0_0,
	&GenInst_OnChangeEvent_t425979699_0_0_0,
	&GenInst_OnValidateInput_t3315013029_0_0_0,
	&GenInst_LayoutElement_t530979270_0_0_0,
	&GenInst_RectOffset_t2531911544_0_0_0,
	&GenInst_TextAnchor_t1172919424_0_0_0,
	&GenInst_AnimationTriggers_t1273266827_0_0_0,
	&GenInst_Animator_t4196124252_0_0_0,
	&GenInst_KeyValuePair_2_t3005528154_0_0_0_KeyValuePair_2_t3005528154_0_0_0,
	&GenInst_Int32_t2946131084_0_0_0_Int32_t2946131084_0_0_0,
	&GenInst_CustomAttributeNamedArgument_t3066689011_0_0_0_CustomAttributeNamedArgument_t3066689011_0_0_0,
	&GenInst_CustomAttributeTypedArgument_t437198719_0_0_0_CustomAttributeTypedArgument_t437198719_0_0_0,
	&GenInst_Color32_t1281607702_0_0_0_Color32_t1281607702_0_0_0,
	&GenInst_RaycastResult_t3064114207_0_0_0_RaycastResult_t3064114207_0_0_0,
	&GenInst_UICharInfo_t498913270_0_0_0_UICharInfo_t498913270_0_0_0,
	&GenInst_UILineInfo_t2500817891_0_0_0_UILineInfo_t2500817891_0_0_0,
	&GenInst_UIVertex_t3704361653_0_0_0_UIVertex_t3704361653_0_0_0,
	&GenInst_Vector2_t1743417791_0_0_0_Vector2_t1743417791_0_0_0,
	&GenInst_Vector3_t2486370225_0_0_0_Vector3_t2486370225_0_0_0,
	&GenInst_Vector4_t4214292213_0_0_0_Vector4_t4214292213_0_0_0,
	&GenInst_KeyValuePair_2_t501915592_0_0_0_KeyValuePair_2_t501915592_0_0_0,
	&GenInst_KeyValuePair_2_t501915592_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t573483709_0_0_0_KeyValuePair_2_t573483709_0_0_0,
	&GenInst_KeyValuePair_2_t573483709_0_0_0_RuntimeObject_0_0_0,
	&GenInst_IntPtr_t_0_0_0_IntPtr_t_0_0_0,
	&GenInst_Boolean_t2724601657_0_0_0_Boolean_t2724601657_0_0_0,
	&GenInst_KeyValuePair_2_t2928695729_0_0_0_KeyValuePair_2_t2928695729_0_0_0,
	&GenInst_KeyValuePair_2_t2928695729_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t3150225156_0_0_0_KeyValuePair_2_t3150225156_0_0_0,
	&GenInst_KeyValuePair_2_t3150225156_0_0_0_RuntimeObject_0_0_0,
	&GenInst_KeyValuePair_2_t3005528154_0_0_0_RuntimeObject_0_0_0,
};
